<?php
/*
Plugin Name: Usefooma (formerly pulsepoint)
Plugin URI:  https://usefooma.site
Description: Bills payment plugin for Data, Airtime, Cable TV, Electricity, and more — built for WordPress.
Version: 2.1.0
Author: faav11_
Author URI: https://usefooma.site/faav11_
Text Domain: pulsepoint
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/* =========================
   🔥 TIMEZONE FIX (SAFE)
   ========================= */

add_action('init', function() {

    // Fix PHP timezone safely
    if (function_exists('date_default_timezone_set')) {
        date_default_timezone_set('Africa/Lagos');
    }

    // Fix MySQL timezone (shared hosting fix)
    global $wpdb;
    if (!empty($wpdb)) {
        $wpdb->query("SET time_zone = '+01:00'");
    }

});

/**
 * Add “Settings” link next to Activate/Deactivate
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=pulsepoint-customization') . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
});

/**
 * Add custom meta links
 */
add_filter('plugin_row_meta', function ($links, $file) {
    if (plugin_basename(__FILE__) === $file) {
        $custom_links = [
            '<a href="https://www.usefooma.site/developer" target="_blank">Developer</a>',
            '<a href="https://www.usefooma.site/docs" target="_blank">Docs</a>',
        ];
        $links = array_merge($links, $custom_links);
    }
    return $links;
}, 10, 2);

// -----------------------------
// Load all plugin files
// -----------------------------
// Define plugin constants

require_once plugin_dir_path(__FILE__) . 'loader.php';

// Activation
register_activation_hook(__FILE__, function() {  
    if (function_exists('pulsepoint_add_rewrite')) {
        pulsepoint_add_rewrite();  
    }
    flush_rewrite_rules();  
});

// Deactivation
register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules();
});

// Auto-update
new Pulsepoint_Updater(
    __FILE__,
    'https://favouradjenuvurhe.github.io/Usefooma/api/file.json',
    '2.1.0'
);

/* Plugin loaded */
add_action('plugins_loaded', function() {
    if (class_exists('WC_Payment_Gateway')) {
        if (file_exists(PULSEPOINT_DIR . 'includes/woo-gateway.php')) {
            require_once PULSEPOINT_DIR . 'includes/woo-gateway.php';
        }
    }
});

add_action('rest_api_init', function () {

    $route = [
        'methods' => ['GET', 'POST'],
        'callback' => function (WP_REST_Request $request) {

            // Make request available to endpoint files
            if (!defined('USEFOOMA_API_PATH')) {
                define('USEFOOMA_API_PATH', trim($request->get_param('path'), '/'));
            }

            if (!defined('USEFOOMA_API_REQUEST')) {
                define('USEFOOMA_API_REQUEST', $request);
            }

            // Load API dispatcher
            require plugin_dir_path(__FILE__) . 'wp-admin/loader.php';
        },
        'permission_callback' => '__return_true',
    ];

    // Legacy
    register_rest_route('pulsepoint/v1', '/cron', [
        'methods' => ['GET', 'POST'],
        'callback' => function () {
            require plugin_dir_path(__FILE__) . 'cron/pulsepoint-cron.php';
        },
        'permission_callback' => '__return_true',
    ]);

    // Catch all API routes
    register_rest_route('usefooma/v1', '/api/(?P<path>.*)', $route);

    // Optional: /api
    register_rest_route('usefooma/v1', '/api', [
        'methods' => ['GET', 'POST'],
        'callback' => function (WP_REST_Request $request) {

            if (!defined('USEFOOMA_API_PATH')) {
                define('USEFOOMA_API_PATH', '');
            }

            if (!defined('USEFOOMA_API_REQUEST')) {
                define('USEFOOMA_API_REQUEST', $request);
            }

            require plugin_dir_path(__FILE__) . 'wp-admin/loader.php';
        },
        'permission_callback' => '__return_true',
    ]);

});



register_activation_hook(__FILE__, 'pulsepoint_safe_activation');

function pulsepoint_safe_activation() {
    ob_start(); // Capture any accidental output

    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset = $wpdb->get_charset_collate();
    $base_prefix = $wpdb->prefix . 'pulsepoint_';


    // NOTE: dbDelta expects correctly formatted CREATE TABLE statements with keys in place.
    // We'll use backticks around table names because of the hyphen in PS-NG.

    // USERS
    $sql_users = "CREATE TABLE `{$base_prefix}users` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `zid` VARCHAR(200) DEFAULT NULL,
    `customerId` VARCHAR(100) DEFAULT NULL,   
    `cardid` VARCHAR(100) DEFAULT NULL,
    `uniqueid` VARCHAR(200) DEFAULT NULL,      
    `firstname` VARCHAR(100) NOT NULL,
    `lastname` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(30) DEFAULT NULL,
    `email` VARCHAR(200) NOT NULL,
    `wallet` DECIMAL(14,2) DEFAULT 0.00,
    `dollar` DECIMAL(14,2) DEFAULT 0.00,
    `referral_balance` DECIMAL(14,2) DEFAULT 0.00,
    `referby` BIGINT UNSIGNED DEFAULT NULL,
    `token` VARCHAR(255) DEFAULT NULL,
    `reset_token` VARCHAR(255) DEFAULT NULL,
    `passcode` VARCHAR(4) DEFAULT NULL,
    `password` VARCHAR(255) NOT NULL,
    `twofa_secret` VARCHAR(255) NOT NULL,
    `twofa_enabled` INT(1) DEFAULT 0,
    `security_code` VARCHAR(255) DEFAULT NULL,
    `security_question1` VARCHAR(255) DEFAULT NULL,
    `security_question2` VARCHAR(255) DEFAULT NULL,
    `security_question3` VARCHAR(255) DEFAULT NULL,
    `account_limit` DECIMAL(14,2) DEFAULT 0.00,
    `auto_login` TINYINT(1) DEFAULT 0,
    `alert` TINYINT(1) DEFAULT 1,
    `close_account` TINYINT(1) DEFAULT 0,
    `gender` ENUM('Male','Female','Other') DEFAULT NULL,
    `dob` DATE DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `account_type` ENUM('Customer','Agent','API') DEFAULT 'Customer',
    `status` TINYINT(1) DEFAULT 1,
    `status_email` TINYINT(1) DEFAULT 1,
    `statuskyc` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `email_unique` (`email`),
    FOREIGN KEY (`referby`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE SET NULL
) {$charset};";

 $sql_referrals = "CREATE TABLE `{$base_prefix}referrals` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `referrer_id` BIGINT UNSIGNED NOT NULL,
    `referee_id` BIGINT UNSIGNED NOT NULL,
    `completed` TINYINT(1) DEFAULT 0,
    `bonus_given` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`referrer_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`referee_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_referral` (`referrer_id`,`referee_id`)
) {$charset};";

// TRANSACTIONS
$sql_trnx = "CREATE TABLE `{$base_prefix}trnx` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `request_id` VARCHAR(64) DEFAULT NULL,
    `details` TEXT,
    `value` TEXT,
    `recipient` VARCHAR(255) DEFAULT NULL,
    `amount` DECIMAL(14,2) DEFAULT 0.00,
    `profit_amount` DECIMAL(14,2) DEFAULT 0.00,
    `reference` VARCHAR(255) DEFAULT NULL,
    `payment` ENUM('wallet','api','app') DEFAULT 'wallet',
    `category` ENUM('airtime','data','cable','bill','education','virtual-account','funding','transfer','cards','convert-naira','conversion','recharge','crypto','others') DEFAULT 'others',
    `status` ENUM('pending','success','failed') DEFAULT 'pending',
    `type` ENUM('debit','credit') DEFAULT 'debit',
    `gateway_response` TEXT,
    `session` VARCHAR(255) DEFAULT NULL,
    `description` TEXT,
    `date` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_pp_request_id` (`request_id`),
    UNIQUE KEY `idx_pp_reference` (`reference`),
    KEY `user_id_idx` (`user_id`)
) {$charset};";

        // AIRTIME SCHEDULING JOBS
    $sql_airtime_jobs = "CREATE TABLE `{$base_prefix}airtime_jobs` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
       `token` VARCHAR(255) DEFAULT NULL,
       `network` VARCHAR(10) DEFAULT NULL,
       `amount` DECIMAL(14,2) DEFAULT 0.00,
       `mobile_number` VARCHAR(20) DEFAULT NULL,
       `ported_number` TINYINT(1) DEFAULT 0,
       `airtime_type` VARCHAR(20) DEFAULT 'VTU',
       `schedule_type` ENUM('one_time','recurring') NOT NULL,
       `run_at` DATETIME NOT NULL,
       `interval_minutes` INT DEFAULT NULL,
       `last_run` DATETIME DEFAULT NULL,
       `next_run` DATETIME DEFAULT NULL,
       `is_active` TINYINT(1) DEFAULT 1,
       `last_response` TEXT,
       `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) {$charset};";
    
       // AIRTIME TO CASH
    $sql_airtime_to_cash = "CREATE TABLE `{$base_prefix}airtime_to_cash` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `network` VARCHAR(50) DEFAULT NULL,
        `receiver_number` VARCHAR(20) DEFAULT NULL,
        `receiver_name` VARCHAR(150) DEFAULT NULL,
        `rate` DECIMAL(14,2) DEFAULT 0.00,
        `min_amount` DECIMAL(14,2) DEFAULT 0.00,
        `max_amount` DECIMAL(14,2) DEFAULT 0.00,
        `status` VARCHAR(20) DEFAULT 'active',
        `instruction` TEXT,
        `provider` VARCHAR(100) DEFAULT NULL,
    PRIMARY KEY (`id`)
    ) {$charset};";
    
      // AIRTIME TO CASH TRANSACTIONS
    $sql_airtime_to_cash_transactions = "CREATE TABLE `{$base_prefix}airtime_to_cash_transactions` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `reference` VARCHAR(100) DEFAULT NULL,
        `user_id` BIGINT UNSIGNED NOT NULL,
        `network` VARCHAR(50) DEFAULT NULL,
        `sender_number` VARCHAR(20) DEFAULT NULL,
        `receiver_number` VARCHAR(20) DEFAULT NULL,
        `amount` DECIMAL(14,2) DEFAULT 0.00,
        `rate` DECIMAL(14,2) DEFAULT 0.00,
        `payable` DECIMAL(14,2) DEFAULT 0.00,
        `proof` TEXT,
        `status` VARCHAR(30) DEFAULT 'pending',
        `remark` TEXT,
        `created` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       PRIMARY KEY (`id`)
    ) {$charset};";

    // DATA PLANS
    $sql_data = "CREATE TABLE `{$base_prefix}data` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `plan` VARCHAR(255) DEFAULT NULL,
        `details` TEXT,
        `value` TEXT,
        `network` VARCHAR(50) DEFAULT NULL,
        `amount` DECIMAL(14,2) DEFAULT 0.00,
        `purchase` DECIMAL(14,2) DEFAULT 0.00,
        `cashback` DECIMAL(14,2) DEFAULT 0.00,
        `apiamount` DECIMAL(14,2) DEFAULT 0.00,
        `type` VARCHAR(50) DEFAULT NULL,
        `provider` VARCHAR(100) DEFAULT NULL,
        `status` VARCHAR(20) DEFAULT 'active',
        PRIMARY KEY (`id`)
    ) {$charset};";
    
          // DATA SCHEDULING JOBS
    $sql_data_jobs = "CREATE TABLE `{$base_prefix}data_jobs` (
       `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
       `token` VARCHAR(255) DEFAULT NULL,
       `network` VARCHAR(10) DEFAULT NULL,
       `plan` VARCHAR(50) DEFAULT NULL,
       `mobile_number` VARCHAR(20) DEFAULT NULL,
       `ported_number` TINYINT(1) DEFAULT 0,
       `schedule_type` ENUM('one_time','recurring') NOT NULL,
       `run_at` DATETIME NOT NULL,
       `interval_minutes` INT DEFAULT NULL,
       `last_run` DATETIME DEFAULT NULL,
       `next_run` DATETIME DEFAULT NULL,
       `is_active` TINYINT(1) DEFAULT 1,
       `last_response` TEXT,
       `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) {$charset};";

    // CABLE PLANS
    $sql_cable = "CREATE TABLE `{$base_prefix}cable` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `plan` VARCHAR(255) DEFAULT NULL,
        `details` TEXT,
        `type` ENUM('DSTV','GOTV','STARTIMES') DEFAULT 'DSTV',
        `amount` DECIMAL(14,2) DEFAULT 0.00,
        `cashback` DECIMAL(14,2) DEFAULT 0.00,
        `apiamount` DECIMAL(14,2) DEFAULT 0.00,
        `provider` VARCHAR(100) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) {$charset};";

    // BILL PLANS
    $sql_bill = "CREATE TABLE `{$base_prefix}bill` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `disco` VARCHAR(255) DEFAULT NULL,
        `plan` VARCHAR(255) DEFAULT NULL,
        `details` TEXT,
        `fee` DECIMAL(14,2) DEFAULT 0.00,
        `fee_api` DECIMAL(14,2) DEFAULT 0.00,
        `provider` VARCHAR(100) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) {$charset};";
    
    // BETTING SERVICES
     $sql_betting = "CREATE TABLE `{$base_prefix}betting` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
         `serviceid` VARCHAR(100) DEFAULT NULL,
         `biller` VARCHAR(150) DEFAULT NULL,
         `cashback` DECIMAL(14,2) DEFAULT 0.00,
         `fee` DECIMAL(14,2) DEFAULT 0.00,
         `fee_api` DECIMAL(14,2) DEFAULT 0.00,
         `provider` VARCHAR(100) DEFAULT NULL,
         PRIMARY KEY (`id`)
      ) {$charset};";
        
        // EDUCATION SERVICES
      $sql_education = "CREATE TABLE `{$base_prefix}education` (
         `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
         `serviceid` VARCHAR(100) NOT NULL,
         `servicename` VARCHAR(150) DEFAULT NULL,
         `cashback` DECIMAL(14,2) DEFAULT 0.00,
         `price` DECIMAL(14,2) DEFAULT 0.00,
         `price_api` DECIMAL(14,2) DEFAULT 0.00,
         `provider` VARCHAR(100) DEFAULT NULL,
         PRIMARY KEY (`id`),
         UNIQUE KEY `unique_serviceid` (`serviceid`)
      ) {$charset};";
        
    // ACCOUNTS (user bank accounts / virtual accounts)
    $sql_account = "CREATE TABLE `{$base_prefix}account` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT UNSIGNED NOT NULL,
        `bank` VARCHAR(150) DEFAULT NULL,
        `name` VARCHAR(200) DEFAULT NULL,
        `number` VARCHAR(100) DEFAULT NULL,
        `provider` VARCHAR(100) DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `user_idx` (`user_id`)
    ) {$charset};";
      
      // WALLETS (user crypto wallets / USDT addresses)
$sql_wallet = "CREATE TABLE {$base_prefix}wallets (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    network VARCHAR(50) DEFAULT 'USDT',
    address VARCHAR(255) DEFAULT NULL,
    balance DECIMAL(20,8) DEFAULT 0.00000000,
    status TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_idx (user_id)
) {$charset};";
          
    // PROVIDERS (APIs, vendors, etc.)
    $sql_provider = "CREATE TABLE `{$base_prefix}provider` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(150) NOT NULL,
        `token` TEXT,
        `value` TEXT,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `provider_name_unique` (`name`)
    ) {$charset};";
    
    $sql_savings_pocket = "CREATE TABLE `{$base_prefix}savings_pocket` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(200) NOT NULL,                  -- Name of saving pocket e.g. 'Car Savings', 'Rent Plan'
    `target_amount` DECIMAL(14,2) NOT NULL,         -- Target saving goal amount
    `current_amount` DECIMAL(14,2) DEFAULT 0.00,    -- Amount currently saved
    `frequency` ENUM('daily','weekly','monthly','manual') DEFAULT 'manual',  -- Saving frequency type
    `auto_save` TINYINT(1) DEFAULT 0,               -- 1=Auto Save Enabled, 0=Manual
    `amount_per_cycle` DECIMAL(14,2) DEFAULT 0.00,  -- Amount to save per frequency cycle
    `start_date` DATE DEFAULT NULL,                 -- When the saving starts
    `maturity_date` DATE DEFAULT NULL,              -- When user plans to withdraw (target date)
    `status` ENUM('active','completed','paused','cancelled') DEFAULT 'active',
    `withdrawable` TINYINT(1) DEFAULT 0,            -- 1=User can withdraw anytime, 0=Locked until maturity
    `interest_rate` DECIMAL(5,2) DEFAULT 0.00,      -- Optional interest or bonus rate (%)
    `locked` TINYINT(1) DEFAULT 0,                  -- 1=Locked until maturity date
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE
) {$charset};";

$sql_savings_transactions = "CREATE TABLE `{$base_prefix}savings_transactions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `pocket_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `type` ENUM('deposit','withdrawal','interest') NOT NULL,
    `amount` DECIMAL(14,2) NOT NULL,
    `reference` VARCHAR(255) DEFAULT NULL,
    `method` ENUM('wallet','card','transfer','auto-save') DEFAULT 'wallet',
    `status` ENUM('pending','success','failed') DEFAULT 'success',
    `note` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`pocket_id`) REFERENCES `{$base_prefix}savings_pocket`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE
) {$charset};";

     // 1. Giftcard Settings
$sql_giftcard_settings = "CREATE TABLE `{$base_prefix}giftcard_settings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `category` VARCHAR(100) NOT NULL,                  -- e.g., 'Amazon', 'iTunes'
    `sub_category` VARCHAR(100) NOT NULL,                  -- e.g., 'Amazon Uk', 'iTunes Uk'
    `image_url` VARCHAR(500) NOT NULL,
    `type` ENUM('digital','physical') DEFAULT 'digital',
    `rate` DECIMAL(14,2) NOT NULL,                     -- How much admin pays per card
    `min_amount` DECIMAL(14,2) DEFAULT 0.00,
    `max_amount` DECIMAL(14,2) DEFAULT 0.00,
    `status` ENUM('active','inactive') DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) {$charset};";

// 2. User Giftcard Listings
$sql_giftcard_listings = "CREATE TABLE `{$base_prefix}giftcard_listings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `giftcard_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(14,2) NOT NULL,                  -- Face value of the card
    `selling_price` DECIMAL(14,2) NOT NULL,           -- Admin pays this price
    `type` ENUM('digital','physical') NOT NULL,
    `digital_code` VARCHAR(255) DEFAULT NULL,         -- For digital cards
    `physical_image` VARCHAR(255) DEFAULT NULL,       -- For physical cards (image path)
    `status` ENUM('pending','approved','rejected','sold') DEFAULT 'pending',
    `note` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`giftcard_id`) REFERENCES `{$base_prefix}giftcard_settings`(`id`) ON DELETE CASCADE
) {$charset};";

// 3. Giftcard Transactions
$sql_giftcard_transactions = "CREATE TABLE `{$base_prefix}giftcard_transactions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `listing_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,               -- Seller
    `amount` DECIMAL(14,2) NOT NULL,                 -- Face value
    `selling_price` DECIMAL(14,2) NOT NULL,          -- Paid to user
    `fee` DECIMAL(14,2) DEFAULT 0.00,               -- Optional platform fee
    `status` ENUM('pending','completed','failed') DEFAULT 'pending',
    `payment_method` ENUM('wallet','bank','manual') DEFAULT 'wallet',
    `reference` VARCHAR(255) DEFAULT NULL,
    `note` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`listing_id`) REFERENCES `{$base_prefix}giftcard_listings`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE
) {$charset};";

// 4. Giftcard Sales
$sql_giftcard_sales = "CREATE TABLE `{$base_prefix}giftcard_sales` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `transaction_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,             -- Seller
    `giftcard_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(14,2) NOT NULL,
    `selling_price` DECIMAL(14,2) NOT NULL,
    `fee` DECIMAL(14,2) DEFAULT 0.00,
    `status` ENUM('completed','refunded') DEFAULT 'completed',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`transaction_id`) REFERENCES `{$base_prefix}giftcard_transactions`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`giftcard_id`) REFERENCES `{$base_prefix}giftcard_settings`(`id`) ON DELETE CASCADE
) {$charset};";

// 5. Giftcard Rate History
$sql_giftcard_rate_history = "CREATE TABLE `{$base_prefix}giftcard_rate_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `giftcard_id` BIGINT UNSIGNED NOT NULL,
    `old_rate` DECIMAL(14,2) NOT NULL,
    `new_rate` DECIMAL(14,2) NOT NULL,
    `changed_by` BIGINT UNSIGNED DEFAULT NULL,        -- Admin ID
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`giftcard_id`) REFERENCES `{$base_prefix}giftcard_settings`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`changed_by`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE SET NULL
) {$charset};";

// Virtual Cards Table
$sql_virtual_cards = "CREATE TABLE `{$base_prefix}virtual_cards` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `card_holder_name` VARCHAR(255) DEFAULT NULL,
    `card_name` VARCHAR(255) DEFAULT NULL,
    `card_id` VARCHAR(100) DEFAULT NULL,
    `card_created_date` DATE DEFAULT NULL,
    `card_type` VARCHAR(50) DEFAULT NULL,
    `card_brand` VARCHAR(50) DEFAULT NULL,
    `card_user_id` VARCHAR(100) DEFAULT NULL,
    `reference` VARCHAR(100) DEFAULT NULL,
    `card_status` VARCHAR(50) DEFAULT 'inactive',
    `card_number` VARCHAR(20) DEFAULT NULL,
    `last4` VARCHAR(4) DEFAULT NULL,
    `cvv` VARCHAR(4) DEFAULT NULL,
    `expiry` VARCHAR(10) DEFAULT NULL,
    `customer_email` VARCHAR(255) DEFAULT NULL,
    `customer_id` VARCHAR(100) DEFAULT NULL,
    `balance` DECIMAL(12,2) DEFAULT 0.00,
    `billing_address_city` VARCHAR(100) DEFAULT 'Miami',
    `billing_address_street` VARCHAR(255) DEFAULT '3401 N. Miami, Ave. Ste 230',
    `billing_address_country` VARCHAR(100) DEFAULT 'United States',
    `billing_address_zipcode` VARCHAR(20) DEFAULT '33127',
    `billing_address_country_code` VARCHAR(10) DEFAULT 'US',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `card_id_unique` (`card_id`),
    KEY `user_id` (`user_id`)
) {$wpdb->get_charset_collate()};";

// Virtual Card Transactions Table
$sql_virtualcard_transactions = "CREATE TABLE `{$base_prefix}virtualcard_transactions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `transaction_id` VARCHAR(100) NOT NULL,
    `card_id` VARCHAR(100) NOT NULL,
    `created_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `amount` DECIMAL(12,2) DEFAULT 0.00,
    `cent_amount` BIGINT DEFAULT 0,
    `type` VARCHAR(100) DEFAULT NULL,
    `method` VARCHAR(50) DEFAULT NULL,
    `narrative` VARCHAR(255) DEFAULT NULL,
    `status` VARCHAR(50) DEFAULT NULL,
    `currency` VARCHAR(10) DEFAULT NULL,
    `reference` VARCHAR(100) DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `transaction_id_unique` (`transaction_id`),
    KEY `card_id` (`card_id`)
) {$wpdb->get_charset_collate()};";

// SMM PANEL SERVICES
$sql_socpanel = "CREATE TABLE `{$base_prefix}socpanel` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `service_id` BIGINT UNSIGNED DEFAULT NULL,
    `code` VARCHAR(100) DEFAULT NULL,
    `category` VARCHAR(255) DEFAULT NULL,
    `name` VARCHAR(255) DEFAULT NULL,
    `image` VARCHAR(500) DEFAULT NULL,
    `currency` VARCHAR(10) DEFAULT '₦',
    `rate` DECIMAL(14,6) DEFAULT 0.000000,
    `cost_rate` DECIMAL(14,6) DEFAULT NULL,
    `minimum` BIGINT UNSIGNED DEFAULT 0,
    `maximum` BIGINT UNSIGNED DEFAULT 0,
    `refill` VARCHAR(100) DEFAULT NULL,
    `provider` VARCHAR(100) DEFAULT NULL,
    `status` ENUM('active','inactive') DEFAULT 'active',
    `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `service_id` (`service_id`),
    UNIQUE KEY `code` (`code`),
    KEY `category` (`category`),
    KEY `provider` (`provider`),
    KEY `status` (`status`)
) {$charset};";

// SMM PANEL TRANSACTIONS
$sql_socpanel_transactions = "CREATE TABLE `{$base_prefix}socpanel_transactions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `reference` VARCHAR(100) DEFAULT NULL,
    `user_id` BIGINT UNSIGNED DEFAULT NULL,
    `service_id` BIGINT UNSIGNED DEFAULT NULL,
    `service_code` VARCHAR(100) DEFAULT NULL,
    `provider_order_id` VARCHAR(100) DEFAULT NULL,
    `link` TEXT,
    `quantity` BIGINT UNSIGNED DEFAULT 0,
    `charge` DECIMAL(14,2) DEFAULT 0.00,
    `provider_charge` DECIMAL(14,2) DEFAULT 0.00,
    `start_count` BIGINT DEFAULT NULL,
    `remains` BIGINT DEFAULT NULL,
    `status` ENUM('pending','processing','completed','partial','cancelled','refunded','failed') DEFAULT 'pending',
    `provider` VARCHAR(100) DEFAULT NULL,
    `response` LONGTEXT,
    `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `reference` (`reference`),
    KEY `user_id` (`user_id`),
    KEY `service_id` (`service_id`),
    KEY `provider_order_id` (`provider_order_id`),
    KEY `status` (`status`)
) {$charset};";

// NOTIFICATIONS
$sql_notifications = "CREATE TABLE `{$base_prefix}notifications` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `type` ENUM('info','success','warning','error','system','transaction','promotion') DEFAULT 'info',
    `icon` VARCHAR(100) DEFAULT NULL,
    `status` ENUM('unread','read') DEFAULT 'unread',
    `is_deleted` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id_idx` (`user_id`),
    KEY `status_idx` (`status`),
    KEY `type_idx` (`type`),
    KEY `created_at_idx` (`created_at`)
) {$charset};";

// LOGS TABLE
$sql_logs = "CREATE TABLE `{$base_prefix}logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `event` VARCHAR(100) NOT NULL,
    `meta` TEXT,
    `ip` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME NOT NULL,
    PRIMARY KEY (`id`)
) {$charset};";

$sql_services = "CREATE TABLE `{$base_prefix}services` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `service_key` VARCHAR(100) NOT NULL,
    `service_name` VARCHAR(150) NOT NULL,
    `status` TINYINT(1) DEFAULT 1, -- 1 = enabled, 0 = disabled
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),
    UNIQUE KEY `service_key_unique` (`service_key`)
) {$charset};";

    // SETTINGS (complex VTU & integration settings)
$sql_settings = "CREATE TABLE `{$base_prefix}settings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `opt_key` VARCHAR(255) NOT NULL,
    `opt_value` TEXT,
    `type` VARCHAR(50) DEFAULT 'string',
    `grouping` VARCHAR(100) DEFAULT NULL,
    `autoload` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `opt_key_unique` (`opt_key`)
) {$charset};";

// Run dbDelta for each table
dbDelta($sql_users);
dbDelta($sql_referrals);
dbDelta($sql_trnx);
dbDelta($sql_airtime_jobs);
dbDelta($sql_airtime_to_cash);
dbDelta($sql_airtime_to_cash_transactions);
dbDelta($sql_data);
dbDelta($sql_data_jobs);
dbDelta($sql_cable);
dbDelta($sql_bill);
dbDelta($sql_betting);
dbDelta($sql_education);
dbDelta($sql_account);
dbDelta($sql_wallet);
dbDelta($sql_provider);
dbDelta($sql_savings_pocket);
dbDelta($sql_savings_transactions);
dbDelta($sql_giftcard_settings);
dbDelta($sql_giftcard_listings);
dbDelta($sql_giftcard_transactions);
dbDelta($sql_giftcard_sales);
dbDelta($sql_giftcard_rate_history);
dbDelta($sql_virtual_cards);
dbDelta($sql_virtualcard_transactions);
dbDelta($sql_socpanel);
dbDelta($sql_socpanel_transactions);
dbDelta($sql_notifications);
dbDelta($sql_logs);
dbDelta($sql_services);
dbDelta($sql_settings);

// Insert default complex VTU & integration settings (only if not exists)
$defaults = [
    // 🌐 Platform Info
    'platform_name'     => 'Usefooma',
    'color_hex'         => '#356cf9',
    'phone_number'      => '09064873505',
    'email_number'      => 'favour-amaaavl@outlook.com',
    'referral_amount'   => '50',
    'auth_email'   => '0',

    // 💳 Payvessel Configuration
    'payment_gateway'   => 'type',
    'payment_type'   => 'static',
    'pay_token'         => 'token',
    'pay_secret'        => 'secret',
    'pay_biz'           => 'bus_id',
    'pay_fee'           => 'fundung_fee',
    'pay_bank'           => 'banking_fee',
    'pay_usdt'           => 'cryto_fee',

    // ⚙️ Platform Controls   
    'maintenance_mode'  => '0',

    // 💰 Account & Discount Settings
    'account_limit'     => '5000',
    'agent_discount'    => '5',
    'api_discount'      => '3',

    // 📡 API Configuration for Services
    'airtime_api'       => 'adex',
    'airtime_kyc'       => '1',
    'airtime_token'     => 'token:endpoint.com',
    'cable_api'         => 'endpoint.com',
    'cable_kyc'       => '0',
    'cable_token'       => 'token',
    'bill_api'          => 'endpoint.com',
    'bill_kyc'       => '0',
    'bill_token'        => 'token',
    'bet_api'          => 'endpoint.com',
    'bet_kyc'       => '1',
    'bet_token'        => 'token',
    'edu_api'          => 'endpoint.com',
    'edu_kyc'       => '0',
    'edu_token'        => 'token',   
    'bank_token'       => 'token',
    'bank_kyc'       => '1',
    'bank_transfer'       => 'wallet',
    
    // 💳 Card Fee Configuration
    'card_creation_flat_fee'    => '2.50',   // Flat $2.50 charge
    'card_creation_percent_fee' => '1.5',    // 1.5% additional
    'card_funding_flat_fee'     => '1.90',   // Flat $1.90 charge
    'card_funding_percent_fee'  => '1.9',    // 1.9% additional
    'card_withdraw_flat_fee'  => '1.90',    // Flat $1.90 charge
    'card_withdraw_percent_fee'  => '1.9',    // 1.9% additional

    // 📦 Others
    'logo_url'          => 'url',
    'favicon_url'       => 'url',
    'ads1_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    'ads2_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    'ads3_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    'api_mode'          => 'live',
    'rate_usd'          => '1560',
    'rate_naira'          => '1460',
    'botauth_token'          => 'input',
    'marketplace_vat'          => '1.7',
    'virtualcard_type'          => 'strowallet',
    'stropay_pkey'          => 'public-key',
    'stropay_skey'          => 'secret-key',
    'strowallet_vip_key'          => 'vip-key'
];

// ✅ FIX: only insert defaults if key does NOT exist
foreach ($defaults as $k => $v) {
    $exists = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$base_prefix}settings WHERE opt_key = %s", $k)
    );

    if (!$exists) {
        $wpdb->insert(
            $base_prefix . 'settings',
            [
                'opt_key'    => $k,
                'opt_value'  => maybe_serialize($v),
                'type'       => (is_numeric($v) ? 'number' : 'string'),
                'grouping'   => 'vtu',
                'autoload'   => 0
            ],
            ['%s', '%s', '%s', '%d']
        );
    }
}

$default_services = [
    ['airtime',       'Airtime',       1],
    ['data',          'Data',          1],
    ['electricity',   'Electricity',   1],
    ['flights',       'Flights',       0],
    ['internet',      'Internet',      1],
    ['esim',          'eSIM',          0],
    ['giftcard',      'Giftcard',      0],
    ['transport',     'Transport',     0],
    ['send',          'Transfer',          0],
    ['betting',       'Betting',       0],
    ['cable_tv',      'Cable TV',      1],
    ['virtual_card',  'Virtual Card',  0],
    ['education',     'Education',     1],
    ['saving',        'Saving',        0],
    ['event_ticket',  'Event Ticket',  0],
    ['currency',  'Convert',  0],
    ['bitcoin',  'Send Crypto',  0],
    ['hand-coins',  'Receive Crypto',  0],
    ['shopping-cart',  'Marketplace',  0],
];

// Insert default services ONLY if they don't exist
foreach ($default_services as $srv) {
    $service_key  = $srv[0];
    $service_name = $srv[1];
    $status       = $srv[2];

    // Check if service exists
    $exists = $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$base_prefix}services WHERE service_key = %s", $service_key)
    );

    if (!$exists) {
        $wpdb->insert(
            $base_prefix . 'services',
            [
                'service_key'  => $service_key,
                'service_name' => $service_name,
                'status'       => $status
            ],
            ['%s', '%s', '%d']
        );
    }
}
// Ensure rewrite rules are present (redundant but safe)
if (function_exists('pulsepoint_add_rewrite')) {
    pulsepoint_add_rewrite();
}

flush_rewrite_rules();
}

/* ✅ FIXED: Safe Activation — keeps all data live and ensures tables exist */
register_activation_hook(__FILE__, 'pulsepoint_safe_setup');
function pulsepoint_safe_setup() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $sql_settings = "CREATE TABLE IF NOT EXISTS {$base_prefix}settings (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        opt_key VARCHAR(100) NOT NULL,
        opt_value LONGTEXT,
        type VARCHAR(50) DEFAULT 'string',
        grouping VARCHAR(50) DEFAULT 'vtu',
        autoload TINYINT(1) DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY opt_key (opt_key)
    ) DEFAULT CHARSET=utf8mb4;";
    dbDelta($sql_settings);
}

/* ❌ Old uninstall cleanup removed — DO NOT DELETE TABLES OR DATA */
// register_uninstall_hook(__FILE__, 'pulsepoint_uninstall_cleanup');
// function pulsepoint_uninstall_cleanup() {
//     global $wpdb;
//     $base_prefix = $wpdb->prefix . 'PS-NG_';
//     $tables = [
//         $base_prefix . 'users',
//         $base_prefix . 'trnx',
//         $base_prefix . 'data',
//         $base_prefix . 'cable',
//         $base_prefix . 'bill',
//         $base_prefix . 'account',
//         $base_prefix . 'provider',
//         $base_prefix . 'settings',
//     ];
//     foreach ($tables as $t) {
//         $wpdb->query("DROP TABLE IF EXISTS `{$t}`;");
//     }
// }