<?php
/**
 * Email Verification Handler for Pulsepoint Plugin
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_email_verify', 'pulsepoint_email_verify');
add_action('wp_ajax_pulsepoint_email_verify', 'pulsepoint_email_verify');

function pulsepoint_email_verify() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request']);
    }

    // Start session if not started
    if (!session_id()) session_start();

    // Only logged-in session can verify
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Verification session expired. Please login again.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $code    = sanitize_text_field($_POST['code'] ?? '');

    if (!preg_match('/^\d{6}$/', $code)) {
        wp_send_json(['success' => false, 'message' => 'Invalid code']);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    // Fetch user by ID, OTP code, and status=0 (pending verification)
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id=%d AND security_code=%s AND status_email=0 LIMIT 1",
            $user_id,
            $code
        )
    );

    if (!$user) {
        wp_send_json(['success' => false, 'message' => 'Invalid or expired code']);
    }

    // Update user status to active
    $wpdb->update(
        $table,
        [
            'status_email'        => 1,
            'security_code' => null,
            'updated_at'    => current_time('mysql', 1)
        ],
        ['id' => $user->id]
    );

    // Update session to reflect verified status
    $_SESSION['pulsepoint_user'] = [
        'id'            => $user->id,
        'firstname'     => $user->firstname,
        'lastname'      => $user->lastname,
        'email'         => $user->email,
        'phone'         => $user->phone,
        'wallet'        => $user->wallet,
        'token'         => $user->token ?? '',
        'account_limit' => $user->account_limit ?? 0,
    ];

    // Optional: refresh HTTP-only session cookie
    setcookie(
        'pulsepoint_user_session',
        session_id(),
        time() + 86400,
        '/',
        $_SERVER['SERVER_NAME'],
        is_ssl(),
        true
    );

    wp_send_json([
        'success'  => true,
        'message'  => 'Email verified successfully.',
        'redirect' => site_url('/app/dashboard'),
        'user'     => $_SESSION['pulsepoint_user']
    ]);
}

/**
 * Optional: Resend OTP function
 */
add_action('wp_ajax_nopriv_pulsepoint_resend_otp', 'pulsepoint_resend_otp');
add_action('wp_ajax_pulsepoint_resend_otp', 'pulsepoint_resend_otp');

function pulsepoint_resend_otp() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) session_start();

    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id=%d AND status_email=0 LIMIT 1",
            $user_id
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'Account already verified or invalid user.'
        ]);
    }

    // Generate new OTP
    $security_code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

    $wpdb->update(
        $table,
        ['security_code' => $security_code, 'updated_at' => current_time('mysql', 1)],
        ['id' => $user->id]
    );

    // Send OTP email
    $platform_name = 'Pulsepoint';
    $subject = "Verify your {$platform_name} account";
    $message = "
        Hi {$user->firstname},<br><br>
        Your new verification code is:<br><br>
        <h2>{$security_code}</h2>
        <br>
        Enter this code to activate your account.<br><br>
        Regards,<br>
        {$platform_name} Team
    ";
    wp_mail($user->email, $subject, $message, ['Content-Type: text/html; charset=UTF-8']);

    wp_send_json([
        'success' => true,
        'message' => 'New verification code sent to your email.'
    ]);
}