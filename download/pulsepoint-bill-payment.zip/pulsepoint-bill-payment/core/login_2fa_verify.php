<?php

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__DIR__) . 'libs/PHPGangsta/GoogleAuthenticator.php';

add_action(
    'wp_ajax_nopriv_pulsepoint_login_2fa_verify',
    'pulsepoint_login_2fa_verify'
);

add_action(
    'wp_ajax_pulsepoint_login_2fa_verify',
    'pulsepoint_login_2fa_verify'
);

function pulsepoint_login_2fa_verify() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_2fa_user'])) {

        wp_send_json([
            'success' => false,
            'message' => '2FA session expired.'
        ]);
    }

    $code = sanitize_text_field($_POST['code'] ?? '');

    if (empty($code)) {

        wp_send_json([
            'success' => false,
            'message' => 'Authentication code required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_2fa_user']);

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user) {

        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    $ga = new PHPGangsta_GoogleAuthenticator();

    $valid = $ga->verifyCode(
        $user->twofa_secret,
        $code,
        2
    );

    if (!$valid) {

        wp_send_json([
            'success' => false,
            'message' => 'Invalid authentication code.'
        ]);
    }

    // FINAL LOGIN SESSION
    $_SESSION['pulsepoint_user'] = [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode
    ];

    unset($_SESSION['pulsepoint_2fa_user']);

    wp_send_json([
        'success' => true,
        'message' => '2FA login successful.',
        'redirect' => site_url('/app/dashboard')
    ]);
}