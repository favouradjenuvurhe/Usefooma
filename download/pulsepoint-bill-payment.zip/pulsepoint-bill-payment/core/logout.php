<?php
/**
 * Secure Logout Function for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/logout.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// Register AJAX actions for logout
add_action('wp_ajax_nopriv_pulsepoint_user_logout', 'pulsepoint_user_logout');
add_action('wp_ajax_pulsepoint_user_logout', 'pulsepoint_user_logout');

function pulsepoint_user_logout() {
    header('Content-Type: application/json; charset=utf-8');

    // Start session if not already started
    if (!session_id()) {
        session_start();
    }

    // Unset user session
    if (isset($_SESSION['pulsepoint_user'])) {
        unset($_SESSION['pulsepoint_user']);
    }

    // Destroy entire session
    session_destroy();

    // Remove session cookie
    if (isset($_COOKIE['pulsepoint_user_session'])) {
        setcookie('pulsepoint_user_session', '', time() - 3600, '/', $_SERVER['SERVER_NAME'], is_ssl(), true);
        unset($_COOKIE['pulsepoint_user_session']);
    }

    // Send JSON response with redirect to login page
    wp_send_json([
        'success' => true,
        'message' => 'Logout successful.',
        'redirect' => site_url('/app/login')
    ]);
}