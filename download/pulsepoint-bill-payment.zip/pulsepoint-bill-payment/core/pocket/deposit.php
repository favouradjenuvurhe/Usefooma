<?php
/**
 * Pulsepoint Deposit to Savings Pocket
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pocket/deposit.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// AJAX hooks
add_action('wp_ajax_pulsepoint_deposit_to_pocket', 'pulsepoint_deposit_to_pocket');
add_action('wp_ajax_nopriv_pulsepoint_deposit_to_pocket', 'pulsepoint_deposit_to_pocket');

function pulsepoint_deposit_to_pocket() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    // ✅ Allow only POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    // ✅ Ensure session started
    if (!session_id()) session_start();

    // ✅ Check user login (Pulsepoint user session)
    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id      = $_SESSION['pulsepoint_user']['id'];
    $base_prefix  = $wpdb->prefix . 'pulsepoint_';
    $table_users  = $base_prefix . 'users';
    $table_pocket = $base_prefix . 'savings_pocket';
    $table_trnx   = $base_prefix . 'savings_transactions';
    $table_settings = $base_prefix . 'settings';

    // 🧠 Anti-flood: Prevent spamming (max 1 deposit per 10 seconds)
    $now = time();
    if (isset($_SESSION['last_pocket_deposit'][$user_id]) && ($now - $_SESSION['last_pocket_deposit'][$user_id]) < 10) {
        wp_send_json(['success' => false, 'message' => 'Please wait 10 seconds before another deposit.']);
    }
    $_SESSION['last_pocket_deposit'][$user_id] = $now;

    // 🧩 Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT id, wallet, status FROM {$table_users} WHERE id = %d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or not found.']);
    }

    // 🧩 Fetch platform settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
    $settings = [];
    foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'System currently under maintenance.']);
    }

    // 🧾 Sanitize inputs
    $pocket_id = intval($_POST['pocket_id'] ?? 0);
    $amount    = floatval($_POST['amount'] ?? 0);

    // 🧪 Validate
    if ($pocket_id <= 0 || $amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Invalid pocket or amount.']);
    }

    // 🧾 Fetch pocket
    $pocket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_pocket} WHERE id = %d AND user_id = %d", $pocket_id, $user_id));
    if (!$pocket) {
        wp_send_json(['success' => false, 'message' => 'Pocket not found.']);
    }

    // 🧮 Check wallet balance
    if ($user->wallet < $amount) {
        wp_send_json(['success' => false, 'message' => 'Insufficient wallet balance.']);
    }

    // 🧾 Generate transaction reference
    $reference = 'DPW' . strtoupper(uniqid()) . mt_rand(100, 999);

    // ✅ Deduct from wallet (atomic update)
    $update_wallet = $wpdb->query($wpdb->prepare(
        "UPDATE {$table_users} SET wallet = wallet - %f WHERE id = %d AND wallet >= %f",
        $amount, $user_id, $amount
    ));
    if ($update_wallet === false || $wpdb->rows_affected === 0) {
        wp_send_json(['success' => false, 'message' => 'Failed to deduct from wallet.']);
    }

    // ✅ Update pocket balance
    $update_pocket = $wpdb->query($wpdb->prepare(
        "UPDATE {$table_pocket} SET current_amount = current_amount + %f, updated_at = NOW() WHERE id = %d",
        $amount, $pocket_id
    ));
    if ($update_pocket === false) {
        wp_send_json(['success' => false, 'message' => 'Failed to update savings pocket.']);
    }

    // 💾 Record transaction
    $wpdb->insert($table_trnx, [
        'pocket_id'  => $pocket_id,
        'user_id'    => $user_id,
        'type'       => 'deposit',
        'amount'     => $amount,
        'reference'  => $reference,
        'method'     => 'wallet',
        'status'     => 'success',
        'note'       => 'Wallet deposit to savings pocket',
        'created_at' => current_time('mysql')
    ], [
        '%d','%d','%s','%f','%s','%s','%s','%s','%s'
    ]);

    // ✅ Return success response
    wp_send_json([
        'success'  => true,
        'message'  => 'Deposit successful!',
        'reference'=> $reference,
        'wallet'   => number_format($user->wallet - $amount, 2),
        'amount'   => number_format($amount, 2),
    ]);
}