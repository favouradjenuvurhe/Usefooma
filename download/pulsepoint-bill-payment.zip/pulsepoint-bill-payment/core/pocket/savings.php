<?php
/**
 * Pulsepoint Savings Core
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pocket/savings.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_users  = "{$base_prefix}users";
$table_pocket = "{$base_prefix}savings_pocket";
$table_trnx   = "{$base_prefix}savings_transactions";

// ✅ AJAX Hooks
add_action('wp_ajax_pulsepoint_withdraw_from_pocket', 'pulsepoint_withdraw_from_pocket');
add_action('wp_ajax_nopriv_pulsepoint_withdraw_from_pocket', 'pulsepoint_withdraw_from_pocket');

add_action('wp_ajax_pulsepoint_toggle_auto_save', 'pulsepoint_toggle_auto_save');
add_action('wp_ajax_nopriv_pulsepoint_toggle_auto_save', 'pulsepoint_toggle_auto_save');

add_action('wp_ajax_pulsepoint_break_saving', 'pulsepoint_break_saving');
add_action('wp_ajax_nopriv_pulsepoint_break_saving', 'pulsepoint_break_saving');

/**
 * ✅ Withdraw from Pocket
 */
function pulsepoint_withdraw_from_pocket() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') wp_send_json(['success'=>false,'message'=>'Invalid request method']);
    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) wp_send_json(['success'=>false,'message'=>'User not logged in.']);

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_users  = "{$base_prefix}users";
    $table_pocket = "{$base_prefix}savings_pocket";
    $table_trnx   = "{$base_prefix}savings_transactions";

    $pocket_id = intval($_POST['pocket_id'] ?? 0);
    $amount    = floatval($_POST['amount'] ?? 0);
    if ($pocket_id <= 0 || $amount <= 0) wp_send_json(['success'=>false,'message'=>'Invalid pocket or amount']);

    $pocket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_pocket} WHERE id=%d AND user_id=%d", $pocket_id, $user_id));
    if (!$pocket) wp_send_json(['success'=>false,'message'=>'Pocket not found']);
    if ($pocket->locked == 1 && strtotime($pocket->maturity_date) > time()) {
        wp_send_json(['success'=>false,'message'=>'Savings locked until maturity date.']);
    }
    if ($pocket->current_amount < $amount) wp_send_json(['success'=>false,'message'=>'Insufficient savings balance.']);

    $reference = 'WDW'.strtoupper(uniqid());

    // Deduct & credit
    $deduct = $wpdb->query($wpdb->prepare("UPDATE {$table_pocket} SET current_amount=current_amount-%f WHERE id=%d AND current_amount >= %f", $amount, $pocket_id, $amount));
    if ($deduct === false || $wpdb->rows_affected === 0) wp_send_json(['success'=>false,'message'=>'Unable to deduct from pocket']);

    $wpdb->query($wpdb->prepare("UPDATE {$table_users} SET wallet=wallet+%f WHERE id=%d", $amount, $user_id));

    // Log
    $wpdb->insert($table_trnx, [
        'pocket_id'=>$pocket_id,
        'user_id'=>$user_id,
        'type'=>'withdrawal',
        'amount'=>$amount,
        'reference'=>$reference,
        'method'=>'wallet',
        'status'=>'success',
        'note'=>'User withdrawal from saving pocket',
        'created_at'=>current_time('mysql')
    ]);

    wp_send_json(['success'=>true,'message'=>'Withdrawal successful! Funds added to wallet','reference'=>$reference]);
}

/**
 * ✅ Toggle Auto-Save
 */
function pulsepoint_toggle_auto_save() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') wp_send_json(['success'=>false,'message'=>'Invalid request']);
    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) wp_send_json(['success'=>false,'message'=>'User not logged in.']);

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $pocket_id = intval($_POST['pocket_id'] ?? 0);
    if ($pocket_id <= 0) wp_send_json(['success'=>false,'message'=>'Invalid pocket']);

    $prefix = $wpdb->prefix . 'pulsepoint_';
    $pocket = $wpdb->get_row($wpdb->prepare("SELECT auto_save FROM {$prefix}savings_pocket WHERE id=%d AND user_id=%d", $pocket_id, $user_id));
    if (!$pocket) wp_send_json(['success'=>false,'message'=>'Pocket not found']);

    $new_state = $pocket->auto_save ? 0 : 1;
    $wpdb->query($wpdb->prepare("UPDATE {$prefix}savings_pocket SET auto_save=%d, updated_at=NOW() WHERE id=%d", $new_state, $pocket_id));

    wp_send_json(['success'=>true,'message'=>$new_state ? 'Auto-Save Enabled' : 'Auto-Save Disabled']);
}

/**
 * ✅ Break Saving (Withdraw All & Close)
 */
function pulsepoint_break_saving() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) wp_send_json(['success'=>false,'message'=>'Not logged in']);

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $pocket_id = intval($_POST['pocket_id'] ?? 0);
    if ($pocket_id <= 0) wp_send_json(['success'=>false,'message'=>'Invalid pocket']);

    $prefix = $wpdb->prefix.'pulsepoint_';
    $pocket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$prefix}savings_pocket WHERE id=%d AND user_id=%d", $pocket_id, $user_id));
    if(!$pocket) wp_send_json(['success'=>false,'message'=>'Pocket not found']);

    $amount = floatval($pocket->current_amount);
    if ($amount <= 0) wp_send_json(['success'=>false,'message'=>'Nothing to withdraw']);

    // Credit to wallet
    $wpdb->query($wpdb->prepare("UPDATE {$prefix}users SET wallet=wallet+%f WHERE id=%d", $amount, $user_id));

    // Mark as cancelled
    $wpdb->query($wpdb->prepare("UPDATE {$prefix}savings_pocket SET status='cancelled', current_amount=0, updated_at=NOW() WHERE id=%d", $pocket_id));

    // Log transaction
    $wpdb->insert("{$prefix}savings_transactions", [
        'pocket_id'=>$pocket_id,
        'user_id'=>$user_id,
        'type'=>'withdrawal',
        'amount'=>$amount,
        'reference'=>'BRK'.uniqid(),
        'method'=>'wallet',
        'status'=>'success',
        'note'=>'Break saving withdrawal',
        'created_at'=>current_time('mysql')
    ]);

    wp_send_json(['success'=>true,'message'=>'Saving broken & funds transferred']);
}

/**
 * ✅ Apply Daily/Weekly/Monthly Interest (auto run hook or manual call)
 * Optional cron-style if you later schedule it.
 */
function pulsepoint_apply_interest() {
    global $wpdb;
    $prefix = $wpdb->prefix.'pulsepoint_';
    $today = date('Y-m-d');

    $pockets = $wpdb->get_results("SELECT id,user_id,interest_rate,current_amount FROM {$prefix}savings_pocket WHERE status='active' AND interest_rate>0");
    foreach ($pockets as $pocket) {
        $interest = ($pocket->current_amount * $pocket->interest_rate) / 100;
        if ($interest <= 0) continue;

        $wpdb->query($wpdb->prepare("UPDATE {$prefix}savings_pocket SET current_amount=current_amount+%f WHERE id=%d", $interest, $pocket->id));
        $wpdb->insert("{$prefix}savings_transactions", [
            'pocket_id'=>$pocket->id,
            'user_id'=>$pocket->user_id,
            'type'=>'interest',
            'amount'=>$interest,
            'reference'=>'INT'.uniqid(),
            'method'=>'system',
            'status'=>'success',
            'note'=>'Interest credited',
            'created_at'=>current_time('mysql')
        ]);
    }
}