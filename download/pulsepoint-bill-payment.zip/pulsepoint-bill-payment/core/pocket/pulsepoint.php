<?php
/**
 * Pulsepoint Create Savings Pocket
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pocket/pulsepoint.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// AJAX hooks
add_action('wp_ajax_nopriv_pulsepoint_create_savings', 'pulsepoint_create_savings');
add_action('wp_ajax_pulsepoint_create_savings', 'pulsepoint_create_savings');

function pulsepoint_create_savings() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id      = $_SESSION['pulsepoint_user']['id'];
    $base_prefix  = $wpdb->prefix . 'pulsepoint_';
    $table_users  = $base_prefix . 'users';
    $table_pocket = $base_prefix . 'savings_pocket';
    $table_trnx   = $base_prefix . 'savings_transactions';

    // 🧠 Anti-flood protection — 1 request per 15 seconds per user
    $now = time();
    if (isset($_SESSION['last_savings_create'][$user_id]) && ($now - $_SESSION['last_savings_create'][$user_id]) < 15) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds before creating another pocket.']);
    }
    $_SESSION['last_savings_create'][$user_id] = $now;

    // 🧩 Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // 🧩 Fetch platform settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'System currently under maintenance.']);
    }

    // 🧾 Collect and sanitize form input
    $title          = sanitize_text_field($_POST['title'] ?? '');
    $target_amount  = floatval($_POST['target_amount'] ?? 0);
    $frequency      = sanitize_text_field($_POST['frequency'] ?? 'manual');
    $amount_cycle   = floatval($_POST['amount_per_cycle'] ?? 0);
    $start_date     = sanitize_text_field($_POST['start_date'] ?? date('Y-m-d'));
    $maturity_date  = sanitize_text_field($_POST['maturity_date'] ?? null);
    $withdrawable   = isset($_POST['withdrawable']) ? intval($_POST['withdrawable']) : 0;
    $auto_save      = isset($_POST['auto_save']) ? intval($_POST['auto_save']) : 0;
    $interest_rate  = floatval($_POST['interest_rate'] ?? 0);

    // 🧪 Validation
    if (empty($title) || $target_amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Pocket title and valid target amount are required.']);
    }

    $allowed_frequencies = ['daily', 'weekly', 'monthly', 'manual'];
    if (!in_array($frequency, $allowed_frequencies)) {
        wp_send_json(['success' => false, 'message' => 'Invalid frequency type.']);
    }

    if ($frequency != 'manual' && $amount_cycle <= 0) {
        wp_send_json(['success' => false, 'message' => 'Amount per cycle required for auto-save pockets.']);
    }

    // 🧱 Check existing pockets count (optional limit)
    $existing_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_pocket} WHERE user_id = %d", $user_id));
    if ($existing_count >= 20) {
        wp_send_json(['success' => false, 'message' => 'You have reached the maximum allowed savings pockets (20).']);
    }

    // 🧾 Generate reference
    $reference = 'PSP' . strtoupper(uniqid()) . mt_rand(100, 999);

    // 🏦 Create new savings pocket
    $insert_result = $wpdb->insert($table_pocket, [
        'user_id'         => $user_id,
        'title'           => $title,
        'target_amount'   => $target_amount,
        'current_amount'  => 0.00,
        'frequency'       => $frequency,
        'auto_save'       => $auto_save,
        'amount_per_cycle'=> $amount_cycle,
        'start_date'      => $start_date,
        'maturity_date'   => $maturity_date,
        'status'          => 'active',
        'withdrawable'    => $withdrawable,
        'interest_rate'   => $interest_rate,
        'locked'          => ($withdrawable == 0 ? 1 : 0),
        'created_at'      => current_time('mysql'),
        'updated_at'      => current_time('mysql')
    ], [
        '%d','%s','%f','%f','%s','%d','%f','%s','%s','%s','%d','%f','%d','%s','%s'
    ]);

    if (!$insert_result) {
        wp_send_json(['success' => false, 'message' => 'Failed to create savings pocket.']);
    }

    $pocket_id = $wpdb->insert_id;

    // 💾 Log creation as a "deposit" transaction with ₦0 (for audit)
    $wpdb->insert($table_trnx, [
        'pocket_id' => $pocket_id,
        'user_id'   => $user_id,
        'type'      => 'deposit',
        'amount'    => 0.00,
        'reference' => $reference,
        'method'    => 'wallet',
        'status'    => 'success',
        'note'      => 'Pocket created',
        'created_at'=> current_time('mysql')
    ], ['%d','%d','%s','%f','%s','%s','%s','%s']);

    // ✅ Response
    wp_send_json([
        'success' => true,
        'message' => 'Savings pocket created successfully.',
        'pocket' => [
            'id'             => $pocket_id,
            'title'          => $title,
            'target_amount'  => $target_amount,
            'frequency'      => $frequency,
            'auto_save'      => $auto_save,
            'withdrawable'   => $withdrawable,
            'interest_rate'  => $interest_rate,
            'start_date'     => $start_date,
            'maturity_date'  => $maturity_date,
        ]
    ]);
}