<?php  
/**  
 * Pulsepoint Giftcard Selling Function  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/giftcard/pulsepoint.php  
 * Author: Amaaavl  
 */  

if (!defined('ABSPATH')) exit;  

// Hook AJAX  
add_action('wp_ajax_nopriv_pulsepoint_sell_giftcard', 'pulsepoint_sell_giftcard');  
add_action('wp_ajax_pulsepoint_sell_giftcard', 'pulsepoint_sell_giftcard');  

function pulsepoint_sell_giftcard() {  
    global $wpdb;  

    header('Content-Type: application/json; charset=utf-8');  

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {  
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);  
    }  

    if (!session_id()) session_start();  

    if (!isset($_SESSION['pulsepoint_user']['id'])) {  
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);  
    }  

    $user_id     = $_SESSION['pulsepoint_user']['id'];  
    $base_prefix = $wpdb->prefix . 'pulsepoint_';  

    $tbl_users        = $base_prefix . 'users';  
    $tbl_settings     = $base_prefix . 'giftcard_settings';  
    $tbl_listings     = $base_prefix . 'giftcard_listings';  
    $tbl_transactions = $base_prefix . 'giftcard_transactions';  

    // === Inputs ===  
    $giftcard_id  = intval($_POST['giftcard_id'] ?? 0);  
    $amount       = floatval($_POST['amount'] ?? 0);  
    $type         = sanitize_text_field($_POST['type'] ?? 'digital');  
    $digital_code = sanitize_text_field($_POST['digital_code'] ?? '');  
    $note         = sanitize_textarea_field($_POST['note'] ?? '');  

    if ($giftcard_id <= 0 || $amount <= 0) {  
        wp_send_json(['success' => false, 'message' => 'Invalid card or amount.']);  
    }  

    // === Fetch Giftcard Setting ===  
    $giftcard = $wpdb->get_row($wpdb->prepare(  
        "SELECT * FROM {$tbl_settings} WHERE id = %d AND status = 'active'",  
        $giftcard_id  
    ));  

    if (!$giftcard) {  
        wp_send_json(['success' => false, 'message' => 'Giftcard not found or inactive.']);  
    }  

    // === Validate Amount Range ===  
    if ($giftcard->min_amount > 0 && $amount < $giftcard->min_amount) {  
        wp_send_json(['success' => false, 'message' => "Minimum amount is {$giftcard->min_amount}"]);  
    }  
    if ($giftcard->max_amount > 0 && $amount > $giftcard->max_amount) {  
        wp_send_json(['success' => false, 'message' => "Maximum amount is {$giftcard->max_amount}"]);  
    }  

    // === Calculate Selling Price ===  
    $selling_price = $amount * $giftcard->rate;  

    // === Handle Image Upload (For Physical Cards) ===  
    $uploaded_image_url = null;  
    if ($type === 'physical' && !empty($_FILES['physical_image']['name'])) {  
        $upload_dir = PULSEPOINT_DIR . 'assets/giftcard/';  
        $upload_url = PULSEPOINT_URL . 'assets/giftcard/';  

        if (!file_exists($upload_dir)) {  
            wp_mkdir_p($upload_dir);  
        }  

        $file_name = time() . '_' . sanitize_file_name($_FILES['physical_image']['name']);  
        $file_path = $upload_dir . $file_name;  

        if (!move_uploaded_file($_FILES['physical_image']['tmp_name'], $file_path)) {  
            wp_send_json(['success' => false, 'message' => 'Image upload failed.']);  
        }  

        $uploaded_image_url = $upload_url . $file_name;  
    }  

    // === Insert Listing ===  
    $wpdb->insert($tbl_listings, [  
        'user_id'        => $user_id,  
        'giftcard_id'    => $giftcard_id,  
        'amount'         => $amount,  
        'selling_price'  => $selling_price,  
        'type'           => $type,  
        'digital_code'   => $digital_code,  
        'physical_image' => $uploaded_image_url,  
        'status'         => 'pending',  
        'note'           => $note  
    ], [  
        '%d','%d','%f','%f','%s','%s','%s','%s'  
    ]);  

    $listing_id = $wpdb->insert_id;  
    if (!$listing_id) {  
        wp_send_json(['success' => false, 'message' => 'Failed to record listing.']);  
    }  

    // === Create Transaction Record ===  
    $reference = 'PSGC' . strtoupper(uniqid());  
    $wpdb->insert($tbl_transactions, [  
        'listing_id'     => $listing_id,  
        'user_id'        => $user_id,  
        'amount'         => $amount,  
        'selling_price'  => $selling_price,  
        'fee'            => 0.00,  
        'status'         => 'pending',  
        'payment_method' => 'wallet',  
        'reference'      => $reference,  
        'note'           => 'Giftcard submission awaiting review'  
    ], [  
        '%d','%d','%f','%f','%f','%s','%s','%s','%s'  
    ]);  

    $transaction_id = $wpdb->insert_id;  

    if (!$transaction_id) {  
        wp_send_json(['success' => false, 'message' => 'Failed to create transaction record.']);  
    }  

    // === 📨 EMAIL NOTIFICATION TO ADMIN ===  
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
    $settings = [];  
    foreach ($settings_rows as $row) {  
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
    }  

    $platform_name = isset($settings['platform_name']) ? $settings['platform_name'] : 'Pulsepoint';  
    $admin_email   = isset($settings['email_number']) ? $settings['email_number'] : get_option('admin_email');  
    $user          = $wpdb->get_row($wpdb->prepare("SELECT firstname, lastname, email, phone FROM {$tbl_users} WHERE id = %d", $user_id));  
    $user_ip       = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';  
    $date_time     = date('Y-m-d H:i:s');  

    $subject_admin = "New Giftcard Submitted on {$platform_name}";  
    $message_admin = "  
    Hello Admin,<br><br>  
    A new giftcard has been submitted and is pending review.<br><br>  
    <strong>User:</strong> {$user->firstname} {$user->lastname} ({$user->email})<br>  
    <strong>Phone:</strong> {$user->phone}<br>  
    <strong>Giftcard:</strong> {$giftcard->category}<br>  
    <strong>Type:</strong> {$type}<br>  
    <strong>Amount:</strong> {$amount}<br>  
    <strong>Rate:</strong> {$giftcard->rate}<br>  
    <strong>Calculated Value:</strong> {$selling_price}<br>  
    <strong>Reference:</strong> {$reference}<br>  
    <strong>Status:</strong> Pending Review<br>  
    <strong>Submitted At:</strong> {$date_time}<br>  
    <strong>IP:</strong> {$user_ip}<br>  
    " . ($uploaded_image_url ? "<strong>Image:</strong> <a href='{$uploaded_image_url}'>View Uploaded Card</a><br>" : '') . "  
    <br><strong>Note:</strong> {$note}<br><br>  
    Regards,<br>{$platform_name} System  
    ";  

    $headers = ['Content-Type: text/html; charset=UTF-8'];  
    @wp_mail($admin_email, $subject_admin, $message_admin, $headers);  
    // === END EMAIL NOTIFICATION ===  

    // === Return Response ===  
    wp_send_json([  
        'success' => true,  
        'message' => 'Giftcard successfully. Awaiting!!',  
        'data' => [  
            'listing_id'      => $listing_id,  
            'transaction_id'  => $transaction_id,  
            'giftcard'        => $giftcard->category,  
            'type'            => $type,  
            'amount'          => $amount,  
            'selling_price'   => $selling_price,  
            'status'          => 'pending',  
            'uploaded_image'  => $uploaded_image_url,  
            'reference'       => $reference  
        ]  
    ]);  
}