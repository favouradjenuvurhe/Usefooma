<?php
/**
 * UseFooma Topupmate Gift Card integration.
 * Supports catalog discovery, purchases and redeem-code retrieval.
 */
if (!defined('ABSPATH')) exit;

if (!function_exists('usefooma_topupmate_base_url')) {
    function usefooma_topupmate_base_url(): string {
        return 'https://connect.topupmate.com/api/giftcard';
    }
}

if (!function_exists('usefooma_topupmate_api_key')) {
    function usefooma_topupmate_api_key(): string {
        return trim((string) get_option('pulsepoint_giftcard_api_key', ''));
    }
}

if (!function_exists('usefooma_topupmate_request')) {
    function usefooma_topupmate_request(string $method, string $path = '', array $query = [], ?array $body = null): array {
        $key = usefooma_topupmate_api_key();
        if ($key === '') return ['ok' => false, 'code' => 0, 'data' => null, 'message' => 'Giftcard API key is not configured.'];

        $url = untrailingslashit(usefooma_topupmate_base_url()) . '/' . ltrim($path, '/');
        if ($query) $url = add_query_arg($query, $url);

        $args = [
            'timeout' => 45,
            'redirection' => 2,
            'headers' => [
                'Authorization' => 'Token ' . $key,
                'Accept' => 'application/json',
            ],
        ];

        if (strtoupper($method) === 'POST') {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body ?: []);
            $res = wp_remote_post($url, $args);
        } else {
            $res = wp_remote_get($url, $args);
        }

        if (is_wp_error($res)) {
            return ['ok' => false, 'code' => 0, 'data' => null, 'message' => $res->get_error_message()];
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $raw = wp_remote_retrieve_body($res);
        $json = json_decode($raw, true);
        if (!is_array($json)) {
            return ['ok' => false, 'code' => $code, 'data' => null, 'message' => 'Topupmate returned an invalid JSON response.'];
        }

        $status = strtolower((string) ($json['status'] ?? ''));
        $ok = ($code >= 200 && $code < 300 && $status === 'success');
        $message = $json['message'] ?? $json['msg'] ?? $json['error'] ?? 'Topupmate request failed.';
        if (is_array($message)) $message = $message['message'] ?? $message['content'] ?? 'Topupmate request failed.';

        return [
            'ok' => $ok,
            'code' => $code,
            'data' => $json,
            'message' => is_string($message) ? $message : 'Topupmate request failed.',
        ];
    }
}

if (!function_exists('usefooma_topupmate_products_from_response')) {
    function usefooma_topupmate_products_from_response(array $json): array {
        $msg = $json['msg'] ?? null;
        if (is_array($msg) && isset($msg['content']) && is_array($msg['content'])) return $msg['content'];
        if (is_array($msg) && array_is_list($msg)) return $msg;
        if (isset($json['data']['products']) && is_array($json['data']['products'])) return $json['data']['products'];
        if (isset($json['data']) && is_array($json['data']) && array_is_list($json['data'])) return $json['data'];
        if (isset($json['content']) && is_array($json['content'])) return $json['content'];
        return [];
    }
}

if (!function_exists('usefooma_topupmate_find_product')) {
    function usefooma_topupmate_find_product(int $product_id): ?array {
        $res = usefooma_topupmate_request('GET', 'available/', ['productId' => $product_id]);
        if (!$res['ok']) return null;
        foreach (usefooma_topupmate_products_from_response($res['data']) as $product) {
            if ((int) ($product['productId'] ?? $product['product_id'] ?? 0) === $product_id) return $product;
        }
        return null;
    }
}

if (!function_exists('usefooma_topupmate_sender_amount')) {
    function usefooma_topupmate_sender_amount(array $product, float $recipient_amount): float {
        $map = $product['fixedRecipientToSenderDenominationsMap'] ?? $product['fixed_recipient_to_sender_denominations_map'] ?? [];
        foreach ($map as $recipient => $sender) {
            if (abs((float) $recipient - $recipient_amount) < 0.00001) return round((float) $sender, 4);
        }

        $rate = (float) ($product['recipientCurrencyToSenderCurrencyExchangeRate'] ?? $product['recipient_currency_to_sender_currency_exchange_rate'] ?? 0);
        $sender_fee = (float) ($product['senderFee'] ?? $product['sender_fee'] ?? 0);
        $sender_fee_pct = (float) ($product['senderFeePercentage'] ?? $product['sender_fee_percentage'] ?? 0);
        $base = $recipient_amount * $rate;
        return round($base + $sender_fee + ($base * $sender_fee_pct / 100), 4);
    }
}

if (!function_exists('usefooma_topupmate_wallet_charge')) {
    function usefooma_topupmate_wallet_charge(array $product, float $recipient_amount): float {
        $sender_amount = usefooma_topupmate_sender_amount($product, $recipient_amount);
        $ngn_rate = max(0, (float) get_option('pulsepoint_giftcard_api_fx_rate', 1));
        $markup = max(0, (float) get_option('pulsepoint_giftcard_api_markup', 0));
        return round($sender_amount * $ngn_rate * (1 + $markup / 100), 2);
    }
}

if (!function_exists('usefooma_topupmate_normalize_product')) {
    function usefooma_topupmate_normalize_product(array $p): array {
        $recipient = array_values(array_map('floatval', $p['fixedRecipientDenominations'] ?? $p['fixed_recipient_denominations'] ?? []));
        $sender = array_values(array_map('floatval', $p['fixedSenderDenominations'] ?? $p['fixed_sender_denominations'] ?? []));
        $map = $p['fixedRecipientToSenderDenominationsMap'] ?? $p['fixed_recipient_to_sender_denominations_map'] ?? [];
        $wallet_rate = max(0, (float) get_option('pulsepoint_giftcard_api_fx_rate', 1));
        $markup = max(0, (float) get_option('pulsepoint_giftcard_api_markup', 0));
        $prices = [];
        foreach ($recipient as $i => $amount) {
            $sender_amount = isset($map[number_format($amount, 2, '.', '')]) ? (float) $map[number_format($amount, 2, '.', '')] : ($sender[$i] ?? usefooma_topupmate_sender_amount($p, $amount));
            $prices[] = [
                'recipient_amount' => $amount,
                'sender_amount' => round($sender_amount, 4),
                'wallet_charge' => round($sender_amount * $wallet_rate * (1 + $markup / 100), 2),
            ];
        }
        return [
            'product_id' => (int) ($p['productId'] ?? $p['product_id'] ?? 0),
            'name' => (string) ($p['productName'] ?? $p['name'] ?? ''),
            'brand' => (string) ($p['brand']['brandName'] ?? $p['brand'] ?? ''),
            'brand_id' => (int) ($p['brand']['brandId'] ?? 0),
            'country_iso' => (string) ($p['country']['isoName'] ?? $p['countryCode'] ?? $p['country_iso'] ?? ''),
            'country_name' => (string) ($p['country']['name'] ?? ''),
            'currency' => (string) ($p['recipientCurrencyCode'] ?? $p['currency'] ?? ''),
            'sender_currency' => (string) ($p['senderCurrencyCode'] ?? ''),
            'denomination_type' => (string) ($p['denominationType'] ?? $p['denomination_type'] ?? ''),
            'fixed_denominations' => $recipient,
            'fixed_sender_denominations' => $sender,
            'fixed_recipient_to_sender_map' => $map,
            'min_amount' => isset($p['minRecipientDenomination']) ? (float) $p['minRecipientDenomination'] : null,
            'max_amount' => isset($p['maxRecipientDenomination']) ? (float) $p['maxRecipientDenomination'] : null,
            'sender_fee' => (float) ($p['senderFee'] ?? 0),
            'sender_fee_percentage' => (float) ($p['senderFeePercentage'] ?? 0),
            'exchange_rate' => (float) ($p['recipientCurrencyToSenderCurrencyExchangeRate'] ?? 0),
            'wallet_rate' => $wallet_rate,
            'wallet_markup_percent' => $markup,
            'denomination_prices' => $prices,
            'logo_url' => (string) ($p['brand']['logoUrl'] ?? ($p['logoUrls'][0] ?? '')),
            'logo_urls' => array_values($p['logoUrls'] ?? []),
            'redeem_instruction' => $p['redeemInstruction'] ?? [],
            'additional_requirements' => $p['additionalRequirements'] ?? [],
            'raw_product' => $p,
        ];
    }
}

if (!function_exists('usefooma_topupmate_catalog')) {
    function usefooma_topupmate_catalog(array $query = []): array {
        $res = usefooma_topupmate_request('GET', 'available/', $query);
        if (!$res['ok']) return $res;
        $products = [];
        foreach (usefooma_topupmate_products_from_response($res['data']) as $p) {
            if (!is_array($p)) continue;
            $products[] = usefooma_topupmate_normalize_product($p);
        }
        return ['ok' => true, 'code' => $res['code'], 'data' => $products, 'message' => ''];
    }
}

if (!function_exists('usefooma_topupmate_purchase')) {
    function usefooma_topupmate_purchase(int $product_id, float $amount, string $email, string $sender, string $ref): array {
        return usefooma_topupmate_request('POST', '', [], [
            'product' => $product_id,
            'preorder' => false,
            'email' => $email,
            'amount' => $amount,
            'sender' => $sender,
            'units' => 1,
            'ref' => $ref,
        ]);
    }
}

if (!function_exists('usefooma_topupmate_redeem')) {
    function usefooma_topupmate_redeem(string $ref = ''): array {
        $query = $ref !== '' ? ['ref' => $ref] : [];
        return usefooma_topupmate_request('GET', 'redeem/', $query);
    }
}

if (!function_exists('usefooma_topupmate_extract_redeem')) {
    function usefooma_topupmate_extract_redeem(array $json): array {
        $d = $json;
        if (isset($json['data']) && is_array($json['data'])) $d = array_merge($json, $json['data']);
        return [
            'status' => strtolower((string) ($d['Status'] ?? $d['status'] ?? '')),
            'redeem_id' => (string) ($d['redeemId'] ?? $d['redeem_id'] ?? ''),
            'card_name' => (string) ($d['cardName'] ?? $d['card_name'] ?? ''),
            'card_amount' => (float) ($d['cardAmount'] ?? $d['card_amount'] ?? 0),
            'card_currency' => (string) ($d['cardCurrency'] ?? $d['card_currency'] ?? ''),
            'redeem' => (string) ($d['redeem'] ?? $d['cardNumber'] ?? ''),
            'redeem_details' => (string) ($d['redeem_details'] ?? $d['redeemInstructions'] ?? ''),
            'card_number' => (string) ($d['cardNumber'] ?? ''),
            'pin_code' => (string) ($d['pinCode'] ?? ''),
            'raw' => $json,
        ];
    }
}
