<?php          
/**          
 * Pulsepoint Data Purchase Function          
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/pulsepoint.php          
 * Author: Amaaavl          
 */          
  
if (!defined('ABSPATH')) exit;          
  
// AJAX Hooks          
add_action('wp_ajax_nopriv_pulsepoint_data_purchase', 'pulsepoint_data_purchase');          
add_action('wp_ajax_pulsepoint_data_purchase', 'pulsepoint_data_purchase');          
  
function pulsepoint_data_purchase() {          
    global $wpdb;          
  
    header('Content-Type: application/json; charset=utf-8');          
  
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {          
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);          
    }          
  
    if (!session_id()) session_start();          
  
    if (!isset($_SESSION['pulsepoint_user']['id'])) {          
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);          
    }          
  
    $user_id     = $_SESSION['pulsepoint_user']['id'];          
    $table_users = $wpdb->prefix . 'pulsepoint_users';          
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';          
    $base_prefix = $wpdb->prefix . 'pulsepoint_';          
  
    $log_security = function($event, $meta = []) use ($wpdb, $base_prefix) {    
        $wpdb->insert(    
            "{$base_prefix}logs",    
            [    
                'event'      => $event,    
                'meta'       => json_encode($meta),    
                'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',    
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',    
                'created_at' => current_time('mysql')    
            ],    
            ['%s','%s','%s','%s','%s']    
        );    
    };          
  
    $now = time();          
    if (isset($_SESSION['last_data_request'][$user_id]) && ($now - $_SESSION['last_data_request'][$user_id]) < 10) {          
        $log_security('rate_limited', ['user'=>$user_id]);  
        wp_send_json(['success' => false, 'message' => 'Please wait 10 seconds.']);          
    }          
    $_SESSION['last_data_request'][$user_id] = $now;          
  
    $wpdb->query('START TRANSACTION');          
  
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id = %d FOR UPDATE", $user_id));          
    if (!$user || $user->status != 1) {          
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success' => false, 'message' => 'User not active or not found.']);          
    }          
  
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");          
    $settings = [];          
    foreach ($settings_rows as $row) {          
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);          
    }          
  
    $maintenance_mode = $settings['maintenance_mode'] ?? '0';          
    $api_mode         = $settings['api_mode'] ?? 'live';          
  
    if ($maintenance_mode == '1') {          
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success' => false, 'message' => 'Service under maintenance.']);          
    }          
  
    // Inputs          
    $network   = isset($_POST['network']) ? sanitize_text_field($_POST['network']) : '';          
    $plan_id   = isset($_POST['plan']) ? intval($_POST['plan']) : 0;          
    $phone     = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';          
    $reference = isset($_POST['reference']) ? sanitize_text_field($_POST['reference']) : '';          
  
    if (empty($network) || empty($plan_id) || empty($phone)) {          
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success' => false, 'message' => 'Network, Plan, and Phone are required.']);          
    }          
  
    // Plan          
    $data_plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$base_prefix}data WHERE id = %d", $plan_id));          
    if (!$data_plan) {          
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success' => false, 'message' => 'Invalid data plan selected.']);          
    }          
  
    // ================================
    // 🔥 FIXED: Get prices from DB
    // ================================
    $amount      = floatval($data_plan->amount);     // selling price (user pays)
    $buy_amount  = floatval($data_plan->purchase);   // buying price (API cost)

    $api_plan = $data_plan->plan;          

    // Provider          
    $provider_id = intval($data_plan->provider);          
    $provider = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$base_prefix}provider WHERE id = %d",
        $provider_id
    ));          

    if (!$provider) {          
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success' => false, 'message' => 'Invalid provider.']);          
    }          

    $api_name  = strtolower(trim($provider->name));          
    $api_token = trim($provider->token);          
    $api_value = maybe_unserialize($provider->value);          

    if (empty($reference)) {          
        $reference = 'PSNG' . mt_rand(1000000,9999999) . strtoupper($api_name);          
    }          

    $description = "{$data_plan->details} ({$data_plan->type} - " . strtoupper($network) . ")";          


    // ================================
    // 🔥 NAVIGATE BALANCE SECURITY BLOCK (ADDED HERE)
    // ================================

    $current_balance = floatval($user->wallet);

    // ❌ BLOCK INVALID / NEGATIVE BALANCE
    if ($current_balance <= 0) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Too low or invalid. Insufficient funds.'
        ]);
    }

    // ❌ BLOCK INSUFFICIENT BALANCE
    if ($current_balance < $amount) {

        $needed = $amount - $current_balance;

        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'You need ₦' . number_format($needed, 2) . ' more to proceed.'
        ]);
    }


    // ================================
    // DAILY LIMIT CHECK
    // ================================

    $today_start = date('Y-m-d 00:00:00');          
    $today_end   = date('Y-m-d 23:59:59');          

    $spent_today = $wpdb->get_var($wpdb->prepare(  
        "SELECT SUM(amount) FROM {$table_trnx}   
         WHERE user_id=%d AND date BETWEEN %s AND %s AND type='debit' FOR UPDATE",  
        $user_id, $today_start, $today_end  
    ));          

    $spent_today = $spent_today ?: 0;          
    $account_limit = $user->account_limit ?: 5000;          

    if (($spent_today + $amount) > $account_limit) {          
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success' => false, 'message' => "Daily limit reached."]);          
    }
  
    $wpdb->insert($table_trnx, [          
        'user_id'     => $user_id,          
        'details'     => json_encode(['network' => $network, 'plan' => $api_plan, 'phone' => $phone]),          
        'recipient'   => $phone,          
        'amount'      => $amount,          
        'reference'   => $reference,          
        'payment'     => 'wallet',          
        'category'    => 'data',          
        'status'      => 'pending',          
        'type'        => 'debit',          
        'session'     => session_id(),          
        'description' => $description          
    ]);          
  
    $trnx_id = $wpdb->insert_id;          
  
    if ($api_plan == 0) {  
        $deduct = $wpdb->query($wpdb->prepare(  
            "UPDATE {$table_users}   
             SET wallet = wallet - %f   
             WHERE id=%d AND wallet >= %f",  
            $amount, $user_id, $amount  
        ));  
  
        if ($wpdb->rows_affected !== 1) {  
            $wpdb->query('ROLLBACK');  
            wp_send_json(['success'=>false,'message'=>'Insufficient balance']);  
        }  
  
        $wpdb->update($table_trnx, [  
            'status' => 'pending',  
            'updated_at' => current_time('mysql')  
        ], ['id'=>$trnx_id]);  
  
        $wpdb->query('COMMIT');  
  
        wp_send_json([  
            'success' => true,  
            'message' => 'Queued successfully',  
            'reference' => $reference  
        ]);  
    }  
  
    require_once __DIR__ . '/' . $api_name . '.php';  
  
    if (!function_exists('send_data')) {  
        $wpdb->query('ROLLBACK');  
        wp_send_json(['success'=>false,'message'=>'API missing']);  
    }  
  
    // ✅ FIXED: Use buying price for API
    $api_response = send_data($network,$api_plan,$phone,$buy_amount,$api_token,$api_value,$reference,$trnx_id);  
  
    $status = $api_response['success'] ? 'success' : 'failed';  
  
    if (in_array($status, ['success','pending'])) {  
        $wpdb->query($wpdb->prepare(  
            "UPDATE {$table_users}   
             SET wallet = wallet - %f   
             WHERE id=%d AND wallet >= %f",  
            $amount,$user_id,$amount  
        ));  
  
        if ($wpdb->rows_affected !== 1) {  
            $wpdb->query('ROLLBACK');  
            wp_send_json(['success'=>false,'message'=>'Wallet error']);  
        }  
    }  
  
    $wpdb->update($table_trnx, [  
        'status' => $status,  
        'gateway_response' => json_encode($api_response['details'] ?? []),  
        'updated_at' => current_time('mysql')  
    ], ['id'=>$trnx_id]);  
  
    if ($status === 'failed') {  
        $wpdb->update($table_users, [  
            'wallet' => $user->wallet  
        ], ['id'=>$user_id]);  
    }  
  
    $wpdb->query('COMMIT');  
  
    wp_send_json([  
        'success' => in_array($status,['success','pending']),  
        'message' => $api_response['message'] ?? $status,  
        'reference' => $reference  
    ]);  
}