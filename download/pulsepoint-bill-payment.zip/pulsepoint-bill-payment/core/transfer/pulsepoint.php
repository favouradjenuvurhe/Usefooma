<?php  
/**
 * Pulsepoint Bank Transfer Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/bank/transfer.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// Hook for AJAX requests
add_action('wp_ajax_nopriv_pulsepoint_bank_transfer', 'pulsepoint_bank_transfer');
add_action('wp_ajax_pulsepoint_bank_transfer', 'pulsepoint_bank_transfer');

function pulsepoint_bank_transfer() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Rate limiter: 1 request per 15 seconds
    $now = time();
    if (isset($_SESSION['last_bank_request'][$user_id]) && ($now - $_SESSION['last_bank_request'][$user_id]) < 15) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);
    }
    $_SESSION['last_bank_request'][$user_id] = $now;

    // Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id = %d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode  = $settings['maintenance_mode'] ?? '0';
    $api_mode          = $settings['api_mode'] ?? 'live';
    $bank_transfer_api = $settings['bank_transfer'] ?? 'strowallet';
    $strowallet_key    = $settings['strowallet_key'] ?? '';
    $bank_fee          = isset($settings['pay_bank']) ? floatval($settings['pay_bank']) : 0;
    $require_kyc       = isset($settings['bank_kyc']) && $settings['bank_kyc'] == 1;

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    // ✅ KYC CHECK (dynamic)
    if ($require_kyc && $user->statuskyc != 1) {
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }

    // Sanitize inputs
    $bank_code      = isset($_POST['bank_code']) ? sanitize_text_field($_POST['bank_code']) : '';
    $account_number = isset($_POST['account_number']) ? sanitize_text_field($_POST['account_number']) : '';
    $account_name   = isset($_POST['account_name']) ? sanitize_text_field($_POST['account_name']) : '';
    $amount         = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
    $narration      = isset($_POST['narration']) ? sanitize_text_field($_POST['narration']) : '';

    $description    = (!empty($narration)) ? $narration : "{$account_number} | {$account_name}";
    $reference      = 'PSNG' . mt_rand(1000000, 9999999) . strtoupper(substr($bank_transfer_api,0,3));

    if (empty($bank_code) || empty($account_number) || $amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Bank code, account number, and amount are required.']);
    }

    // ✅ Calculate stamp duty for transfers ≥ 10,000
    $stamp_fee = ($amount >= 10000) ? 50 : 0;

    // Total debit = amount + bank fee + stamp duty
    $total_debit = $amount + $bank_fee + $stamp_fee;

    // Daily limit check (only SUCCESS transactions count)
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');
    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx} 
        WHERE user_id=%d AND date BETWEEN %s AND %s AND type='debit' AND category='bank' AND status='success'",
        $user_id, $today_start, $today_end
    ));
    $spent_today = $spent_today ?: 0;
    $account_limit = $user->account_limit ?: 100000;

    if (($spent_today + $total_debit) > $account_limit) {
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$account_limit} per day"]);
    }

    // Wallet check
    if ($api_mode === 'live' && $user->wallet < $total_debit) {
        wp_send_json(['success' => false, 'message' => "Insufficient wallet. Need ₦{$total_debit}"]);
    }

    // Sandbox mode
    if ($api_mode === 'sandbox') {
        wp_send_json(['success' => true, 'message' => 'Bank Transfer Successful Mode', 'reference' => $reference]);
    }

    // Include API handler
    $api_file = __DIR__ . '/' . strtolower($bank_transfer_api) . '.php';
    if (!file_exists($api_file)) {
        wp_send_json(['success' => false, 'message' => "Bank Transfer API handler not found"]);
    }
    require_once $api_file;
    if (!function_exists('send_bank_transfer')) {
        wp_send_json(['success' => false, 'message' => "Function not implemented"]);
    }

    // Record transaction as pending
    $wpdb->insert($table_trnx, [
        'user_id'     => $user_id,
        'details'     => json_encode([
            'bank_code'    => $bank_code,
            'account_number'=> $account_number,
            'account_name' => $account_name,
            'narration'    => $narration,
            'bank_fee'     => $bank_fee,
            'stamp_fee'    => $stamp_fee,
            'total_debit'  => $total_debit
        ]),
        'recipient'   => $account_number,
        'amount'      => $total_debit,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'bank',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description
    ], [
        '%d','%s','%s','%f','%s','%s','%s','%s','%s','%s','%s'
    ]);

    $trnx_id = $wpdb->insert_id;

    // Payload for API
    $api_payload = [
        'bank_code'      => $bank_code,
        'account_number' => $account_number,
        'account_name'   => $account_name,
        'amount'         => $amount,
        'narration'      => $description,
        'reference'      => $reference,
        'token'          => $strowallet_key,
        'transaction_id' => $trnx_id
    ];

    // Call API
    $api_response = send_bank_transfer(...array_values($api_payload));

    // Update transaction
    $status = ($api_response['success'] ?? false) ? 'success' : 'failed';
    $wpdb->update($table_trnx, [
        'status'           => $status,
        'gateway_response' => json_encode($api_response['details'] ?? []),
        'updated_at'       => current_time('mysql')
    ], ['id' => $trnx_id], ['%s','%s','%s'], ['%d']);

    // Deduct wallet only if live mode and success
    if ($status === 'success' && $api_mode === 'live') {
        $new_wallet = $user->wallet - $total_debit;
        $wpdb->update($table_users, ['wallet' => $new_wallet], ['id' => $user_id], ['%f'], ['%d']);
    } else {
        $new_wallet = $user->wallet;
    }

    wp_send_json([
        'success'    => $status === 'success',
        'message'    => $api_response['message'] ?? ($status === 'failed' ? 'Bank transfer failed.' : ''),
        'new_wallet' => $new_wallet,
        'reference'  => $reference,
        'details'    => $api_response['details'] ?? [],
        'bank_fee'   => $bank_fee,
        'stamp_fee'  => $stamp_fee,
        'total_debit'=> $total_debit
    ]);
}