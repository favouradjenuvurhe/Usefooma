<?php
/**
 * WhoGoPay Bank Transfer Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/bank/whogopay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Resolve Bank Name using Bank Code (Pulsepoint Bank API)
 */
function pulsepoint_get_bank_name($bank_code) {

    $cache_key = 'pulsepoint_bank_list';
    $banks = get_transient($cache_key);

    if (!$banks) {
        $response = wp_remote_get(
            'https://pulsepoint-plugin.vercel.app/api/banks.json',
            ['timeout' => 15]
        );

        if (is_wp_error($response)) {
            return '';
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!isset($body['data']) || !is_array($body['data'])) {
            return '';
        }

        $banks = $body['data'];

        // Cache for 12 hours
        set_transient($cache_key, $banks, 12 * HOUR_IN_SECONDS);
    }

    foreach ($banks as $bank) {
        if (
            isset($bank['bankCode'], $bank['bankName']) &&
            (string)$bank['bankCode'] === (string)$bank_code
        ) {
            return trim($bank['bankName']);
        }
    }

    return '';
}

function send_bank_transfer($bank_code, $account_number, $account_name, $amount, $narration, $reference, $token, $transaction_id) {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    /** -----------------------------------------
     * 1. FETCH WHOGOPAY TOKEN FROM DB
     * ----------------------------------------- */
    $db_token = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT opt_value FROM {$base_prefix}settings WHERE opt_key = %s LIMIT 1",
            'bank_token'
        )
    );

    if (empty($token)) {
        $token = $db_token;
    }

    if (empty($narration)) {
        $narration = "Wallet Transfer - $reference";
    }

    /** -----------------------------------------
     * LOGGING SETUP
     * ----------------------------------------- */
    $log_dir = PULSEPOINT_DIR . 'logs/';
    if (!file_exists($log_dir)) {
        wp_mkdir_p($log_dir);
    }

    $log_file = $log_dir . 'whogopay_log.txt';
    $timestamp = date('Y-m-d H:i:s');

    $write_log = function($text) use ($log_file, $timestamp, $transaction_id) {
        file_put_contents(
            $log_file,
            "[$timestamp] (Transaction: $transaction_id) $text" . PHP_EOL,
            FILE_APPEND
        );
    };

    /** INPUT LOG */
    $write_log("INPUT: " . json_encode([
        'bank_code'      => $bank_code,
        'account_number' => $account_number,
        'account_name'   => $account_name,
        'amount'         => $amount,
        'reference'      => $reference
    ]));

    /** -----------------------------------------
     * RESOLVE BANK NAME
     * ----------------------------------------- */
    $bank_name = pulsepoint_get_bank_name($bank_code);

    if (empty($bank_name)) {
        $write_log("BANK NAME NOT FOUND FOR CODE: $bank_code");

        return [
            'success' => false,
            'message' => 'Invalid bank selected. Bank name not found.',
            'details' => []
        ];
    }

    $write_log("RESOLVED BANK NAME: $bank_name");

    /** -----------------------------------------
     * ACCOUNT REFERENCE (REQUIRED)
     * ----------------------------------------- */
    $account_reference = $reference;
    $write_log("ACCOUNT REFERENCE: $account_reference");

    /** -----------------------------------------
     * BUILD PAYLOAD
     * ----------------------------------------- */
    $payload = [
        'amount'            => floatval($amount),
        'clientRef'         => $reference,
        'accountReference'  => $account_reference, // ✅ FIX
        'accountName'       => $account_name,
        'accountNumber'     => $account_number,
        'bankCode'          => $bank_code,
        'bankName'          => $bank_name,
        'narration'         => $narration
    ];

    $write_log("POST BODY: " . json_encode($payload));

    /** -----------------------------------------
     * SEND REQUEST
     * ----------------------------------------- */
    $ch = curl_init('https://whogopay.com.ng/api/v1/bank-transfer');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token
        ]
    ]);

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $write_log("HTTP CODE: $httpcode");
    $write_log("RAW RESPONSE: $response");

    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);

        $write_log("CURL ERROR: $error");

        return [
            'success' => false,
            'message' => "cURL Error: $error",
            'details' => []
        ];
    }

    curl_close($ch);

    /** -----------------------------------------
     * PARSE RESPONSE
     * ----------------------------------------- */
    $data = json_decode($response, true);

    if (!$data) {
        $write_log("INVALID JSON RESPONSE");

        return [
            'success' => false,
            'message' => 'Invalid response from WhoGoPay',
            'details' => ['raw' => $response]
        ];
    }

    return [
        'success' => $data['ok'] ?? false,
        'message' => $data['content']['message'] ?? $data['message'] ?? 'No message',
        'details' => $data['content']['result'] ?? []
    ];
}