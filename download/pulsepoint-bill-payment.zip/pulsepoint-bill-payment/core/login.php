<?php      
/**      
 * Secure Login Function for Pulsepoint Plugin      
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/login.php      
 * Author: Amaaavl      
 */      

if (!defined('ABSPATH')) {      
    exit; // Prevent direct file access      
}      

add_action('wp_ajax_nopriv_pulsepoint_user_login', 'pulsepoint_user_login');       
add_action('wp_ajax_pulsepoint_user_login', 'pulsepoint_user_login');       

function pulsepoint_user_login() {      
    global $wpdb;      

    header('Content-Type: application/json; charset=utf-8');      

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {      
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);      
    }      

    $email_or_phone = isset($_POST['email']) ? sanitize_text_field($_POST['email']) : '';      
    $password       = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';      

    if (empty($email_or_phone) || empty($password)) {      
        wp_send_json(['success' => false, 'message' => 'Email or Phone Number and Password are required.']);      
    }      

    $table = $wpdb->prefix . 'pulsepoint_users';      

    $user = $wpdb->get_row(      
        $wpdb->prepare("SELECT * FROM `{$table}` WHERE (`email` = %s OR `phone` = %s) LIMIT 1", $email_or_phone, $email_or_phone)      
    );      

    if (!$user) {      
        wp_send_json(['success' => false, 'message' => 'Invalid login credentials.']);      
    }      

    if ((int)$user->close_account === 1) {      
        wp_send_json(['success' => false, 'message' => 'Your account is pending deletion and cannot login.']);      
    }      

    // ===============================
    // STATUS CONTROL (FIXED LOGIC)
    // ===============================

    if ((int)$user->status === 0) {

        // Suspended → send email + block
        @wp_mail(
            $user->email,
            'Account Suspended Notice',
            "Hi {$user->firstname},<br><br>Your account has been suspended.",
            ['Content-Type: text/html; charset=UTF-8']
        );

        wp_send_json([
            'success' => false,
            'message' => 'Your account has been suspended.'
        ]);
    }

    if ((int)$user->status === 2) {
        wp_send_json([
            'success' => false,
            'message' => 'Inactive account.'
        ]);
    }

    // Password check ONLY for active users
    if (!password_verify($password, $user->password)) {      
        wp_send_json(['success' => false, 'message' => 'Incorrect password.']);      
    }      

    // Generate token/passcode
    $update_data = [];      

    if (empty($user->token)) {      
        $update_data['token'] = bin2hex(random_bytes(16));      
    }      

    if (empty($user->passcode)) {      
        $update_data['passcode'] = rand(1000, 9999);      
    }      

    if (!empty($update_data)) {      
        $wpdb->update($table, $update_data, ['id' => $user->id]);      
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $user->id));      
    }      

    if (!session_id()) session_start();      

    $_SESSION['pulsepoint_user'] = [      
        'id'        => $user->id,      
        'firstname' => $user->firstname,      
        'lastname'  => $user->lastname,      
        'email'     => $user->email,      
        'phone'     => $user->phone,      
        'wallet'    => $user->wallet,      
        'token'     => $user->token,      
        'passcode'  => $user->passcode      
    ];      

    setcookie(      
        'pulsepoint_user_session',      
        session_id(),      
        time() + 86400,      
        '/',      
        $_SERVER['SERVER_NAME'],      
        is_ssl(),      
        true      
    );      

    $user_ip    = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';      
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Device';      
    $login_time = date('Y-m-d H:i:s');      

    // ===============================
    // EMAIL CONTROL + REDIRECT LOGIC
    // ===============================

    if ((int)$user->status_email === 1) {

        // SEND EMAIL
        @wp_mail(
            $user->email,
            'New Login Activity on Your Account',
            "Hi {$user->firstname},<br><br>
            A new login was detected.<br><br>
            <strong>Date:</strong> {$login_time}<br>
            <strong>IP:</strong> {$user_ip}<br>
            <strong>Device:</strong> {$user_agent}<br><br>
            If this was not you, secure your account.",
            ['Content-Type: text/html; charset=UTF-8']
        );

        // NORMAL LOGIN
        wp_send_json([
            'success' => true,
            'message' => 'Login successful.',
            'redirect' => site_url('/app/dashboard'),
            'user' => $_SESSION['pulsepoint_user']
        ]);
    }

    // status_email = 0 → NO EMAIL + SEND TO VERIFICATION
    wp_send_json([
        'success' => true,
        'message' => 'Login successful. Please verify your account.',
        'redirect' => site_url('/app/verification'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}

// ===============================
// GOOGLE LOGIN (UNCHANGED)
// ===============================
add_action('wp_ajax_nopriv_pulsepoint_google_login', 'pulsepoint_google_login');      
add_action('wp_ajax_pulsepoint_google_login', 'pulsepoint_google_login');      

function pulsepoint_google_login() {      
    global $wpdb;      

    header('Content-Type: application/json; charset=utf-8');      

    $id_token = isset($_POST['id_token']) ? sanitize_text_field($_POST['id_token']) : (isset($_POST['credential']) ? sanitize_text_field($_POST['credential']) : '');      

    if (empty($id_token)) {      
        wp_send_json(['success' => false, 'message' => 'Google ID token is required.']);      
    }      

    $google_url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . $id_token;      
    $response   = wp_remote_get($google_url);      

    if (is_wp_error($response)) {      
        wp_send_json(['success' => false, 'message' => 'Unable to verify Google token.']);      
    }      

    $data = json_decode(wp_remote_retrieve_body($response), true);      

    if (!isset($data['email_verified']) || $data['email_verified'] != 'true') {      
        wp_send_json(['success' => false, 'message' => 'Google email not verified.']);      
    }      

    $email = sanitize_email($data['email']);      
    $firstname = sanitize_text_field($data['given_name'] ?? '');      
    $lastname  = sanitize_text_field($data['family_name'] ?? '');      

    $table = $wpdb->prefix . 'pulsepoint_users';      

    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `email` = %s LIMIT 1", $email));      

    if (!$user) {      
        $wpdb->insert($table, [      
            'firstname' => $firstname,      
            'lastname'  => $lastname,      
            'email'     => $email,      
            'password'  => password_hash(bin2hex(random_bytes(6)), PASSWORD_DEFAULT),      
            'status'    => 1,      
            'status_email' => 1,      
            'wallet'    => 0.00,      
            'created_at'=> current_time('mysql', 1)      
        ]);      

        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $wpdb->insert_id));      
    }      

    if (!session_id()) session_start();      

    $_SESSION['pulsepoint_user'] = $user;      

    wp_send_json([      
        'success' => true,      
        'message' => 'Login successful via Google.',      
        'redirect' => site_url('/app/dashboard'),      
        'user' => $_SESSION['pulsepoint_user']      
    ]);      
}