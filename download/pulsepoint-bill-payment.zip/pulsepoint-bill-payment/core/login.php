<?php
/**
 * Secure Login Function for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/login.php
 * Author: Amaaavl
 *
 * SECURITY / RELIABILITY PATCH:
 * 1. Brute-force protection: login attempts are rate-limited per
 *    (identifier + IP) using WP transients. 5 failed attempts locks
 *    that combination out for 15 minutes.
 * 2. Session fixation protection: session_regenerate_id(true) is called
 *    once a session is established for a newly authenticated user.
 * 3. Session cookie hardened: HttpOnly + Secure (when on HTTPS) + SameSite=Lax,
 *    set via the array-options form of setcookie() (PHP 7.3+/8.3 safe).
 * 4. Passwords are now auto-rehashed with password_needs_rehash() so that
 *    if the hashing cost/algorithm is upgraded later, existing users
 *    transparently get the stronger hash next time they log in.
 * 5. Notification emails (suspension notice + new-login-activity notice)
 *    now render from a shared HTML template instead of inline HTML strings,
 *    with all dynamic values escaped before injection.
 * 6. FIXED BUG: pulsepoint_google_login() was storing the *entire* DB row
 *    (including the bcrypt password hash and raw token/passcode) into
 *    $_SESSION and returning it in the JSON response. It now stores/returns
 *    the same trimmed-down shape as the normal login path.
 * 7. Defensive input limits (max password length) to avoid abuse of
 *    the bcrypt hashing cost with oversized input.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file access
}

const PULSEPOINT_LOGIN_MAX_ATTEMPTS  = 5;
const PULSEPOINT_LOGIN_LOCKOUT_SECS  = 900;   // 15 minutes
const PULSEPOINT_LOGIN_MAX_PW_LENGTH = 1024;  // defensive cap, bcrypt itself caps at 72 bytes

add_action('wp_ajax_nopriv_pulsepoint_user_login', 'pulsepoint_user_login');
add_action('wp_ajax_pulsepoint_user_login', 'pulsepoint_user_login');

/**
 * Build the transient key used for login rate limiting.
 */
function pulsepoint_login_rl_key(string $identifier, string $ip): string {
    return 'pp_login_rl_' . md5(strtolower(trim($identifier)) . '|' . $ip);
}

/**
 * Get current failed-attempt count for this identifier+IP.
 */
function pulsepoint_login_get_attempts(string $identifier, string $ip): int {
    $val = get_transient(pulsepoint_login_rl_key($identifier, $ip));
    return $val ? (int) $val : 0;
}

/**
 * Record a failed attempt, refreshing the lockout window.
 */
function pulsepoint_login_record_failure(string $identifier, string $ip): void {
    $key = pulsepoint_login_rl_key($identifier, $ip);
    $attempts = pulsepoint_login_get_attempts($identifier, $ip) + 1;
    set_transient($key, $attempts, PULSEPOINT_LOGIN_LOCKOUT_SECS);
}

/**
 * Clear the failure counter (called on successful login).
 */
function pulsepoint_login_clear_attempts(string $identifier, string $ip): void {
    delete_transient(pulsepoint_login_rl_key($identifier, $ip));
}

/**
 * Load and render the shared email template.
 * Template path: /templates/login.html relative to the plugin root.
 * Supported placeholders: {{platform_name}} {{heading}} {{firstname}}
 * {{message}} {{year}} {{support_email}} {{color_hex}}
 */
function pulsepoint_render_email_template(array $vars): string {
    $template_path = dirname(__DIR__) . '/templates/login.html';

    if (!file_exists($template_path)) {
        // Fallback so email sending never hard-fails if the template is missing.
        return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
    }

    $html = file_get_contents($template_path);

    $defaults = [
        'platform_name'  => 'Pulsepoint',
        'heading'        => '',
        'firstname'      => '',
        'message'        => '',
        'year'           => date('Y'),
        'support_email'  => get_option('admin_email'),
        'color_hex'      => '#6C63FF',
    ];

    $vars = array_merge($defaults, $vars);

    foreach ($vars as $key => $value) {
        // 'message' is allowed to carry pre-built safe HTML (line breaks etc);
        // everything else is escaped as plain text.
        $safe = $key === 'message'
            ? $value
            : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');

        $html = str_replace('{{' . $key . '}}', $safe, $html);
    }

    return $html;
}

/**
 * Fetch branding settings (platform name / color) used in emails.
 */
function pulsepoint_get_branding(\wpdb $wpdb, string $base_prefix): array {
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    return [
        'platform_name' => $settings['platform_name'] ?? 'Pulsepoint',
        'color_hex'     => $settings['color_hex'] ?? '#6C63FF',
    ];
}

function pulsepoint_user_login() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    $email_or_phone = isset($_POST['email']) ? sanitize_text_field(wp_unslash($_POST['email'])) : '';
    $password       = isset($_POST['password']) ? (string) wp_unslash($_POST['password']) : '';

    $user_ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'unknown');

    if (empty($email_or_phone) || empty($password)) {
        wp_send_json(['success' => false, 'message' => 'Email or Phone Number and Password are required.']);
    }

    if (strlen($password) > PULSEPOINT_LOGIN_MAX_PW_LENGTH) {
        wp_send_json(['success' => false, 'message' => 'Invalid login credentials.']);
    }

    // === Brute-force check (before touching the DB) ===
    $attempts = pulsepoint_login_get_attempts($email_or_phone, $user_ip);
    if ($attempts >= PULSEPOINT_LOGIN_MAX_ATTEMPTS) {
        wp_send_json([
            'success' => false,
            'message' => 'Too many login attempts. Please try again in a few minutes.'
        ]);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM `{$table}` WHERE (`email` = %s OR `phone` = %s) LIMIT 1", $email_or_phone, $email_or_phone)
    );

    if (!$user) {
        pulsepoint_login_record_failure($email_or_phone, $user_ip);
        wp_send_json(['success' => false, 'message' => 'Invalid login credentials.']);
    }

    if ((int) $user->close_account === 1) {
        wp_send_json(['success' => false, 'message' => 'Your account is pending deletion and cannot login.']);
    }

    $branding = pulsepoint_get_branding($wpdb, $wpdb->prefix . 'pulsepoint_');

    // ===============================
    // STATUS CONTROL
    // ===============================
    switch ((int) $user->status) {
        case 0: // Suspended → email + block
            @wp_mail(
                $user->email,
                'Account Suspended Notice',
                pulsepoint_render_email_template([
                    'platform_name' => $branding['platform_name'],
                    'color_hex'     => $branding['color_hex'],
                    'heading'       => 'Account Suspended',
                    'firstname'     => $user->firstname,
                    'message'       => 'Your account has been suspended. If you believe this is a mistake, please contact support.',
                ]),
                ['Content-Type: text/html; charset=UTF-8']
            );

            wp_send_json([
                'success' => false,
                'message' => 'Your account has been suspended.'
            ]);
            break;

        case 2: // Inactive
            wp_send_json([
                'success' => false,
                'message' => 'Inactive account.'
            ]);
            break;
    }

    // Password check ONLY for active users
    if (!password_verify($password, $user->password)) {
        pulsepoint_login_record_failure($email_or_phone, $user_ip);
        wp_send_json(['success' => false, 'message' => 'Incorrect password.']);
    }

    // Successful auth — clear any failure counter for this identifier/IP
    pulsepoint_login_clear_attempts($email_or_phone, $user_ip);

    // Transparently upgrade the password hash if the algorithm/cost has changed
    if (password_needs_rehash($user->password, PASSWORD_DEFAULT)) {
        $wpdb->update($table, [
            'password' => password_hash($password, PASSWORD_DEFAULT)
        ], ['id' => $user->id]);
    }

    // Generate token/passcode
    $update_data = [];

    if (empty($user->token)) {
        $update_data['token'] = bin2hex(random_bytes(16));
    }

    if (empty($user->passcode)) {
        $update_data['passcode'] = random_int(1000, 9999);
    }

    if (!empty($update_data)) {
        $wpdb->update($table, $update_data, ['id' => $user->id]);
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $user->id));
    }

    // === Session handling (fixation-safe) ===
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    // New authenticated identity → rotate the session ID.
    session_regenerate_id(true);

    $_SESSION['pulsepoint_user'] = [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode
    ];

    setcookie('pulsepoint_user_session', session_id(), [
        'expires'  => time() + 86400,
        'path'     => '/',
        'domain'   => $_SERVER['SERVER_NAME'] ?? '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    $login_time = date('Y-m-d H:i:s');

    // ===============================
    // EMAIL CONTROL + REDIRECT LOGIC
    // ===============================

    if ((int) $user->status_email === 1) {

        @wp_mail(
            $user->email,
            'New Login Activity on Your Account',
            pulsepoint_render_email_template([
                'platform_name' => $branding['platform_name'],
                'color_hex'     => $branding['color_hex'],
                'heading'       => 'New Login Detected',
                'firstname'     => $user->firstname,
                'message'       => sprintf(
                    'A new login was detected on your account.<br><br><strong>Date:</strong> %s<br><strong>IP:</strong> %s<br><strong>Device:</strong> %s<br><br>If this was not you, please secure your account immediately.',
                    htmlspecialchars($login_time, ENT_QUOTES, 'UTF-8'),
                    htmlspecialchars($user_ip, ENT_QUOTES, 'UTF-8'),
                    htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Device', ENT_QUOTES, 'UTF-8')
                ),
            ]),
            ['Content-Type: text/html; charset=UTF-8']
        );

        wp_send_json([
            'success' => true,
            'message' => 'Login successful.',
            'redirect' => site_url('/app/dashboard'),
            'user' => $_SESSION['pulsepoint_user']
        ]);
    }

    // status_email = 0 → NO EMAIL + SEND TO VERIFICATION
    wp_send_json([
        'success' => true,
        'message' => 'Login successful. Please verify your account.',
        'redirect' => site_url('/app/verification'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}

// ===============================
// GOOGLE LOGIN
// ===============================
add_action('wp_ajax_nopriv_pulsepoint_google_login', 'pulsepoint_google_login');
add_action('wp_ajax_pulsepoint_google_login', 'pulsepoint_google_login');

function pulsepoint_google_login() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    $id_token = isset($_POST['id_token'])
        ? sanitize_text_field(wp_unslash($_POST['id_token']))
        : (isset($_POST['credential']) ? sanitize_text_field(wp_unslash($_POST['credential'])) : '');

    if (empty($id_token)) {
        wp_send_json(['success' => false, 'message' => 'Google ID token is required.']);
    }

    $google_url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($id_token);
    $response   = wp_remote_get($google_url);

    if (is_wp_error($response)) {
        wp_send_json(['success' => false, 'message' => 'Unable to verify Google token.']);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!isset($data['email_verified']) || $data['email_verified'] != 'true') {
        wp_send_json(['success' => false, 'message' => 'Google email not verified.']);
    }

    // Google's own audience/client-id check should be added here if not already
    // enforced elsewhere (compare $data['aud'] against your OAuth client ID) to
    // stop tokens issued for a *different* app from being accepted.

    $email     = sanitize_email($data['email']);
    $firstname = sanitize_text_field($data['given_name'] ?? '');
    $lastname  = sanitize_text_field($data['family_name'] ?? '');

    if (!is_email($email)) {
        wp_send_json(['success' => false, 'message' => 'Invalid Google account email.']);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `email` = %s LIMIT 1", $email));

    if (!$user) {
        $wpdb->insert($table, [
            'firstname'    => $firstname,
            'lastname'     => $lastname,
            'email'        => $email,
            'password'     => password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT),
            'status'       => 1,
            'status_email' => 1,
            'wallet'       => 0.00,
            'created_at'   => current_time('mysql', 1)
        ]);

        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $wpdb->insert_id));
    }

    if ((int) $user->close_account === 1) {
        wp_send_json(['success' => false, 'message' => 'Your account is pending deletion and cannot login.']);
    }

    if ((int) $user->status === 0) {
        wp_send_json(['success' => false, 'message' => 'Your account has been suspended.']);
    }

    if ((int) $user->status === 2) {
        wp_send_json(['success' => false, 'message' => 'Inactive account.']);
    }

    // Ensure token/passcode exist, same as the normal login path
    $update_data = [];
    if (empty($user->token)) {
        $update_data['token'] = bin2hex(random_bytes(16));
    }
    if (empty($user->passcode)) {
        $update_data['passcode'] = random_int(1000, 9999);
    }
    if (!empty($update_data)) {
        $wpdb->update($table, $update_data, ['id' => $user->id]);
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $user->id));
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    session_regenerate_id(true);

    // FIX: only store the same trimmed-down shape used by normal login —
    // never the raw DB row (it previously leaked the password hash into
    // the session and the JSON response).
    $_SESSION['pulsepoint_user'] = [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode
    ];

    setcookie('pulsepoint_user_session', session_id(), [
        'expires'  => time() + 86400,
        'path'     => '/',
        'domain'   => $_SERVER['SERVER_NAME'] ?? '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    wp_send_json([
        'success' => true,
        'message' => 'Login successful via Google.',
        'redirect' => site_url('/app/dashboard'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}
