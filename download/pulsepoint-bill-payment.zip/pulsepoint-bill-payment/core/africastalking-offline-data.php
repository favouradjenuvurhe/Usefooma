<?php
/**
 * UseFooma Africa's Talking Offline Data integration.
 * Uses the existing pulsepoint_users, pulsepoint_data, pulsepoint_provider
 * and pulsepoint_trnx tables and the existing data provider functions.
 */
if (!defined('ABSPATH')) exit;

if (!function_exists('usefooma_offline_data_settings')) {
    function usefooma_offline_data_settings(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'pulsepoint_settings';
        $rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table}");
        $settings = [];
        foreach ((array) $rows as $row) {
            $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
        }
        return $settings;
    }
}

if (!function_exists('usefooma_offline_data_normalize_phone')) {
    function usefooma_offline_data_normalize_phone(string $phone): string {
        $digits = preg_replace('/\D+/', '', $phone);
        if (str_starts_with($digits, '234') && strlen($digits) === 13) {
            return '0' . substr($digits, 3);
        }
        if (strlen($digits) === 10) return '0' . $digits;
        if (strlen($digits) === 11 && $digits[0] === '0') return $digits;
        return '';
    }
}

if (!function_exists('usefooma_offline_data_verify_signature')) {
    function usefooma_offline_data_verify_signature(string $body, string $signature, string $timestamp, string $secret, int $max_age = 300): bool {
        if ($secret === '' || $signature === '' || $timestamp === '' || !ctype_digit($timestamp)) return false;
        if (abs(time() - (int) $timestamp) > $max_age) return false;
        $expected = 'sha256=' . hash_hmac('sha256', $timestamp . '.' . $body, $secret);
        return hash_equals($expected, $signature);
    }
}

if (!function_exists('usefooma_offline_data_get_header')) {
    function usefooma_offline_data_get_header(string $name): string {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        if (isset($_SERVER[$key])) return trim((string) $_SERVER[$key]);
        if (function_exists('getallheaders')) {
            foreach ((array) getallheaders() as $header => $value) {
                if (strcasecmp($header, $name) === 0) return trim((string) $value);
            }
        }
        return '';
    }
}

if (!function_exists('usefooma_offline_data_log')) {
    /**
     * Create one webhook diagnostic row. Raw payloads, signatures and API keys
     * are deliberately never stored.
     */
    function usefooma_offline_data_log(array $data): int {
        global $wpdb;
        $table = $wpdb->prefix . 'pulsepoint_voicebip_logs';
        $now = current_time('mysql');
        $row = [
            'event_id' => sanitize_text_field((string) ($data['event_id'] ?? '')),
            'event_type' => sanitize_key((string) ($data['event_type'] ?? '')),
            'channel' => sanitize_key((string) ($data['channel'] ?? '')),
            'call_id' => sanitize_text_field((string) ($data['call_id'] ?? '')),
            'caller' => sanitize_text_field((string) ($data['caller'] ?? '')),
            'number' => sanitize_text_field((string) ($data['number'] ?? '')),
            'signature_valid' => !empty($data['signature_valid']) ? 1 : 0,
            'customer_id' => max(0, (int) ($data['customer_id'] ?? 0)),
            'plan_id' => max(0, (int) ($data['plan_id'] ?? 0)),
            'transaction_id' => max(0, (int) ($data['transaction_id'] ?? 0)),
            'status' => sanitize_key((string) ($data['status'] ?? 'received')),
            'message' => sanitize_textarea_field((string) ($data['message'] ?? '')),
            'response_code' => max(100, min(999, (int) ($data['response_code'] ?? 200))),
            'payload_hash' => preg_match('/^[a-f0-9]{64}$/', (string) ($data['payload_hash'] ?? '')) ? (string) $data['payload_hash'] : '',
            'received_at' => (string) ($data['received_at'] ?? $now),
            'updated_at' => $now,
        ];
        $ok = $wpdb->insert($table, $row, [
            '%s','%s','%s','%s','%s','%s','%d','%d','%d','%d','%s','%s','%d','%s','%s','%s'
        ]);
        return $ok ? (int) $wpdb->insert_id : 0;
    }
}

if (!function_exists('usefooma_offline_data_update_log')) {
    function usefooma_offline_data_update_log(int $log_id, array $data): void {
        if ($log_id <= 0) return;
        global $wpdb;
        $table = $wpdb->prefix . 'pulsepoint_voicebip_logs';
        $allowed = [
            'event_id','event_type','channel','call_id','caller','number','signature_valid',
            'customer_id','plan_id','transaction_id','status','message','response_code','payload_hash'
        ];
        $update = [];
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $data)) continue;
            if (in_array($key, ['signature_valid','customer_id','plan_id','transaction_id','response_code'], true)) {
                $update[$key] = (int) $data[$key];
            } elseif ($key === 'status' || $key === 'event_type' || $key === 'channel') {
                $update[$key] = sanitize_key((string) $data[$key]);
            } elseif ($key === 'message') {
                $update[$key] = sanitize_textarea_field((string) $data[$key]);
            } elseif ($key === 'payload_hash') {
                $update[$key] = preg_match('/^[a-f0-9]{64}$/', (string) $data[$key]) ? (string) $data[$key] : '';
            } else {
                $update[$key] = sanitize_text_field((string) $data[$key]);
            }
        }
        if (!$update) return;
        $update['updated_at'] = current_time('mysql');
        $wpdb->update($table, $update, ['id' => $log_id]);
    }
}

if (!function_exists('usefooma_offline_data_process_data')) {
    /**
     * Purchase one configured offline-data bundle using the existing data
     * provider/transaction/wallet infrastructure.
     */
    function usefooma_offline_data_process_data(object $user, object $plan, string $phone, string $event_id, string $call_id): array {
        global $wpdb;
        $base = $wpdb->prefix . 'pulsepoint_';
        $users = $base . 'users';
        $trnx = $base . 'trnx';
        $settings = usefooma_offline_data_settings();

        $api_mode = $settings['api_mode'] ?? 'live';
        $max_amount = isset($settings['data_max_amount']) && (float) $settings['data_max_amount'] > 0
            ? (float) $settings['data_max_amount'] : 50000.00;
        $plan_amount = (float) $plan->amount;
        $fee_enabled = ($settings['offline_data_fee_enabled'] ?? '0') === '1';
        $fee_type = ($settings['offline_data_fee_type'] ?? 'flat') === 'percent' ? 'percent' : 'flat';
        $fee_value = max(0, (float) ($settings['offline_data_fee'] ?? 0));
        $service_fee = $fee_enabled ? ($fee_type === 'percent' ? round($plan_amount * $fee_value / 100, 2) : $fee_value) : 0.0;
        $amount = round($plan_amount + $service_fee, 2);
        $buy_amount = (float) $plan->purchase;
        $network = strtoupper((string) $plan->network);
        $api_plan = $plan->plan;
        $phone = usefooma_offline_data_normalize_phone($phone);

        if ($phone === '') return ['success' => false, 'message' => 'Invalid configured receiving number.'];
        if ($plan_amount <= 0 || $amount <= 0 || $plan_amount > $max_amount) return ['success' => false, 'message' => 'Configured data plan is not available.'];

        $provider = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$base}provider WHERE id=%d", (int) $plan->provider
        ));
        if (!$provider) return ['success' => false, 'message' => 'Configured data provider is unavailable.'];

        $api_name = strtolower(trim((string) $provider->name));
        $api_token = trim((string) $provider->token);
        $api_value = maybe_unserialize($provider->value);
        $api_file = PULSEPOINT_DIR . 'core/data/' . $api_name . '.php';
        if (!is_file($api_file)) return ['success' => false, 'message' => 'Configured data provider is unavailable.'];
        require_once $api_file;
        if (!function_exists('send_data')) return ['success' => false, 'message' => 'Configured data provider is unavailable.'];

        $reference = 'ATOFF_' . preg_replace('/[^A-Za-z0-9_-]/', '', $event_id);
        if ($reference === 'ATOFF_') $reference = 'ATOFF_' . bin2hex(random_bytes(8));

        $wpdb->query('START TRANSACTION');
        $locked = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE id=%d FOR UPDATE", (int) $user->id));
        if (!$locked || (int) $locked->status !== 1) {
            $wpdb->query('ROLLBACK');
            return ['success' => false, 'message' => 'Customer account is inactive.'];
        }

        $daily_limit = (float) ($settings['africas_talking_daily_limit'] ?? 0);
        if ($daily_limit > 0) {
            $start = current_time('Y-m-d') . ' 00:00:00';
            $end = current_time('Y-m-d') . ' 23:59:59';
            $spent = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(amount),0) FROM {$trnx}
                 WHERE user_id=%d AND reference LIKE 'ATOFF_%'
                 AND type='debit' AND category='data' AND status IN ('success','pending')
                 AND date BETWEEN %s AND %s",
                (int) $user->id, $start, $end
            ));
            if (($spent + $amount) > $daily_limit) {
                $wpdb->query('ROLLBACK');
                return ['success' => false, 'message' => 'Daily Offline Data limit reached.'];
            }
        }

        $wallet = (float) $locked->wallet;
        $referral = (float) $locked->referral_balance;
        if ($api_mode === 'live' && ($wallet + $referral) < $amount) {
            $wpdb->query('ROLLBACK');
            return ['success' => false, 'message' => 'Insufficient wallet balance.'];
        }

        $description = sprintf('%s (%s - %s) — Offline Data', $plan->details, $plan->type, $network);
        $details = [
            'source' => 'africastalking_offline_data',
            'africastalking_event_id' => $event_id,
            'africastalking_call_id' => $call_id,
            'network' => $network,
            'plan' => $api_plan,
            'plan_amount' => $plan_amount,
            'service_fee' => $service_fee,
            'service_fee_type' => $fee_type,
            'service_fee_value' => $fee_value,
            'phone' => $phone,
            'wallet_used' => 0,
            'referral_used' => 0,
        ];

        $wpdb->insert($trnx, [
            'user_id' => (int) $user->id,
            'details' => wp_json_encode($details),
            'recipient' => $phone,
            'amount' => $amount,
            'reference' => $reference,
            'payment' => 'wallet',
            'category' => 'data',
            'status' => 'pending',
            'type' => 'debit',
            'session' => 'africastalking:' . $call_id,
            'description' => $description,
        ], ['%d','%s','%s','%f','%s','%s','%s','%s','%s','%s','%s']);
        $trnx_id = (int) $wpdb->insert_id;
        if (!$trnx_id) {
            $wpdb->query('ROLLBACK');
            return ['success' => false, 'message' => 'Transaction initialization failed.'];
        }
        $wpdb->query('COMMIT');

        $api_response = send_data($network, $api_plan, $phone, $buy_amount, $api_token, $api_value, $reference, $trnx_id);
        $status = !empty($api_response['success']) ? 'success' : 'failed';
        $wallet_used = 0.0;
        $referral_used = 0.0;
        $wallet_debited = false;

        if (in_array($status, ['success','pending'], true) && $api_mode === 'live') {
            $wpdb->query('START TRANSACTION');
            $locked_user = $wpdb->get_row($wpdb->prepare("SELECT wallet, referral_balance FROM {$users} WHERE id=%d FOR UPDATE", (int) $user->id));
            if (!$locked_user) {
                $wpdb->query('ROLLBACK');
                return ['success' => false, 'message' => 'Wallet could not be verified.'];
            }
            $live_wallet = (float) $locked_user->wallet;
            $live_referral = (float) $locked_user->referral_balance;
            if (($live_wallet + $live_referral) < $amount) {
                $wpdb->query('ROLLBACK');
                $wpdb->update($trnx, ['status'=>'failed','gateway_response'=>wp_json_encode(['message'=>'Insufficient balance at final debit']),'updated_at'=>current_time('mysql')], ['id'=>$trnx_id]);
                return ['success'=>false,'message'=>'Insufficient wallet balance.'];
            }
            // Same wallet-first/referral-second model as the existing data purchase handler.
            $wallet_used = min($live_wallet, $amount);
            $referral_used = round($amount - $wallet_used, 2);
            $updated = $wpdb->query($wpdb->prepare(
                "UPDATE {$users} SET wallet=wallet-%f, referral_balance=referral_balance-%f WHERE id=%d AND wallet>=%f AND referral_balance>=%f",
                $wallet_used, $referral_used, (int) $user->id, $wallet_used, $referral_used
            ));
            if ($updated !== 1) {
                $wpdb->query('ROLLBACK');
                return ['success'=>false,'message'=>'Wallet balance changed. Please try again.'];
            }
            $wallet_debited = true;
            $details['wallet_used'] = $wallet_used;
            $details['referral_used'] = $referral_used;
            $wpdb->update($trnx, ['details'=>wp_json_encode($details)], ['id'=>$trnx_id]);
            $wpdb->query('COMMIT');

            if ($status === 'success' && function_exists('pulsepoint_credit_cashback') && (float) $plan->cashback > 0) {
                pulsepoint_credit_cashback((int) $user->id, (float) $plan->cashback, 'data', $reference, 'Cashback — ' . $plan->details);
            }
        }

        if ($status === 'failed' && $api_mode === 'live' && $wallet_debited) {
            $wpdb->query('START TRANSACTION');
            $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f, referral_balance=referral_balance+%f WHERE id=%d", $wallet_used, $referral_used, (int) $user->id));
            $wpdb->query('COMMIT');
        }

        $wpdb->update($trnx, [
            'status' => $status,
            'gateway_response' => wp_json_encode($api_response['details'] ?? []),
            'updated_at' => current_time('mysql'),
            'details' => wp_json_encode($details),
        ], ['id' => $trnx_id]);

        if ($status === 'success' && function_exists('pulsepoint_save_beneficiary')) {
            pulsepoint_save_beneficiary((int) $user->id, 'data', $phone, $phone, $network, ['network'=>$network]);
        }

        return [
            'success' => in_array($status, ['success','pending'], true),
            'status' => $status,
            'message' => $api_response['message'] ?? $status,
            'reference' => $reference,
            'transaction_id' => $trnx_id,
            'event_id' => $event_id,
            'call_id' => $call_id,
        ];
    }
}

if (!function_exists('usefooma_africastalking_xml_response')) {
    function usefooma_africastalking_xml_response($message = '') {
        status_header(200);
        nocache_headers();
        header('Content-Type: text/xml; charset=utf-8');
        $xml = '<?xml version="1.0" encoding="UTF-8"?><Response>';
        if ($message !== '') $xml .= '<Say>' . esc_html($message) . '</Say>';
        $xml .= '<Reject/></Response>';
        echo $xml;
    }
}

if (!function_exists('usefooma_africastalking_webhook')) {
    function usefooma_africastalking_webhook() {
        $settings = usefooma_offline_data_settings();
        if (($settings['africas_talking_enabled'] ?? '0') !== '1') {
            usefooma_africastalking_xml_response();
            return;
        }
        global $wpdb;
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
            usefooma_africastalking_xml_response();
            return;
        }
        $input = wp_unslash($_POST);
        if (!is_array($input) || !$input) {
            $raw = (string) file_get_contents('php://input');
            parse_str($raw, $input);
        }
        $caller_raw = sanitize_text_field((string) ($input['callerNumber'] ?? ''));
        $number = sanitize_text_field((string) ($input['destinationNumber'] ?? ''));
        $session_id = sanitize_text_field((string) ($input['sessionId'] ?? ''));
        $direction = sanitize_text_field((string) ($input['direction'] ?? ''));
        $call_state = sanitize_text_field((string) ($input['callSessionState'] ?? ''));
        $active = sanitize_text_field((string) ($input['isActive'] ?? ''));
        $caller = usefooma_offline_data_normalize_phone($caller_raw);
        $call_id = $session_id !== '' ? $session_id : ('AT_' . md5(uniqid('', true)));
        $event_id = $session_id !== '' ? 'AT_' . $session_id . '_' . ($call_state ?: 'incoming') : $call_id;
        $log_id = usefooma_offline_data_log([
            'event_id'=>$event_id, 'event_type'=>$call_state ?: 'incoming', 'channel'=>'voice',
            'call_id'=>$call_id, 'caller'=>$caller, 'number'=>$number, 'status'=>'received',
            'message'=>"Africa's Talking voice callback received.", 'response_code'=>200,
            'payload_hash'=>hash('sha256', wp_json_encode($input)),
        ]);
        if (strcasecmp($direction, 'Inbound') !== 0 || ($active !== '' && $active !== '1')) {
            usefooma_offline_data_update_log($log_id, ['status'=>'ignored','message'=>'Non-active inbound event ignored.']);
            usefooma_africastalking_xml_response(); return;
        }
        $configured = trim((string) ($settings['africas_talking_number'] ?? ''));
        if ($configured !== '' && $number !== '' && usefooma_offline_data_normalize_phone($number) !== usefooma_offline_data_normalize_phone($configured)) {
            usefooma_offline_data_update_log($log_id, ['status'=>'wrong_number','message'=>'Destination number does not match configured service number.']);
            usefooma_africastalking_xml_response(); return;
        }
        if ($caller === '') {
            usefooma_offline_data_update_log($log_id, ['status'=>'incomplete','message'=>'Caller number missing or invalid.']);
            usefooma_africastalking_xml_response(); return;
        }
        $key = 'AT:' . $call_id;
        if (class_exists('UseFooma\\Security\\IdempotencyService')) {
            $claim = \UseFooma\Security\IdempotencyService::claim('africas_talking_offline_data', $key, 0, defined('DAY_IN_SECONDS') ? DAY_IN_SECONDS : 86400);
            if (empty($claim['owner'])) {
                usefooma_offline_data_update_log($log_id, ['status'=>'duplicate','message'=>'Duplicate call session ignored.']);
                usefooma_africastalking_xml_response(); return;
            }
        }
        $users = $wpdb->prefix . 'pulsepoint_users';
        $last10 = substr($caller, 1);
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE status=1 AND (phone=%s OR phone=%s OR phone LIKE %s) LIMIT 1", $caller, '234'.$last10, '%'.$last10));
        if (!$user) {
            usefooma_offline_data_update_log($log_id, ['status'=>'unregistered','message'=>'Caller is not a registered customer.']);
            if (class_exists('UseFooma\\Security\\IdempotencyService')) \UseFooma\Security\IdempotencyService::complete('africas_talking_offline_data',$key,['processed'=>false]);
            usefooma_africastalking_xml_response(); return;
        }
        usefooma_offline_data_update_log($log_id, ['customer_id'=>(int)$user->id]);
        $plan_id = (int) ($user->offline_data_plan_id ?? 0);
        if ((int)$user->offline_data_enabled !== 1 || $plan_id <= 0) {
            usefooma_offline_data_update_log($log_id, ['status'=>'not_configured','message'=>'Offline Data is not configured for this customer.','plan_id'=>$plan_id]);
            if (class_exists('UseFooma\\Security\\IdempotencyService')) \UseFooma\Security\IdempotencyService::complete('africas_talking_offline_data',$key,['processed'=>false]);
            usefooma_africastalking_xml_response(); return;
        }
        $network = strtoupper((string) ($user->offline_data_network ?? ''));
        $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pulsepoint_data WHERE id=%d AND network=%s AND status='active' LIMIT 1", $plan_id, $network));
        if (!$plan) {
            usefooma_offline_data_update_log($log_id, ['status'=>'plan_unavailable','message'=>'Configured data plan is unavailable.','plan_id'=>$plan_id]);
            if (class_exists('UseFooma\\Security\\IdempotencyService')) \UseFooma\Security\IdempotencyService::complete('africas_talking_offline_data',$key,['processed'=>false]);
            usefooma_africastalking_xml_response(); return;
        }
        usefooma_offline_data_update_log($log_id, ['plan_id'=>$plan_id]);
        $result = usefooma_offline_data_process_data($user, $plan, (string)($user->offline_data_phone ?? ''), $event_id, $call_id);
        $success = !empty($result['success']);
        usefooma_offline_data_update_log($log_id, ['status'=>$success ? ($result['status'] ?? 'success') : 'failed','message'=>(string)($result['message'] ?? ''),'transaction_id'=>(int)($result['transaction_id'] ?? 0)]);
        if (class_exists('UseFooma\\Security\\IdempotencyService')) {
            if ($success) \UseFooma\Security\IdempotencyService::complete('africas_talking_offline_data',$key,$result);
            else \UseFooma\Security\IdempotencyService::fail('africas_talking_offline_data',$key,$result);
        }
        usefooma_africastalking_xml_response();
    }
}
