<?php
/**
 * Pulsepoint Profile Edit
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/profile/edit.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$table_users = $wpdb->prefix . 'pulsepoint_users';

// ----------------------------
// Edit Phone Only
// ----------------------------
add_action('wp_ajax_pulsepoint_edit_phone', 'pulsepoint_edit_phone');
add_action('wp_ajax_nopriv_pulsepoint_edit_phone', 'pulsepoint_edit_phone');

function pulsepoint_edit_phone() {
    global $wpdb;
    $table_users = $wpdb->prefix . 'pulsepoint_users';

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success'=>false,'message'=>'Invalid request method.']);
    }

    if (!session_id()) session_start();
    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success'=>false,'message'=>'User not logged in.']);
    }

    $user_id = $_SESSION['pulsepoint_user']['id'];

    // Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success'=>false,'message'=>'User not active or found.']);
    }

    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    if (empty($phone)) {
        wp_send_json(['success'=>false,'message'=>'Phone cannot be empty.']);
    }

    // Check uniqueness
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_users} WHERE phone=%s AND id != %d", $phone, $user_id));
    if ($exists) {
        wp_send_json(['success'=>false,'message'=>'Phone already in use.']);
    }

    $updated = $wpdb->update($table_users, ['phone'=>$phone,'updated_at'=>current_time('mysql')], ['id'=>$user_id], ['%s','%s'], ['%d']);
    if ($updated !== false) {
        wp_send_json(['success'=>true,'message'=>'Phone updated successfully.','phone'=>$phone]);
    } else {
        wp_send_json(['success'=>false,'message'=>'Failed to update phone.']);
    }
}

// ----------------------------
// Edit Other Safe Fields
// ----------------------------
add_action('wp_ajax_pulsepoint_edit_profile', 'pulsepoint_edit_profile');
add_action('wp_ajax_nopriv_pulsepoint_edit_profile', 'pulsepoint_edit_profile');

function pulsepoint_edit_profile() {
    global $wpdb;
    $table_users = $wpdb->prefix . 'pulsepoint_users';

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success'=>false,'message'=>'Invalid request method.']);
    }

    if (!session_id()) session_start();
    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success'=>false,'message'=>'User not logged in.']);
    }

    $user_id = $_SESSION['pulsepoint_user']['id'];

    // Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success'=>false,'message'=>'User not active or found.']);
    }

    // Allowed editable fields
    $fields = [
        'passcode'=>['type'=>'string','max'=>4],
        'password'=>['type'=>'string'],
        'security_question1'=>['type'=>'string'],
        'security_question2'=>['type'=>'string'],
        'security_question3'=>['type'=>'string'],
        'account_limit'=>['type'=>'decimal'],
        'auto_login'=>['type'=>'int'],
        'alert'=>['type'=>'int'],
        'close_account'=>['type'=>'int'],
        'gender'=>['type'=>'enum','options'=>['Male','Female','Other']],
        'dob'=>['type'=>'date'],
        'address'=>['type'=>'string']
    ];

    $update_data = [];
    foreach($fields as $field=>$props){
        if(isset($_POST[$field])){
            $value = sanitize_text_field($_POST[$field]);

            // Validation
            if($field==='passcode' && strlen($value)!==4){
                wp_send_json(['success'=>false,'message'=>'Passcode must be 4 characters.']);
            }
            if($field==='gender' && !in_array($value,$props['options'])){
                wp_send_json(['success'=>false,'message'=>'Invalid gender selected.']);
            }
            if($field==='dob' && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$value)){
                wp_send_json(['success'=>false,'message'=>'Invalid date format (YYYY-MM-DD).']);
            }
            if(in_array($field,['auto_login','alert','close_account'])){
                $value = intval($value);
            }
            if($field==='account_limit'){
                $value = floatval($value);
            }
            if($field==='password'){
                $value = password_hash($value,PASSWORD_DEFAULT);
            }

            $update_data[$field]=$value;
        }
    }

    if(empty($update_data)){
        wp_send_json(['success'=>false,'message'=>'No valid fields to update.']);
    }

    $update_data['updated_at']=current_time('mysql');

    $updated = $wpdb->update($table_users,$update_data,['id'=>$user_id],array_fill(0,count($update_data),'%s'),['%d']);
    if($updated!==false){
        wp_send_json(['success'=>true,'message'=>'Profile updated successfully.','updated_fields'=>$update_data]);
    }else{
        wp_send_json(['success'=>false,'message'=>'Failed to update profile.']);
    }
}