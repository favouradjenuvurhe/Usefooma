<?php
/**
 * XIXAPAY Customer Creation (KYC + File Upload + DB Save + cURL FIXED)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/customer-xixa.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

function pulsepoint_kyc_xixapay() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    // =========================
    // LOG FILE
    // =========================
    $log_file = PULSEPOINT_DIR . 'core/log-xixa.txt';

    function xixa_log($message, $file) {

        $timestamp = date('Y-m-d H:i:s');

        file_put_contents(
            $file,
            "[$timestamp] $message\n",
            FILE_APPEND
        );
    }

    xixa_log("==== XIXA CUSTOMER CREATE START ====", $log_file);

    // =========================
    // REQUEST METHOD
    // =========================
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

        xixa_log("Invalid request method", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method'
        ]);
    }

    // =========================
    // SESSION CHECK
    // =========================
    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {

        xixa_log("Session expired", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Session expired'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    // =========================
// FIX: TABLE DEFINITIONS (REQUIRED)
// =========================
$base_prefix    = $wpdb->prefix . 'pulsepoint_';
$user_table     = $base_prefix . 'users';
$settings_table = $base_prefix . 'settings';

    // =========================
// GET USER
// =========================
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$user_table} WHERE id = %d LIMIT 1",
        $user_id
    )
);

if (!$user) {

    xixa_log("User not found", $log_file);

    wp_send_json([
        'success' => false,
        'message' => 'User not found'
    ]);
}

// =========================
// EXISTING CUSTOMER CHECK
// =========================
$existing_customer_id = trim(
    $user->customerId ?? ''
);

    // =========================
    // API SETTINGS
    // =========================
    $secret_key = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
            'pay_secret'
        )
    );

    $api_key = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
            'pay_token'
        )
    );

    $business_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
            'pay_biz'
        )
    );

    if (
        empty($secret_key) ||
        empty($api_key) ||
        empty($business_id)
    ) {

        xixa_log("Missing API keys", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'XIXAPAY settings not configured'
        ]);
    }

    // =========================
    // SANITIZE INPUT
    // =========================
    $first_name   = sanitize_text_field($_POST['first_name'] ?? '');
    $last_name    = sanitize_text_field($_POST['last_name'] ?? '');
    $email        = sanitize_email($_POST['email'] ?? '');
    $phone        = sanitize_text_field($_POST['phone_number'] ?? '');
    $address      = sanitize_text_field($_POST['address'] ?? '');
    $state        = sanitize_text_field($_POST['state'] ?? '');
    $city         = sanitize_text_field($_POST['city'] ?? '');
    $postal_code  = sanitize_text_field($_POST['postal_code'] ?? '');
    $dob          = sanitize_text_field($_POST['date_of_birth'] ?? '');
    $id_type      = sanitize_text_field($_POST['id_type'] ?? '');
    $id_number    = sanitize_text_field($_POST['id_number'] ?? '');

    // =========================
    // VALIDATION
    // =========================
    if (
        empty($first_name) ||
        empty($last_name) ||
        empty($email) ||
        empty($phone) ||
        empty($address) ||
        empty($state) ||
        empty($city) ||
        empty($postal_code) ||
        empty($dob) ||
        empty($id_type) ||
        empty($id_number)
    ) {

        xixa_log("Missing required fields", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'All fields are required'
        ]);
    }

    // =========================
    // FILE VALIDATION
    // =========================
    if (
        empty($_FILES['id_card']['tmp_name']) ||
        empty($_FILES['utility_bill']['tmp_name'])
    ) {

        xixa_log("Files missing", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'ID card and utility bill are required'
        ]);
    }

    // =========================
    // FILE SIZE CHECK
    // =========================
    if (
        $_FILES['id_card']['size'] > 5 * 1024 * 1024 ||
        $_FILES['utility_bill']['size'] > 5 * 1024 * 1024
    ) {

        xixa_log("File too large", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Files must not exceed 5MB'
        ]);
    }

    // =========================
    // FILE TYPE VALIDATION
    // =========================
    $allowed_types = [
        'image/jpeg',
        'image/png',
        'application/pdf'
    ];

    if (
        !in_array($_FILES['id_card']['type'], $allowed_types) ||
        !in_array($_FILES['utility_bill']['type'], $allowed_types)
    ) {

        xixa_log("Invalid file type", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Only JPG, PNG or PDF allowed'
        ]);
    }

    // =========================
    // CURL CHECK
    // =========================
    if (!function_exists('curl_init')) {

        xixa_log("cURL extension missing", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'PHP cURL extension is disabled'
        ]);
    }

// =========================
// CREATE OR UPDATE
// =========================
$is_update = !empty($existing_customer_id);

$api_url = $is_update
    ? "https://api.xixapay.com/api/customer/update"
    : "https://api.xixapay.com/api/customer/create";

xixa_log(
    $is_update
        ? "Customer exists. Updating KYC."
        : "Customer not found. Creating customer.",
    $log_file
);

// =========================
// REQUEST BODY
// =========================
$body = [

    'first_name'    => $first_name,
    'last_name'     => $last_name,
    'email'         => $email,
    'phone_number'  => $phone,
    'address'       => $address,
    'state'         => $state,
    'city'          => $city,
    'postal_code'   => $postal_code,
    'date_of_birth' => $dob,
    'id_type'       => $id_type,
    'id_number'     => $id_number,
    'businessId'    => $business_id,

    'id_card' => new CURLFile(
        $_FILES['id_card']['tmp_name'],
        $_FILES['id_card']['type'],
        $_FILES['id_card']['name']
    ),

    'utility_bill' => new CURLFile(
        $_FILES['utility_bill']['tmp_name'],
        $_FILES['utility_bill']['type'],
        $_FILES['utility_bill']['name']
    ),
];

    xixa_log("Sending request to XIXAPAY", $log_file);

    // =========================
    // API REQUEST (FIXED)
    // =========================
    $ch = curl_init();

    curl_setopt_array($ch, [

        CURLOPT_URL => $api_url,

        CURLOPT_RETURNTRANSFER => true,

        CURLOPT_POST => true,

        CURLOPT_POSTFIELDS => $body,

        CURLOPT_HTTPHEADER => [

            'Authorization: Bearer ' . $secret_key,

            'api-key: ' . $api_key,
        ],

        CURLOPT_TIMEOUT => 60,

    ]);

    $raw_response = curl_exec($ch);

    $curl_error = curl_error($ch);

    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    curl_close($ch);

    // =========================
    // LOG RESPONSE
    // =========================
    xixa_log("HTTP CODE: " . $http_code, $log_file);

    xixa_log(
        "RAW RESPONSE: " . $raw_response,
        $log_file
    );

    // =========================
    // CURL ERROR
    // =========================
    if ($curl_error) {

        xixa_log(
            "CURL ERROR: " . $curl_error,
            $log_file
        );

        wp_send_json([
            'success' => false,
            'message' => 'cURL Error: ' . $curl_error
        ]);
    }

    // =========================
    // DECODE RESPONSE
    // =========================
    $result = json_decode($raw_response, true);

    if (!$result) {

        xixa_log("Invalid JSON response", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Invalid API response',
            'raw' => $raw_response
        ]);
    }

    // =========================
    // API FAILED
    // =========================
    if (
        !isset($result['status']) ||
        $result['status'] !== true
    ) {

        xixa_log(
            "API FAILURE: " . json_encode($result),
            $log_file
        );

        wp_send_json([
            'success' => false,
            'message' => $result['message'] ?? 'API request failed',
            'response' => $result
        ]);
    }

    // =========================
    // CUSTOMER DATA
    // =========================
    $customer = $result['customer'] ?? [];

$customer_id = sanitize_text_field(
    $customer['customer_id'] ?? ''
);

// If update endpoint doesn't return customer_id
// use existing one already saved
if (empty($customer_id) && !empty($existing_customer_id)) {
    $customer_id = $existing_customer_id;
}

if (empty($customer_id)) {

    xixa_log("Customer ID missing", $log_file);

    wp_send_json([
        'success' => false,
        'message' => 'Customer ID missing from response'
    ]);
}

    // =========================
    // SAVE CUSTOMER ID
    // =========================
    $updated = $wpdb->update(

        $user_table,

        [
            'customerId' => $customer_id
        ],

        [
            'id' => $user_id
        ],

        [
            '%s'
        ],

        [
            '%d'
        ]
    );

    if ($updated === false) {

        xixa_log(
            "DB ERROR: " . $wpdb->last_error,
            $log_file
        );

        wp_send_json([
            'success' => false,
            'message' => 'Customer created but DB save failed',
            'db_error' => $wpdb->last_error
        ]);
    }

    // =========================
    // OPTIONAL KYC STATUS
    // =========================
    $kyc_update = $wpdb->update(

        $user_table,

        [
            'statuskyc' => 1
        ],

        [
            'id' => $user_id
        ],

        [
            '%d'
        ],

        [
            '%d'
        ]
    );

    if ($kyc_update === false) {

        xixa_log(
            "KYC STATUS UPDATE FAILED: " . $wpdb->last_error,
            $log_file
        );

    } else {

        xixa_log(
            "KYC approved for user ID: " . $user_id,
            $log_file
        );
    }

    // =========================
    // SUCCESS LOG
    // =========================
    xixa_log(
        "Customer ID saved: " . $customer_id,
        $log_file
    );

    xixa_log(
        "==== XIXA CUSTOMER CREATE END ====",
        $log_file
    );

    // =========================
    // FINAL RESPONSE
    // =========================
    wp_send_json([

        'success' => true,

        'message' => $result['message'] ?? (
    $is_update
        ? 'Customer updated successfully'
        : 'Customer created successfully'
),

        'customer' => $customer,

        'customerId_saved' => $customer_id,

        'kyc_status' => 1

    ]);
}