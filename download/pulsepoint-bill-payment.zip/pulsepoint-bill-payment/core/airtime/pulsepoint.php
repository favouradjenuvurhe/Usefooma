<?php    
/**    
 * Pulsepoint Airtime Purchase Function    
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/pulsepoint.php    
 * Author: Amaaavl    
 */    
    
if (!defined('ABSPATH')) exit;    
    
// Hook for AJAX requests    
add_action('wp_ajax_nopriv_pulsepoint_airtime_purchase', 'pulsepoint_airtime_purchase');    
add_action('wp_ajax_pulsepoint_airtime_purchase', 'pulsepoint_airtime_purchase');    
    
function pulsepoint_airtime_purchase() {    
    global $wpdb;    
    
    header('Content-Type: application/json; charset=utf-8');    
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {    
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);    
    }    
    
    if (!session_id()) session_start();    
    
    if (!isset($_SESSION['pulsepoint_user']['id'])) {    
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);    
    }    
    
    $user_id     = $_SESSION['pulsepoint_user']['id'];    
    $table_users = $wpdb->prefix . 'pulsepoint_users';    
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';    
    $base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
    /* =====================================================    
       SECURITY LOGGING FUNCTION (NO NEW TABLE)    
    ====================================================== */    
    $log_security = function($event, $meta = []) use ($wpdb, $base_prefix) {    
        $wpdb->insert(    
            "{$base_prefix}logs",    
            [    
                'event'      => $event,    
                'meta'       => json_encode($meta),    
                'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',    
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',    
                'created_at' => current_time('mysql')    
            ],    
            ['%s','%s','%s','%s','%s']    
        );    
    };    
    
    // Rate limiter    
    $now = time();    
    if (isset($_SESSION['last_airtime_request'][$user_id]) && ($now - $_SESSION['last_airtime_request'][$user_id]) < 15) {    
        $log_security('rate_limited', ['user'=>$user_id]);    
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);    
    }    
    $_SESSION['last_airtime_request'][$user_id] = $now;    
    
    // Fetch user (LOCKED)    
    $wpdb->query('START TRANSACTION');    
    
    $user = $wpdb->get_row(    
        $wpdb->prepare(    
            "SELECT * FROM `{$table_users}` WHERE id=%d FOR UPDATE",    
            $user_id    
        )    
    );    
    
    if (!$user || $user->status != 1) {    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);    
    }    
    
    // Fetch settings    
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
    $settings = [];    
    foreach ($settings_rows as $row) {    
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
    }    
    
    $maintenance_mode = $settings['maintenance_mode'] ?? '0';    
    $api_mode         = $settings['api_mode'] ?? 'live';    
    $airtime_api      = $settings['airtime_api'] ?? 'adex';    
    $airtime_token    = $settings['airtime_token'] ?? '';    

    // ✅ NEW: KYC SETTING
    $require_kyc = isset($settings['airtime_kyc']) && $settings['airtime_kyc'] == 1;
    
    // ✅ NEW: KYC CHECK (LIKE BANK)
    if ($require_kyc && $user->statuskyc != 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }
    
    if ($maintenance_mode == '1') {    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);    
    }    
    
    // Sanitize inputs    
    $network   = isset($_POST['network']) ? strtoupper(trim($_POST['network'])) : '';    
    $phone     = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';    
    $amount    = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;    
    $reference = isset($_POST['reference']) ? sanitize_text_field($_POST['reference']) : '';    
    
    /* =====================================================    
       STRICT AMOUNT RULE (₦50 MINIMUM)    
    ====================================================== */    
    if ($api_mode === 'live' && $user->wallet < $amount) {

    $needed = $amount - $user->wallet;

    $log_security('wallet_insufficient', [
        'user'   => $user_id,
        'amount' => $amount
    ]);

    $wpdb->query('ROLLBACK');

    wp_send_json([
        'success' => false,
        'message' => 'You need ₦' . number_format($needed, 2) . ' more to proceed.'
    ]);
}

// Minimum airtime check second
if ($amount < 100) {

    $needed = 50 - $amount;

    $wpdb->query('ROLLBACK');

    wp_send_json([
        'success' => false,
        'message' => 'Minimum airtime purchase is ₦100.'
    ]);
}    
    
    if (empty($network) || empty($phone) || $amount <= 0) {    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success' => false, 'message' => 'Network, Phone, and Amount are required.']);    
    }    
    
    if (empty($reference)) {    
        $reference = 'PSNG' . bin2hex(random_bytes(6));    
    }    
    
    /* =====================================================    
       IDEMPOTENCY + UNIQUE REFERENCE ENFORCEMENT    
    ====================================================== */    
    $exists = $wpdb->get_var(    
        $wpdb->prepare(    
            "SELECT id FROM {$table_trnx} WHERE reference=%s LIMIT 1",    
            $reference    
        )    
    );    
    
    if ($exists) {    
        $log_security('duplicate_reference_blocked', [    
            'user'=>$user_id,    
            'reference'=>$reference    
        ]);    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success'=>false,'message'=>'Duplicate transaction blocked']);    
    }    
    
    // Description created ONCE    
    $description = "Airtime {$network} - Direct";    
    
    // ✅ UPDATED DAILY LIMIT (ONLY SUCCESS)
    $today_start = date('Y-m-d 00:00:00');    
    $today_end   = date('Y-m-d 23:59:59');    
    $spent_today = $wpdb->get_var($wpdb->prepare(    
        "SELECT SUM(amount) FROM {$table_trnx}     
         WHERE user_id=%d     
         AND date BETWEEN %s AND %s     
         AND type='debit'     
         AND category='airtime'
         AND status='success'
         FOR UPDATE",    
        $user_id, $today_start, $today_end    
    )) ?: 0;    
    
    $account_limit = $user->account_limit ?: 5000;    
    
    if (($spent_today + $amount) > $account_limit) {    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success'=>false,'message'=>"Daily Max ₦{$account_limit} per day"]);    
    }    
    
    // Wallet check (LOCKED, NO NATIVE RACE)    
    if ($api_mode === 'live' && $user->wallet < $amount) {    
        $log_security('wallet_insufficient', ['user'=>$user_id,'amount'=>$amount]);    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success'=>false,'message'=>"Insufficient wallet balance"]);    
    }    
    
    /* =====================================================    
       INSERT PENDING (SAFE)    
    ====================================================== */    
    $wpdb->insert($table_trnx, [    
        'user_id'     => $user_id,    
        'details'     => json_encode(['network'=>$network,'phone'=>$phone]),    
        'recipient'   => $phone,    
        'amount'      => $amount,    
        'reference'   => $reference,    
        'payment'     => 'wallet',    
        'category'    => 'airtime',    
        'status'      => 'pending',    
        'type'        => 'debit',    
        'session'     => session_id(),    
        'description' => $description    
    ], ['%d','%s','%s','%f','%s','%s','%s','%s','%s','%s','%s']);    
    
    $trnx_id = $wpdb->insert_id;    
    
    if (!$trnx_id) {    
        $wpdb->query('ROLLBACK');    
        wp_send_json(['success'=>false,'message'=>'Transaction initialization failed']);    
    }    
    
    $wpdb->query('COMMIT');    
    
    /* =====================================================    
       API CALL (OUTSIDE TRANSACTION)    
    ====================================================== */    
    
    $api_file = __DIR__ . '/' . strtolower($airtime_api) . '.php';    
    if (!file_exists($api_file)) wp_send_json(['success'=>false,'message'=>"Airtime API handler not found"]);    
    require_once $api_file;    
    if (!function_exists('send_airtime')) wp_send_json(['success'=>false,'message'=>"Function not implemented"]);    
    
    $wallet_debited = false;    
    
    $api_response = send_airtime($network,$amount,$phone,$airtime_token,$reference,$trnx_id);    
    
    $status = ($api_response['success'] ?? false) ? 'success' : 'failed';    
    
    // Final wallet debit (LOCKED)    
    if ($status==='success' && $api_mode==='live') {    
        $wpdb->query('START TRANSACTION');    
    
        $wpdb->query(    
            $wpdb->prepare(    
                "UPDATE {$table_users}     
                 SET wallet = wallet - %f     
                 WHERE id=%d AND wallet >= %f",    
                $amount, $user_id, $amount    
            )    
        );    
    
        if ($wpdb->rows_affected !== 1) {    
            $wpdb->query('ROLLBACK');    
            $log_security('wallet_race_blocked',['user'=>$user_id]);    
            wp_send_json(['success'=>false,'message'=>'Balance integrity violation blocked']);    
        }    
    
        $wallet_debited = true;    
    
        $wpdb->query('COMMIT');    
    }    
    
    /* =====================================================    
       AUTO-REFUND ON FAILED API (FAIL-SAFE)    
    ====================================================== */    
    if ($status === 'failed' && $api_mode === 'live' && $wallet_debited === true) {    
    
        $wpdb->query('START TRANSACTION');    
    
        $wpdb->query(    
            $wpdb->prepare(    
                "UPDATE {$table_users} SET wallet = wallet + %f WHERE id=%d",    
                $amount, $user_id    
            )    
        );    
    
        $wpdb->update(    
            $table_trnx,    
            [    
                'status'     => 'failed',    
                'updated_at' => current_time('mysql')    
            ],    
            ['id'=>$trnx_id],    
            ['%s','%s'],    
            ['%d']    
        );    
    
        $wpdb->query('COMMIT');    
    
        $log_security('auto_refund_executed', [    
            'user'      => $user_id,    
            'amount'    => $amount,    
            'reference' => $reference,    
            'trnx_id'   => $trnx_id    
        ]);    
    }    
    
    $wpdb->update($table_trnx, [    
        'status'           => $status,    
        'gateway_response' => json_encode($api_response['details'] ?? []),    
        'updated_at'       => current_time('mysql')    
    ], ['id'=>$trnx_id], ['%s','%s','%s'], ['%d']);    
    
    wp_send_json([    
        'success'    => $status==='success',    
        'message'    => $api_response['message'] ?? 'Airtime purchase failed.',    
        'reference'  => $reference,    
        'details'    => $api_response['details'] ?? [],    
        'description'=> $description    
    ]);    
}