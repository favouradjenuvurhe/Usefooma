<?php
/**
 * Pulsepoint Electricity Purchase Function (Bill + Verification + Fee + KYC + Secure Limit)
 */

if (!defined('ABSPATH')) exit;

// AJAX Hooks
add_action('wp_ajax_nopriv_pulsepoint_electricity_purchase', 'pulsepoint_electricity_purchase');
add_action('wp_ajax_pulsepoint_electricity_purchase', 'pulsepoint_electricity_purchase');

function pulsepoint_electricity_purchase() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id      = $_SESSION['pulsepoint_user']['id'];
    $table_users  = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx   = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix  = $wpdb->prefix . 'pulsepoint_';
    $table_bill   = $base_prefix . 'bill';

    // 15 Seconds Limit
    $now = time();
    if (isset($_SESSION['last_electricity_request'][$user_id]) && ($now - $_SESSION['last_electricity_request'][$user_id]) < 15) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);
    }
    $_SESSION['last_electricity_request'][$user_id] = $now;

    // Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    /** ---------------------------------------------
     *  LOAD SETTINGS (🔥 ADDED)
     * --------------------------------------------- */
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $require_kyc = isset($settings['bill_kyc']) && $settings['bill_kyc'] == 1;

    /** ---------------------------------------------
     *  KYC CHECK (🔥 ADDED)
     * --------------------------------------------- */
    if ($require_kyc && $user->statuskyc != 1) {
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }

    /** ---------------------------------------------
     *  SANITIZE INPUTS
     * --------------------------------------------- */
    $disco        = sanitize_text_field($_POST['disco'] ?? '');
    $meter_type   = sanitize_text_field($_POST['meter_type'] ?? '');
    $meter_number = sanitize_text_field($_POST['meter_number'] ?? '');
    $amount       = floatval($_POST['amount'] ?? 0);
    $bypass       = isset($_POST['bypass']) ? boolval($_POST['bypass']) : false;
    $request_id   = sanitize_text_field($_POST['request_id'] ?? '');
    $reference    = $request_id ?: 'PSNG' . mt_rand(10000,99999) . 'E';

    if (empty($disco) || empty($meter_type) || empty($meter_number) || $amount <= 0) {
        wp_send_json(['success'=>false, 'message'=>'All fields are required and amount must be > 0']);
    }

    /** ---------------------------------------------
     *  FETCH PLAN & FEE
     * --------------------------------------------- */
    $bill = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_bill} WHERE details=%s LIMIT 1",
        $disco
    ));

    if (!$bill) {
        wp_send_json(['success'=>false, 'message'=>'Invalid Disco / Plan not found']);
    }

    $plan_name  = $bill->plan;
    $fee        = floatval($bill->fee);
    $provider   = $bill->provider;

    /** ---------------------------------------------
     *  VERIFY METER
     * --------------------------------------------- */
    $disco_map = [
        'IKEDC'=>1,'EKEDC'=>2,'KEDC'=>3,'PHED'=>4,'JED'=>5,'IBEDC'=>6,
        'KEDCO'=>7,'AEDC'=>8,'BEDC'=>9,'EEDC'=>10,'ABA'=>11,'YEDC'=>12
    ];

    $disco_id = $disco_map[$disco] ?? 0;

    $verify_url = "https://mansurdata.net/api/bill/bill-validation?meter_number={$meter_number}&disco={$disco_id}&meter_type={$meter_type}";
    $response = wp_remote_get($verify_url);

    if (is_wp_error($response)) {
        wp_send_json(['success'=>false,'message'=>'Verification failed']);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($data['status']) || $data['status'] !== 'success') {
        wp_send_json(['success'=>false,'message'=>'Meter verification failed']);
    }

    /** ---------------------------------------------
     *  DAILY LIMIT (🔥 FIXED)
     * --------------------------------------------- */
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');

    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount + fee) FROM {$table_trnx} 
         WHERE user_id=%d 
         AND date BETWEEN %s AND %s 
         AND type='debit'
         AND category='electricity'
         AND status='success'
         FOR UPDATE",
        $user_id, $today_start, $today_end
    )) ?: 0;

    $limit = $user->account_limit ?: 5000;

    if (($spent_today + $amount + $fee) > $limit) {
        wp_send_json(['success'=>false,'message'=>"Daily Max ₦{$limit} reached"]);
    }

    /** ---------------------------------------------
     *  WALLET CHECK
     * --------------------------------------------- */
    if ($user->wallet < ($amount + $fee)) {
        wp_send_json(['success'=>false,'message'=>'Insufficient balance']);
    }

    /** ---------------------------------------------
     *  LOG REQUEST
     * --------------------------------------------- */
    $log_data = [
        'user_id'=>$user_id,
        'disco'=>$disco,
        'plan'=>$plan_name,
        'meter_type'=>$meter_type,
        'meter_number'=>$meter_number,
        'amount'=>$amount,
        'fee'=>$fee,
        'bypass'=>$bypass,
        'reference'=>$reference,
        'timestamp'=>date('Y-m-d H:i:s')
    ];

    file_put_contents(__DIR__.'/log.txt', json_encode($log_data).PHP_EOL, FILE_APPEND);

    /** ---------------------------------------------
     *  LOAD PROVIDER
     * --------------------------------------------- */
    $safe_provider = preg_replace('/[^a-z0-9]/i','',$provider);
    $api_file = __DIR__ . "/{$safe_provider}.php";

    if (!file_exists($api_file)) {
        wp_send_json(['success'=>false,'message'=>'Provider API file missing']);
    }

    require_once $api_file;

    if (!function_exists('send_electricity')) {
        wp_send_json(['success'=>false,'message'=>'send_electricity() missing']);
    }

    /** ---------------------------------------------
     *  INSERT TRANSACTION
     * --------------------------------------------- */
    $description = "Electricity - {$disco} - {$meter_type} - {$plan_name}";

    $wpdb->insert($table_trnx, [
        'user_id'=>$user_id,
        'details'=>json_encode($log_data),
        'recipient'=>$meter_number,
        'amount'=>$amount,
        'fee'=>$fee,
        'reference'=>$reference,
        'payment'=>'wallet',
        'category'=>'electricity',
        'status'=>'pending',
        'type'=>'debit',
        'session'=>session_id(),
        'description'=>$description
    ]);

    $trnx_id = $wpdb->insert_id;

    /** ---------------------------------------------
     *  CALL API
     * --------------------------------------------- */
    try {
        $api_response = send_electricity($disco, $plan_name, $meter_type, $meter_number, $amount, $bypass, $reference, $trnx_id);
    } catch(Exception $e) {
        wp_send_json(['success'=>false,'message'=>'Provider Error']);
    }

    $status = (!empty($api_response['success'])) ? 'success' : 'failed';

    /** ---------------------------------------------
     *  UPDATE TRANSACTION
     * --------------------------------------------- */
    $wpdb->update($table_trnx, [
        'status'=>$status,
        'gateway_response'=>json_encode($api_response),
        'updated_at'=>current_time('mysql')
    ], ['id'=>$trnx_id]);

    /** ---------------------------------------------
     *  DEDUCT WALLET
     * --------------------------------------------- */
    $new_wallet = $user->wallet;

    if ($status === 'success') {
        $new_wallet -= ($amount + $fee);
        $wpdb->update($table_users, ['wallet'=>$new_wallet], ['id'=>$user_id]);
    }

    wp_send_json([
        'success'=>$status === 'success',
        'message'=>$api_response['message'] ?? 'Electricity purchase completed',
        'new_wallet'=>$new_wallet,
        'reference'=>$reference
    ]);
}