<?php            
/**            
 * Secure Register Function for Pulsepoint Plugin            
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/register.php            
 * Author: Amaaavl            
 */            
            
if (!defined('ABSPATH')) {            
    exit; // Prevent direct file access            
}            
            
// ==========================
// REGULAR USER REGISTRATION
// ==========================
add_action('wp_ajax_nopriv_pulsepoint_user_register', 'pulsepoint_user_register');            
add_action('wp_ajax_pulsepoint_user_register', 'pulsepoint_user_register');            
            
function pulsepoint_user_register() {            
    global $wpdb;            
            
    header('Content-Type: application/json; charset=utf-8');            
            
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {            
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);            
    }            
            
    // Sanitize inputs            
    $firstname = isset($_POST['firstname']) ? sanitize_text_field($_POST['firstname']) : '';            
    $lastname  = isset($_POST['lastname']) ? sanitize_text_field($_POST['lastname']) : '';            
    $phone     = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';            
    $password  = isset($_POST['password']) ? $_POST['password'] : '';            
    $passcode  = isset($_POST['passcode']) ? sanitize_text_field($_POST['passcode']) : '';            
    $email     = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';            
    $refer     = isset($_POST['refer']) ? sanitize_text_field($_POST['refer']) : '';            
            
    // Required fields check            
    if (empty($firstname) || empty($lastname) || empty($phone) || empty($password) || empty($passcode)) {            
        wp_send_json(['success' => false, 'message' => 'Firstname, lastname, phone, password and passcode are required.']);            
    }            
            
    // Normalize phone            
    $phone = preg_replace('/\s+/', '', $phone);            
    $phone = preg_replace('/[^0-9+]/', '', $phone);            
            
    // Validate passcode            
    if (!preg_match('/^\d{4}$/', $passcode)) {            
        wp_send_json(['success' => false, 'message' => 'Passcode must be exactly 4 digits.']);            
    }            
            
    $weak_passcodes = ['1234','1111','0000','1212','9999','4321','0001','2580'];            
    if (in_array($passcode, $weak_passcodes, true)) {            
        wp_send_json(['success' => false, 'message' => 'Passcode is too weak.']);            
    }            
            
    // Email fallback            
    if (empty($email)) {            
        $email = preg_replace('/^\+/', '', $phone) . '@pulsepoint.ng';            
        $email = sanitize_email($email);            
    }            
            
    $base_prefix = $wpdb->prefix . 'pulsepoint_';            
    $table = $base_prefix . 'users';            
            
    // Check duplicates            
    $existing = $wpdb->get_row(            
        $wpdb->prepare("SELECT * FROM `{$table}` WHERE `phone` = %s OR `email` = %s LIMIT 1", $phone, $email)            
    );            
            
    if ($existing) {            
        if ($existing->phone === $phone) wp_send_json(['success' => false, 'message' => 'Phone number already registered.']);            
        if ($existing->email === $email) wp_send_json(['success' => false, 'message' => 'Email already registered.']);            
        wp_send_json(['success' => false, 'message' => 'Account already exists.']);            
    }            
            
    // Handle referral if provided (using uniqueid or phone)            
    $referby_id = null;            
    if (!empty($refer)) {            
        $referby = $wpdb->get_row(            
            $wpdb->prepare("SELECT id FROM `{$table}` WHERE phone = %s OR uniqueid = %s LIMIT 1", $refer, $refer)            
        );            
        if ($referby) $referby_id = $referby->id;            
    }            
            
    // Generate token            
    $prefix = 'PS-NG';            
    $random_len = 30 - strlen($prefix);            
    $pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';            
    $rand = '';            
    for ($i = 0; $i < $random_len; $i++) {            
        $rand .= $pool[random_int(0, strlen($pool) - 1)];            
    }            
    $token = $prefix . $rand;            
            
    // Hash password            
    $password_hash = password_hash($password, PASSWORD_DEFAULT);            
            
    // Load settings            
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");            
    $settings = [];            
    foreach ($settings_rows as $row) {            
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);            
    }            
            
    $account_limit = isset($settings['account_limit']) ? floatval($settings['account_limit']) : 5000.00;            
    $auth_email    = isset($settings['auth_email']) ? intval($settings['auth_email']) : 0;            
            
    // ===== EMAIL VERIFICATION ADDITION =====    
$user_status   = 1;   // default active
$email_status  = 1;   // default email enabled
$security_code = null;

if ($auth_email === 1) {    
    $user_status   = 1;   // must verify first
    $email_status  = 0;   // no login email until verified
    $security_code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);    
}   
    // ===== END ADDITION =====    
            
    // Insert user            
    $inserted = $wpdb->insert(            
        $table,            
        [            
            'firstname'       => $firstname,            
            'lastname'        => $lastname,            
            'phone'           => $phone,            
            'email'           => $email,            
            'wallet'          => 0.00,            
            'referral_balance'=> 0.00,            
            'referby'         => $referby_id,            
            'token'           => $token,            
            'passcode'        => $passcode,            
            'password'        => $password_hash,            
            'security_code'   => $security_code,            
            'account_limit'   => $account_limit,            
            'status'          => $user_status,
            'status_email'          => $email_status,            
            'created_at'      => current_time('mysql', 1),            
            'updated_at'      => current_time('mysql', 1),            
        ],            
        [            
            '%s','%s','%s','%s','%f','%f','%d','%s','%s','%s','%s','%f','%d','%s','%s'            
        ]            
    );            
            
    if ($inserted === false) {            
        wp_send_json(['success' => false, 'message' => 'Registration failed. Please try again later.']);            
    }            
            
    $new_user_id = $wpdb->insert_id;            
            
    // ===== EMAIL OTP SEND =====    
    if ($auth_email === 1) {    
        $platform_name = isset($settings['platform_name']) ? $settings['platform_name'] : 'Pulsepoint';    
    
        $subject = "Verify your {$platform_name} account";    
        $message = "    
        Hi {$firstname},<br><br>    
        Your verification code is:<br><br>    
        <h2>{$security_code}</h2>    
        <br>    
        Enter this code to activate your account.<br><br>    
        Regards,<br>    
        {$platform_name} Team    
        ";    
    
        wp_mail($email, $subject, $message, ['Content-Type: text/html; charset=UTF-8']);    
    
        wp_send_json([    
            'success'  => true,    
            'message'  => 'Verification code sent to your email.',    
            'redirect' => site_url('/app/verification')    
        ]);    
    }    
    // ===== END EMAIL VERIFICATION FLOW =====    
            
    $user = $wpdb->get_row(            
        $wpdb->prepare("SELECT id, firstname, lastname, email, phone, wallet, token, passcode, account_limit FROM `{$table}` WHERE id = %d LIMIT 1", $new_user_id)            
    );            
            
    if (!$user) {            
        wp_send_json(['success' => false, 'message' => 'Registration succeeded but could not retrieve user.']);            
    }            
            
    // Start session            
    if (!session_id()) session_start();            
            
    $_SESSION['pulsepoint_user'] = [            
        'id'            => $user->id,            
        'firstname'     => $user->firstname,            
        'lastname'      => $user->lastname,            
        'email'         => $user->email,            
        'phone'         => $user->phone,            
        'wallet'        => $user->wallet,            
        'token'         => $user->token,            
        'passcode'      => $user->passcode,            
        'account_limit' => $user->account_limit,            
    ];            
            
    // Optional: set cookie            
    setcookie(            
        'pulsepoint_user_session',            
        session_id(),            
        time() + 86400,            
        '/',            
        $_SERVER['SERVER_NAME'],            
        is_ssl(),            
        true            
    );            
            
    wp_send_json([            
        'success' => true,            
        'message' => 'Registration successful.',            
        'redirect' => site_url('/app/dashboard'),            
        'user' => $_SESSION['pulsepoint_user']            
    ]);            
}  

// ==========================================
// GOOGLE SIGN-UP / AUTO-LOGIN
// ==========================================
add_action('wp_ajax_nopriv_pulsepoint_google_signup', 'pulsepoint_google_signup');
add_action('wp_ajax_pulsepoint_google_signup', 'pulsepoint_google_signup');

function pulsepoint_google_signup() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $id_token = isset($_POST['id_token']) ? sanitize_text_field($_POST['id_token']) : (isset($_POST['credential']) ? sanitize_text_field($_POST['credential']) : '');

    if (empty($id_token)) {
        wp_send_json(['success' => false, 'message' => 'Google ID token is required.']);
    }

    $google_url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . $id_token;
    $response   = wp_remote_get($google_url);

    if (is_wp_error($response)) {
        wp_send_json(['success' => false, 'message' => 'Unable to verify Google token.']);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!isset($data['email_verified']) || $data['email_verified'] != 'true') {
        wp_send_json(['success' => false, 'message' => 'Google email not verified.']);
    }

    $email = sanitize_email($data['email']);
    $firstname = sanitize_text_field($data['given_name'] ?? '');
    $lastname  = sanitize_text_field($data['family_name'] ?? '');

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `email` = %s LIMIT 1", $email));

    if (!$user) {
        // Auto-create user
        $token = 'PS-NG' . bin2hex(random_bytes(14));
        $passcode = rand(1000, 9999);

        $wpdb->insert($table, [
            'firstname' => $firstname,
            'lastname'  => $lastname,
            'email'     => $email,
            'passcode'  => $passcode,
            'token'     => $token,
            'password'  => password_hash(bin2hex(random_bytes(6)), PASSWORD_DEFAULT),
            'status'    => 1,
            'wallet'    => 0.00,
            'created_at'=> current_time('mysql', 1)
        ]);

        $user_id = $wpdb->insert_id;
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $user_id));
    }

    if (!session_id()) session_start();

    $_SESSION['pulsepoint_user'] = [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode
    ];

    wp_send_json([
        'success' => true,
        'message' => 'Login successful via Google.',
        'redirect' => site_url('/app/dashboard'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}