<?php
/**
 * Pulsepoint Recharge Printing (Bulk PDF Generator)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/recharge/recharge.php
 */

if (!defined('ABSPATH')) exit;

use Dompdf\Dompdf;

add_action('wp_ajax_nopriv_pulsepoint_recharge', 'pulsepoint_recharge');
add_action('wp_ajax_pulsepoint_recharge', 'pulsepoint_recharge');

function pulsepoint_recharge() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success'=>false,'message'=>'Invalid request method']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success'=>false,'message'=>'User not logged in']);
    }

    $user_id = $_SESSION['pulsepoint_user']['id'];

    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    /* =========================
       SECURITY LOGGER
    ========================= */
    $log_security = function($event,$meta=[]) use ($wpdb,$base_prefix){
        $wpdb->insert(
            "{$base_prefix}logs",
            [
                'event'=>$event,
                'meta'=>json_encode($meta),
                'ip'=>$_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent'=>$_SERVER['HTTP_USER_AGENT'] ?? '',
                'created_at'=>current_time('mysql')
            ],
            ['%s','%s','%s','%s','%s']
        );
    };

    /* =========================
       RATE LIMIT
    ========================= */
    $now = time();
    if (isset($_SESSION['last_recharge'][$user_id]) && ($now - $_SESSION['last_recharge'][$user_id]) < 10) {
        $log_security('rate_limited',['user'=>$user_id]);
        wp_send_json(['success'=>false,'message'=>'Please wait 10 seconds']);
    }
    $_SESSION['last_recharge'][$user_id] = $now;

    /* =========================
       FETCH USER
    ========================= */
    $wpdb->query("START TRANSACTION");

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d FOR UPDATE",$user_id)
    );

    if (!$user || $user->status != 1) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'User not active']);
    }

    /* =========================
       SETTINGS
    ========================= */
    $settings_rows = $wpdb->get_results("SELECT opt_key,opt_value FROM {$base_prefix}settings");
    $settings = [];

    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $require_kyc = $settings['recharge_kyc'] ?? 0;

    if ($require_kyc && $user->statuskyc != 1) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'Complete KYC first']);
    }

    /* =========================
       INPUTS
    ========================= */
    $network = isset($_POST['network']) ? strtoupper(trim($_POST['network'])) : '';
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;
    $name_on_card = isset($_POST['name_on_card']) ? sanitize_text_field($_POST['name_on_card']) : '';
    $amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';

    $valid_amounts = [100,200,500,1000];

    if (!in_array($amount,$valid_amounts)) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'Invalid recharge amount']);
    }

    if (!$network || !$quantity || !$name_on_card || !$email) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'Missing required fields']);
    }

    if ($quantity < 1 || $quantity > 20) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'Invalid quantity']);
    }

    $total_cost = $amount * $quantity;

    if ($user->wallet < $total_cost) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'Insufficient balance']);
    }

    $reference = 'RCG' . bin2hex(random_bytes(6));

    /* =========================
       TRANSACTION INSERT
    ========================= */
    $wpdb->insert($table_trnx,[
        'user_id'=>$user_id,
        'amount'=>$total_cost,
        'reference'=>$reference,
        'category'=>'recharge',
        'type'=>'debit',
        'status'=>'pending',
        'description'=>"Recharge Print {$network} x{$quantity}",
        'date'=>current_time('mysql')
    ]);

    $trnx_id = $wpdb->insert_id;

    if (!$trnx_id) {
        $wpdb->query("ROLLBACK");
        wp_send_json(['success'=>false,'message'=>'Transaction failed']);
    }

    $wpdb->query("COMMIT");

    /* =========================
       CALL PROVIDER FILE
    ========================= */
    $api_file = __DIR__ . '/provider.php';
    require_once $api_file;

    if (!function_exists('send_recharge')) {
        wp_send_json(['success'=>false,'message'=>'Provider not ready']);
    }

    $cards = [];

    for ($i=0; $i<$quantity; $i++) {
        $cards[] = send_recharge([
            'network'=>$network,
            'amount'=>$amount,
            'name'=>$name_on_card,
            'reference'=>$reference.'-'.$i
        ]);
    }

    /* =========================
       GENERATE PDF
    ========================= */
    require_once __DIR__ . '/../../libs/dompdf/autoload.inc.php';

    $options = new \Dompdf\Options();
    $options->setDefaultFont('Helvetica');
    $dompdf = new Dompdf($options);

    $html = "<style>body{font-family:Helvetica,sans-serif;} h2{font-family:Helvetica,sans-serif;}</style><h2>Recharge Cards</h2><hr>";

    foreach ($cards as $index=>$card) {
        $code = $card['code'] ?? 'PENDING';
        $serial = $card['serial'] ?? 'PENDING';

        $html .= "
        <div style='padding:10px;border:1px solid #000;margin-bottom:10px'>
            <h3>Card ".($index+1)."</h3>
            <p><b>Network:</b> {$network}</p>
            <p><b>Amount:</b> ₦{$amount}</p>
            <p><b>Name:</b> {$name_on_card}</p>
            <p><b>Serial:</b> {$serial}</p>
            <p><b>PIN:</b> {$code}</p>
        </div>
        ";
    }

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4','portrait');
    $dompdf->render();

    $pdf_output = $dompdf->output();

    $upload_dir = wp_upload_dir();
    $file_path = $upload_dir['path'] . "/recharge_{$reference}.pdf";

    file_put_contents($file_path,$pdf_output);

    /* =========================
       EMAIL PDF
    ========================= */
    $subject = "Your Recharge Cards";
    $message = "Hello {$name_on_card},<br>Your recharge cards are attached.";
    $headers = ['Content-Type: text/html; charset=UTF-8'];

    $mail_sent = wp_mail(
        $email,
        $subject,
        $message,
        $headers,
        [$file_path]
    );

    if (!$mail_sent) {
        $log_security('email_failed',['ref'=>$reference]);
    }

    /* =========================
       FINAL UPDATE
    ========================= */
    $wpdb->update($table_trnx,[
        'status'=>'success',
        'updated_at'=>current_time('mysql')
    ],['id'=>$trnx_id]);

    wp_send_json([
        'success'=>true,
        'message'=>'Recharge cards generated successfully',
        'reference'=>$reference,
        'pdf'=>$file_path
    ]);
}