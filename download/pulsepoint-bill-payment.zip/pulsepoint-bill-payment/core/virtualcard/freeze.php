<?php
/**
 * Freeze or Unfreeze Virtual Card
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/freeze.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_card_action', 'pulsepoint_card_action');
add_action('wp_ajax_nopriv_pulsepoint_card_action', 'pulsepoint_card_action');

function pulsepoint_card_action() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';
    function pulsepoint_freeze_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }

    pulsepoint_freeze_log("==== Card Freeze/Unfreeze Request Started ====", $log_file);

    // Ensure POST method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    // Start session
    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        pulsepoint_freeze_log("Session expired or user not logged in", $log_file);
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $user_table = $base_prefix . 'users';
    $settings_table = $base_prefix . 'settings';

    // Get user and card data
    $user = $wpdb->get_row($wpdb->prepare("SELECT id, cardid FROM {$user_table} WHERE id = %d LIMIT 1", $user_id));
    if (!$user || empty($user->cardid)) {
        pulsepoint_freeze_log("User or Card ID not found", $log_file);
        wp_send_json(['success' => false, 'message' => 'No card found for this user.']);
    }

    $card_id = sanitize_text_field($_POST['card_id'] ?? $user->cardid);
    $action = sanitize_text_field($_POST['action_type'] ?? 'freeze'); // 'freeze' or 'unfreeze'

    // Validate action
    if (!in_array($action, ['freeze', 'unfreeze'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid action type.']);
    }

    // Get Strowallet public key
    $public_key = $wpdb->get_var("SELECT opt_value FROM {$settings_table} WHERE opt_key = 'stropay_pkey' LIMIT 1");
    if (empty($public_key)) {
        pulsepoint_freeze_log("Public key missing", $log_file);
        wp_send_json(['success' => false, 'message' => 'Strowallet public key not configured.']);
    }

    // Build API request
    $api_url = "https://strowallet.com/api/bitvcard/action/status/?action={$action}&card_id={$card_id}&public_key={$public_key}";
    pulsepoint_freeze_log("Requesting API URL: $api_url", $log_file);

    $response = wp_remote_post($api_url, [
        'headers' => ['accept' => 'application/json'],
        'timeout' => 40,
    ]);

    if (is_wp_error($response)) {
        pulsepoint_freeze_log("API Error: " . $response->get_error_message(), $log_file);
        wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet API.']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    pulsepoint_freeze_log("API Response: " . json_encode($body), $log_file);

    if (empty($body) || !isset($body['success'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid API response.']);
    }

    if ($body['success'] === true) {
        pulsepoint_freeze_log("Card {$action} successful for {$card_id}", $log_file);
        wp_send_json([
            'success' => true,
            'message' => ucfirst($action) . " successful.",
            'response' => $body
        ]);
    } else {
        pulsepoint_freeze_log("Card {$action} failed: " . ($body['message'] ?? 'Unknown error'), $log_file);
        wp_send_json([
            'success' => false,
            'message' => $body['message'] ?? "Failed to {$action} card.",
            'response' => $body
        ]);
    }
}
?>