<?php
/**
 * Convert Naira ↔ Dollar Balance for Pulsepoint Plugin (SECURED)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/convert-balance.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_convert_balance', 'pulsepoint_convert_balance');
add_action('wp_ajax_nopriv_pulsepoint_convert_balance', 'pulsepoint_convert_balance');

function pulsepoint_convert_balance() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $log_file = PULSEPOINT_DIR . 'core/convert_log.txt';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $user_table = $base_prefix . 'users';
    $trnx_table = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    // Logging function
    $log_security = function($event, $meta = []) use ($wpdb, $base_prefix) {
        $wpdb->insert(
            "{$base_prefix}logs",
            [
                'event'      => $event,
                'meta'       => json_encode($meta),
                'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'created_at' => current_time('mysql')
            ],
            ['%s','%s','%s','%s','%s']
        );
    };

    function pulsepoint_convert_log($msg, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $msg\n", FILE_APPEND);
    }

    pulsepoint_convert_log("==== Conversion Request Started ====", $log_file);

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    // Rate limiting (15 sec)
    if (!isset($_SESSION['last_convert_request'])) $_SESSION['last_convert_request'] = [];
    $now = time();
    if (isset($_SESSION['last_convert_request'][$user_id]) && ($now - $_SESSION['last_convert_request'][$user_id]) < 15) {
        $log_security('convert_rate_limited', ['user'=>$user_id]);
        wp_send_json(['success'=>false,'message'=>'Please wait 15 seconds before converting again.']);
    }
    $_SESSION['last_convert_request'][$user_id] = $now;

    // Fetch user with locking
    $wpdb->query('START TRANSACTION');
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$user_table} WHERE id=%d FOR UPDATE", $user_id));

    if (!$user || $user->status != 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success'=>false,'message'=>'User not active or found.']);
    }

    // Input
    $direction = sanitize_text_field($_POST['direction'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success'=>false,'message'=>'Invalid amount.']);
    }

    if (!in_array($direction, ['naira_to_dollar', 'dollar_to_naira'])) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success'=>false,'message'=>'Invalid conversion direction.']);
    }

    // Get rates
    $rate_usd = (float) $wpdb->get_var("SELECT opt_value FROM {$settings_table} WHERE opt_key = 'rate_usd'");
    $rate_naira = (float) $wpdb->get_var("SELECT opt_value FROM {$settings_table} WHERE opt_key = 'rate_naira'");
    if (!$rate_usd || !$rate_naira) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success'=>false,'message'=>'Conversion rates not configured.']);
    }

    // Idempotent unique reference
    $reference = sanitize_text_field($_POST['reference'] ?? '');
    if (empty($reference)) {
        $reference = 'CONV-' . strtoupper(bin2hex(random_bytes(6)));
    }

    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$trnx_table} WHERE reference=%s LIMIT 1", $reference));
    if ($exists) {
        $log_security('duplicate_conversion_blocked', ['user'=>$user_id,'reference'=>$reference]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success'=>false,'message'=>'Duplicate transaction blocked']);
    }

    // Conversion logic
    if ($direction === 'naira_to_dollar') {
        if ($user->wallet < $amount) {
            $log_security('convert_insufficient_naira', ['user'=>$user_id,'amount'=>$amount]);
            $wpdb->query('ROLLBACK');
            wp_send_json(['success'=>false,'message'=>'Insufficient Naira wallet balance']);
        }
        $converted = round($amount / $rate_usd, 2);
        $new_wallet = $user->wallet - $amount;
        $new_dollar = $user->dollar + $converted;
        $description = "Converted ₦{$amount} to \${$converted} at rate ₦{$rate_usd}/\$";
    } else {
        if ($user->dollar < $amount) {
            $log_security('convert_insufficient_dollar', ['user'=>$user_id,'amount'=>$amount]);
            $wpdb->query('ROLLBACK');
            wp_send_json(['success'=>false,'message'=>'Insufficient Dollar wallet balance']);
        }
        $converted = round($amount * $rate_naira, 2);
        $new_dollar = $user->dollar - $amount;
        $new_wallet = $user->wallet + $converted;
        $description = "Converted \${$amount} to ₦{$converted} at rate ₦{$rate_naira}/\$";
    }

    // Update user balances (locked)
    $updated = $wpdb->update($user_table, [
        'wallet' => $new_wallet,
        'dollar' => $new_dollar
    ], ['id'=>$user_id]);

    if (!$updated) {
        $wpdb->query('ROLLBACK');
        $log_security('convert_update_failed', ['user'=>$user_id,'direction'=>$direction,'amount'=>$amount]);
        wp_send_json(['success'=>false,'message'=>'Failed to update balance.']);
    }

    // Record transaction
    $wpdb->insert($trnx_table, [
        'user_id' => $user_id,
        'details' => 'Currency Conversion',
        'recipient' => '-',
        'amount' => $amount,
        'reference' => $reference,
        'payment' => 'wallet',
        'category' => 'conversion',
        'status' => 'success',
        'type' => 'debit',
        'description' => $description,
        'gateway_response' => json_encode(['converted'=>$converted,'direction'=>$direction]),
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql')
    ]);

    $wpdb->query('COMMIT');

    $log_security('conversion_success', ['user'=>$user_id,'amount'=>$amount,'converted'=>$converted,'direction'=>$direction,'reference'=>$reference]);
    pulsepoint_convert_log("Transaction Recorded: " . $description, $log_file);
    pulsepoint_convert_log("==== Conversion Completed ====", $log_file);

    wp_send_json([
        'success' => true,
        'message' => 'Conversion successful.',
        'converted' => $converted,
        'description' => $description,
        'reference' => $reference
    ]);
}
?>