<?php
/**
 * Card Funding for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/fund-card.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_fund_card', 'pulsepoint_fund_card');
add_action('wp_ajax_nopriv_pulsepoint_fund_card', 'pulsepoint_fund_card');

function pulsepoint_fund_card() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';
    function pulsepoint_card_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }

    pulsepoint_card_log("==== Card Funding Started ====", $log_file);

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        pulsepoint_card_log("Session expired or user not found", $log_file);
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $user_table = $base_prefix . 'users';
    $trnx_table = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    // Fetch user
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$user_table} WHERE id = %d LIMIT 1", $user_id));
    if (!$user) {
        pulsepoint_card_log("User not found in DB.", $log_file);
        wp_send_json(['success' => false, 'message' => 'User not found.']);
    }

    // Input sanitization
    $card_id = sanitize_text_field($_POST['card_id'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);

    if (empty($card_id)) {
        wp_send_json(['success' => false, 'message' => 'Card ID is required.']);
    }

    if ($amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Invalid amount.']);
    }

    // Get Strowallet public key
    $public_key = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1", 'stropay_pkey'));
    if (empty($public_key)) {
        wp_send_json(['success' => false, 'message' => 'Strowallet public key not configured.']);
    }

    // Card funding fees
    $flat_fee = (float) $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_funding_flat_fee')) ?: 1.90;
    $percent_fee = (float) $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_funding_percent_fee')) ?: 1.9;
    $total_fee = $flat_fee + ($amount * ($percent_fee / 100));
    $total_deduction = $amount + $total_fee;

    pulsepoint_card_log("Funding Amount: $amount, Flat Fee: $flat_fee, Percent Fee: $percent_fee, Total Deduction: $total_deduction", $log_file);

    if ($user->dollar < $total_deduction) {
        wp_send_json(['success' => false, 'message' => 'Insufficient dollar balance.']);
    }

    // Deduct from user wallet
    $new_balance = $user->dollar - $total_deduction;
    $wpdb->update($user_table, ['dollar' => $new_balance], ['id' => $user_id]);

    // Prepare API request
    $api_url = 'https://strowallet.com/api/bitvcard/fund-card/';
    $params = [
        'card_id'    => $card_id,
        'amount'     => $amount,
        'public_key' => $public_key,
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'accept' => 'application/json',
            'content-type' => 'application/json'
        ],
        'body' => wp_json_encode($params),
        'timeout' => 40,
    ]);

    if (is_wp_error($response)) {
        pulsepoint_card_log("API Error: " . $response->get_error_message(), $log_file);
        wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet API.']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    pulsepoint_card_log("API Response: " . json_encode($body), $log_file);

    if (empty($body) || !isset($body['success'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid API response.']);
    }

    if ($body['success'] !== true) {
        wp_send_json(['success' => false, 'message' => $body['message'] ?? 'Card funding failed.']);
    }

    $api_resp = $body['apiresponse']['data'] ?? [];

    // Record transaction
    $wpdb->insert($trnx_table, [
        'user_id' => $user_id,
        'details' => 'Card Funding',
        'recipient' => $card_id,
        'amount' => $total_deduction,
        'reference' => $api_resp['reference'] ?? '',
        'payment' => 'wallet',
        'category' => 'funding',
        'status' => $api_resp['status'] === true ? 'pending' : 'failed',
        'type' => 'debit',
        'description' => 'Funding card + fees deducted from dollar wallet',
        'gateway_response' => json_encode($body)
    ]);

    pulsepoint_card_log("Funding Transaction Recorded for User #$user_id", $log_file);
    pulsepoint_card_log("==== Card Funding Completed ====", $log_file);

    wp_send_json([
        'success' => true,
        'message' => $body['message'] ?? 'Funding in progress',
        'response' => $api_resp
    ]);
}
?>