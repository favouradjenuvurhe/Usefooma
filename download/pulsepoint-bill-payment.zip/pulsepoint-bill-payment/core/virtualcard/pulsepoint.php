<?php
/**
 * Multi Provider Virtual Card Creation for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/create-card.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_create_card', 'pulsepoint_create_card');
add_action('wp_ajax_nopriv_pulsepoint_create_card', 'pulsepoint_create_card');

function pulsepoint_create_card() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    /**
     * LOG FUNCTION
     */
    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';

    function pulsepoint_card_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }

    pulsepoint_card_log("==== Card Creation Started ====", $log_file);

    /**
     * REQUEST METHOD
     */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    /**
     * SESSION
     */
    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {

        pulsepoint_card_log("Session expired or user not found", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    /**
     * TABLES
     */
    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $base_prefix   = $wpdb->prefix . 'pulsepoint_';
    $user_table    = $base_prefix . 'users';
    $trnx_table    = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    /**
     * USER
     */
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$user_table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user) {

        pulsepoint_card_log("User not found in DB.", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    /**
     * FORM INPUT
     */
    $card_type = sanitize_text_field($_POST['card_type'] ?? '');
    $amount    = floatval($_POST['amount'] ?? 0);

    if (empty($card_type)) {
        wp_send_json([
            'success' => false,
            'message' => 'Please select card type.'
        ]);
    }

    if ($amount < 3) {
        wp_send_json([
            'success' => false,
            'message' => 'Minimum amount is $3.'
        ]);
    }

    /**
     * GET ACTIVE CARD PROVIDER
     * Example:
     * virtualcard_type => strowallet
     */
    $payment_gateway = strtolower(trim(
        $wpdb->get_var(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key='virtualcard_type' LIMIT 1"
        )
    ));

    if (empty($payment_gateway)) {

        wp_send_json([
            'success' => false,
            'message' => 'Virtual card provider not configured.'
        ]);
    }

    pulsepoint_card_log("Selected Gateway: {$payment_gateway}", $log_file);

    /**
     * INCLUDE PROVIDER FILE
     * Example:
     * /core/strowallet.php
     * /core/xixapay.php
     */
    $api_file = __DIR__ . '/gateway/' . strtolower($payment_gateway) . '.php';

    if (!file_exists($api_file)) {

        pulsepoint_card_log("Provider file missing: {$api_file}", $log_file);

        wp_send_json([
            'success' => false,
            'message' => "Virtual card handler not found for '{$payment_gateway}'"
        ]);
    }

    require_once $api_file;

    /**
     * CHECK PROVIDER FUNCTION
     */
    if (!function_exists('create_virtual_card')) {

        pulsepoint_card_log("create_virtual_card() missing in provider file", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'create_virtual_card() not implemented in gateway file'
        ]);
    }

    /**
     * FEES
     */
    $flat_fee = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key='card_creation_flat_fee'"
    );

    $percent_fee = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key='card_creation_percent_fee'"
    );

    $total_fee = $flat_fee + ($amount * ($percent_fee / 100));

    $total_deduction = $amount + $total_fee;

    pulsepoint_card_log(
        "Flat Fee: {$flat_fee}, Percent Fee: {$percent_fee}, Total Deduction: {$total_deduction}",
        $log_file
    );

    /**
     * CHECK BALANCE
     */
    if ($user->dollar < $total_deduction) {

        wp_send_json([
            'success' => false,
            'message' => 'Insufficient dollar balance.'
        ]);
    }

    /**
     * PREPARE PAYLOAD
     */
    $payload = [
        'user_id'    => $user->id,
        'name'       => trim($user->firstname . ' ' . $user->lastname),
        'firstname'  => $user->firstname,
        'lastname'   => $user->lastname,
        'email'      => $user->email,
        'phone'      => $user->phone,
        'amount'     => $amount,
        'card_type'  => $card_type,
        'user'       => $user
    ];

    /**
     * CREATE CARD USING PROVIDER FILE
     */
    $result = create_virtual_card($payload);

    pulsepoint_card_log(
        "Provider Response: " . json_encode($result),
        $log_file
    );

    /**
     * VALIDATE RESPONSE
     */
    if (
        !is_array($result) ||
        !isset($result['success'])
    ) {

        wp_send_json([
            'success' => false,
            'message' => 'Invalid provider response.'
        ]);
    }

    /**
     * API FAILED
     */
    if ($result['success'] !== true) {

        wp_send_json([
            'success' => false,
            'message' => $result['message'] ?? 'Card creation failed.'
        ]);
    }

    /**
     * SUCCESS
     */
    $response = $result['response'] ?? [];

    $card_id = sanitize_text_field(
        $response['card_id'] ??
        $response['id'] ??
        ''
    );

    $reference = sanitize_text_field(
        $response['reference'] ??
        $response['ref'] ??
        uniqid('CARD-')
    );

    $card_status = sanitize_text_field(
        $response['card_status'] ??
        $response['status'] ??
        'pending'
    );

    if (empty($card_id)) {

        wp_send_json([
            'success' => false,
            'message' => 'No card ID returned from provider.'
        ]);
    }

    /**
     * DEDUCT USER FUNDS
     */
    $new_balance = $user->dollar - $total_deduction;

    $wpdb->update(
        $user_table,
        ['dollar' => $new_balance],
        ['id' => $user_id]
    );

    /**
     * SAVE CARD ID
     */
    $wpdb->update(
        $user_table,
        ['cardid' => $card_id],
        ['id' => $user_id]
    );

    /**
     * SAVE TRANSACTION
     */
    $wpdb->insert($trnx_table, [

        'user_id'          => $user_id,
        'details'          => 'Virtual Card Creation (' . $card_type . ')',
        'recipient'        => $card_id,
        'amount'           => $total_deduction,
        'reference'        => $reference,
        'payment'          => 'wallet',
        'category'         => 'funding',
        'status'           => $card_status === 'pending' ? 'pending' : 'success',
        'type'             => 'debit',
        'description'      => 'Card creation fee + amount deducted from dollar wallet',
        'gateway_response' => json_encode($result)

    ]);

    pulsepoint_card_log(
        "CardID saved, Transaction recorded, User #{$user_id}",
        $log_file
    );

    pulsepoint_card_log(
        "==== Card Creation Completed ====",
        $log_file
    );

    /**
     * FINAL RESPONSE
     */
    wp_send_json([

        'success'     => true,
        'message'     => $result['message'] ?? 'Card created successfully.',
        'response'    => $response,
        'provider'    => $payment_gateway,
        'new_balance' => $new_balance

    ]);
}
?>