<?php
/**
 * Multi Provider Virtual Card Creation for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/create-card.php
 * Author: Amaaavl
 *
 * UPDATED: Card creation now deducts from the user's NAIRA wallet balance
 * instead of the DOLLAR balance. The card amount (entered in $) is
 * converted to Naira using the configured rate before deduction.
 * Users no longer need to convert Naira -> Dollar before creating a card.
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_create_card', 'pulsepoint_create_card');
add_action('wp_ajax_nopriv_pulsepoint_create_card', 'pulsepoint_create_card');

/**
 * LOG FUNCTION
 * Guarded with function_exists() because fund.php declares a function
 * with the same name — without the guard, loading both files in the
 * same request causes a fatal "cannot redeclare" error.
 */
if (!function_exists('pulsepoint_card_log')) {
    function pulsepoint_card_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }
}

function pulsepoint_create_card() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $log_file = PULSEPOINT_DIR . 'core/log.txt';

    pulsepoint_card_log("==== Card Creation Started ====", $log_file);

    /**
     * REQUEST METHOD
     */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    /**
     * SESSION
     */
    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {

        pulsepoint_card_log("Session expired or user not found", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    /**
     * TABLES
     */
    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $user_table     = $base_prefix . 'users';
    $trnx_table     = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    /**
     * USER (locked for update since we're about to deduct a balance)
     */
    $wpdb->query('START TRANSACTION');

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$user_table} WHERE id = %d LIMIT 1 FOR UPDATE",
            $user_id
        )
    );

    if (!$user) {

        pulsepoint_card_log("User not found in DB.", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    /**
     * FORM INPUT
     */
    $card_type = sanitize_text_field($_POST['card_type'] ?? '');
    $amount    = floatval($_POST['amount'] ?? 0); // amount is still entered in $

    if (empty($card_type)) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Please select card type.'
        ]);
    }

    if ($amount < 3) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Minimum amount is $3.'
        ]);
    }

    /**
     * GET ACTIVE CARD PROVIDER
     * Example:
     * virtualcard_type => strowallet
     */
    $payment_gateway = strtolower(trim(
        $wpdb->get_var(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key='virtualcard_type' LIMIT 1"
        )
    ));

    if (empty($payment_gateway)) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Virtual card provider not configured.'
        ]);
    }

    pulsepoint_card_log("Selected Gateway: {$payment_gateway}", $log_file);

    /**
     * INCLUDE PROVIDER FILE
     * Example:
     * /core/strowallet.php
     * /core/xixapay.php
     */
    $api_file = __DIR__ . '/gateway/' . strtolower($payment_gateway) . '.php';

    if (!file_exists($api_file)) {

        pulsepoint_card_log("Provider file missing: {$api_file}", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => "Virtual card handler not found for '{$payment_gateway}'"
        ]);
    }

    require_once $api_file;

    /**
     * CHECK PROVIDER FUNCTION
     */
    if (!function_exists('create_virtual_card')) {

        pulsepoint_card_log("create_virtual_card() missing in provider file", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'create_virtual_card() not implemented in gateway file'
        ]);
    }

    /**
     * FEES (still calculated in $, same as before)
     */
    $flat_fee = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key='card_creation_flat_fee'"
    );

    $percent_fee = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key='card_creation_percent_fee'"
    );

    $total_fee = $flat_fee + ($amount * ($percent_fee / 100));

    $total_deduction_usd = $amount + $total_fee;

    /**
     * CONVERT $ DEDUCTION TO NAIRA
     * Uses the same rate_usd used by the Naira -> Dollar conversion flow,
     * since we're effectively "buying" dollars with Naira here.
     */
    $rate_usd = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key = 'rate_usd'"
    );

    if (!$rate_usd) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Conversion rate not configured.'
        ]);
    }

    $total_deduction_naira = round($total_deduction_usd * $rate_usd, 2);

    pulsepoint_card_log(
        "Flat Fee: {$flat_fee}, Percent Fee: {$percent_fee}, Total \$ Deduction: {$total_deduction_usd}, Rate: {$rate_usd}, Total Naira Deduction: {$total_deduction_naira}",
        $log_file
    );

    /**
     * CHECK NAIRA WALLET BALANCE
     */
    if ($user->wallet < $total_deduction_naira) {

        pulsepoint_card_log(
            "Insufficient naira wallet balance for user #{$user_id}. Has: {$user->wallet}, Needs: {$total_deduction_naira}",
            $log_file
        );

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Insufficient wallet balance.'
        ]);
    }

    /**
     * PREPARE PAYLOAD
     */
    $payload = [
        'user_id'    => $user->id,
        'name'       => trim($user->firstname . ' ' . $user->lastname),
        'firstname'  => $user->firstname,
        'lastname'   => $user->lastname,
        'email'      => $user->email,
        'phone'      => $user->phone,
        'amount'     => $amount,
        'card_type'  => $card_type,
        'user'       => $user
    ];

    /**
     * CREATE CARD USING PROVIDER FILE
     */
    $result = create_virtual_card($payload);

    pulsepoint_card_log(
        "Provider Response: " . json_encode($result),
        $log_file
    );

    /**
     * VALIDATE RESPONSE
     */
    if (
        !is_array($result) ||
        !isset($result['success'])
    ) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Invalid provider response.'
        ]);
    }

    /**
     * API FAILED
     */
    if ($result['success'] !== true) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => $result['message'] ?? 'Card creation failed.'
        ]);
    }

    /**
     * SUCCESS
     */
    $response = $result['response'] ?? [];

    $card_id = sanitize_text_field(
        $response['card_id'] ??
        $response['id'] ??
        ''
    );

    $reference = sanitize_text_field(
        $response['reference'] ??
        $response['ref'] ??
        uniqid('CARD-')
    );

    $card_status = sanitize_text_field(
        $response['card_status'] ??
        $response['status'] ??
        'pending'
    );

    if (empty($card_id)) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'No card ID returned from provider.'
        ]);
    }

    /**
     * DEDUCT USER'S NAIRA WALLET
     */
    $new_wallet_balance = $user->wallet - $total_deduction_naira;

    $wpdb->update(
        $user_table,
        ['wallet' => $new_wallet_balance],
        ['id' => $user_id]
    );

    /**
     * SAVE CARD ID
     */
    $wpdb->update(
        $user_table,
        ['cardid' => $card_id],
        ['id' => $user_id]
    );

    /**
     * SAVE TRANSACTION
     */
    $wpdb->insert($trnx_table, [

        'user_id'          => $user_id,
        'details'          => 'Virtual Card Creation (' . $card_type . ')',
        'recipient'        => $card_id,
        'amount'           => $total_deduction_naira,
        'reference'        => $reference,
        'payment'          => 'wallet',
        'category'         => 'funding',
        'status'           => $card_status === 'pending' ? 'pending' : 'success',
        'type'             => 'debit',
        'description'      => "Card creation: \${$amount} card + fee (\${$total_fee}) deducted as ₦{$total_deduction_naira} from Naira wallet at rate ₦{$rate_usd}/\$",
        'gateway_response' => json_encode($result)

    ]);

    $wpdb->query('COMMIT');

    pulsepoint_card_log(
        "CardID saved, Transaction recorded, User #{$user_id}, Naira Deducted: {$total_deduction_naira}",
        $log_file
    );

    pulsepoint_card_log(
        "==== Card Creation Completed ====",
        $log_file
    );

    /**
     * FINAL RESPONSE
     */
    wp_send_json([

        'success'     => true,
        'message'     => $result['message'] ?? 'Card created successfully.',
        'response'    => $response,
        'provider'    => $payment_gateway,
        'new_balance' => $new_wallet_balance

    ]);
}
?>
