<?php
/**
 * Card Withdrawal for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/withdrawal.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_withdraw_card', 'pulsepoint_withdraw_card');
add_action('wp_ajax_nopriv_pulsepoint_withdraw_card', 'pulsepoint_withdraw_card');

function pulsepoint_withdraw_card() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';
    function pulsepoint_withdraw_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }

    pulsepoint_withdraw_log("==== Card Withdrawal Started ====", $log_file);

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        pulsepoint_withdraw_log("Session expired or user not found", $log_file);
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $user_table = $base_prefix . 'users';
    $trnx_table = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    // Fetch user record
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$user_table} WHERE id = %d LIMIT 1", $user_id));
    if (!$user) {
        pulsepoint_withdraw_log("User not found in DB.", $log_file);
        wp_send_json(['success' => false, 'message' => 'User not found.']);
    }

    // Sanitize input
    $card_id = sanitize_text_field($_POST['card_id'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);

    if (empty($card_id)) {
        wp_send_json(['success' => false, 'message' => 'Card ID is required.']);
    }

    if ($amount < 1) {
        wp_send_json(['success' => false, 'message' => 'Minimum withdrawal amount is $1.']);
    }

    // Get Strowallet public key
    $public_key = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1", 'stropay_pkey'));
    if (empty($public_key)) {
        wp_send_json(['success' => false, 'message' => 'Strowallet public key not configured.']);
    }

    // Withdrawal fee configuration
    $flat_fee = (float) $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_withdraw_flat_fee')) ?: 1.00;
    $percent_fee = (float) $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_withdraw_percent_fee')) ?: 1.5;
    $total_fee = $flat_fee + ($amount * ($percent_fee / 100));
    $final_amount = $amount - $total_fee;

    if ($final_amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Withdrawal amount too low after fees.']);
    }

    pulsepoint_withdraw_log("Withdrawal Amount: $amount, Flat Fee: $flat_fee, Percent Fee: $percent_fee, Final: $final_amount", $log_file);

    // Prepare API request
    $api_url = "https://strowallet.com/api/bitvcard/card_withdraw/?card_id={$card_id}&amount={$final_amount}&public_key={$public_key}";

    $response = wp_remote_post($api_url, [
        'headers' => ['accept' => 'application/json'],
        'timeout' => 40,
    ]);

    if (is_wp_error($response)) {
        pulsepoint_withdraw_log("API Error: " . $response->get_error_message(), $log_file);
        wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet API.']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    pulsepoint_withdraw_log("API Response: " . json_encode($body), $log_file);

    if (empty($body) || !isset($body['success'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid API response.']);
    }

    if ($body['success'] !== true) {
        wp_send_json(['success' => false, 'message' => $body['message'] ?? 'Withdrawal failed.']);
    }

    $resp_data = $body['response']['data'] ?? [];

    // Credit user wallet with withdrawn amount (USD)
    $new_balance = $user->dollar + $final_amount;
    $wpdb->update($user_table, ['dollar' => $new_balance], ['id' => $user_id]);

    // Record transaction
    $wpdb->insert($trnx_table, [
        'user_id' => $user_id,
        'details' => 'Card Withdrawal',
        'recipient' => $card_id,
        'amount' => $amount,
        'reference' => $resp_data['reference'] ?? '',
        'payment' => 'card',
        'category' => 'withdrawal',
        'status' => $resp_data['status'] ?? 'pending',
        'type' => 'credit',
        'description' => 'Withdrawal from card credited to dollar wallet',
        'gateway_response' => json_encode($body)
    ]);

    pulsepoint_withdraw_log("Withdrawal Transaction Recorded for User #$user_id", $log_file);
    pulsepoint_withdraw_log("==== Card Withdrawal Completed ====", $log_file);

    wp_send_json([
        'success' => true,
        'message' => $body['message'] ?? 'Withdrawal submitted',
        'reference' => $resp_data['reference'] ?? '',
        'status' => $resp_data['status'] ?? 'pending',
        'response' => $resp_data
    ]);
}
?>