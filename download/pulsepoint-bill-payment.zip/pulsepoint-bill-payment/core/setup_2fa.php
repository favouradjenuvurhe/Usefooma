<?php
/**
 * PulsePoint 2FA Setup
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/setup_2fa.php
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__DIR__) . 'libs/PHPGangsta/GoogleAuthenticator.php';

add_action('wp_ajax_pulsepoint_setup_2fa', 'pulsepoint_setup_2fa');

function pulsepoint_setup_2fa() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    // Check login
    if (!isset($_SESSION['pulsepoint_user'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Login required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    $ga = new PHPGangsta_GoogleAuthenticator();

    // Generate secret if empty
    if (empty($user->twofa_secret)) {

        $secret = $ga->createSecret();

        $wpdb->update(
            $table,
            [
                'twofa_secret' => $secret
            ],
            [
                'id' => $user_id
            ]
        );

    } else {

        $secret = $user->twofa_secret;
    }

    // QR Code
    $company_name = 'Pulsepoint SaaS Limited';

    $qrCodeUrl = $ga->getQRCodeGoogleUrl(
        $company_name . ':' . $user->email,
        $secret,
        $company_name
    );

    wp_send_json([
        'success' => true,
        'message' => '2FA setup generated.',
        'secret' => $secret,
        'qr_code' => $qrCodeUrl
    ]);
}