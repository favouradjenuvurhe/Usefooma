<?php
/**
 * UseFooma theme compatibility layer.
 *
 * Some UseFooma theme builds load this file from the plugin directory before
 * rendering their options. Keep the file intentionally dependency-free so a
 * plugin update can never take the whole WordPress site down because the
 * theme expects this legacy path.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('usefooma_options_schema')) {
    function usefooma_options_schema() {
        return array();
    }
}

if (!isset($usefooma_options_schema) || !is_array($usefooma_options_schema)) {
    $usefooma_options_schema = array();
}
