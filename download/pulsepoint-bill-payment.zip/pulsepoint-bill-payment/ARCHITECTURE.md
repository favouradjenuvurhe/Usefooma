# UseFooma Architecture (2.5.x)

UseFooma remains a real WordPress plugin while introducing a Laravel-style application boundary.

## Application layer

- `app/Core/Application.php` — application bootstrap and service registration.
- `app/Providers/LegacyProvider.php` — compatibility bridge for the existing feature modules.
- `app/Controllers/AdminController.php` — admin menu and panel routing.
- `app/Security/IdempotencyService.php` — database-backed idempotency storage.
- `app/Security/AjaxIdempotencyMiddleware.php` — opt-in idempotency for financial AJAX operations.
- `app/Database/Migrator.php` — versioned application migrations.
- `app/AI/DeepSeekService.php` — server-side DeepSeek intelligence service. AI is advisory only and cannot authorize financial operations.
- `config/config.php` — central application configuration.
- `routes/admin.php` — application admin route registration.

## Financial safety

Financial AJAX actions can send an `Idempotency-Key` HTTP header. The middleware claims the key before the legacy handler executes and stores the JSON response for replay. Existing reference/request_id values are accepted as backward-compatible fallbacks. Requests without an idempotency identifier continue through the legacy path unchanged.

The existing airtime purchase implementation also has explicit idempotency handling and remains compatible with the shared service.

Wallet debits/refunds and provider decisions remain in the existing business logic. The idempotency layer does not replace balance checks, transaction references, provider status handling, KYC, limits, or authorization.

## Runtime-safe paths

The bootstrap defines `USEFOOMA_DIR`, `USEFOOMA_URL`, `PULSEPOINT_DIR`, and `PULSEPOINT_URL` from the actual installed plugin location. Runtime code that previously assumed `/wp-content/plugins/pulsepoint-bill-payment/` has been moved to these constants where identified.

## Legacy compatibility

`core/`, `includes/`, `base/`, `cron/`, and provider adapters remain intact. They are loaded by `legacy-loader.php` in the original dependency order. This is intentional: the application layer can be expanded module-by-module without breaking existing WordPress hooks or provider integrations.

## DeepSeek

Configure `USEFOOMA_DEEPSEEK_API_KEY` server-side. The service is designed for internal intelligence such as classification, diagnostics, summaries, and recommendations. It must never be used as the authority for wallet debits, refunds, transfers, purchases, permissions, or other financial state changes.


## 2.5.2 activation-safe bootstrap
The proven legacy loader is restored in the root bootstrap to preserve WordPress activation/load order. The application layer remains additive: it registers new security services without taking ownership of legacy loading. This avoids activation-time ordering issues while migration continues incrementally.
