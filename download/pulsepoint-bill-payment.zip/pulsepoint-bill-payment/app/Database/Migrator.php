<?php
namespace UseFooma\Database;

if (!defined('ABSPATH')) { exit; }

final class Migrator
{
    private const VERSION = '1.1.3';

    public static function maybeRun(): void
    {
        if (get_option('usefooma_app_db_version') === self::VERSION) {
            return;
        }

        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = $wpdb->prefix . 'pulsepoint_idempotency';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            scope VARCHAR(100) NOT NULL,
            idempotency_key CHAR(64) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'processing',
            response LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            expires_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY scope_key (scope, idempotency_key),
            KEY user_idx (user_id),
            KEY status_idx (status),
            KEY expires_idx (expires_at)
        ) {$charset};";
        dbDelta($sql);

        // Offline Data webhook diagnostics. This stores only delivery/processing
        // metadata (not the raw webhook body or secrets) so administrators can
        // confirm that the Voice callback is actually reaching the callback endpoint.
        $offline_data_logs = $wpdb->prefix . 'pulsepoint_voicebip_logs';
        $offline_data_sql = "CREATE TABLE {$offline_data_logs} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_id VARCHAR(191) NOT NULL DEFAULT '',
            event_type VARCHAR(80) NOT NULL DEFAULT '',
            channel VARCHAR(40) NOT NULL DEFAULT '',
            call_id VARCHAR(191) NOT NULL DEFAULT '',
            caller VARCHAR(40) NOT NULL DEFAULT '',
            number VARCHAR(40) NOT NULL DEFAULT '',
            signature_valid TINYINT(1) NOT NULL DEFAULT 0,
            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            plan_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            transaction_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(40) NOT NULL DEFAULT 'received',
            message TEXT NULL,
            response_code SMALLINT UNSIGNED NOT NULL DEFAULT 200,
            payload_hash CHAR(64) NOT NULL DEFAULT '',
            received_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY event_id_idx (event_id),
            KEY call_id_idx (call_id),
            KEY status_idx (status),
            KEY received_idx (received_at)
        ) {$charset};";
        dbDelta($offline_data_sql);

        // Offline Data uses the existing customer and data-plan tables.
        // These are customer preferences only; no duplicate wallet/plan system is created.
        $users = $wpdb->prefix . 'pulsepoint_users';
        $columns = [
            'offline_data_enabled' => "TINYINT(1) NOT NULL DEFAULT 0",
            'offline_data_phone' => "VARCHAR(30) DEFAULT NULL",
            'offline_data_network' => "VARCHAR(20) DEFAULT NULL",
            'offline_data_plan_id' => "BIGINT UNSIGNED DEFAULT NULL",
            'offline_data_updated_at' => "DATETIME DEFAULT NULL",
        ];
        foreach ($columns as $column => $definition) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s AND COLUMN_NAME=%s",
                DB_NAME, $users, $column
            ));
            if (!$exists) {
                $wpdb->query("ALTER TABLE {$users} ADD COLUMN {$column} {$definition}");
            }
        }

        update_option('usefooma_app_db_version', self::VERSION, false);
    }
}
