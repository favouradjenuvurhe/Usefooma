<?php
namespace UseFooma\Controllers;

if (!defined('ABSPATH')) { exit; }

final class AdminController
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
    }

    public static function menu(): void
    {
        $panelDir = trailingslashit(defined('PULSEPOINT_DIR') ? PULSEPOINT_DIR : plugin_dir_path(dirname(__DIR__, 2))) . 'includes/panel/';
        $iconUrl = defined('PULSEPOINT_URL') ? PULSEPOINT_URL . 'assets/conn/pulsepoint.png' : plugins_url('../../assets/conn/pulsepoint.png', __FILE__);

        add_action('admin_head', static function () {
            echo '<style>#adminmenu .toplevel_page_pulsepoint-dashboard .wp-menu-image img{width:16px!important;height:16px!important;max-width:16px!important;max-height:16px!important;object-fit:contain!important;margin-top:3px!important}</style>';
        });

        add_menu_page(
            'Pulsepoint Dashboard', 'Usefooma', 'manage_options',
            'pulsepoint-dashboard', [self::class, 'render'], $iconUrl, 26
        );

        $pages = [
            'dashboard' => 'Dashboard',
            'configuration' => 'Configuration',
            'transactions' => 'Transactions',
            'customers' => 'Customers',
            'customization' => 'Customization',
            'ai-intelligence' => 'AI Intelligence',
        ];

        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        $isAdmin = in_array('administrator', $roles, true);
        $isEditor = in_array('editor', $roles, true);

        foreach ($pages as $slug => $title) {
            if (!$isAdmin && (!$isEditor || !in_array($slug, ['dashboard', 'transactions', 'customers'], true))) {
                continue;
            }
            add_submenu_page(
                'pulsepoint-dashboard', $title, $title, 'manage_options',
                'pulsepoint-' . $slug, [self::class, 'render']
            );
        }

        /*
         * Register legacy/action pages as hidden admin pages. Using an empty
         * parent keeps them out of the visible UseFooma submenu while still
         * making admin.php?page=pulsepoint-* a real WordPress admin route.
         */
        if (is_dir($panelDir)) {
            foreach (scandir($panelDir) as $file) {
                if (substr($file, -4) !== '.php') continue;
                $slug = basename($file, '.php');
                if (isset($pages[$slug])) continue;

                $menuSlug = 'pulsepoint-' . $slug;
                $title = ucwords(str_replace(['-', '_'], ' ', $slug));
                $hook = add_submenu_page(
                    '',
                    $title,
                    $title,
                    'read',
                    $menuSlug,
                    [self::class, 'render']
                );

                if ($hook) {
                    global $_registered_pages, $_parent_pages;
                    $_registered_pages[$hook] = true;
                    $_parent_pages[$menuSlug] = '';
                }
            }
        }

        do_action('pulsepoint_addon_menu', $isAdmin, $isEditor);
    }

    public static function render(): void
    {
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        $isAdmin = in_array('administrator', $roles, true);
        $isEditor = in_array('editor', $roles, true);
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : 'pulsepoint-dashboard';
        $slug = preg_replace('/^pulsepoint-/', '', $page);

        if ($slug === 'ai-intelligence') {
            if (!$isAdmin || !current_user_can('manage_options')) {
                echo '<div class="wrap"><h1>Access Denied</h1></div>';
                return;
            }
            \UseFooma\Controllers\AIController::render();
            return;
        }

        if (!$isAdmin && (!$isEditor || !in_array($slug, ['dashboard', 'transactions', 'customers'], true))) {
            echo '<div class="wrap"><h1>Access Denied</h1></div>';
            return;
        }

        $base = defined('PULSEPOINT_DIR') ? PULSEPOINT_DIR : plugin_dir_path(dirname(__DIR__, 2));
        $file = trailingslashit($base) . 'includes/panel/' . $slug . '.php';
        if (is_file($file)) {
            include $file;
            return;
        }
        echo '<div class="wrap"><h1>Page Not Found</h1></div>';
    }
}
