<?php
namespace UseFooma\Controllers;

use UseFooma\AI\DeepSeekService;

if (!defined('ABSPATH')) { exit; }

final class AIController
{
    public static function register(): void
    {
        add_action('admin_post_usefooma_ai_analyze', [self::class, 'analyze']);
    }

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.'));
        }

        $service = new DeepSeekService();
        $configured = $service->available();
        $result = get_transient('usefooma_ai_last_result');
        if ($result !== false) delete_transient('usefooma_ai_last_result');
        ?>
        <div class="wrap usefooma-ai-page">
            <h1>UseFooma AI Intelligence</h1>
            <p>Business intelligence that reviews your platform performance, profitability, failures and operational risks.</p>

            <div class="usefooma-ai-grid">
                <div class="usefooma-ai-card">
                    <h2>What it checks</h2>
                    <ul class="usefooma-ai-list">
                        <li><strong>Profitability:</strong> tells you whether the business is actually making money and where margin is strongest or weakest.</li>
                        <li><strong>Growth opportunities:</strong> recommends practical ways to improve revenue, transaction volume and profit.</li>
                        <li><strong>Silent problems:</strong> highlights failures, stuck transactions, zero-profit sales, unusual drops and other issues customers may not have reported.</li>
                        <li><strong>Service health:</strong> identifies categories or providers that may need attention based on transaction behaviour.</li>
                        <li><strong>Action plan:</strong> gives prioritized recommendations instead of only showing raw statistics.</li>
                    </ul>
                    <p><strong>Status:</strong> <?php echo $configured ? '<span style="color:#16803c">Ready</span>' : '<span style="color:#b32d2e">Not configured</span>'; ?></p>
                </div>

                <div class="usefooma-ai-card">
                    <h2>Run intelligence analysis</h2>
                    <p>The analysis uses an aggregated operational summary. It cannot authorize payments, deduct wallets, issue refunds or perform financial actions.</p>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="usefooma_ai_analyze">
                        <?php wp_nonce_field('usefooma_ai_analyze'); ?>
                        <?php submit_button('Analyze My Business', 'primary', 'submit', false); ?>
                    </form>
                    <?php if (is_array($result) && !empty($result['content'])): ?>
                        <div class="usefooma-ai-result"><pre><?php echo esc_html($result['content']); ?></pre></div>
                    <?php elseif (is_array($result) && !empty($result['message'])): ?>
                        <div class="notice notice-error inline"><p><?php echo esc_html($result['message']); ?></p></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <style>
            .usefooma-ai-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:20px;margin-top:20px;max-width:1200px}
            .usefooma-ai-card{background:#fff;border-radius:16px;box-shadow:0 6px 24px rgba(0,0,0,.08);padding:24px}
            .usefooma-ai-card h2{margin-top:0}
            .usefooma-ai-list{margin:0 0 20px 20px;line-height:1.7}
            .usefooma-ai-result{margin-top:20px;background:#f6f7f7;border-radius:12px;padding:16px;overflow:auto}
            .usefooma-ai-result pre{white-space:pre-wrap;margin:0;font:13px/1.6 monospace}
            @media(max-width:900px){.usefooma-ai-grid{grid-template-columns:1fr}}
        </style>
        <?php
    }

    public static function analyze(): void
    {
        if (!current_user_can('manage_options')) wp_die(esc_html__('Sorry, you are not allowed to access this page.'));
        check_admin_referer('usefooma_ai_analyze');

        $service = new DeepSeekService();
        $instruction = 'Act as the private business intelligence analyst for this platform. Analyze the supplied operational data and give an honest assessment.\n\n'
            . 'Your report must cover:\n'
            . '1. PROFIT: Is the business genuinely profitable during the measured period? Calculate or interpret revenue, profit, profit margin and loss where the data supports it. Do not call revenue profit.\n'
            . '2. PROFIT DRIVERS: Which services/categories appear to make the most money and which have weak or negative margins?\n'
            . '3. GROWTH: Give practical, realistic actions that could increase profit and revenue without inventing customer behaviour.\n'
            . '4. SILENT PROBLEMS: Find issues that customers may not be reporting, including unusually high failure rates, old pending transactions, declining activity, successful transactions with zero/negative recorded profit, sudden category weakness, data inconsistencies and other anomalies. Clearly label these as detected signals, not confirmed complaints.\n'
            . '5. SERVICE/PROVIDER RISK: Identify categories showing reliability problems or unusual failure patterns. Do not claim a provider is at fault unless the data proves it.\n'
            . '6. PRIORITY ACTIONS: Give the top 5 actions, ordered by expected business impact.\n\n'
            . 'Use naira amounts where applicable. Be concise but specific. Never invent facts, customer complaints, costs or causes. If a required metric is unavailable, explicitly say that it is unavailable.';

        $result = $service->analyze($instruction, self::metrics());
        set_transient('usefooma_ai_last_result', $result, 120);
        wp_safe_redirect(admin_url('admin.php?page=pulsepoint-ai-intelligence'));
        exit;
    }

    private static function metrics(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'trnx';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists !== $table) return ['error' => 'Transaction table is unavailable.'];

        $rows = $wpdb->get_results("SELECT category, status, type, COUNT(*) AS total, COALESCE(SUM(amount),0) AS amount, COALESCE(SUM(profit_amount),0) AS profit FROM `{$table}` WHERE date >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY category, status, type ORDER BY category, status, type", ARRAY_A);

        $overall = $wpdb->get_row("SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN status='success' THEN amount ELSE 0 END),0) AS successful_revenue, COALESCE(SUM(CASE WHEN status='success' THEN profit_amount ELSE 0 END),0) AS successful_profit, COALESCE(SUM(CASE WHEN status='failed' THEN amount ELSE 0 END),0) AS failed_amount, SUM(status='success') AS success_count, SUM(status='failed') AS failed_count, SUM(status='pending') AS pending_count FROM `{$table}` WHERE date >= DATE_SUB(NOW(), INTERVAL 30 DAY)", ARRAY_A);

        $today = $wpdb->get_row("SELECT COUNT(*) AS total, SUM(status='success') AS success_count, SUM(status='failed') AS failed_count, SUM(status='pending') AS pending_count, COALESCE(SUM(CASE WHEN status='success' THEN amount ELSE 0 END),0) AS revenue, COALESCE(SUM(CASE WHEN status='success' THEN profit_amount ELSE 0 END),0) AS profit FROM `{$table}` WHERE date >= CURDATE()", ARRAY_A);
        $week = $wpdb->get_row("SELECT COUNT(*) AS total, SUM(status='success') AS success_count, SUM(status='failed') AS failed_count, SUM(status='pending') AS pending_count, COALESCE(SUM(CASE WHEN status='success' THEN amount ELSE 0 END),0) AS revenue, COALESCE(SUM(CASE WHEN status='success' THEN profit_amount ELSE 0 END),0) AS profit FROM `{$table}` WHERE date >= DATE_SUB(NOW(), INTERVAL 7 DAY)", ARRAY_A);
        $previous_week = $wpdb->get_row("SELECT COUNT(*) AS total, SUM(status='success') AS success_count, SUM(status='failed') AS failed_count, COALESCE(SUM(CASE WHEN status='success' THEN amount ELSE 0 END),0) AS revenue, COALESCE(SUM(CASE WHEN status='success' THEN profit_amount ELSE 0 END),0) AS profit FROM `{$table}` WHERE date >= DATE_SUB(NOW(), INTERVAL 14 DAY) AND date < DATE_SUB(NOW(), INTERVAL 7 DAY)", ARRAY_A);

        $pending_old = $wpdb->get_row("SELECT COUNT(*) AS total, COALESCE(SUM(amount),0) AS amount FROM `{$table}` WHERE status='pending' AND date < DATE_SUB(NOW(), INTERVAL 30 MINUTE)", ARRAY_A);
        $zero_profit_success = $wpdb->get_row("SELECT COUNT(*) AS total, COALESCE(SUM(amount),0) AS amount FROM `{$table}` WHERE status='success' AND amount > 0 AND profit_amount <= 0 AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)", ARRAY_A);
        $negative_profit_success = $wpdb->get_row("SELECT COUNT(*) AS total, COALESCE(SUM(amount),0) AS amount, COALESCE(SUM(profit_amount),0) AS profit FROM `{$table}` WHERE status='success' AND profit_amount < 0 AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)", ARRAY_A);

        $categories = $wpdb->get_results("SELECT category, COUNT(*) AS total, SUM(status='success') AS success_count, SUM(status='failed') AS failed_count, SUM(status='pending') AS pending_count, COALESCE(SUM(CASE WHEN status='success' THEN amount ELSE 0 END),0) AS revenue, COALESCE(SUM(CASE WHEN status='success' THEN profit_amount ELSE 0 END),0) AS profit FROM `{$table}` WHERE date >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY category ORDER BY profit DESC", ARRAY_A);

        return [
            'period' => 'last_30_days',
            'overall' => $overall ?: [],
            'by_category_status_type' => $rows ?: [],
            'categories' => $categories ?: [],
            'today' => $today ?: [],
            'last_7_days' => $week ?: [],
            'previous_7_days' => $previous_week ?: [],
            'silent_issue_signals' => [
                'pending_older_than_30_minutes' => $pending_old ?: [],
                'successful_transactions_with_zero_or_negative_profit' => $zero_profit_success ?: [],
                'successful_transactions_with_negative_profit' => $negative_profit_success ?: [],
            ],
            'interpretation_notes' => [
                'Revenue is successful transaction amount, not profit.',
                'Profit is the recorded profit_amount field and may be incomplete if providers do not populate it.',
                'Silent issue signals are operational indicators; they are not evidence of customer complaints.'
            ],
        ];
    }
}
