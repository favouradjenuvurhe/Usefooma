<?php
/**
 * Lightweight PSR-4-style autoloader for the UseFooma application layer.
 * Legacy plugin files continue to be loaded by loader.php for compatibility.
 */
if (!defined('ABSPATH')) { exit; }

spl_autoload_register(static function ($class) {
    $prefix = 'UseFooma\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_readable($file)) {
        require_once $file;
    }
});
