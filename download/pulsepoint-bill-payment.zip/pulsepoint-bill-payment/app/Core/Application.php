<?php
namespace UseFooma\Core;

if (!defined('ABSPATH')) { exit; }

final class Application
{
    private static $booted = false;

    public static function boot(): void
    {
        if (self::$booted) return;
        self::$booted = true;

        add_action('plugins_loaded', [self::class, 'registerServices'], 1);
        add_action('init', [self::class, 'maybeMigrate'], 1);
    }

    public static function registerServices(): void
    {
        // Legacy runtime is loaded by the main bootstrap for activation/runtime compatibility.
        \UseFooma\Security\AjaxIdempotencyMiddleware::register();
        \UseFooma\Controllers\AIController::register();
        do_action('usefooma_services_loaded');
    }

    public static function maybeMigrate(): void
    {
        \UseFooma\Database\Migrator::maybeRun();
    }
}
