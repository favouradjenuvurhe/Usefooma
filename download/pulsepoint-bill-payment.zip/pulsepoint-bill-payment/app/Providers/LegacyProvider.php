<?php
namespace UseFooma\Providers;

if (!defined('ABSPATH')) { exit; }

final class LegacyProvider
{
    public static function register(): void
    {
        $loader = defined('PULSEPOINT_DIR') ? PULSEPOINT_DIR . 'legacy-loader.php' : '';
        if ($loader && is_file($loader)) {
            require_once $loader;
        }
    }
}
