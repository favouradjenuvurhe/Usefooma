<?php
namespace UseFooma\AI;

if (!defined('ABSPATH')) { exit; }

final class DeepSeekService
{
    private $endpoint;
    private $model;
    private $apiKey;
    private $timeout;

    public function __construct()
    {
        $config = require dirname(__DIR__, 2) . '/config/config.php';
        $this->endpoint = $config['ai']['endpoint'];
        $this->model = (string) $config['ai']['model'];
        $this->timeout = (int) $config['ai']['timeout'];
        $this->apiKey = (string) $config['ai']['api_key'];
    }

    public function get_model(): string
    {
        return $this->model;
    }

    public function available(): bool
    {
        return $this->apiKey !== '' && $this->apiKey !== 'PASTE_YOUR_USEFOOMA_AI_KEY_HERE';
    }

    /**
     * Server-side intelligence helper. This is intentionally not a chat UI.
     */
    public function analyze(string $instruction, $context = null): array
    {
        if (!$this->available()) {
            return ['success' => false, 'code' => 'AI_NOT_CONFIGURED', 'message' => 'AI intelligence is currently unavailable.'];
        }

        $payload = [
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => 'You are the internal intelligence layer for UseFooma. Return concise, structured analysis. Do not authorize payments, wallet deductions, refunds, transfers, purchases, permissions, or other security-sensitive actions.'],
                ['role' => 'user', 'content' => $instruction . "\n\nContext:\n" . wp_json_encode($context)],
            ],
            'temperature' => 0.1,
            'stream' => false,
        ];

        $response = wp_remote_post($this->endpoint, [
            'timeout' => $this->timeout,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'code' => 'AI_HTTP_ERROR', 'message' => $response->get_error_message()];
        }

        $status = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($body)) {
            return ['success' => false, 'code' => 'AI_API_ERROR', 'message' => 'AI intelligence request failed.', 'status' => $status];
        }

        $content = $body['choices'][0]['message']['content'] ?? null;
        if (!is_string($content) || $content === '') {
            return ['success' => false, 'code' => 'AI_EMPTY_RESPONSE', 'message' => 'AI intelligence returned no usable result.'];
        }

        return ['success' => true, 'content' => $content, 'model' => 'internal'];
    }
}
