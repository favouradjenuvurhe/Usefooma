<?php
namespace UseFooma\Security;

if (!defined('ABSPATH')) { exit; }

/**
 * Opt-in idempotency for financial AJAX operations.
 *
 * Clients send Idempotency-Key. The middleware claims the key before the
 * legacy handler runs and captures wp_send_json output so the exact response
 * can be replayed on a retry. Business rules and wallet mutations remain in
 * the legacy handlers; this class only prevents duplicate execution.
 */
final class AjaxIdempotencyMiddleware
{
    private static $actions = [
        'pulsepoint_airtime_purchase',
        'pulsepoint_data_purchase',
        'pulsepoint_cable_purchase',
        'pulsepoint_electricity_purchase',
        'pulsepoint_education_purchase',
        'pulsepoint_betting_purchase',
        'pulsepoint_smm_purchase',
        'pulsepoint_bank_transfer',
        'pulsepoint_wallet_transfer',
        'pulsepoint_create_card',
        'pulsepoint_fund_card',
        'pulsepoint_withdraw_card',
        'pulsepoint_convert_balance',
        'pulsepoint_esim_purchase',
        'pulsepoint_recharge',
        'pulsepoint_woocommerce_fund_wallet',
    ];

    public static function register(): void
    {
        foreach (self::$actions as $action) {
            add_action('wp_ajax_' . $action, [self::class, 'before'], 1);
            add_action('wp_ajax_nopriv_' . $action, [self::class, 'before'], 1);
        }
    }

    public static function before(): void
    {
        if (function_exists('wp_doing_ajax') && !wp_doing_ajax()) {
            return;
        }

        $raw = isset($_SERVER['HTTP_IDEMPOTENCY_KEY'])
            ? sanitize_text_field(wp_unslash($_SERVER['HTTP_IDEMPOTENCY_KEY']))
            : '';

        // Backward-compatible fallbacks for clients that already send a reference.
        if ($raw === '' && isset($_POST['reference'])) {
            $raw = sanitize_text_field(wp_unslash($_POST['reference']));
        }
        if ($raw === '' && isset($_POST['request_id'])) {
            $raw = sanitize_text_field(wp_unslash($_POST['request_id']));
        }

        // Do not change existing clients that do not provide an idempotency identifier.
        if ($raw === '') {
            return;
        }

        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : 'unknown';
        $userId = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
        $key = $userId . ':' . $raw;
        $result = IdempotencyService::claim($action, $key, $userId);

        if (!$result['owner']) {
            if (is_array($result['response'])) {
                wp_send_json($result['response']);
            }

            wp_send_json([
                'success' => false,
                'message' => 'This request is already being processed. Please wait for the original request to finish.',
                'code'    => 'IDEMPOTENCY_IN_PROGRESS',
            ], 409);
        }

        $scope = $action;
        ob_start();

        add_action('shutdown', function () use ($scope, $key) {
            $output = ob_get_contents();
            if ($output === false || trim($output) === '') {
                return;
            }

            $decoded = json_decode(trim($output), true);
            if (!is_array($decoded)) {
                return;
            }

            if (!empty($decoded['success'])) {
                IdempotencyService::complete($scope, $key, $decoded);
            } else {
                IdempotencyService::fail($scope, $key, $decoded);
            }
        }, 0);
    }
}
