<?php
namespace UseFooma\Security;

if (!defined('ABSPATH')) { exit; }

final class IdempotencyService
{
    private static function table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'pulsepoint_idempotency';
    }

    public static function key(string $scope, string $key): string
    {
        return hash('sha256', $scope . '|' . $key);
    }

    /**
     * Atomically claims an idempotency key. Returns an existing record when
     * another request already owns the key, preventing duplicate processing.
     */
    public static function claim(string $scope, string $key, int $userId = 0, int $ttl = 86400): array
    {
        global $wpdb;
        $key = self::key($scope, trim($key));
        $now = current_time('mysql', true);
        $expires = gmdate('Y-m-d H:i:s', time() + max(60, $ttl));
        $table = self::table();

        $inserted = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$table} (scope,idempotency_key,user_id,status,created_at,updated_at,expires_at)
             VALUES (%s,%s,%d,'processing',%s,%s,%s)",
            $scope, $key, $userId, $now, $now, $expires
        ));

        if ($inserted === 1) {
            return ['owner' => true, 'status' => 'processing', 'response' => null];
        }

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT status,response FROM {$table} WHERE scope=%s AND idempotency_key=%s LIMIT 1",
            $scope, $key
        ), ARRAY_A);

        if (!$row) {
            // Extremely rare fallback: allow a retry if the database insert was interrupted.
            return ['owner' => true, 'status' => 'processing', 'response' => null];
        }

        return [
            'owner' => false,
            'status' => (string) $row['status'],
            'response' => $row['response'] ? json_decode($row['response'], true) : null,
        ];
    }

    public static function complete(string $scope, string $key, array $response): void
    {
        self::finish($scope, $key, 'completed', $response);
    }

    public static function fail(string $scope, string $key, array $response): void
    {
        self::finish($scope, $key, 'failed', $response);
    }

    private static function finish(string $scope, string $key, string $status, array $response): void
    {
        global $wpdb;
        $wpdb->update(
            self::table(),
            ['status' => $status, 'response' => wp_json_encode($response), 'updated_at' => current_time('mysql', true)],
            ['scope' => $scope, 'idempotency_key' => self::key($scope, trim($key))],
            ['%s', '%s', '%s'],
            ['%s', '%s']
        );
    }
}
