<?php
if (!defined('ABSPATH')) exit;

/**
 * Pulsepoint WooCommerce Payment Gateway
 * Fully working version that appears on checkout
 */

add_action('plugins_loaded', function() {

    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_Gateway_Pulsepoint extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'pulsepoint';
            $this->method_title       = 'Pulsepoint';
            $this->method_description = 'Pay using Pulsepoint Wallet';
            $this->has_fields         = false;

            // Initialize form fields & settings
            $this->init_form_fields();
            $this->init_settings();

            // Enabled as boolean
            $this->enabled = isset($this->settings['enabled']) && $this->settings['enabled'] === 'yes';
            $this->title   = !empty($this->settings['title']) ? $this->settings['title'] : 'Pulsepoint (Pay)';

            // Save admin options
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        // Admin settings
        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Pulsepoint payment',
                    'default' => 'yes'
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'Title customers see during checkout',
                    'default'     => 'Pulsepoint (Pay)'
                )
            );
        }

        // Payment processing
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);

            // Put order on-hold and reduce stock
            $order->update_status('on-hold', 'Awaiting Pulsepoint payment');
            wc_reduce_stock_levels($order_id);
            wc_add_order_item_meta($order_id, '_pulsepoint_txn_ref', time());

            // Return success with redirect to thank you page
            return array(
                'result'   => 'success',
                'redirect' => $this->get_return_url($order)
            );
        }

        /**
         * Ensure gateway is available on checkout
         */
        public function is_available() {
            // Only if enabled
            if (!$this->enabled) return false;

            // Only if cart exists and has items
            if (!WC()->cart || WC()->cart->is_empty()) return false;

            // Always available if above conditions are met
            return true;
        }
    }

    // Register gateway with WooCommerce
    add_filter('woocommerce_payment_gateways', function($methods) {
        $methods[] = 'WC_Gateway_Pulsepoint';
        return $methods;
    });

}, 20);