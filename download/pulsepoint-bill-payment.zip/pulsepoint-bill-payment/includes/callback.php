<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 🔹 Add query var for callback
 */
add_filter('query_vars', function ($vars) {
    $vars[] = 'pulsepoint_callback';
    return $vars;
});

/**
 * 🔹 Add rewrite rules for callback URLs
 *    e.g. /callback/whogopay → includes/callback/whogopay.php
 */
add_action('init', function () {
    add_rewrite_rule('^callback/?$', 'index.php?pulsepoint_callback=index', 'top');
    add_rewrite_rule('^callback/([^/]*)/?', 'index.php?pulsepoint_callback=$matches[1]', 'top');
});

/**
 * 🔹 Start session (if needed)
 */
add_action('init', function () {
    if (!session_id()) {
        session_start();
    }
});

/**
 * 🔹 Template redirect handler for /callback/*
 */
add_action('template_redirect', function () {
    $cb = get_query_var('pulsepoint_callback');
    if ($cb) {

        status_header(200);
        nocache_headers();

        // ✅ Define the callback directory
        $callback_dir = PULSEPOINT_DIR . 'includes/callback/';

        // Sanitize and find target file
        $callback_file = sanitize_file_name($cb);
        $file_path = $callback_dir . $callback_file . '.php';

        // Default to index.php if no file found
        if (!file_exists($file_path)) {
            $file_path = $callback_dir . 'index.php';
        }

        // ✅ Include the callback file
        include $file_path;
        exit;
    }
});