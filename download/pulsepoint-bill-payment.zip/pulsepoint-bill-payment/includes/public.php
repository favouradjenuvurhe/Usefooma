<?php
/**
 * Pulsepoint App Router (Public Pages)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/public.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// === Register query vars ===
add_filter('query_vars', function ($vars) {
    $vars[] = 'pulsepoint_app';
    return $vars;
});

// === Add rewrite rules ===
add_action('init', function () {
    add_rewrite_rule('^app/?$', 'index.php?pulsepoint_app=dashboard', 'top');
    add_rewrite_rule('^app/([^/]*)/?', 'index.php?pulsepoint_app=$matches[1]', 'top');
});

// === Start session ===
function pulsepoint_start_session(){if(session_status()===PHP_SESSION_NONE && !headers_sent()){session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax','use_strict_mode'=>true]);}}
add_action('init','pulsepoint_start_session',1);

add_shortcode('Usefooma',function(){ob_start();include PULSEPOINT_DIR.'includes/pages/dashboard.php';return ob_get_clean();});

// === Template redirect handler ===
add_action('template_redirect', function () {

    $qp = get_query_var('pulsepoint_app');
    if (!$qp) return;

    status_header(200);
    nocache_headers();

    // === Session check ===
    $is_logged_in = !empty($_SESSION['pulsepoint_user']);

    // ======================================================
    // 🔐 FORCE LOGIN PROTECTION
    // ======================================================
    if (
        !$is_logged_in &&
        !in_array($qp, ['login', 'register', 'recovery', 'verification', 'reset-password'])
    ) {
        wp_redirect('/app/login');
        exit;
    }

    if ($is_logged_in && in_array($qp, ['login', 'register'])) {
        wp_redirect('/app/dashboard');
        exit;
    }

    // ======================================================
    // 🔐 EMAIL VERIFICATION FORCE (status_email = 0)
    // ======================================================
    if ($is_logged_in) {

        global $wpdb;
        $table = $wpdb->prefix . 'pulsepoint_users';
        $user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

        if ($user_id) {

            $user = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT status_email FROM `{$table}` WHERE id = %d LIMIT 1",
                    $user_id
                )
            );

            if ($user && (int)$user->status_email === 0) {

                // allow only verification page
                if (!in_array($qp, ['verification', 'logout'])) {

                    wp_redirect('/app/verification');
                    exit;
                }
            }
        }
    }

    // ======================================================
    // CORE PAGE LOADER
    // ======================================================
    $page = sanitize_file_name($qp);

    /**
     * ======================================================
     * ADDON PAGE OVERRIDE
     * ======================================================
     */
    $addon_file = apply_filters('pulsepoint_addon_page', null, $page);

    if ($addon_file && file_exists($addon_file)) {
        include $addon_file;
        exit;
    }

    /**
     * ======================================================
     * CORE PAGE LOADER
     * ======================================================
     */
    $file = PULSEPOINT_DIR . 'includes/pages/' . $page . '.php';
    if (!file_exists($file)) {
        $file = PULSEPOINT_DIR . 'includes/pages/dashboard.php';
    }

    // === Load requested page ===
    include $file;
    exit;
});