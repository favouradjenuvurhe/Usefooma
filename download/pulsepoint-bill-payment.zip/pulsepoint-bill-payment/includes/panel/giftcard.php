<?php
/**
 * Pulsepoint Giftcard Settings Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/giftcard-setting.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

$table_giftcard = "{$base_prefix}giftcard_settings";

// === Giftcard purchase source settings (manual stock or external API) ===
$purchase_mode = get_option('pulsepoint_giftcard_purchase_mode', 'api');
$gift_api_base = 'https://connect.topupmate.com/api/giftcard';
$gift_api_key = get_option('pulsepoint_giftcard_api_key', '');
$gift_api_fx = (float) get_option('pulsepoint_giftcard_api_fx_rate', '1');
$gift_api_markup = (float) get_option('pulsepoint_giftcard_api_markup', '0');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_giftcard_purchase_settings'])) {
    check_admin_referer('pulsepoint_giftcard_purchase_settings');
    $purchase_mode = in_array($_POST['purchase_mode'] ?? 'api', ['manual','api'], true) ? $_POST['purchase_mode'] : 'api';
    $gift_api_base = 'https://connect.topupmate.com/api/giftcard';
    $gift_api_key = sanitize_text_field($_POST['gift_api_key'] ?? '');
    $gift_api_fx = max(0, (float) ($_POST['gift_api_fx_rate'] ?? 1));
    $gift_api_markup = max(0, (float) ($_POST['gift_api_markup'] ?? 0));
    update_option('pulsepoint_giftcard_purchase_mode', $purchase_mode, false);
    update_option('pulsepoint_giftcard_api_base', $gift_api_base, false);
    update_option('pulsepoint_giftcard_api_key', $gift_api_key, false);
    update_option('pulsepoint_giftcard_api_fx_rate', $gift_api_fx, false);
    update_option('pulsepoint_giftcard_api_markup', $gift_api_markup, false);
    echo '<div class="updated notice"><p><strong>Giftcard purchase settings saved.</strong></p></div>';
}


// === Create Giftcard Settings Table if not exists ===
$sql_giftcard_settings = "CREATE TABLE IF NOT EXISTS `{$table_giftcard}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `category` VARCHAR(100) NOT NULL,                  
    `type` ENUM('digital','physical') DEFAULT 'digital',
    `rate` DECIMAL(14,2) NOT NULL,                     
    `min_amount` DECIMAL(14,2) DEFAULT 0.00,
    `max_amount` DECIMAL(14,2) DEFAULT 0.00,
    `status` ENUM('active','inactive') DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) {$charset};";
$wpdb->query($sql_giftcard_settings);

// === Delete Giftcard ===
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $wpdb->delete($table_giftcard, ['id' => $id]);
    echo '<div class="updated notice"><p><strong>Giftcard deleted successfully.</strong></p></div>';
}

// === Toggle Status (Active / Inactive) ===
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = intval($_GET['toggle']);
    $gift = $wpdb->get_row($wpdb->prepare("SELECT status FROM {$table_giftcard} WHERE id = %d", $id));
    if ($gift) {
        $new_status = ($gift->status === 'active') ? 'inactive' : 'active';
        $wpdb->update($table_giftcard, ['status' => $new_status], ['id' => $id]);
        echo '<div class="updated notice"><p><strong>Status changed to '.esc_html(ucfirst($new_status)).'.</strong></p></div>';
    }
}

// === Fetch All Giftcards ===
$giftcards = $wpdb->get_results("SELECT * FROM {$table_giftcard} ORDER BY id DESC");

// === Platform Info for Styling ===
$settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings_map = [];
foreach ($settings as $s) { $settings_map[$s->opt_key] = maybe_unserialize($s->opt_value); }

$platform_name = $settings_map['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings_map['color_hex'] ?? '#356cf9';
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Giftcard Settings</h1>
  <a href="?page=pulsepoint-add-giftcard" class="page-title-action"><i class="bi bi-plus-circle"></i> Add New Giftcard</a>
  <a href="?page=pulsepoint-trade-giftcard" class="page-title-action"><i class="bi bi-history"></i> View Trades</a>
  <a href="?page=pulsepoint-giftcard-inventory" class="page-title-action"><i class="bi bi-box-seam"></i> Manage Stock</a>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    table { width: 100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 10px 8px; font-size: 14px; }
    th { text-align: left; background: #f9fafb; font-weight: 600; }
    .pulse-btn {
      background: var(--primary);
      color: #fff;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
    }
    .pulse-btn-danger {
      background: #ef4444;
      color: #fff;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
    }
    .pulse-btn-warning {
      background: #f59e0b;
      color: #fff;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
    }
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-cart-check"></i> Giftcard Purchase Source</h2>
    <div class="mb-4 rounded-xl bg-blue-50 border border-blue-100 px-4 py-3 text-sm text-blue-800">Topupmate now supplies the live giftcard catalog, purchase endpoint, and redemption-code retrieval. Set your Topupmate API key and the NGN rate for 1 USD. Fixed cards use Topupmate's sender-currency denomination map, including provider fees.</div>
    <p class="text-sm text-gray-500 mb-4">Choose whether the Redeem page sells your manually stocked cards or products supplied by the external Giftcard API.</p>
    <form method="post">
      <?php wp_nonce_field('pulsepoint_giftcard_purchase_settings'); ?>
      <input type="hidden" name="save_giftcard_purchase_settings" value="1">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label class="block"><span class="font-semibold text-sm">Purchase Source</span><select name="purchase_mode" class="pulse-input"><option value="manual" <?= $purchase_mode === 'manual' ? 'selected' : '' ?>>Manual Stock</option><option value="api" <?= $purchase_mode === 'api' ? 'selected' : '' ?>>Topupmate Giftcard API</option></select></label>
        <label class="block"><span class="font-semibold text-sm">API Base URL</span><input type="url" name="gift_api_base" value="https://connect.topupmate.com/api/giftcard" class="pulse-input" readonly><small class="text-gray-500">Topupmate Gift Card API endpoint.</small></label>
        <label class="block md:col-span-2"><span class="font-semibold text-sm">API Key</span><input type="password" name="gift_api_key" value="<?= esc_attr($gift_api_key) ?>" class="pulse-input" autocomplete="new-password" placeholder="YOUR_API_KEY"></label>
        <label class="block"><span class="font-semibold text-sm">NGN Rate per API Currency Unit</span><input type="number" step="0.0001" min="0" name="gift_api_fx_rate" value="<?= esc_attr($gift_api_fx) ?>" class="pulse-input"><small class="text-gray-500">Enter the NGN value of 1 USD (Topupmate sender currency). Example: 1 USD = ₦1,500 → enter 1500.</small></label>
        <label class="block"><span class="font-semibold text-sm">API Markup (%)</span><input type="number" step="0.01" min="0" name="gift_api_markup" value="<?= esc_attr($gift_api_markup) ?>" class="pulse-input"></label>
      </div>
      <button class="pulse-btn" type="submit">Save Purchase Source</button>
    </form>
  </div>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-gift"></i> Giftcard Settings</h2>

    <?php if (!$giftcards): ?>
      <p>No giftcards found. <a href="?page=pulsepoint-add-giftcard" class="text-blue-600">Add your first giftcard</a>.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Category</th>
              <th>Type</th>
              <th>Rate</th>
              <th>Min Amount</th>
              <th>Max Amount</th>
              <th>Status</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($giftcards as $g): ?>
              <tr>
                <td><?= esc_html($g->id) ?></td>
                <td><strong><?= esc_html($g->category) ?></strong></td>
                <td><?= esc_html(ucfirst($g->type)) ?></td>
                <td><?= number_format($g->rate, 2) ?></td>
                <td><?= number_format($g->min_amount, 2) ?></td>
                <td><?= number_format($g->max_amount, 2) ?></td>
                <td>
                  <span class="<?= $g->status === 'active' ? 'text-green-600' : 'text-gray-500' ?>">
                    <?= ucfirst($g->status) ?>
                  </span>
                </td>
                <td><?= esc_html(date('Y-m-d', strtotime($g->created_at))) ?></td>
                <td>
                  <a href="?page=pulsepoint-add-giftcard&edit=<?= $g->id ?>" class="pulse-btn"><i class="bi bi-pencil-square"></i> Edit</a>
                  <a href="?page=pulsepoint-giftcard&toggle=<?= $g->id ?>" class="pulse-btn-warning"><i class="bi bi-toggle2-on"></i> Toggle</a>
                  <a href="?page=pulsepoint-giftcard&delete=<?= $g->id ?>" onclick="return confirm('Delete this giftcard?')" class="pulse-btn-danger"><i class="bi bi-trash"></i> Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>