<?php
/**
 * Pulsepoint View User Page (Enhanced Admin Control)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/view_user.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_users = "{$base_prefix}users";

// === Get user ID ===
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user = $wpdb->get_row("SELECT * FROM {$table_users} WHERE id = {$user_id}");

if (!$user) {
    echo '<div class="wrap"><h2>User not found.</h2><p><a href="?page=pulsepoint-users" class="button button-primary">← Back to Users</a></p></div>';
    return;
}

// === Handle Form Actions ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = sanitize_text_field($_POST['action']);

    if ($action === 'update_user') {
        $customerId     = sanitize_text_field($_POST['customerId']);
        $email          = sanitize_email($_POST['email']); // ✅ get email
        $account_limit  = floatval($_POST['account_limit']);
        $status         = intval($_POST['status']);
        $statuskyc      = intval($_POST['statuskyc']);
        $wallet         = floatval($_POST['wallet']);
        $referral_bal   = floatval($_POST['referral_balance']);
        $account_type   = sanitize_text_field($_POST['account_type']);

        $wpdb->update($table_users, [
            'customerId'       => $customerId,
            'email'            => $email, // 
            'account_limit'    => $account_limit,
            'status'           => $status,
            'statuskyc'        => $statuskyc,
            'account_type'     => $account_type,
            'wallet'           => $wallet,
            'referral_balance' => $referral_bal,
        ], ['id' => $user_id]);

        echo '<div class="updated notice"><p><strong>User details updated successfully!</strong></p></div>';
        $user = $wpdb->get_row("SELECT * FROM {$table_users} WHERE id = {$user_id}");
    }

    if ($action === 'fund_wallet') {
        $amount = floatval($_POST['fund_amount']);
        if ($amount > 0) {
            $wpdb->query("UPDATE {$table_users} SET wallet = wallet + {$amount} WHERE id = {$user_id}");
            echo '<div class="updated notice"><p><strong>₦' . number_format($amount, 2) . ' added to wallet.</strong></p></div>';
            $user = $wpdb->get_row("SELECT * FROM {$table_users} WHERE id = {$user_id}");
        }
    }

    if ($action === 'debit_wallet') {
        $amount = floatval($_POST['debit_amount']);
        if ($amount > 0 && $user->wallet >= $amount) {
            $wpdb->query("UPDATE {$table_users} SET wallet = wallet - {$amount} WHERE id = {$user_id}");
            echo '<div class="updated notice"><p><strong>₦' . number_format($amount, 2) . ' debited from wallet.</strong></p></div>';
            $user = $wpdb->get_row("SELECT * FROM {$table_users} WHERE id = {$user_id}");
        } else {
            echo '<div class="error notice"><p><strong>Invalid debit amount or insufficient balance.</strong></p></div>';
        }
    }
}

// === Platform Settings ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// === Format Amount ===
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }
function fmt_usd($num) { return '$' . number_format((float)$num, 2); }

?>
<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — View User</h1>
  <p>Detailed user information and control panel below.</p>
  <hr class="wp-header-end">

  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-box {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 20px;
      max-width: 900px;
    }
    .pulse-grid {
      display: grid;
      grid-template-columns: 180px 1fr;
      gap: 12px;
      margin-bottom: 14px;
    }
    .label {
      font-weight: 600;
      color: #555;
      font-size: 14px;
    }
    .value {
      color: #222;
      font-size: 15px;
      word-break: break-word;
    }
    .section-title {
      font-weight: 700;
      color: var(--primary);
      margin-top: 25px;
      font-size: 18px;
      border-bottom: 2px solid #eee;
      padding-bottom: 6px;
    }
    .back-btn {
      display: inline-flex;
      align-items: center;
      background: var(--primary);
      color: #fff;
      padding: 10px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-size: 14px;
      margin-top: 16px;
    }
    .back-btn i { margin-right: 6px; }
    input, select {
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 6px 8px;
      width: 100%;
    }
    button {
      background: var(--primary);
      color: #fff;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      margin-top: 8px;
    }
    button:hover { opacity: 0.9; }
  </style>

  <div class="pulse-box">
    <div class="section-title">Personal Information</div>
    <div class="pulse-grid"><div class="label">Full Name:</div><div class="value"><?= esc_html($user->firstname . ' ' . $user->lastname) ?></div></div>
    <div class="pulse-grid"><div class="label">Phone:</div><div class="value"><?= esc_html($user->phone ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Email:</div><div class="value"><?= esc_html($user->email ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Gender:</div><div class="value"><?= esc_html($user->gender ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Date of Birth:</div><div class="value"><?= esc_html($user->dob ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Address:</div><div class="value"><?= esc_html($user->address ?: '-') ?></div></div>

    <div class="section-title">Account Details</div>
    <div class="pulse-grid"><div class="label">Wallet Balance:</div><div class="value font-semibold"><?= fmt_amt($user->wallet) ?></div></div>
    <div class="pulse-grid"><div class="label">Dollar Balance:</div><div class="value font-semibold"><?= fmt_usd($user->dollar) ?></div></div>
    <div class="pulse-grid"><div class="label">Referral Balance:</div><div class="value"><?= fmt_amt($user->referral_balance) ?></div></div>
    <div class="pulse-grid"><div class="label">Account Limit:</div><div class="value"><?= fmt_amt($user->account_limit) ?></div></div>
    <div class="pulse-grid"><div class="label">KYC Status:</div>
      <div class="value">
        <?= $user->statuskyc ? '<span class="text-green-600 font-semibold">Verified</span>' : '<span class="text-red-600 font-semibold">Unverified</span>' ?>
      </div>
    </div>
    <div class="pulse-grid"><div class="label">Account Type:</div><div class="value"><?= esc_html($user->account_type) ?></div></div>
    <div class="pulse-grid"><div class="label">Customer ID:</div><div class="value"><?= esc_html($user->customerId ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Status:</div>
      <div class="value">
        <?php if ($user->status == 1): ?>
          <span class="text-green-600 font-semibold">Active</span>
        <?php else: ?>
          <span class="text-red-600 font-semibold">Suspended</span>
        <?php endif; ?>
      </div>
    </div>

    <!-- Admin Update Form -->
    <div class="section-title">Admin Update Controls</div>
    <form method="POST">
      <input type="hidden" name="action" value="update_user">

      <div class="pulse-grid"><div class="label">Customer ID:</div><div><input type="text" name="customerId" value="<?= esc_attr($user->customerId) ?>"></div></div>
      <div class="pulse-grid">
    <div class="label">Email:</div>
    <div>
      <input type="email" name="email" value="<?= esc_attr($user->email) ?>" required>
    </div>
  </div>
      <div class="pulse-grid"><div class="label">Account Limit (₦):</div><div><input type="number" step="0.01" name="account_limit" value="<?= esc_attr($user->account_limit) ?>"></div></div>
      <div class="pulse-grid"><div class="label">Wallet Balance (₦):</div><div><input type="number" step="0.01" name="wallet" value="<?= esc_attr($user->wallet) ?>"></div></div>
      <div class="pulse-grid"><div class="label">Referral Balance (₦):</div><div><input type="number" step="0.01" name="referral_balance" value="<?= esc_attr($user->referral_balance) ?>"></div></div>
      <div class="pulse-grid"><div class="label">Account Type:</div>
        <div>
          <select name="account_type">
            <option <?= $user->account_type == 'Customer' ? 'selected' : '' ?>>Customer</option>
            <option <?= $user->account_type == 'Agent' ? 'selected' : '' ?>>Agent</option>
            <option <?= $user->account_type == 'API' ? 'selected' : '' ?>>API</option>
          </select>
        </div>
      </div>
      <div class="pulse-grid"><div class="label">Account Status:</div>
        <div>
          <select name="status">
            <option value="1" <?= $user->status == 1 ? 'selected' : '' ?>>Active</option>
            <option value="0" <?= $user->status == 0 ? 'selected' : '' ?>>Suspended</option>
          </select>
        </div>
      </div>
      <div class="pulse-grid"><div class="label">KYC Status:</div>
        <div>
          <select name="statuskyc">
            <option value="1" <?= $user->statuskyc == 1 ? 'selected' : '' ?>>Verified</option>
            <option value="0" <?= $user->statuskyc == 0 ? 'selected' : '' ?>>Unverified</option>
          </select>
        </div>
      </div>
      <button type="submit">Update User Details</button>
    </form>

    <!-- Wallet Actions -->
    <div class="section-title">Wallet Actions</div>
    <form method="POST" style="margin-bottom: 10px;">
      <input type="hidden" name="action" value="fund_wallet">
      <div class="pulse-grid"><div class="label">Fund Amount (₦):</div><div><input type="number" step="0.01" name="fund_amount" required></div></div>
      <button type="submit">Fund Wallet</button>
    </form>

    <form method="POST">
      <input type="hidden" name="action" value="debit_wallet">
      <div class="pulse-grid"><div class="label">Debit Amount (₦):</div><div><input type="number" step="0.01" name="debit_amount" required></div></div>
      <button type="submit" style="background:#d90429;">Debit Wallet</button>
    </form>

    <div class="section-title">Referral Information</div>
    <div class="pulse-grid"><div class="label">Referred By:</div>
      <div class="value">
        <?php 
          if ($user->referby) {
            $ref = $wpdb->get_row("SELECT firstname, lastname, email FROM {$table_users} WHERE id = {$user->referby}");
            echo esc_html($ref ? ($ref->firstname . ' ' . $ref->lastname . ' (' . $ref->email . ')') : 'Unknown');
          } else {
            echo '-';
          }
        ?>
      </div>
    </div>

    <div class="section-title">Security</div>
    <div class="pulse-grid"><div class="label">Passcode:</div><div class="value"><?= esc_html($user->passcode ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Token:</div><div class="value"><?= esc_html($user->token ?: '-') ?></div></div>
    <div class="pulse-grid"><div class="label">Reset Token:</div><div class="value"><?= esc_html($user->reset_token ?: '-') ?></div></div>

    <div class="section-title">Timestamps</div>
    <div class="pulse-grid"><div class="label">Created At:</div><div class="value"><?= esc_html($user->created_at) ?></div></div>
    <div class="pulse-grid"><div class="label">Updated At:</div><div class="value"><?= esc_html($user->updated_at) ?></div></div>

    <a href="?page=pulsepoint-users" class="back-btn"><i class="bi bi-arrow-left"></i> Back to Users</a>
  </div>
</div>