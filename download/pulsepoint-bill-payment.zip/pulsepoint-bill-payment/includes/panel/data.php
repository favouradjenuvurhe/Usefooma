<?php
/**
 * Pulsepoint Data Plans Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/data.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

$table_data = "{$base_prefix}data";
$table_provider = "{$base_prefix}provider";

// === Create Tables if not exist ===
$wpdb->query("CREATE TABLE IF NOT EXISTS {$table_provider} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    token TEXT,
    value TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY provider_name_unique (name)
) {$charset};");

$wpdb->query("CREATE TABLE IF NOT EXISTS {$table_data} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    plan VARCHAR(255) DEFAULT NULL,
    details TEXT,
    network VARCHAR(50) DEFAULT NULL,
    amount DECIMAL(14,2) DEFAULT 0.00,
    cashback DECIMAL(14,2) DEFAULT 0.00,
    apiamount DECIMAL(14,2) DEFAULT 0.00,
    type VARCHAR(50) DEFAULT NULL,
    provider BIGINT UNSIGNED DEFAULT NULL,
    PRIMARY KEY (id)
) {$charset};");

// === Delete Logic ===
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $wpdb->delete($table_data, ['id' => $id]);
    echo '<div class="updated notice"><p><strong>Data Plan deleted successfully.</strong></p></div>';
}

// === Fetch All Plans ===
$plans = $wpdb->get_results("
    SELECT d.*, p.name AS provider_name
    FROM {$table_data} d
    LEFT JOIN {$table_provider} p ON d.provider = p.id
    ORDER BY d.id DESC
");
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Data Plans</h1>
  <a href="?page=pulsepoint-add-data" class="page-title-action"><i class="bi bi-plus-circle"></i> Add New Plan</a>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      border-bottom: 1px solid #eee;
      padding: 10px 8px;
      font-size: 14px;
    }
    th {
      text-align: left;
      background: #f9fafb;
      font-weight: 600;
    }
    .pulse-btn {
      background: var(--primary);
      color: #fff;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
    }
    .pulse-btn-danger {
      background: #ef4444;
      color: #fff;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
    }
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-diagram-3"></i> Data Plans</h2>

    <?php if (!$plans): ?>
      <p>No data plans found. <a href="?page=pulsepoint-add-data" class="text-blue-600">Add your first plan</a>.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Plan</th>
              <th>Network</th>
              <th>Amount (₦)</th>
              <th>Cashback</th>
              <th>API Amt</th>
              <th>Type</th>
              <th>Provider</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($plans as $p): ?>
              <tr>
                <td><?= esc_html($p->id) ?></td>
                <td><strong><?= esc_html($p->details) ?></strong><br><small><?= esc_html($p->plan) ?></small></td>
                <td><?= esc_html(strtoupper($p->network)) ?></td>
                <td><?= number_format($p->amount, 2) ?></td>
                <td><?= number_format($p->cashback, 2) ?></td>
                <td><?= number_format($p->apiamount, 2) ?></td>
                <td><?= esc_html(strtoupper($p->type)) ?></td>
                <td><?= esc_html($p->provider_name ?: '—') ?></td>
                <td>
                  <a href="?page=pulsepoint-add-data&edit=<?= $p->id ?>" class="pulse-btn"><i class="bi bi-pencil-square"></i> Edit</a>
                  <a href="?page=pulsepoint-data&delete=<?= $p->id ?>" onclick="return confirm('Delete this plan?')" class="pulse-btn-danger"><i class="bi bi-trash"></i> Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>