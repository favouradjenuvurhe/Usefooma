<?php
/**
 * UseFooma Configuration — Offline Data (Africa's Talking)
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$settings_table = $wpdb->prefix . 'pulsepoint_settings';
$settings = [];
foreach ((array) $wpdb->get_results("SELECT opt_key,opt_value FROM {$settings_table}") as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$notice = '';
$notice_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usefooma_offline_nonce']) && wp_verify_nonce($_POST['usefooma_offline_nonce'], 'usefooma_save_offline_data')) {
    $values = [
        'africas_talking_enabled' => isset($_POST['africas_talking_enabled']) ? '1' : '0',
        'africas_talking_number' => sanitize_text_field(wp_unslash($_POST['africas_talking_number'] ?? '')),
        'africas_talking_daily_limit' => max(0, (float) ($_POST['offline_data_daily_limit'] ?? 0)),
        'offline_data_fee_enabled' => isset($_POST['offline_data_fee_enabled']) ? '1' : '0',
        'offline_data_fee_type' => in_array(($_POST['offline_data_fee_type'] ?? 'flat'), ['flat','percent'], true) ? $_POST['offline_data_fee_type'] : 'flat',
        'offline_data_fee' => max(0, (float) ($_POST['offline_data_fee'] ?? 0)),
    ];
    foreach ($values as $key => $value) {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT opt_key FROM {$settings_table} WHERE opt_key=%s LIMIT 1", $key));
        if ($exists) {
            $wpdb->update($settings_table, ['opt_value'=>maybe_serialize($value)], ['opt_key'=>$key]);
        } else {
            $wpdb->insert($settings_table, ['opt_key'=>$key, 'opt_value'=>maybe_serialize($value)]);
        }
        $settings[$key] = $value;
    }
    $notice = 'Offline Data settings saved.';
}

$enabled = ($settings['africas_talking_enabled'] ?? $settings['voicebip_enabled'] ?? '0') === '1';
$number = (string) (($settings['africas_talking_number'] ?? '') ?: ($settings['voicebip_number'] ?? ''));
$daily = (float) ($settings['africas_talking_daily_limit'] ?? ($settings['voicebip_daily_limit'] ?? 0));
$fee_enabled = ($settings['offline_data_fee_enabled'] ?? '0') === '1';
$fee_type = ($settings['offline_data_fee_type'] ?? 'flat') === 'percent' ? 'percent' : 'flat';
$offline_fee = (float) ($settings['offline_data_fee'] ?? 0);
$endpoint = trailingslashit(home_url()) . 'callback/africastalking';

$logs_table = $wpdb->prefix . 'pulsepoint_voicebip_logs';
$logs = [];
if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $logs_table)) === $logs_table) {
    $logs = (array) $wpdb->get_results("SELECT * FROM {$logs_table} ORDER BY id DESC LIMIT 3");
}

$status_labels = [
    'received'=>'Received','success'=>'Processed','pending'=>'Pending','failed'=>'Failed',
    'invalid_signature'=>'Invalid signature','invalid_json'=>'Invalid JSON','unregistered'=>'Unknown caller',
    'not_configured'=>'Not configured','plan_unavailable'=>'Plan unavailable','wrong_number'=>'Wrong number',
    'duplicate'=>'Duplicate','incomplete'=>'Incomplete','ignored'=>'Ignored','disabled'=>'Disabled'
];
?>
<div class="wrap">
  <h1 class="wp-heading-inline">Offline Data</h1>
  <p>Let registered customers trigger their configured data bundle by calling your Africa's Talking Nigerian Voice number.</p>
  <hr class="wp-header-end">
  <style>
    .usefooma-offline-card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;box-shadow:0 3px 10px rgba(0,0,0,.05);padding:24px;margin-top:24px;max-width:1050px}
    .usefooma-offline-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:18px}
    .usefooma-offline-label{display:block;font-weight:600;font-size:13px;margin-bottom:7px}
    .usefooma-offline-input{width:100%;box-sizing:border-box;border:1px solid #dcdcde;border-radius:8px;padding:10px 12px}
    .usefooma-offline-note{color:#646970;font-size:12px;margin-top:7px}
    .usefooma-offline-code{display:block;background:#f6f7f7;border:1px solid #dcdcde;border-radius:8px;padding:10px 12px;font-family:monospace;word-break:break-all}
    .usefooma-offline-status{display:inline-flex;align-items:center;padding:5px 10px;border-radius:999px;font-size:12px;font-weight:700;background:<?= $enabled ? '#ecfdf3' : '#f3f4f6' ?>;color:<?= $enabled ? '#15803d' : '#6b7280' ?>}
    .usefooma-offline-log-wrap{overflow-x:auto}.usefooma-offline-logs{width:100%;border-collapse:collapse;min-width:820px}
    .usefooma-offline-logs th,.usefooma-offline-logs td{padding:11px 10px;border-bottom:1px solid #eee;text-align:left;vertical-align:top;font-size:12px}
    .usefooma-offline-logs th{font-size:11px;text-transform:uppercase;color:#646970;background:#f8f9fa}
    .usefooma-offline-badge{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:700;background:#f3f4f6;color:#50575e;white-space:nowrap}
    .usefooma-offline-badge.good{background:#ecfdf3;color:#15803d}.usefooma-offline-badge.bad{background:#fef2f2;color:#b91c1c}.usefooma-offline-badge.warn{background:#fff7ed;color:#c2410c}
    .usefooma-offline-muted{color:#646970}
  </style>

  <?php if ($notice !== ''): ?><div class="notice notice-<?= $notice_type === 'error' ? 'error' : 'success' ?> is-dismissible"><p><strong><?= esc_html($notice) ?></strong></p></div><?php endif; ?>

  <form method="post">
    <?php wp_nonce_field('usefooma_save_offline_data', 'usefooma_offline_nonce'); ?>
    <div class="usefooma-offline-card">
      <h2 style="margin-top:0">Africa's Talking</h2>
      <p><span class="usefooma-offline-status"><?= $enabled ? 'Enabled' : 'Disabled' ?></span></p>
      <div class="usefooma-offline-grid">
        <div>
          <label class="usefooma-offline-label">Nigeria Voice number</label>
          <input type="text" name="africas_talking_number" value="<?= esc_attr($number) ?>" class="usefooma-offline-input" placeholder="+234...">
          <p class="usefooma-offline-note">The Africa's Talking number customers call to trigger their configured Offline Data plan.</p>
        </div>
        <div>
          <label class="usefooma-offline-label">Daily limit</label>
          <input type="number" min="0" step="0.01" name="offline_data_daily_limit" value="<?= esc_attr($daily) ?>" class="usefooma-offline-input" placeholder="0">
          <p class="usefooma-offline-note">Set 0 for no daily limit.</p>
        </div>
        <div>
          <label class="usefooma-offline-label">Offline Data service charge</label>
          <label style="display:block;margin:0 0 10px"><input type="checkbox" name="offline_data_fee_enabled" value="1" <?= checked($fee_enabled,true,false) ?>> Charge customers a service fee</label>
          <div style="display:grid;grid-template-columns:1fr 140px;gap:8px">
            <input type="number" min="0" step="0.01" name="offline_data_fee" value="<?= esc_attr($offline_fee) ?>" class="usefooma-offline-input" placeholder="0">
            <select name="offline_data_fee_type" class="usefooma-offline-input"><option value="flat" <?= selected($fee_type,'flat',false) ?>>Flat ₦</option><option value="percent" <?= selected($fee_type,'percent',false) ?>>Percent %</option></select>
          </div>
        </div>
      </div>
      <p style="margin-top:18px"><label><input type="checkbox" name="africas_talking_enabled" value="1" <?= checked($enabled,true,false) ?>> Enable Offline Data</label></p>
      <p><button class="button button-primary" type="submit">Save Offline Data Settings</button></p>
    </div>

    <div class="usefooma-offline-card">
      <h2 style="margin-top:0">Callback</h2>
      <p>Set this exact callback URL in your Africa's Talking Voice application:</p>
      <code class="usefooma-offline-code"><?= esc_html($endpoint) ?></code>
      <p class="usefooma-offline-note">Incoming calls are matched to the caller's registered phone number. UseFooma then uses the customer's saved network and data plan, reusing the existing wallet, provider and transaction system.</p>
    </div>
  </form>

  <div class="usefooma-offline-card">
    <h2 style="margin-top:0">Recent Webhook Logs</h2>
    <p class="usefooma-offline-note">The 3 most recent incoming Voice callback requests.</p>
    <?php if (!$logs): ?>
      <p class="usefooma-offline-muted">No webhook logs yet.</p>
    <?php else: ?>
      <div class="usefooma-offline-log-wrap"><table class="usefooma-offline-logs"><thead><tr><th>ID</th><th>Caller</th><th>Number</th><th>Event</th><th>Status</th><th>Customer</th><th>Transaction</th><th>Received</th></tr></thead><tbody>
      <?php foreach ($logs as $log): $status=(string)$log->status; $badge=in_array($status,['success'],true)?'good':(in_array($status,['failed','invalid_signature','invalid_json'],true)?'bad':(in_array($status,['pending','duplicate','wrong_number'],true)?'warn':'')); ?>
        <tr><td><?= (int)$log->id ?></td><td><?= esc_html($log->caller ?: '—') ?></td><td><?= esc_html($log->number ?: '—') ?></td><td><?= esc_html($log->event_type ?: '—') ?></td><td><span class="usefooma-offline-badge <?= esc_attr($badge) ?>"><?= esc_html($status_labels[$status] ?? $status) ?></span></td><td><?= (int)$log->customer_id ?: '—' ?></td><td><?= (int)$log->transaction_id ?: '—' ?></td><td><?= esc_html($log->received_at ?: '—') ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
  </div>
</div>
