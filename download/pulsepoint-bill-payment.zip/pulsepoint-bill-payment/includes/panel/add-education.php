<?php
/**
 * Pulsepoint Add/Edit Education Plan Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-education.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_edu = "{$base_prefix}education";

// === Fetch existing plan for edit ===
$edit_plan = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $plan_id = intval($_GET['edit']);
    $edit_plan = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_edu} WHERE id = %d", $plan_id)
    );
}

// === Handle Form Submission ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_edu_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_edu_nonce'], 'save_pulsepoint_edu')
) {

    $data = [
        'serviceid'   => sanitize_text_field($_POST['serviceid']),
        'servicename' => sanitize_text_field($_POST['servicename']),
        'cashback'    => floatval($_POST['cashback']),
        'price'       => floatval($_POST['price']),
        'price_api'   => floatval($_POST['price_api']),
        'provider'    => sanitize_text_field($_POST['provider']),
    ];

    if ($edit_plan) {
        $wpdb->update($table_edu, $data, ['id' => $edit_plan->id]);
        echo '<div class="updated notice"><p><strong>Education plan updated successfully.</strong></p></div>';
    } else {
        $wpdb->insert($table_edu, $data);
        echo '<div class="updated notice"><p><strong>New education plan added successfully.</strong></p></div>';
    }

    if (!$edit_plan) {
        $edit_plan = (object) $data;
    }
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline">
    <?= $edit_plan ? 'Edit Education Plan' : 'Add New Education Plan' ?>
  </h1>
  <a href="?page=pulsepoint-education" class="page-title-action">
    <i class="bi bi-arrow-left"></i> Back to Education Plans
  </a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section {
      background:#fff;
      border-radius:14px;
      padding:24px;
      box-shadow:0 3px 10px rgba(0,0,0,0.05);
      margin-top:24px;
    }
    .pulse-input {
      width:100%;
      border:1px solid #ddd;
      padding:10px 14px;
      border-radius:8px;
      font-size:14px;
    }
    .pulse-label {
      font-weight:600;
      font-size:14px;
      margin-bottom:6px;
      display:block;
    }
    .pulse-btn {
      background:var(--primary);
      color:#fff;
      padding:10px 20px;
      border:none;
      border-radius:8px;
      cursor:pointer;
      font-weight:600;
    }
    .pulse-grid {
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
      gap:16px;
    }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_edu', 'pulsepoint_edu_nonce'); ?>

    <div class="pulse-section">
      <div class="pulse-grid">

        <div>
          <label class="pulse-label">Service ID</label>
          <input type="text" name="serviceid"
                 value="<?= esc_attr($edit_plan->serviceid ?? '') ?>"
                 class="pulse-input" required>
        </div>

        <div>
          <label class="pulse-label">Service Name</label>
          <input type="text" name="servicename"
                 value="<?= esc_attr($edit_plan->servicename ?? '') ?>"
                 class="pulse-input">
        </div>

        <div>
          <label class="pulse-label">Cashback (₦)</label>
          <input type="number" step="0.01" name="cashback"
                 value="<?= esc_attr($edit_plan->cashback ?? 0) ?>"
                 class="pulse-input">
        </div>

        <div>
          <label class="pulse-label">Price (₦)</label>
          <input type="number" step="0.01" name="price"
                 value="<?= esc_attr($edit_plan->price ?? 0) ?>"
                 class="pulse-input" required>
        </div>

        <div>
          <label class="pulse-label">API Price (₦)</label>
          <input type="number" step="0.01" name="price_api"
                 value="<?= esc_attr($edit_plan->price_api ?? 0) ?>"
                 class="pulse-input">
        </div>

        <div>
          <label class="pulse-label">Provider</label>
          <select name="provider" class="pulse-input">
            <?php
            $edu_dir = PULSEPOINT_DIR . 'core/education/';
            $files = glob($edu_dir . '*.php');
            foreach ($files as $file) {
                $filename = basename($file, '.php');
                if ($filename === 'pulsepoint') continue;
                $selected = ($edit_plan->provider ?? '') === $filename ? 'selected' : '';
                echo "<option value='{$filename}' {$selected}>{$filename}</option>";
            }
            ?>
          </select>
        </div>

      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn">
        <i class="bi bi-save"></i>
        <?= $edit_plan ? 'Update Plan' : 'Add Plan' ?>
      </button>
    </div>

  </form>
</div>