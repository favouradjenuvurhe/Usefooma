<?php  
/**
 * Pulsepoint Add/Edit Electricity/Bill Plan Page  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-bill.php  
 * Author: Amaaavl  
 */  

if (!defined('ABSPATH')) exit;  

global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
$table_bill = "{$base_prefix}bill";  

// === Fetch existing plan for edit ===  
$edit_plan = null;  
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {  
    $plan_id = intval($_GET['edit']);  
    $edit_plan = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_bill} WHERE id = %d", $plan_id)
    );  
}  

// === Handle Form Submission ===  
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_bill_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_bill_nonce'], 'save_pulsepoint_bill')
) {  

    $data = [  
        'plan'     => sanitize_text_field($_POST['plan']),  
        'details'  => sanitize_text_field($_POST['details']),  
        'fee'      => floatval($_POST['fee']),  
        'fee_api'  => floatval($_POST['fee_api']),  
        'provider' => sanitize_text_field($_POST['provider']),  
    ];  

    if ($edit_plan) {  
        $wpdb->update($table_bill, $data, ['id' => $edit_plan->id]);  
        echo '<div class="updated notice"><p><strong>Bill plan updated successfully.</strong></p></div>';  
    } else {  
        $wpdb->insert($table_bill, $data);  
        echo '<div class="updated notice"><p><strong>New bill plan added successfully.</strong></p></div>';  
    }  

    if (!$edit_plan) {  
        $edit_plan = (object) $data;  
    }  
}  
?>  

<div class="wrap">  
  <h1 class="wp-heading-inline">
    <?= $edit_plan ? 'Edit Electricity/Bill Plan' : 'Add New Electricity/Bill Plan' ?>
  </h1>  
  <a href="?page=pulsepoint-bill" class="page-title-action">
    <i class="bi bi-arrow-left"></i> Back to Bill Plans
  </a>  
  <hr class="wp-header-end">  

  <script src="https://cdn.tailwindcss.com"></script>  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">  

  <style>  
    :root { --primary: #356cf9; }  
    .pulse-section {
      background:#fff;
      border-radius:14px;
      padding:24px;
      box-shadow:0 3px 10px rgba(0,0,0,0.05);
      margin-top:24px;
    }  
    .pulse-input {
      width:100%;
      border:1px solid #ddd;
      padding:10px 14px;
      border-radius:8px;
      font-size:14px;
    }  
    .pulse-label {
      font-weight:600;
      font-size:14px;
      margin-bottom:6px;
      display:block;
    }  
    .pulse-btn {
      background:var(--primary);
      color:#fff;
      padding:10px 20px;
      border:none;
      border-radius:8px;
      cursor:pointer;
      font-weight:600;
    }  
    .pulse-grid {
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
      gap:16px;
    }  
  </style>  

  <form method="POST">  
    <?php wp_nonce_field('save_pulsepoint_bill', 'pulsepoint_bill_nonce'); ?>  

    <div class="pulse-section">  
      <div class="pulse-grid">  

        <div>  
          <label class="pulse-label">Disco ID</label>  
          <input type="text" name="plan"
                 value="<?= esc_attr($edit_plan->plan ?? '') ?>"
                 class="pulse-input" required>  
        </div>  

        <div>  
          <label class="pulse-label">Details / Description</label>  
          <select name="details" class="pulse-input">  
            <?php  
            $electricity_providers = [
                'BEDC','EKEDC','AEDC','IKEDC','KEDCO',
                'PHED','YEDC','JED','EEDC','IBEDC','KEDC'
            ];  

            foreach ($electricity_providers as $provider) {  
                $selected = ($edit_plan->details ?? '') === $provider ? 'selected' : '';  
                echo "<option value='{$provider}' {$selected}>{$provider}</option>";  
            }  
            ?>  
          </select>  
        </div>  

        <div>  
          <label class="pulse-label">Fee (₦)</label>  
          <input type="number" step="0.01" name="fee"
                 value="<?= esc_attr($edit_plan->fee ?? '') ?>"
                 class="pulse-input" required>  
        </div>  

        <div>  
          <label class="pulse-label">API Fee (₦)</label>  
          <input type="number" step="0.01" name="fee_api"
                 value="<?= esc_attr($edit_plan->fee_api ?? '') ?>"
                 class="pulse-input">  
        </div>  

        <div>  
          <label class="pulse-label">Provider</label>  
          <select name="provider" class="pulse-input">  
            <?php  
            $electricity_dir = PULSEPOINT_DIR . 'core/electricity/';  
            $files = glob($electricity_dir . '*.php');  

            foreach ($files as $file) {  
                $filename = basename($file, '.php');  
                if ($filename === 'pulsepoint') continue;  

                $selected = ($edit_plan->provider ?? '') === $filename ? 'selected' : '';  
                echo "<option value='{$filename}' {$selected}>{$filename}</option>";  
            }  
            ?>  
          </select>  
        </div>  

      </div>  
    </div>  

    <div class="pulse-section text-right">  
      <button type="submit" class="pulse-btn">
        <i class="bi bi-save"></i>
        <?= $edit_plan ? 'Update Plan' : 'Add Plan' ?>
      </button>  
    </div>  

  </form>  
</div>