<?php
/**
 * Pulsepoint Admin Users Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/users.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

// === CREATE TABLE IF NOT EXISTS (safety) ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$base_prefix}users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstname` VARCHAR(100) NOT NULL,
  `lastname` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `email` VARCHAR(200) NOT NULL,
  `wallet` DECIMAL(14,2) DEFAULT 0.00,
  `referral_balance` DECIMAL(14,2) DEFAULT 0.00,
  `referby` BIGINT UNSIGNED DEFAULT NULL,
  `token` VARCHAR(255) DEFAULT NULL,
  `reset_token` VARCHAR(255) DEFAULT NULL,
  `passcode` VARCHAR(4) DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `security_question1` VARCHAR(255) DEFAULT NULL,
  `security_question2` VARCHAR(255) DEFAULT NULL,
  `security_question3` VARCHAR(255) DEFAULT NULL,
  `account_limit` DECIMAL(14,2) DEFAULT 0.00,
  `auto_login` TINYINT(1) DEFAULT 0,
  `alert` TINYINT(1) DEFAULT 1,
  `close_account` TINYINT(1) DEFAULT 0,
  `gender` ENUM('Male','Female','Other') DEFAULT NULL,
  `dob` DATE DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `account_type` ENUM('Customer','Agent','API') DEFAULT 'Customer',
  `status` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_unique` (`email`),
  FOREIGN KEY (`referby`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE SET NULL
) $charset;");

// === Platform Settings ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// === Totals ===
$total_users = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$base_prefix}users");
$total_wallet = (float) $wpdb->get_var("SELECT SUM(wallet) FROM {$base_prefix}users");
$total_referral = (float) $wpdb->get_var("SELECT SUM(referral_balance) FROM {$base_prefix}users");
$total_agents = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$base_prefix}users WHERE account_type='Agent'");

// === Search Handling ===
$where = "1=1";
$search_value = '';
if (!empty($_GET['search'])) {
    $search_value = sanitize_text_field($_GET['search']);
    $where .= $wpdb->prepare(" AND (
        firstname LIKE %s OR 
        lastname LIKE %s OR 
        phone LIKE %s OR 
        email LIKE %s
    )", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%");
}

// === Fetch Users ===
$users = $wpdb->get_results("
    SELECT * FROM {$base_prefix}users
    WHERE {$where}
    ORDER BY created_at DESC
    LIMIT 100
");

// === Formatter ===
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Users</h1>
  <p>Manage and review all registered users below.</p>
  <hr class="wp-header-end">

  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 18px;
      margin-top: 20px;
    }
    .pulse-card {
      background: #fff;
      border-radius: 14px;
      padding: 18px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
    }
    .pulse-title {
      color: #666;
      font-size: 13px;
      text-transform: uppercase;
      font-weight: 600;
    }
    .pulse-value {
      font-weight: 800;
      font-size: 22px;
      color: var(--primary);
      margin-top: 6px;
    }
    .search-bar {
      margin-top: 24px;
      display: flex;
      gap: 12px;
    }
    .search-input {
      width: 100%;
      padding: 10px 14px;
      border-radius: 8px;
      border: 1px solid #ddd;
      font-size: 14px;
    }
    .search-btn {
      background: var(--primary);
      color: #fff;
      padding: 10px 18px;
      border-radius: 8px;
      cursor: pointer;
      border: none;
    }
    .pulse-table-container {
      margin-top: 28px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      overflow-x: auto;
      width: 100%;
    }
    .pulse-table {
      width: 100%;
      border-collapse: collapse;
      min-width: 1100px;
    }
    .pulse-table th, .pulse-table td {
      padding: 12px 14px;
      border-bottom: 1px solid #eee;
      text-align: left;
      font-size: 14px;
      white-space: nowrap;
    }
    .pulse-table th {
      background: #f8fafc;
      font-weight: 700;
      text-transform: uppercase;
      font-size: 12px;
    }
    .view-btn {
      background: var(--primary);
      color: #fff;
      padding: 6px 12px;
      border-radius: 8px;
      text-decoration: none;
      font-size: 13px;
      white-space: nowrap;
    }
  </style>

  <!-- Summary Cards -->
  <div class="pulse-grid">
    <div class="pulse-card">
      <div class="pulse-title">Total Users</div>
      <div class="pulse-value"><?= number_format($total_users) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Total Wallet Balances</div>
      <div class="pulse-value text-green-600"><?= fmt_amt($total_wallet) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Referral Balances</div>
      <div class="pulse-value text-blue-600"><?= fmt_amt($total_referral) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Total Agents</div>
      <div class="pulse-value text-purple-600"><?= number_format($total_agents) ?></div>
    </div>
  </div>

  <!-- Search -->
  <form method="get" class="search-bar">
    <input type="hidden" name="page" value="pulsepoint-users">
    <input type="text" name="search" value="<?= esc_attr($search_value) ?>" class="search-input" placeholder="Search by name, phone, or email...">
    <button type="submit" class="search-btn"><i class="bi bi-search"></i> Search</button>
  </form>

  <!-- Users Table -->
  <div class="pulse-table-container">
    <table class="pulse-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Wallet</th>
          <th>Referral</th>
          <th>Account Type</th>
          <th>Status</th>
          <th>Created</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($users): foreach ($users as $u): ?>
          <tr>
            <td>#<?= $u->id ?></td>
            <td><?= esc_html(ucfirst($u->firstname) . ' ' . ucfirst($u->lastname)) ?></td>
            <td><?= esc_html($u->phone) ?></td>
            <td><?= esc_html($u->email) ?></td>
            <td><?= fmt_amt($u->wallet) ?></td>
            <td><?= fmt_amt($u->referral_balance) ?></td>
            <td><?= esc_html($u->account_type) ?></td>
            <td>
              <?php if ($u->status): ?>
                <span class="text-green-600 font-semibold">Active</span>
              <?php else: ?>
                <span class="text-red-600 font-semibold">Inactive</span>
              <?php endif; ?>
            </td>
            <td><?= esc_html($u->created_at) ?></td>
            <td><a href="?page=pulsepoint-view_user&id=<?= $u->id ?>" class="view-btn">View</a></td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="10" class="text-center py-4">No users found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>