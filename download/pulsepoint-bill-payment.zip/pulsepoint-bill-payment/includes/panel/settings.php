<?php  
/**  
 * Pulsepoint Admin Settings Page  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/settings.php  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
$charset = $wpdb->get_charset_collate();  
$table_settings = "{$base_prefix}settings";  
  
// === Create settings table if not exists ===  
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_settings}` (  
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,  
    `opt_key` VARCHAR(255) NOT NULL,  
    `opt_value` TEXT,  
    `type` VARCHAR(50) DEFAULT 'string',  
    `grouping` VARCHAR(100) DEFAULT NULL,  
    `autoload` TINYINT(1) DEFAULT 0,  
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,  
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  
    PRIMARY KEY (`id`),  
    UNIQUE KEY `opt_key_unique` (`opt_key`)  
) {$charset};");  
  
// === Default Settings ===  
$defaults = [  
    // 🌐 Platform Info  
    'platform_name'     => 'Pulsepoint',  
    'color_hex'         => '#356cf9',  
    'phone_number'      => '09064873505',  
    'email_number'      => 'favour-amaaavl@outlook.com',
    'referral_amount'      => '50',
    'auth_email'   => '0',   
  
    // 💳 Payvessel Configuration / Payment Gateway  
    'payment_gateway'   => 'payvessel', // default selected  
    'pay_token'         => 'token',  
    'pay_secret'        => 'secret',  
    'pay_biz'           => 'bus_id',  
  
    // NEWLY ADDED VALUES (Your Request)  
    'pay_fee'           => 'fundung_fee',  
    'pay_bank'          => 'banking_fee',  
    'pay_usdt'          => 'cryto_fee',  
  
    'logo_url'          => 'url',  
    'favicon_url'       => 'url',  
  
    'ads1_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    'ads2_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    'ads3_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
  
    // ⚙️ Platform Controls  
    'maintenance_mode'  => '0',  
  
    // 💰 Account & Discount Settings  
    'account_limit'     => '5000',  
    'agent_discount'    => '5',  
    'api_discount'      => '3',  
  
    // 📡 API Configuration for Services  
    'airtime_api'       => 'adex',
    'airtime_kyc'       => '1',  
    'airtime_token'     => 'token',  
    'cable_api'         => 'adex', 
    'cable_kyc'       => '0',
    'cable_token'       => 'token',  
    'bill_api'          => 'adex',  
    'bill_kyc'       => '0',
    'bill_token'        => 'token', 
    'bank_transfer'       => 'strowallet', 
    'bank_kyc'       => '1',
    'bank_token'       => '', 
];  
  
// === Sync defaults with DB ===  
foreach ($defaults as $key => $value) {  
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s", $key));  
    if (!$exists) {  
        $wpdb->insert($table_settings, [  
            'opt_key' => $key,  
            'opt_value' => maybe_serialize($value),  
            'type' => 'string',  
            'autoload' => 1  
        ]);  
    }  
}  
  
// === Handle Save ===  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_settings_nonce']) && wp_verify_nonce($_POST['pulsepoint_settings_nonce'], 'save_pulsepoint_settings')) {  
    foreach ($_POST as $key => $value) {  
        if (array_key_exists($key, $defaults)) {  
            // Fix for Live Chat Script to allow HTML/JS
            if ($key === 'livechat_script') {
                $save_value = maybe_serialize($value); // save raw script
            } else {
                $save_value = maybe_serialize(sanitize_text_field($value));
            }

            $wpdb->update(  
                $table_settings,  
                ['opt_value' => $save_value],  
                ['opt_key' => $key]  
            );  
        }  
    }  
    echo '<div class="updated notice"><p><strong>Settings saved successfully.</strong></p></div>';  
}  
  
// === Fetch all current settings ===  
$settings = [];  
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");  
foreach ($rows as $r) {  
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);  
}  
  
// === Get platform info ===  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#356cf9';  
  
// === Scan Payment Gateways Folder ===
$gateway_folder = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/virtual-account/';
$gateways = [];

// files to block
$blocked_files = [
    'pulsepoint.php',
    'dynamic.php',
    'cashwyre-dynamic.php'
];

if (is_dir($gateway_folder)) {
    foreach (scandir($gateway_folder) as $file) {

        // only php files
        if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
            continue;
        }

        // block specific files
        if (in_array(strtolower($file), $blocked_files, true)) {
            continue;
        }

        $gateways[] = pathinfo($file, PATHINFO_FILENAME);
    }
}
  
?>  

<div class="wrap">  
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Settings</h1>  
  <p>Manage platform configuration and integration credentials below.</p>  
  <hr class="wp-header-end">  

  <script src="https://cdn.tailwindcss.com"></script>  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">  

  <style>  
    :root { --primary: <?= $color_hex ?>; }  
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }  
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }  
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }  
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }  
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }  
  </style>  

  <form method="POST">  
    <?php wp_nonce_field('save_pulsepoint_settings', 'pulsepoint_settings_nonce'); ?>  

    <!-- Platform Info -->  
    <div class="pulse-section">  
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-gear"></i> Platform Info</h2>  
      <div class="pulse-grid">  
        <div>  
          <label class="pulse-label">Platform Name</label>  
          <input type="text" name="platform_name" value="<?= esc_attr($settings['platform_name']) ?>" class="pulse-input">  
        </div>  
        <div>
          <label class="pulse-label">Brand Color (HEX)</label>
          <input type="text" name="color_hex" placeholder="#000000" value="<?= esc_attr($settings['color_hex']) ?>" class="pulse-input">
        </div>
        <div>  
          <label class="pulse-label">Phone Number</label>  
          <input type="text" name="phone_number" value="<?= esc_attr($settings['phone_number']) ?>" class="pulse-input">  
        </div>  
        <div>  
          <label class="pulse-label">Email</label>  
          <input type="email" name="email_number" value="<?= esc_attr($settings['email_number']) ?>" class="pulse-input">  
        </div> 
        <div>
    <label class="pulse-label">Email Authentication</label>
    <select name="auth_email" class="pulse-input">
        <option value="0" <?= (isset($settings['auth_email']) && $settings['auth_email'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['auth_email']) && $settings['auth_email'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>  
          <label class="pulse-label">Referral Amount</label>  
          <input type="text" name="referral_amount" value="<?= esc_attr($settings['referral_amount']) ?>" class="pulse-input">  
        </div> 
        
      </div>  
    </div>  

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-credit-card"></i> Payment Gateway</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Select Gateway</label>
          <select name="payment_gateway" class="pulse-input">
            <?php foreach ($gateways as $gw): ?>
              <option value="<?= esc_attr($gw) ?>" <?= selected($settings['payment_gateway'], $gw, false) ?>><?= esc_html(ucfirst($gw)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="pulse-label">Token</label>
          <input type="text" name="pay_token" value="<?= esc_attr($settings['pay_token']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Secret</label>
          <input type="text" name="pay_secret" value="<?= esc_attr($settings['pay_secret']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Business ID</label>
          <input type="text" name="pay_biz" value="<?= esc_attr($settings['pay_biz']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-sliders"></i> Platform Controls</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Maintenance Mode</label>
          <select name="maintenance_mode" class="pulse-input">
            <option value="0" <?= selected($settings['maintenance_mode'], '0', false) ?>>Disabled</option>
            <option value="1" <?= selected($settings['maintenance_mode'], '1', false) ?>>Enabled</option>
          </select>
        </div>
        <div>
          <label class="pulse-label">API Mode</label>
          <select name="api_mode" class="pulse-input">
            <option value="live" <?= selected($settings['api_mode'], 'live', false) ?>>Live</option>
            <option value="test" <?= selected($settings['api_mode'], 'test', false) ?>>Test</option>
          </select>
        </div>
      </div>
    </div>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-wallet2"></i> Account & Discounts</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Account Limit</label>
          <input type="number" name="account_limit" value="<?= esc_attr($settings['account_limit']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Agent Discount (%)</label>
          <input type="number" name="agent_discount" value="<?= esc_attr($settings['agent_discount']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">API Discount (%)</label>
          <input type="number" name="api_discount" value="<?= esc_attr($settings['api_discount']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-cloud"></i> API Configuration</h2>
      <div class="pulse-grid">
      <div>
    <label class="pulse-label">Bank Transfer - Type</label>
    <select name="bank_transfer" class="pulse-input">
        <?php
        $transfer_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/transfer/';
        $files = glob($transfer_dir . '*.php'); // get all PHP files

        foreach ($files as $file) {
            $filename = basename($file, '.php'); // get file name without .php
            // Skip pulsepoint.php and verification.php
            if (in_array($filename, ['pulsepoint', 'verification', 'wallet2'])) continue;

            $selected = ($settings['bank_transfer'] ?? '') === $filename ? 'selected' : '';
            echo "<option value='{$filename}' {$selected}>{$filename}</option>";
        }
        ?>
    </select>
</div>

<div>
    <label class="pulse-label">Bank Token</label>
    <input type="text" 
           name="bank_token" 
           value="<?= esc_attr($settings['bank_token']) ?>" 
           class="pulse-input">
</div>
<div>
    <label class="pulse-label">Bank Transfer KYC</label>
    <select name="bank_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['bank_kyc']) && $settings['bank_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['bank_kyc']) && $settings['bank_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
    <label class="pulse-label">Airtime API - Type</label>
    <select name="airtime_api" class="pulse-input">
        <?php
        $airtime_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/airtime/';
        $files = glob($airtime_dir . '*.php'); // get all PHP files

        foreach ($files as $file) {
            $filename = basename($file, '.php'); // get file name without .php
            if ($filename === 'pulsepoint') continue; // skip pulsepoint.php

            $selected = ($settings['airtime_api'] ?? '') === $filename ? 'selected' : '';
            echo "<option value='{$filename}' {$selected}>{$filename}</option>";
        }
        ?>
    </select>
</div>
<div>
    <label class="pulse-label">Airtime KYC</label>
    <select name="airtime_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['airtime_kyc']) && $settings['airtime_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['airtime_kyc']) && $settings['airtime_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
          <label class="pulse-label">Airtime Token</label>
          <input type="text" name="airtime_token" value="<?= esc_attr($settings['airtime_token']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Cable API - Endpoint</label>
          <input type="text" name="cable_api" value="<?= esc_attr($settings['cable_api']) ?>" class="pulse-input">
        </div>
        <div>
    <label class="pulse-label">Cable KYC</label>
    <select name="cable_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['cable_kyc']) && $settings['cable_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['cable_kyc']) && $settings['cable_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
          <label class="pulse-label">Cable Token</label>
          <input type="text" name="cable_token" value="<?= esc_attr($settings['cable_token']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Bill API - Endpoint</label>
          <input type="text" name="bill_api" value="<?= esc_attr($settings['bill_api']) ?>" class="pulse-input">
        </div>
        <div>
    <label class="pulse-label">Bill KYC</label>
    <select name="bill_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['bill_kyc']) && $settings['bill_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['bill_kyc']) && $settings['bill_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
          <label class="pulse-label">Bill Token</label>
          <input type="text" name="bill_token" value="<?= esc_attr($settings['bill_token']) ?>" class="pulse-input">
        </div>
      </div>
    </div>
    
    <div class="pulse-section">
  <h2 class="text-lg font-semibold mb-4"><i class="bi bi-cash-stack"></i> Fees Configuration</h2>
  <div class="pulse-grid">

      <div>
        <label class="pulse-label">Funding Fee - % </label>
        <input type="text" name="pay_fee" value="<?= esc_attr($settings['pay_fee']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Bank Transfer Fee ( flat )</label>
        <input type="text" name="pay_bank" value="<?= esc_attr($settings['pay_bank']) ?>" class="pulse-input">
      </div>

      

  </div>
</div>


<div class="pulse-section">
  <h2 class="text-lg font-semibold mb-4"><i class="bi bi-image"></i> Branding Assets</h2>
  <div class="pulse-grid">

      <div>
        <label class="pulse-label">Logo URL</label>
        <input type="text" name="logo_url" value="<?= esc_attr($settings['logo_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Favicon URL</label>
        <input type="text" name="favicon_url" value="<?= esc_attr($settings['favicon_url']) ?>" class="pulse-input">
      </div>

  </div>
</div>


<div class="pulse-section">
  <h2 class="text-lg font-semibold mb-4"><i class="bi bi-badge-ad"></i> Advertisement Banners</h2>
  <div class="pulse-grid">

      <div>
        <label class="pulse-label">Ads Banner 1</label>
        <input type="text" name="ads1_url" value="<?= esc_attr($settings['ads1_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Ads Banner 2</label>
        <input type="text" name="ads2_url" value="<?= esc_attr($settings['ads2_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Ads Banner 3</label>
        <input type="text" name="ads3_url" value="<?= esc_attr($settings['ads3_url']) ?>" class="pulse-input">
      </div>

  </div>
</div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Settings</button>
    </div>

  </form>
</div>