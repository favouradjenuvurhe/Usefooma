<?php
/**
 * Pulsepoint Saving Settings Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/saving-setting.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_settings = "{$base_prefix}settings";
$table_pocket = "{$base_prefix}savings_pocket";
$table_txn = "{$base_prefix}savings_transactions";

// === Create savings tables if not exist ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_pocket}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `target_amount` DECIMAL(14,2) NOT NULL,
    `current_amount` DECIMAL(14,2) DEFAULT 0.00,
    `frequency` ENUM('daily','weekly','monthly','manual') DEFAULT 'manual',
    `auto_save` TINYINT(1) DEFAULT 0,
    `amount_per_cycle` DECIMAL(14,2) DEFAULT 0.00,
    `start_date` DATE DEFAULT NULL,
    `maturity_date` DATE DEFAULT NULL,
    `status` ENUM('active','completed','paused','cancelled') DEFAULT 'active',
    `withdrawable` TINYINT(1) DEFAULT 0,
    `interest_rate` DECIMAL(5,2) DEFAULT 0.00,
    `locked` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) {$charset};");

$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_txn}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `pocket_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `type` ENUM('deposit','withdrawal','interest') NOT NULL,
    `amount` DECIMAL(14,2) NOT NULL,
    `reference` VARCHAR(255) DEFAULT NULL,
    `method` ENUM('wallet','card','transfer','auto-save') DEFAULT 'wallet',
    `status` ENUM('pending','success','failed') DEFAULT 'success',
    `note` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) {$charset};");

// === Create settings table if not exists ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_settings}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `opt_key` VARCHAR(255) NOT NULL,
    `opt_value` TEXT,
    `type` VARCHAR(50) DEFAULT 'string',
    `grouping` VARCHAR(100) DEFAULT NULL,
    `autoload` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `opt_key_unique` (`opt_key`)
) {$charset};");

// === Default Settings ===
$defaults = [
    'saving_int' => '1',
    'saving_fee' => '1',
];

// === Sync defaults with DB ===
foreach ($defaults as $key => $value) {
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s", $key));
    if (!$exists) {
        $wpdb->insert($table_settings, [
            'opt_key' => $key,
            'opt_value' => maybe_serialize($value),
            'type' => 'string',
            'autoload' => 1
        ]);
    }
}

// === Handle Save ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_saving_nonce']) && wp_verify_nonce($_POST['pulsepoint_saving_nonce'], 'save_pulsepoint_saving')) {
    foreach ($_POST as $key => $value) {
        if (array_key_exists($key, $defaults)) {
            $wpdb->update(
                $table_settings,
                ['opt_value' => maybe_serialize(sanitize_text_field($value))],
                ['opt_key' => $key]
            );
        }
    }
    echo '<div class="updated notice"><p><strong>Saving settings updated successfully.</strong></p></div>';
}

// === Fetch all current settings ===
$settings = [];
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
foreach ($rows as $r) {
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);
}

// === Platform Info for Style ===
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#356cf9';

// === Fetch all savings pockets ===
$pockets = $wpdb->get_results("SELECT * FROM {$table_pocket} ORDER BY id DESC");
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Saving Settings</h1>
  <p>Configure saving system settings, interest & fee, and manage user saving pockets here.</p>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; }
    table.saving-table { width: 100%; border-collapse: collapse; margin-top: 12px; }
    table.saving-table th, table.saving-table td { border: 1px solid #eee; padding: 10px; font-size: 13px; text-align: left; }
    table.saving-table th { background: #f9fafb; }
    .action-btn { background: var(--primary); color: #fff; border: none; padding: 6px 10px; border-radius: 6px; font-size: 12px; cursor: pointer; margin-right: 4px; }
    .action-btn.delete { background: #dc2626; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_saving', 'pulsepoint_saving_nonce'); ?>

    <!-- Saving Configuration -->
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-piggy-bank"></i> Saving Configuration</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Interest (%)</label>
          <input type="number" step="0.01" name="saving_int" value="<?= esc_attr($settings['saving_int']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Saving Fee (%)</label>
          <input type="number" step="0.01" name="saving_fee" value="<?= esc_attr($settings['saving_fee']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    <!-- Save Button -->
    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Settings</button>
    </div>
  </form>

  <!-- List of Saving Pockets -->
  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-list"></i> All Saving Pockets</h2>
    <?php if (!empty($pockets)) : ?>
      <table class="saving-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Title</th>
            <th>Target</th>
            <th>Current</th>
            <th>Status</th>
            <th>Auto Save</th>
            <th>Interest %</th>
            <th>Created</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pockets as $p): ?>
            <tr>
              <td><?= esc_html($p->id) ?></td>
              <td><?= esc_html($p->user_id) ?></td>
              <td><?= esc_html($p->title) ?></td>
              <td>₦<?= number_format($p->target_amount, 2) ?></td>
              <td>₦<?= number_format($p->current_amount, 2) ?></td>
              <td><?= ucfirst($p->status) ?></td>
              <td><?= $p->auto_save ? 'Yes' : 'No' ?></td>
              <td><?= esc_html($p->interest_rate) ?>%</td>
              <td><?= esc_html($p->created_at) ?></td>
              <td>
                <button class="action-btn"><i class="bi bi-percent"></i> Add Interest</button>
                <button class="action-btn"><i class="bi bi-check-circle"></i> Change Status</button>
                <button class="action-btn delete"><i class="bi bi-trash"></i> Delete</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No saving pockets found yet.</p>
    <?php endif; ?>
  </div>
</div>