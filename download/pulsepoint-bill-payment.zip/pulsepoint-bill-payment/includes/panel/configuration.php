<?php    
/**    
 * Pulsepoint Configuration Page    
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/configuration.php    
 * Author: Amaaavl    
 */    
    
if (!defined('ABSPATH')) exit;    
    
global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
// === Fetch Platform Settings ===    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    

// Giftcard and Boost are add-on plugins. Their configuration cards are shown
// only when the corresponding add-on plugin is active.
$giftcard_addon_active = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('giftcard');
$smm_addon_active      = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('smm');
$esim_addon_active     = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('esim');
$storefront_addon_active = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('storefront');
$color_hex     = $settings['color_hex'] ?? '#6C63FF';    
?>
<div class="wrap usefooma-config-wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Configuration</h1>
  <p>Manage integrations and platform services from one settings screen.</p>
  <hr class="wp-header-end">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <?php
  $config_tabs = [
      'api-setup' => ['General', 'gear'],
      'provider' => ['Data Slot', 'plug'],
      'data' => ['Data', 'sim'],
      'cable' => ['Cable TV', 'tv'],
      'electricity' => ['Electricity', 'lightning-charge'],
      'betting' => ['Betting', 'controller'],
      'education' => ['Education', 'mortarboard'],
      'other-key' => ['Cards', 'credit-card'],
      'airtime-to-cash' => ['A2Cash', 'arrow-left-right'],
      'virtual-accounts' => ['Accounts', 'bank'],
      'revenue' => ['Revenue', 'graph-up-arrow'],
      'promo-code' => ['Promo Code', 'ticket-perforated'],
      'security' => ['Security', 'shield-lock'],
      'offline-data' => ['Offline Data', 'telephone'],
  ];

  // Add-on configuration tabs are conditional. They only appear when the
  // corresponding add-on is actually active and the configuration panel
  // exists. This keeps the base configuration clean while preserving the
  // previous add-on behaviour.
  $config_addons = [
      'giftcard'   => ['Giftcard', 'gift', 'giftcard.php'],
      'smm'        => ['Boost', 'rocket-takeoff', 'smm.php'],
      'storefront' => ['Storefront', 'shop', 'storefront.php'],
      'esim'       => ['eSIM', 'sim', 'esim.php'],
  ];

  foreach ($config_addons as $addon_slug => $addon_tab) {
      if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active($addon_slug)) {
          $addon_file = trailingslashit(PULSEPOINT_DIR) . 'includes/panel/' . $addon_tab[2];
          if (is_file($addon_file)) {
              $config_tabs[$addon_slug] = [$addon_tab[0], $addon_tab[1]];
          }
      }
  }

  $active_config = isset($_GET['section']) ? sanitize_key(wp_unslash($_GET['section'])) : 'api-setup';
  if (!isset($config_tabs[$active_config])) $active_config = 'api-setup';
  ?>

  <style>
    .usefooma-config-wrap { max-width: 1320px; }
    .usefooma-config-tabs { display:flex; flex-wrap:wrap; gap:0; border-bottom:1px solid #dcdcde; margin-top:20px; overflow-x:auto; }
    .usefooma-config-tab { display:inline-flex; align-items:center; gap:0; padding:11px 15px; margin:0 2px -1px 0; border:0; border-bottom:2px solid transparent; background:transparent; color:#50575e; text-decoration:none; font-size:13px; font-weight:600; white-space:nowrap; }
    .usefooma-config-tab:hover { background:#f6f7f7; color:#1d2327; }
    .usefooma-config-tab.active { color:#2271b1; background:#fff; border-bottom-color:#2271b1; }
    .usefooma-config-content { padding-top:24px; }
    .usefooma-config-content > .wrap { margin:0 !important; padding:0 !important; max-width:none !important; }
    .usefooma-config-content > .wrap > h1,
    .usefooma-config-content > .wrap > p,
    .usefooma-config-content > .wrap > hr.wp-header-end,
    .usefooma-config-content > .wrap > .page-title-action,
    .usefooma-config-content > .wrap > script,
    .usefooma-config-content > .wrap > link { display:none !important; }
    .usefooma-config-content .pulse-section,
    .usefooma-config-content .config-card,
    .usefooma-config-content .pulse-table-container {
      background:#fff !important;
      border:1px solid #e5e7eb !important;
      border-radius:14px !important;
      box-shadow:0 3px 10px rgba(0,0,0,0.05) !important;
    }
    .usefooma-config-content .pulse-section { padding:24px !important; margin:0 0 24px !important; }
    .usefooma-config-content .config-card { padding:24px !important; margin:0 0 24px !important; }
    .usefooma-config-content .pulse-table-container { margin:0 0 24px !important; overflow:hidden; }
    .usefooma-config-content .pulse-input { border-radius:8px !important; box-shadow:none !important; }
    .usefooma-config-content .pulse-btn { border-radius:8px !important; }
    .usefooma-config-content .config-grid { margin-top:0 !important; }
    @media(max-width:782px){ .usefooma-config-tabs { flex-wrap:nowrap; } .usefooma-config-tab { padding:10px 12px; } }
  </style>

  <nav class="usefooma-config-tabs" aria-label="Configuration settings">
    <?php foreach ($config_tabs as $slug => $tab): ?>
      <a class="usefooma-config-tab <?= $active_config === $slug ? 'active' : '' ?>" href="<?= esc_url(admin_url('admin.php?page=pulsepoint-configuration&section=' . $slug)) ?>">
        <?= esc_html($tab[0]) ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="usefooma-config-content">
    <?php
    $config_file = trailingslashit(PULSEPOINT_DIR) . 'includes/panel/' . $active_config . '.php';
    if (is_file($config_file)) {
        include $config_file;
    } else {
        echo '<p>' . esc_html__('Configuration section not found.', 'pulsepoint') . '</p>';
    }
    ?>
  </div>
</div>
