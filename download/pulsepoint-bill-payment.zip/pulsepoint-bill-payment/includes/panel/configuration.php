<?php    
/**    
 * Pulsepoint Configuration Page    
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/configuration.php    
 * Author: Amaaavl    
 */    
    
if (!defined('ABSPATH')) exit;    
    
global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
// === Fetch Platform Settings ===    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#6C63FF';    
?>  
<div class="wrap">      
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Configuration</h1>    
  <p>Manage your integration settings, providers, service APIs, and platform configurations here.</p>    
  <hr class="wp-header-end">    

  <!-- Tailwind + Bootstrap Icons -->    
  <script src="https://cdn.tailwindcss.com"></script>    
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">    

  <style>    
    :root {    
      --primary: <?= $color_hex ?>;    
    }    
    body, .wrap {    
      font-family: 'Inter', sans-serif !important;    
      background: #f8fafc;    
    }    
    .config-grid {    
      display: grid;    
      grid-template-columns: repeat(2, minmax(0, 1fr));    
      gap: 24px;    
      margin-top: 30px;    
      max-width: 1000px;    
    }    
    @media (max-width: 768px) {    
      .config-grid {    
        grid-template-columns: 1fr;    
      }    
    }    
    .config-card {    
      background: #fff;    
      border-radius: 16px;    
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);    
      padding: 28px;    
      text-align: center;    
      transition: all .3s ease;    
      cursor: pointer;    
      border: 2px solid transparent;    
    }    
    .config-card:hover {    
      transform: translateY(-4px);    
      border-color: var(--primary);    
    }    
    .config-icon {    
      font-size: 46px;    
      color: var(--primary);    
      margin-bottom: 12px;    
    }    
    .config-title {    
      font-weight: 700;    
      font-size: 18px;    
      color: #222;    
    }    
    .config-desc {    
      font-size: 14px;    
      color: #777;    
      margin-top: 6px;    
    }    
    .config-center {    
      grid-column: span 2;    
      display: flex;    
      justify-content: center;    
      gap: 24px;    
      flex-wrap: wrap;    
    }    
  </style>    

  <!-- Configuration Sections -->    
  <div class="config-grid">  

    <!-- Row 1 -->    
    <div class="config-card" onclick="openConfigPage('provider')">    
      <i class="bi bi-plug config-icon"></i>    
      <div class="config-title">Provider API</div>    
      <div class="config-desc">Setup your VTU & bill payment API providers.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('data')">    
      <i class="bi bi-sim config-icon"></i>    
      <div class="config-title">Data Plan</div>    
      <div class="config-desc">Configure mobile data bundles & pricing.</div>    
    </div>    

    <!-- Row 2 -->    
    <div class="config-card" onclick="openConfigPage('electricity')">    
      <i class="bi bi-lightning-charge config-icon"></i>    
      <div class="config-title">Electricity</div>    
      <div class="config-desc">Manage electricity bill payment integration.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('cable')">    
      <i class="bi bi-tv config-icon"></i>    
      <div class="config-title">Cable</div>    
      <div class="config-desc">Configure DSTV, GOTV, Startimes & other cable services.</div>    
    </div>    

    <!-- Row 3 -->    
    <div class="config-card" onclick="openConfigPage('education')">    
      <i class="bi bi-mortarboard config-icon"></i>    
      <div class="config-title">Education</div>    
      <div class="config-desc">Integrate WAEC, NECO & exam pin services.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('virtual-accounts')">    
      <i class="bi bi-bank config-icon"></i>    
      <div class="config-title">Virtual Accounts</div>    
      <div class="config-desc">Configure bank virtual account APIs.</div>    
    </div>    
   
    

  </div>    
</div>  

<script>    
function openConfigPage(page) {    
  window.location.href = `admin.php?page=pulsepoint-${page}`;    
}    
</script>