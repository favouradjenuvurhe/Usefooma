<?php  
/**  
 * Pulsepoint Admin Customization Page  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/customization.php  
 * Author: Amaaavl  
 *
 * General/branding platform settings only — API/provider setup for
 * services (airtime, cable, bill, bank transfer, etc.) lives in
 * includes/panel/api-setup.php instead, reachable from Configuration.
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
$charset = $wpdb->get_charset_collate();  
$table_settings = "{$base_prefix}settings";  
  
// === Create settings table if not exists ===  
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_settings}` (  
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,  
    `opt_key` VARCHAR(255) NOT NULL,  
    `opt_value` TEXT,  
    `type` VARCHAR(50) DEFAULT 'string',  
    `grouping` VARCHAR(100) DEFAULT NULL,  
    `autoload` TINYINT(1) DEFAULT 0,  
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,  
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  
    PRIMARY KEY (`id`),  
    UNIQUE KEY `opt_key_unique` (`opt_key`)  
) {$charset};");  
  
// === Default Settings ===  
$defaults = [  
    // 🌐 Platform Info  
    'platform_name'     => 'Pulsepoint',  
    'color_hex'         => '#356cf9',  
    'phone_number'      => '09064873505',  
    'email_number'      => 'favour-amaaavl@outlook.com',
    'twitter_url'       => '',
    'instagram_url'     => '',
    'referral_amount'      => '50',
    'auth_email'   => '0',   
  
    // 💳 Payvessel Configuration / Payment Gateway  
    'payment_gateway'   => 'payvessel', // default selected  
    'pay_token'         => 'token',  
    'pay_secret'        => 'secret',  
    'pay_biz'           => 'bus_id',  
  
    // NEWLY ADDED VALUES (Your Request)  
    'pay_fee'           => 'fundung_fee',  
    'pay_bank'          => 'banking_fee',  
    'pay_usdt'          => 'cryto_fee',  
  
    'logo_url'          => 'url',  
    'favicon_url'       => 'url',
    'app_store_url'     => '',
    'google_play_url'   => '',  
  
    'ads1_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    'ads2_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    'ads3_url'          => 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
  
    // ⚙️ Platform Controls  
    'maintenance_mode'  => '0',  
    'woo_funding_enabled' => '0',
    'kyc_enabled' => '1',
  
    // 💰 Account & Discount Settings  
    'account_limit'     => '5000',  
    'agent_discount'    => '5',  
    'api_discount'      => '3',  
];  
  
// === Sync defaults with DB ===  
foreach ($defaults as $key => $value) {  
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s", $key));  
    if (!$exists) {  
        $wpdb->insert($table_settings, [  
            'opt_key' => $key,  
            'opt_value' => maybe_serialize($value),  
            'type' => 'string',  
            'autoload' => 1  
        ]);  
    }  
}  
  
// === Handle Save ===  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_settings_nonce']) && wp_verify_nonce($_POST['pulsepoint_settings_nonce'], 'save_pulsepoint_settings')) {  
    foreach ($_POST as $key => $value) {  
        if (array_key_exists($key, $defaults)) {  
            // Fix for Live Chat Script to allow HTML/JS
            if ($key === 'livechat_script') {
                $save_value = maybe_serialize($value); // save raw script
            } else {
                if (in_array($key, ['logo_url', 'favicon_url', 'app_store_url', 'google_play_url', 'twitter_url', 'instagram_url', 'telegram_url', 'facebook_url'], true)) {
                    $save_value = maybe_serialize(esc_url_raw((string) $value));
                } else {
                    $save_value = maybe_serialize(sanitize_text_field($value));
                }
            }

            $wpdb->update(  
                $table_settings,  
                ['opt_value' => $save_value],  
                ['opt_key' => $key]  
            );  
        }  
    }  
    echo '<div class="updated notice"><p><strong>Settings saved successfully.</strong></p></div>';  
}  
  
// === Announcements (auto-popup bottom sheet shown to every user) ===
$table_announcements = "{$base_prefix}announcements";

$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_announcements}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `type` VARCHAR(20) DEFAULT 'info',
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) {$charset};");

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_announcement_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_announcement_nonce'], 'save_pulsepoint_announcement')
) {
    $wpdb->insert($table_announcements, [
        'title'   => sanitize_text_field($_POST['announce_title'] ?? ''),
        'message' => sanitize_textarea_field($_POST['announce_message'] ?? ''),
        'type'    => sanitize_text_field($_POST['announce_type'] ?? 'info'),
        'status'  => 'active',
    ]);
    echo '<div class="updated notice"><p><strong>Announcement published — it will pop up for users automatically.</strong></p></div>';
}

if (isset($_GET['toggle_announcement']) && is_numeric($_GET['toggle_announcement']) && check_admin_referer('pulsepoint_announcement_action')) {
    $current = $wpdb->get_var($wpdb->prepare("SELECT status FROM {$table_announcements} WHERE id = %d", intval($_GET['toggle_announcement'])));
    $next = ($current === 'active') ? 'inactive' : 'active';
    $wpdb->update($table_announcements, ['status' => $next], ['id' => intval($_GET['toggle_announcement'])]);
    echo '<div class="updated notice"><p><strong>Announcement marked ' . esc_html($next) . '.</strong></p></div>';
}

if (isset($_GET['delete_announcement']) && is_numeric($_GET['delete_announcement']) && check_admin_referer('pulsepoint_announcement_action')) {
    $wpdb->delete($table_announcements, ['id' => intval($_GET['delete_announcement'])]);
    echo '<div class="updated notice"><p><strong>Announcement deleted.</strong></p></div>';
}

$announcements = $wpdb->get_results("SELECT * FROM {$table_announcements} ORDER BY created_at DESC LIMIT 20");

// === Fetch all current settings ===  
$settings = [];  
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");  
foreach ($rows as $r) {  
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);  
}  
  
// === Get platform info ===  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#356cf9';  
  
// === Scan Payment Gateways Folder ===
$gateway_folder = PULSEPOINT_DIR . 'core/virtual-account/';
$gateways = [];

// files to block
$blocked_files = [
    'pulsepoint.php',
    'dynamic.php',
    'cashwyre-dynamic.php'
];

if (is_dir($gateway_folder)) {
    foreach (scandir($gateway_folder) as $file) {

        // only php files
        if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') {
            continue;
        }

        // block specific files
        if (in_array(strtolower($file), $blocked_files, true)) {
            continue;
        }

        $gateways[] = pathinfo($file, PATHINFO_FILENAME);
    }
}
  
?>  

<div class="wrap usefooma-settings-wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Customization</h1>
  <p>Manage your platform settings from one WooCommerce-style settings screen.</p>
  <hr class="wp-header-end">

  <style>
    :root { --primary: <?= esc_attr($color_hex) ?>; }
    .usefooma-settings-wrap { max-width: 1280px; }
    .usefooma-tabs { display:flex; gap:0; border-bottom:1px solid #dcdcde; margin:20px 0 0; overflow-x:auto; white-space:nowrap; }
    .usefooma-tab { appearance:none; border:0; background:transparent; padding:12px 16px; margin:0 2px -1px 0; color:#50575e; text-decoration:none; font-size:13px; font-weight:600; border-bottom:2px solid transparent; cursor:pointer; }
    .usefooma-tab:hover { color:#1d2327; background:#f6f7f7; }
    .usefooma-tab.active { color:#2271b1; border-bottom-color:#2271b1; background:#fff; }
    .usefooma-panel { display:none; padding:24px 0 10px; }
    .usefooma-panel.active { display:block; }
    .usefooma-panel .pulse-section { background:#fff !important; border:1px solid #e5e7eb !important; border-radius:14px !important; box-shadow:0 3px 10px rgba(0,0,0,0.05) !important; padding:24px !important; margin:0 0 24px !important; }
    .usefooma-panel .pulse-section + .pulse-section { padding-top:24px !important; }
    .usefooma-panel .pulse-section h2 { font-size:14px !important; line-height:1.4; font-weight:600 !important; margin:0 0 18px !important; color:#1d2327; }
    .usefooma-panel .pulse-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:18px 28px; }
    .usefooma-panel .pulse-input { box-sizing:border-box; width:100%; min-height:40px; border:1px solid #8c8f94 !important; border-radius:4px !important; background:#fff !important; box-shadow:none !important; padding:7px 10px !important; }
    .usefooma-panel .pulse-input:focus { border-color:#2271b1 !important; box-shadow:0 0 0 1px #2271b1 !important; outline:0; }
    .usefooma-panel .pulse-label { font-size:13px; font-weight:600; color:#1d2327; margin-bottom:6px; }
    .usefooma-panel .pulse-btn { background:#2271b1 !important; border-radius:3px !important; padding:8px 14px !important; font-size:13px; }
    .usefooma-panel .pulse-btn:hover { background:#135e96 !important; }
    .usefooma-save { display:flex; justify-content:flex-end; padding:20px 0; }
    .usefooma-save .pulse-section { margin:0 !important; }
    .usefooma-save .pulse-btn { display:inline-flex !important; align-items:center !important; justify-content:center !important; gap:7px !important; min-height:40px !important; padding:9px 16px !important; border:1px solid #2271b1 !important; border-radius:6px !important; background:#2271b1 !important; color:#fff !important; text-decoration:none !important; font-weight:600 !important; line-height:1.4 !important; cursor:pointer !important; box-sizing:border-box !important; opacity:1 !important; }
    .usefooma-save .pulse-btn:hover { background:#135e96 !important; border-color:#135e96 !important; color:#fff !important; }
    .usefooma-save .pulse-btn i { display:inline-block !important; font-size:14px !important; line-height:1 !important; }
    .usefooma-announcements { margin-top:10px; }
    @media(max-width:782px){ .usefooma-panel .pulse-grid{grid-template-columns:1fr;} .usefooma-tab{padding:11px 12px;} }
  </style>

  <nav class="usefooma-tabs" aria-label="Customization settings">
    <button type="button" class="usefooma-tab active" data-tab="general">General</button>
    <button type="button" class="usefooma-tab" data-tab="payments">Payments</button>
    <button type="button" class="usefooma-tab" data-tab="controls">Platform</button>
    <button type="button" class="usefooma-tab" data-tab="account">Accounts</button>
    <button type="button" class="usefooma-tab" data-tab="fees">Fees</button>
    <button type="button" class="usefooma-tab" data-tab="branding">Branding</button>
    <button type="button" class="usefooma-tab" data-tab="ads">Ads</button>
    <button type="button" class="usefooma-tab" data-tab="announcements">Announcements</button>
  </nav>

    <div class="usefooma-panel active" data-panel="general">
<form method="POST">  
    <?php wp_nonce_field('save_pulsepoint_settings', 'pulsepoint_settings_nonce'); ?>  

    <!-- Platform Info -->  
    <div class="pulse-section">  
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-gear"></i> Platform Info</h2>  
      <div class="pulse-grid">  
        <div>  
          <label class="pulse-label">Platform Name</label>  
          <input type="text" name="platform_name" value="<?= esc_attr($settings['platform_name']) ?>" class="pulse-input">  
        </div>  
        <div>
          <label class="pulse-label">Brand Color (HEX)</label>
          <input type="text" name="color_hex" placeholder="#000000" value="<?= esc_attr($settings['color_hex']) ?>" class="pulse-input">
        </div>
        <div>  
          <label class="pulse-label">Phone Number</label>  
          <input type="text" name="phone_number" value="<?= esc_attr($settings['phone_number']) ?>" class="pulse-input">  
        </div>  
        <div>  
          <label class="pulse-label">Email</label>  
          <input type="email" name="email_number" value="<?= esc_attr($settings['email_number']) ?>" class="pulse-input">  
        </div> 
        <div>  
          <label class="pulse-label">Twitter / X URL</label>  
          <input type="text" name="twitter_url" value="<?= esc_attr($settings['twitter_url'] ?? '') ?>" placeholder="https://x.com/yourhandle" class="pulse-input">  
        </div> 
        <div>  
          <label class="pulse-label">Instagram URL</label>  
          <input type="text" name="instagram_url" value="<?= esc_attr($settings['instagram_url'] ?? '') ?>" placeholder="https://instagram.com/yourhandle" class="pulse-input">  
        </div> 
        <div>
    <label class="pulse-label">Email Authentication</label>
    <select name="auth_email" class="pulse-input">
        <option value="0" <?= (isset($settings['auth_email']) && $settings['auth_email'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['auth_email']) && $settings['auth_email'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>  
          <label class="pulse-label">Referral Amount</label>  
          <input type="text" name="referral_amount" value="<?= esc_attr($settings['referral_amount']) ?>" class="pulse-input">  
        </div> 
        
      </div>  
    </div>  

    </div>
    <div class="usefooma-panel" data-panel="payments">
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-credit-card"></i> Payment Gateway</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Select Gateway</label>
          <select name="payment_gateway" class="pulse-input">
            <?php foreach ($gateways as $gw): ?>
              <option value="<?= esc_attr($gw) ?>" <?= selected($settings['payment_gateway'], $gw, false) ?>><?= esc_html(ucfirst($gw)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="pulse-label">Token</label>
          <input type="text" name="pay_token" value="<?= esc_attr($settings['pay_token']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Secret</label>
          <input type="text" name="pay_secret" value="<?= esc_attr($settings['pay_secret']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Business ID</label>
          <input type="text" name="pay_biz" value="<?= esc_attr($settings['pay_biz']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    </div>
    <div class="usefooma-panel" data-panel="controls">
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-sliders"></i> Platform Controls</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Maintenance Mode</label>
          <select name="maintenance_mode" class="pulse-input">
            <option value="0" <?= selected($settings['maintenance_mode'], '0', false) ?>>Disabled</option>
            <option value="1" <?= selected($settings['maintenance_mode'], '1', false) ?>>Enabled</option>
          </select>
        </div>
        <div>
          <label class="pulse-label">KYC on User Dashboard</label>
          <select name="kyc_enabled" class="pulse-input">
            <option value="0" <?= selected($settings['kyc_enabled'] ?? '1', '0', false) ?>>Disabled</option>
            <option value="1" <?= selected($settings['kyc_enabled'] ?? '1', '1', false) ?>>Enabled</option>
          </select>
          <p class="text-[11px] text-gray-400 mt-1">When disabled, the KYC section is removed from the user dashboard.</p>
        </div>
        <div>
          <label class="pulse-label">One-Time Payment (WooCommerce)</label>
          <select name="woo_funding_enabled" class="pulse-input">
            <option value="0" <?= selected($settings['woo_funding_enabled'] ?? '0', '0', false) ?>>Disabled</option>
            <option value="1" <?= selected($settings['woo_funding_enabled'] ?? '0', '1', false) ?>>Enabled</option>
          </select>
          <p class="text-[11px] text-gray-400 mt-1">Only shows on Fund Wallet when WooCommerce is active AND this is enabled.</p>
        </div>
        <div>
          <label class="pulse-label">API Mode</label>
          <select name="api_mode" class="pulse-input">
            <option value="live" <?= selected($settings['api_mode'], 'live', false) ?>>Live</option>
            <option value="test" <?= selected($settings['api_mode'], 'test', false) ?>>Test</option>
          </select>
        </div>
      </div>
    </div>

    </div>
    <div class="usefooma-panel" data-panel="account">
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-wallet2"></i> Account & Discounts</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Account Limit</label>
          <input type="number" name="account_limit" value="<?= esc_attr($settings['account_limit']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Agent Discount (%)</label>
          <input type="number" name="agent_discount" value="<?= esc_attr($settings['agent_discount']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">API Discount (%)</label>
          <input type="number" name="api_discount" value="<?= esc_attr($settings['api_discount']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    </div>
    <div class="usefooma-panel" data-panel="fees">
    <div class="pulse-section">
  <h2 class="text-lg font-semibold mb-4"><i class="bi bi-cash-stack"></i> Fees Configuration</h2>
  <div class="pulse-grid">

      <div>
        <label class="pulse-label">Funding Fee - % </label>
        <input type="text" name="pay_fee" value="<?= esc_attr($settings['pay_fee']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Bank Transfer Fee ( flat )</label>
        <input type="text" name="pay_bank" value="<?= esc_attr($settings['pay_bank']) ?>" class="pulse-input">
      </div>

      

  </div>
</div>


    </div>
    <div class="usefooma-panel" data-panel="branding">
<div class="pulse-section">
  <h2 class="text-lg font-semibold mb-4"><i class="bi bi-image"></i> Branding Assets</h2>
  <div class="pulse-grid">

      <div>
        <label class="pulse-label">Logo URL</label>
        <input type="text" name="logo_url" value="<?= esc_attr($settings['logo_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Favicon URL</label>
        <input type="text" name="favicon_url" value="<?= esc_attr($settings['favicon_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">App Store URL</label>
        <input type="url" name="app_store_url" value="<?= esc_attr($settings['app_store_url'] ?? '') ?>" placeholder="https://apps.apple.com/..." class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Google Play Store URL</label>
        <input type="url" name="google_play_url" value="<?= esc_attr($settings['google_play_url'] ?? '') ?>" placeholder="https://play.google.com/store/apps/..." class="pulse-input">
      </div>

  </div>
</div>


    </div>
    <div class="usefooma-panel" data-panel="ads">
<div class="pulse-section">
  <h2 class="text-lg font-semibold mb-4"><i class="bi bi-badge-ad"></i> Advertisement Banners</h2>
  <div class="pulse-grid">

      <div>
        <label class="pulse-label">Ads Banner 1</label>
        <input type="text" name="ads1_url" value="<?= esc_attr($settings['ads1_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Ads Banner 2</label>
        <input type="text" name="ads2_url" value="<?= esc_attr($settings['ads2_url']) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Ads Banner 3</label>
        <input type="text" name="ads3_url" value="<?= esc_attr($settings['ads3_url']) ?>" class="pulse-input">
      </div>

  </div>
</div>

    </div>
    <div class="usefooma-save">    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Customization</button>
    </div></div>

  </form>


  <div class="usefooma-panel" data-panel="announcements">
    <div class="usefooma-announcements">
  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-1"><i class="bi bi-megaphone"></i> Announcements</h2>
    <p class="text-xs text-gray-500 mb-4">Pops up automatically as a bottom sheet the next time a user opens the app — not something they have to go looking for.</p>

    <form method="POST" class="pulse-grid mb-6">
      <?php wp_nonce_field('save_pulsepoint_announcement', 'pulsepoint_announcement_nonce'); ?>

      <div>
        <label class="pulse-label">Title</label>
        <input type="text" name="announce_title" class="pulse-input" required placeholder="e.g. Scheduled Maintenance">
      </div>

      <div>
        <label class="pulse-label">Type</label>
        <select name="announce_type" class="pulse-input">
          <option value="info">Info</option>
          <option value="success">Success</option>
          <option value="warning">Warning</option>
          <option value="error">Error</option>
          <option value="promotion">Promotion / News</option>
        </select>
      </div>

      <div style="grid-column: 1 / -1;">
        <label class="pulse-label">Message</label>
        <textarea name="announce_message" rows="2" class="pulse-input" required placeholder="What should users see?"></textarea>
      </div>

      <div style="grid-column: 1 / -1;" class="text-right">
        <button type="submit" class="pulse-btn"><i class="bi bi-send"></i> Publish Announcement</button>
      </div>
    </form>

    <?php if ($announcements): ?>
      <div class="space-y-2">
        <?php foreach ($announcements as $a): $is_active = $a->status === 'active'; ?>
          <div class="flex items-start justify-between gap-3 bg-gray-50 border border-gray-100 rounded-xl px-4 py-3">
            <div>
              <p class="text-sm font-semibold text-gray-900">
                <?= esc_html($a->title) ?>
                <span class="text-[10px] font-normal text-gray-400 uppercase">(<?= esc_html($a->type) ?>)</span>
                <span style="padding:2px 8px;border-radius:999px;font-size:10px;font-weight:700;text-transform:uppercase;margin-left:6px;<?= $is_active ? 'background:#dcfce7;color:#166534;' : 'background:#fee2e2;color:#991b1b;' ?>"><?= $is_active ? 'Active' : 'Inactive' ?></span>
              </p>
              <p class="text-xs text-gray-500 mt-0.5"><?= esc_html($a->message) ?></p>
              <p class="text-[10px] text-gray-400 mt-1"><?= esc_html($a->created_at) ?></p>
            </div>
            <div class="flex flex-col gap-1 shrink-0">
              <a href="<?= wp_nonce_url('?page=pulsepoint-customization&toggle_announcement=' . $a->id, 'pulsepoint_announcement_action') ?>" style="background:<?= $is_active ? '#f59e0b' : '#22c55e' ?>;color:#fff;padding:4px 10px;border-radius:8px;font-size:11px;font-weight:600;text-decoration:none;white-space:nowrap;">
                <?= $is_active ? 'Turn Off' : 'Turn On' ?>
              </a>
              <a href="<?= wp_nonce_url('?page=pulsepoint-customization&delete_announcement=' . $a->id, 'pulsepoint_announcement_action') ?>" onclick="return confirm('Delete this announcement?')" style="background:#ef4444;color:#fff;padding:4px 10px;border-radius:8px;font-size:11px;font-weight:600;text-decoration:none;white-space:nowrap;">
                <i class="bi bi-trash"></i>
              </a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-sm text-gray-400">No announcements published yet.</p>
    <?php endif; ?>

    </div>
  </div>

  <script>
  (function(){
    var tabs=document.querySelectorAll('.usefooma-tab');
    var panels=document.querySelectorAll('.usefooma-panel');
    tabs.forEach(function(tab){ tab.addEventListener('click',function(){ var key=tab.getAttribute('data-tab'); tabs.forEach(function(t){t.classList.toggle('active',t===tab);}); panels.forEach(function(p){p.classList.toggle('active',p.getAttribute('data-panel')===key);}); if(window.history&&window.history.replaceState){window.history.replaceState(null,'','#'+key);} }); });
    var initial=(window.location.hash||'#general').substring(1);
    var target=document.querySelector('.usefooma-tab[data-tab="'+initial+'"]'); if(target){target.click();}
  })();
  </script>
</div>