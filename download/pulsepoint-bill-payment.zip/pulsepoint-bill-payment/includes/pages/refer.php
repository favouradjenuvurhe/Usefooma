<?php  
/**  
 * Refer Page - Pulsepoint Plugin  
 */  

if (!defined('ABSPATH')) exit;  

global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  

$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#0057ff';  

// Banner flyer image URLs from settings  
$banner_slides = [  
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'  
];      

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;  
$table_users = $wpdb->prefix . 'pulsepoint_users';  

$user = $wpdb->get_row(  
    $wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id)  
);  

$firstname = $user ? esc_html($user->firstname) : "User";
$referral_balance = $user ? number_format($user->referral_balance, 2) : '0.00';  

/* ✅ AUTO GENERATE UNIQUEID IF EMPTY */
if ($user && empty($user->uniqueid)) {

    function generateRefCode($length = 6) {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[random_int(0, strlen($characters) - 1)];
        }
        return $code;
    }

    // Ensure uniqueness
    do {
        $new_code = generateRefCode(6);

        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_users} WHERE uniqueid = %s",
                $new_code
            )
        );

    } while ($exists > 0);

    // Save to database
    $wpdb->update(
        $table_users,
        ['uniqueid' => $new_code],
        ['id' => $user_id]
    );

    $ref_code = $new_code;

} else {
    $ref_code  = $user ? esc_html($user->uniqueid) : "none";
}

/* ✅ GET TOTAL REFERRALS (USING USER ID) */
$total_referrals = 0;

if ($user_id) {
    $total_referrals = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_users} WHERE referby = %d",
            $user_id
        )
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Refer - <?php echo $platform_name; ?></title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>

<style>
body{
background:#f7f8fb;
font-family:'Inter',sans-serif;
margin:0;
}
</style>

</head>

<body>

<div class="px-4 max-w-md mx-auto">

<!-- HEADER (same as support) -->
<div class="mt-6 flex justify-between items-center">
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" class="w-6 h-6"/>
    <span class="font-semibold text-black">Refer</span>
  </div>

  <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg" class="w-5 h-5"/>
</div>

<!-- SPACE -->
<div class="mt-6"></div>
  

<!-- CARD (UPDATED TO GRAY STYLE LIKE AIRTIME) -->
<div class="bg-white rounded-xl p-4 shadow-sm">
</br>
</br>
<!-- IMAGE -->
<div class="flex justify-center mb-4">
  <img src="https://static.vecteezy.com/system/resources/thumbnails/046/376/131/small_2x/gift-box-open-3d-render-illustration-png.png" 
       class="w-[120px] h-[120px] object-contain"/>
</div>
</br>
</br>
<!-- TITLE -->
<p class="text-black text-sm font-medium mb-2">
Invite your friends and get ₦1,000
</p>

<!-- DESCRIPTION -->
<p class="text-gray-500 text-xs leading-relaxed mb-3">
Share your referral code and get ₦1,000 when whoever you refer signs up and carries out up to ₦20,000 worth of transactions.
</p>

<!-- LINK -->
<p class="text-xs font-medium mb-4" style="color: <?php echo $color_hex; ?>">
Learn more about referrals
</p>

<!-- REF CODE -->
<p class="text-gray-400 text-xs mb-1">Referral Code</p>

<div class="flex items-center justify-between gap-3">

  <!-- CODE BOX -->
  <div class="flex items-center justify-between bg-gray-100 px-4 py-2 rounded-full w-full">
    <span id="refCode" class="font-semibold text-sm text-black">
      <?php echo $ref_code; ?>
    </span>

    <img src="https://www.svgrepo.com/show/528917/copy.svg"
         onclick="copyRef()"
         class="w-5 h-5 cursor-pointer opacity-70"/>
  </div>

  <!-- SHARE BUTTON -->
  <button class="text-white text-xs px-4 py-2 rounded-full font-medium"
          style="background: <?php echo $color_hex; ?>">
    Copy
  </button>

</div>

</div>

<!-- STATS -->
<div class="grid grid-cols-2 gap-4 mt-6">

<!-- TOTAL REFERRED -->
<div class="flex items-center gap-3">
  <img src="https://www.svgrepo.com/show/529295/users-group-two-rounded.svg" class="w-8 h-8"/>

  <div>
    <p class="text-sm font-semibold text-black"><?php echo $total_referrals; ?></p>
    <p class="text-xs text-gray-400">Total Referred</p>
  </div>
</div>

<!-- ACTIVE -->
<div class="flex items-center gap-3">
  <img src="https://www.svgrepo.com/show/498220/money-recive.svg" class="w-8 h-8"/>

  <div>
    <p class="text-sm font-semibold text-black">₦<?php echo $referral_balance; ?>    </p>
    <p class="text-xs text-gray-400">Earning so far</p>
  </div>
</div>

</div>
</br>
<!-- Scrollable Banner Flyer Without Card (Using Settings URLs) -->
<div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
    <?php foreach ($banner_slides as $slide): ?>
        <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">
            <img src="<?php echo esc_url($slide); ?>" alt="Flyer Slide" class="w-full h-full object-cover rounded-lg shadow-md">
        </div>
    <?php endforeach; ?>
</div>  

</div>
  <!-- Airtime Service Box -->
<div class="mt-5">
  <h3 class="font-semibold text-gray-900 mb-3"> </h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
</div>
</div>

<script>
function copyRef(){
let code=document.getElementById("refCode").innerText;
navigator.clipboard.writeText(code);
alert("Copied: "+code);
}
</script>

</body>
</html>