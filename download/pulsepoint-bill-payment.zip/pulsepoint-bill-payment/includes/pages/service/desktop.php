<?php      
/**
 * All Services Page - Desktop Mode - Pulsepoint Plugin
 * Author: Amaaavl
 */      
if (!defined('ABSPATH')) exit;      

global $wpdb;      
$base_prefix = $wpdb->prefix . 'pulsepoint_';  

// Fetch settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {      
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);      
}    

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0057ff';    

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
$table_users = $wpdb->prefix . 'pulsepoint_users';    
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));    
$firstname = $user ? esc_html($user->firstname) : 'User';    

// Fetch enabled services  
$table_services = $base_prefix . "services";    
$services = $wpdb->get_results("SELECT * FROM {$table_services} WHERE status = 1 ORDER BY id ASC");  

// Map service ID to icon, background color, and URL  
$service_map = [  
    1 => ['icon' => 'phone', 'bg' => '#f7f7fc', 'url' => '/app/airtime'],  
    2 => ['icon' => 'signal', 'bg' => '#f7f7fc', 'url' => '/app/data'],  
    3 => ['icon' => 'lightbulb', 'bg' => '#fff7f0', 'url' => '/app/electricity'],  
    4 => ['icon' => 'plane', 'bg' => '#f0f9ff', 'url' => '/app/flights'],  
    5 => ['icon' => 'wifi', 'bg' => '#f7f7fc', 'url' => '/app/net'],  
    6 => ['icon' => 'card-sim', 'bg' => '#dff6ff', 'url' => '/app/esim'],  
    7 => ['icon' => 'gift', 'bg' => '#f3fff2', 'url' => '/app/sell-giftcard'],  
    8 => ['icon' => 'bus', 'bg' => '#f3f4ff', 'url' => '/app/transport'],  
    9 => ['icon' => 'send', 'bg' => '#e8f4ff', 'url' => '/app/type-transfer'],  
    10 => ['icon' => 'volleyball', 'bg' => '#fff3f3', 'url' => '/app/betting'],  
    11 => ['icon' => 'tv', 'bg' => '#f7f7fc', 'url' => '/app/cable'],  
    12 => ['icon' => 'credit-card', 'bg' => '#e7f8ff', 'url' => '/app/virtual-card'],  
    13 => ['icon' => 'graduation-cap', 'bg' => '#fff7ed', 'url' => '/app/education'],  
    14 => ['icon' => 'piggy-bank', 'bg' => '#f2fff8', 'url' => '/app/saving'],  
    15 => ['icon' => 'tickets', 'bg' => '#f7f7fc', 'url' => '/app/tickets'],
    16 => ['icon' => 'circle-pound-sterling', 'bg' => '#f7f7fc', 'url' => '/app/currency'],  
];  
?>    

<!DOCTYPE html>    
<html lang="en">    
<head>    
<meta charset="UTF-8" />    
<meta name="viewport" content="width=device-width, initial-scale=1" />    
<title>All Services - <?= esc_html($platform_name) ?></title>    

<!-- Fonts & Tailwind -->    
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">    
<script src="https://cdn.tailwindcss.com"></script>    
<script src="https://unpkg.com/lucide@latest"></script>    

<style>    
body { background: #f7f8fb; font-family: 'Inter', sans-serif; margin:0; padding:0; }    
.header-btn { width:40px; height:40px; display:flex; align-items:center; justify-content:center; border-radius:50%; background:white; box-shadow:0 2px 6px rgba(0,0,0,0.1); cursor:pointer; }    
.card { border-radius: 18px; background: white; box-shadow: 0 6px 18px rgba(20,30,60,0.06); cursor: pointer; transition: transform 0.15s, box-shadow 0.15s; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; padding:24px; }    
.card:hover { transform: translateY(-3px); box-shadow: 0 8px 22px rgba(20,30,60,0.12); }    
@media (min-width: 768px){ .grid-cols-desktop{ grid-template-columns: repeat(5,1fr); gap:20px; } }    
</style>    
</head>    
<body>    
<div class="container mx-auto px-6 py-8">  

<!-- HEADER -->  
<div class="flex items-center justify-between mb-8">  
  <div class="flex items-center gap-4">  
    <button onclick="history.back()" class="header-btn">  
      <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>  
    </button>  
    <h1 class="text-2xl font-bold text-gray-900">All Services</h1>
  </div>    
  <div class="flex items-center gap-3">
    <button class="header-btn"><i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i></button>
    <button class="header-btn"><i data-lucide="bell" class="w-5 h-5 text-gray-800"></i></button>
  </div>
</div>  
<!-- END HEADER -->  

<!-- SERVICES GRID -->  
<div class="grid grid-cols-3 md:grid-cols-desktop gap-6">  
<?php if ($services): ?>    
    <?php foreach ($services as $srv): ?>    
        <?php   
            $id = $srv->id;  
            $icon = $service_map[$id]['icon'] ?? 'circle';  
            $bg   = $service_map[$id]['bg'] ?? '#f7f7fc';  
            $url  = $service_map[$id]['url'] ?? '#';  
        ?>  
        <div class="card" onclick="window.location.href='<?= esc_url($url) ?>'">  
            <div class="h-14 w-14 flex items-center justify-center rounded-full" style="background: <?= esc_attr($bg) ?>;">  
                <i data-lucide="<?= esc_attr($icon) ?>" class="w-6 h-6"></i>  
            </div>  
            <div class="text-center text-sm font-medium"><?= esc_html($srv->service_name) ?></div>  
        </div>    
    <?php endforeach; ?>
<?php else: ?>    
    <p class="text-gray-500 text-center col-span-3">No services available.</p>
<?php endif; ?>    
</div>    
</div>    

<script>  
lucide.createIcons();  
</script>  
</body>    
</html>