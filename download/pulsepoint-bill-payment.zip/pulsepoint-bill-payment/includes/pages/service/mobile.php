<?php      
/**      
 * All Services Page - Pulsepoint Plugin      
 * Author: Amaaavl      
 */      
    
if (!defined('ABSPATH')) exit;      
    
global $wpdb;      
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// Fetch settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {      
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);      
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0057ff';    
    
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
$table_users = $wpdb->prefix . 'pulsepoint_users';    
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));    
$firstname = $user ? esc_html($user->firstname) : 'User';    
  
// Fetch enabled services  
$table_services = $base_prefix . "services";    
$services = $wpdb->get_results("SELECT * FROM {$table_services} WHERE status = 1 ORDER BY id ASC"); // <-- fixed column name  
  
// Map service ID to icon, background color, and URL  
$service_map = [  
    1 => ['icon' => 'phone', 'bg' => '#f7f7fc', 'url' => '/app/airtime'],  
    2 => ['icon' => 'signal', 'bg' => '#f7f7fc', 'url' => '/app/data'],  
    3 => ['icon' => 'lightbulb', 'bg' => '#fff7f0', 'url' => '/app/electricity'],  
    4 => ['icon' => 'plane', 'bg' => '#f0f9ff', 'url' => '/app/flights'],  
    5 => ['icon' => 'wifi', 'bg' => '#f7f7fc', 'url' => '/app/net'],  
    6 => ['icon' => 'card-sim', 'bg' => '#dff6ff', 'url' => '/app/esim'],  
    7 => ['icon' => 'gift', 'bg' => '#f3fff2', 'url' => '/app/sell-giftcard'],  
    8 => ['icon' => 'bus', 'bg' => '#f3f4ff', 'url' => '/app/transport'],  
    9 => ['icon' => 'send', 'bg' => '#e8f4ff', 'url' => '/app/type-transfer'],  
    10 => ['icon' => 'volleyball', 'bg' => '#fff3f3', 'url' => '/app/betting'],  
    11 => ['icon' => 'tv', 'bg' => '#f7f7fc', 'url' => '/app/cable'],  
    12 => ['icon' => 'credit-card', 'bg' => '#e7f8ff', 'url' => '/app/virtual-card'],  
    13 => ['icon' => 'graduation-cap', 'bg' => '#fff7ed', 'url' => '/app/education'],  
    14 => ['icon' => 'piggy-bank', 'bg' => '#f2fff8', 'url' => '/app/saving'],  
    15 => ['icon' => 'tickets', 'bg' => '#f7f7fc', 'url' => '/app/tickets'],
    16 => ['icon' => 'circle-pound-sterling', 'bg' => '#f7f7fc', 'url' => '/app/currency'],  
    17 => ['icon' => 'bitcoin', 'bg' => '#f7f7fc', 'url' => '/app/send'],  
    18 => ['icon' => 'hand-coins', 'bg' => '#f7f7fc', 'url' => '/app/receive'],  
];  
?>    

<!DOCTYPE html>    
<html lang="en">    
<head>    
<meta charset="UTF-8" />    
<meta name="viewport" content="width=device-width, initial-scale=1" />    
<title>All Services</title>    

<!-- Font + Tailwind -->    
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">    
<script src="https://cdn.tailwindcss.com"></script>    
<script src="https://unpkg.com/lucide@latest"></script>    

<style>    
body {    
  background: #f7f8fb;    
  font-family: 'Inter', sans-serif;    
  margin: 0;    
  padding: 0;    
}    
  
.card {    
  border-radius: 18px;    
  background: white;    
  box-shadow: 0 6px 18px rgba(20,30,60,0.06);    
  cursor: pointer;    
  transition: transform 0.15s, box-shadow 0.15s;    
}    
  
.card:hover {    
  transform: translateY(-3px);    
  box-shadow: 0 8px 22px rgba(20,30,60,0.12);    
}    
</style>    
</head>    
<body>    
<div id="app" class="max-w-sm mx-auto px-5 pt-6 pb-10">  

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Bill payment</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- SERVICES GRID -->  
<div class="grid grid-cols-3 gap-3 mb-4">  
<?php if ($services): ?>    
    <?php foreach ($services as $srv): ?>    
        <?php   
            $id = $srv->id;  // <-- use 'id' not 'service_id'
            $icon = $service_map[$id]['icon'] ?? 'circle';  
            $bg   = $service_map[$id]['bg'] ?? '#f7f7fc';  
            $url  = $service_map[$id]['url'] ?? '#';  
        ?>  
        <div class="card flex flex-col items-center justify-center gap-2 p-4 aspect-square" onclick="window.location.href='<?php echo esc_url($url); ?>'">  
            <div class="h-12 w-12 flex items-center justify-center rounded-full" style="background: <?php echo $bg; ?>;">  
                <i data-lucide="<?php echo esc_attr($icon); ?>" class="w-5 h-5"></i>  
            </div>  
            <div class="text-sm text-center"><?php echo esc_html($srv->service_name); ?></div>  
        </div>    
    <?php endforeach; ?>
<?php else: ?>    
    <p class="text-gray-500 text-center col-span-3">No services available.</p>
<?php endif; ?>    
</div>    
</div>    

<script>  
lucide.createIcons();  
</script>  
</body>    
</html>