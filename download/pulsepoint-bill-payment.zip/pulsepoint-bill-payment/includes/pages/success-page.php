<?php  
/**
 * Transaction Successful Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Get current user ID from session
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

if ($user_id > 0) {
    // Fetch latest successful transaction
    $table_trnx = $base_prefix . 'trnx';
    $transaction = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id FROM {$table_trnx} WHERE user_id = %d AND status = 'success' ORDER BY id DESC LIMIT 1",
            $user_id
        )
    );

    if ($transaction) {
        // Redirect to the transaction details page
        $trnx_id = $transaction->id;
        wp_redirect("/app/view-transaction/?id={$trnx_id}");
        exit;
    }
}

// If no transaction found, redirect to dashboard or fallback
wp_redirect("/app/dashboard/");
exit;