<?php
if (!defined('ABSPATH')) exit;

// Detect device
function pulsepoint_is_mobile(){
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|ipod|mobile)/i', $ua);
}

$is_mobile = pulsepoint_is_mobile();

// Decide dashboard file
$file = $is_mobile ? 'dashboard.php' : 'dashboard-ds.php';

// Load from theme
$theme_file = pulsepoint_theme_file($file);

// Include
if (file_exists($theme_file)) {
    include $theme_file;
} else {
    echo "<h2 style='color:red'>Dashboard UI missing.</h2>";
}