<?php
/**
 * Profile Page - Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/profile.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Detect device
function is_mobile_device() {
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);
}

$is_mobile = is_mobile_device();

// Load settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

// Defaults
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Logged-in user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : "User";
$wallet = $user ? number_format($user->wallet, 2) : "0.00";
$referral_balance = $user ? number_format($user->referral_balance, 2) : "0.00";

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>Profile - <?= $platform_name ?></title>

<!-- Inter Font -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Tailwind -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Lucide Icons -->
<script src="https://unpkg.com/lucide@latest"></script>

<style>
body {
  background: #f7f8fb;
  font-family: 'Inter', sans-serif;
  margin: 0;
  padding: 0;
}
.btn-circle {
  background: #fff;
  border-radius: 9999px;
  width: 42px;
  height: 42px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 10px rgba(0,0,0,0.03);
}
.card {
  border-radius: 18px;
  background: #fff;
  box-shadow: 0 6px 18px rgba(20,30,60,0.06);
}
.copy-box {
  border-radius: 14px;
  padding: 16px;
  background: #fff;
  box-shadow: 0 6px 18px rgba(20,30,60,0.06);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 76px;
  background: linear-gradient(180deg,#ffffff,#fbfcff);
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
  box-shadow: 0 -6px 22px rgba(15,25,60,0.04);
  z-index: 50;
}
.muted { color: #8b90a0; }

/* Dynamic Colors */
.bg-main { background-color: <?= $color_hex ?>; }
.text-main { color: <?= $color_hex ?>; }
.bg-main-10 { background-color: <?= $color_hex ?>1A; }
.shadow-main { box-shadow: 0 3px 10px <?= $color_hex ?>33; }

/* Menu Cards */
.menu-card {
  background: #fff;
  padding: 16px;
  border-radius: 14px;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 6px 18px rgba(20,30,60,0.06);
  text-decoration: none;
  color: inherit;
}
.menu-left {
  display: flex;
  align-items: center;
  gap: 12px;
}
.menu-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: #f0f2f7;
  display: flex;
  align-items: center;
  justify-content: center;
}
.menu-title {
  font-weight: 600;
}
.menu-desc {
  font-size: 12px;
  color: #8b90a0;
}
.logout-btn {
  display: block;
  text-align: center;
  padding: 14px;
  background: #ff3b30;
  color: white;
  border-radius: 14px;
  margin-top: 20px;
  font-weight: 600;
}
</style>
</head>

<body>

<div id="app" class="max-w-sm mx-auto px-5 pt-6 pb-32">


<!-- HEADER -->
<div class="flex items-start justify-between mb-6">
  <div class="flex items-center space-x-3">
    <div class="w-12 h-12 rounded-full overflow-hidden">
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" class="w-full h-full object-cover">
    </div>
    <div>
      <p class="text-gray-400 text-sm leading-tight">Profile</p>
      <p class="font-semibold text-lg tracking-tight text-gray-900">
        <?= strtolower($firstname) ?>
      </p>
    </div>
  </div>

  <button class="btn-circle">
    <i data-lucide="user" class="w-5 h-5 text-gray-800"></i>
  </button>
</div>


<!-- TITLE -->
<h2 class="text-xl font-bold mb-3">Your Account</h2>
<p class="text-gray-500 text-sm mb-5">Manage your personal details & wallet info.</p>


<!-- WALLET -->
<div class="copy-box mb-4">
  <div>
    <p class="text-xs text-gray-500 mb-1">Main Wallet</p>
    <p class="text-lg font-semibold text-gray-900">₦<?= $wallet ?></p>
  </div>
  <button class="p-2 rounded-full bg-main-10">
      <i data-lucide="wallet" class="w-5 h-5 text-main"></i>
  </button>
</div>


<!-- REFERRAL BALANCE -->
<div class="copy-box mb-4">
  <div>
    <p class="text-xs text-gray-500 mb-1">Referral Balance</p>
    <p class="text-lg font-semibold text-gray-900">₦<?= $referral_balance ?></p>
  </div>
  <button class="p-2 rounded-full bg-main-10">
      <i data-lucide="gift" class="w-5 h-5 text-main"></i>
  </button>
</div>


<!-- MENU ITEMS (UPDATED TO LUCIDE) -->
<a href="/app/profile-edit" class="menu-card">
  <div class="menu-left">
    <div class="menu-icon"><i data-lucide="user-circle" class="w-5 h-5"></i></div>
    <div>
      <div class="menu-title">Personal Information</div>
      <div class="menu-desc">Edit your information</div>
    </div>
  </div>
  <i data-lucide="chevron-right" class="w-5 h-5 text-gray-400"></i>
</a>

<a href="/app/settings" class="menu-card">
  <div class="menu-left">
    <div class="menu-icon"><i data-lucide="settings" class="w-5 h-5"></i></div>
    <div>
      <div class="menu-title">Settings</div>
      <div class="menu-desc">Account, notification</div>
    </div>
  </div>
  <i data-lucide="chevron-right" class="w-5 h-5 text-gray-400"></i>
</a>

<a href="/app/refer" class="menu-card">
  <div class="menu-left">
    <div class="menu-icon"><i data-lucide="users" class="w-5 h-5"></i></div>
    <div>
      <div class="menu-title">Refer & Earn</div>
      <div class="menu-desc">Invite your friends and get a bonus</div>
    </div>
  </div>
  <i data-lucide="chevron-right" class="w-5 h-5 text-gray-400"></i>
</a>

<a href="/privacy-policy" class="menu-card">
  <div class="menu-left">
    <div class="menu-icon"><i data-lucide="file-text" class="w-5 h-5"></i></div>
    <div>
      <div class="menu-title">Legal & Policies</div>
      <div class="menu-desc">Privacy policy, terms of service</div>
    </div>
  </div>
  <i data-lucide="chevron-right" class="w-5 h-5 text-gray-400"></i>
</a>

<a href="/app/support" class="menu-card">
  <div class="menu-left">
    <div class="menu-icon"><i data-lucide="headphones" class="w-5 h-5"></i></div>
    <div>
      <div class="menu-title">Help & Support</div>
      <div class="menu-desc">Have an issue? Speak to our team</div>
    </div>
  </div>
  <i data-lucide="chevron-right" class="w-5 h-5 text-gray-400"></i>
</a>

<!-- LOGOUT -->
<a href="/app/logout" class="logout-btn">Sign Out</a>


</div>


<!-- BOTTOM NAV -->
<div class="bottom-nav px-6 py-2 flex items-center justify-between">

  <a href="/app/dashboard" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full">
      <i data-lucide="home" class="muted w-5 h-5"></i>
    </div>
  </a>

  <a href="/app/refer" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full">
      <i data-lucide="send" class="muted w-5 h-5"></i>
    </div>
  </a>

  <a href="/app/support" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full">
      <i data-lucide="headphones" class="muted w-5 h-5"></i>
    </div>
  </a>

  <a href="#" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full bg-main text-white shadow-main">
      <i data-lucide="user" class="w-5 h-5"></i>
    </div>
    <div class="text-xs font-semibold text-main">Profile</div>
  </a>

</div>

<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script>
const { createApp } = Vue;
createApp({}).mount('#app');
lucide.createIcons();
</script>

</body>
</html>