<?php
/**
 * Pulsepoint Deposit to Savings Pocket Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pocket/deposit-pocket.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// ✅ Ensure session started
if (!session_id()) session_start();

// ✅ Check Pulsepoint user session
if (!isset($_SESSION['pulsepoint_user']['id'])) {
    wp_die('<h3 style="text-align:center;margin-top:50px;">You must be logged in to continue.</h3>');
}

$user_id = $_SESSION['pulsepoint_user']['id'];

// ✅ Detect device
function is_mobile_device() {
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);
}
$is_mobile = is_mobile_device();

// ✅ Platform Settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#000';

// ✅ Get pocket info (session user only)
$pocket_id = isset($_GET['pocket']) ? intval($_GET['pocket']) : 0;
$pocket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$base_prefix}savings_pocket WHERE id = %d AND user_id = %d", $pocket_id, $user_id));
if (!$pocket) wp_die('<h3 style="text-align:center;margin-top:50px;">Invalid or unauthorized pocket.</h3>');

// ✅ Get current user wallet
$user_data = $wpdb->get_row($wpdb->prepare("SELECT wallet FROM {$base_prefix}users WHERE id=%d", $user_id));
$wallet_balance = $user_data ? $user_data->wallet : 0.00;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Deposit to <?= esc_html($pocket->title) ?> | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<style>
:root { --primary: <?= $color_hex ?>; }
body { font-family: 'Inter', sans-serif; background: #f9f9fb; min-height: 100vh; padding: 20px; }
.header-bar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
.header-bar i { font-size: 22px; color: #000; cursor: pointer; }
.header-avatar { width: 38px; height: 38px; border-radius: 50%; background: var(--primary); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.header-avatar img { width: 100%; height: 100%; object-fit: cover; }
.progress-bar { background: #eee; height: 8px; border-radius: 5px; overflow: hidden; }
.progress-fill { height: 100%; background: var(--primary); }
input { border: 1px solid #ddd; border-radius: 10px; padding: 10px 14px; width: 100%; outline: none; }
input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(0,0,0,0.05); }
label { font-weight: 600; color: #333; font-size: 0.9rem; }
</style>
</head>
<body>

<div class="<?= $is_mobile ? 'max-w-md' : 'max-w-4xl' ?> mx-auto pb-24">
  <div class="header-bar">
    <a href="/app/saving"><i class="bi bi-arrow-left-circle"></i></a>
    <div class="header-avatar"><img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt=""></div>
  </div>

  <div class="p-6 rounded-2xl text-white mb-6" style="background: <?= $color_hex ?>;">
    <div class="text-lg font-semibold"><?= esc_html($pocket->title) ?></div>
    <div class="opacity-80 text-sm">Target: ₦<?= number_format($pocket->target_amount, 2) ?></div>
    <div class="opacity-80 text-sm">Current: ₦<?= number_format($pocket->current_amount, 2) ?></div>
    <div class="progress-bar mt-3">
      <?php $percent = min(100, ($pocket->current_amount / max(1, $pocket->target_amount)) * 100); ?>
      <div class="progress-fill" style="width: <?= $percent ?>%;"></div>
    </div>
  </div>

  <div class="bg-white p-4 mb-4 rounded-xl shadow-sm text-center text-gray-700 font-medium">
    Wallet Balance: ₦<?= number_format($wallet_balance, 2) ?>
  </div>

  <?php if ($pocket->current_amount >= $pocket->target_amount): ?>
    <div class="bg-green-100 text-green-800 text-center p-6 rounded-2xl font-semibold text-lg">
      🎉 Goal has been reached!
    </div>
  <?php else: ?>
    <form id="depositForm" class="bg-white rounded-2xl shadow-sm p-6 space-y-5">
      <input type="hidden" name="pocket_id" value="<?= esc_attr($pocket_id) ?>">
      <input type="hidden" name="action" value="pulsepoint_deposit_to_pocket">

      <div>
        <label>Amount to Deposit (₦)</label>
        <input type="number" name="amount" placeholder="Enter amount" required min="1">
      </div>

      <button type="submit" class="w-full py-3 mt-4 rounded-xl font-semibold text-white" style="background: <?= $color_hex ?>;">
        Deposit from Wallet
      </button>
    </form>
  <?php endif; ?>
</div>

<script>
function showToast(msg, type='info') {
  Toastify({
    text: msg,
    duration: 3500,
    close: true,
    gravity: "top",
    position: "center",
    stopOnFocus: true,
    style: {
      background: type === 'error' ? "#ff3860" : "green",
      color: "#fff",
      borderRadius: "12px"
    }
  }).showToast();
}

document.getElementById('depositForm')?.addEventListener('submit', async function(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  try {
    const response = await fetch("<?= admin_url('admin-ajax.php'); ?>", {
      method: "POST",
      body: formData
    });
    const data = await response.json();

    if (data.success) {
      showToast(data.message, 'success');
      setTimeout(() => { window.location.href = "/app/saving"; }, 1500);
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast("Network error. Please try again.", 'error');
  }
});
</script>

</body>
</html>