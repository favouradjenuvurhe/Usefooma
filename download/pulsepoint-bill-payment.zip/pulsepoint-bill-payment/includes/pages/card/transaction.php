<?php
/**
 * Card Transactions Frontend Page for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/card-transactions.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session
if (!session_id()) session_start();

// Validate session
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Fetch user record
$user = $wpdb->get_row($wpdb->prepare("SELECT id, customerId, cardid FROM {$base_prefix}users WHERE id = %d", $user_id));
if (!$user) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">User not found.</div>';
    exit;
}

// Redirect if customerId missing
if (empty($user->customerId)) {
    echo '<script>window.location.href="/app/customer/";</script>';
    exit;
}

// Redirect if no card exists yet
if (empty($user->cardid)) {
    echo '<script>window.location.href="/app/create-card/";</script>';
    exit;
}

// Settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0d6efd';
$card_id       = esc_attr($user->cardid);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Card Transactions | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root { --primary: <?= esc_attr($color_hex) ?>; }
body { font-family:"Inter",sans-serif; background:#f9f9f9; padding:24px; min-height:100vh; }
.card { background:#fff; border-radius:22px; box-shadow:0 3px 12px rgba(0,0,0,0.07); padding:24px; }
.header-bar { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
.header-bar i { font-size:1.6rem; color:var(--primary); }
.tx-item { display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; padding:14px 0; }
.tx-item:last-child { border-bottom:none; }
.tx-info { flex:1; }
.tx-info .title { font-weight:600; font-size:15px; color:#333; }
.tx-info .meta { color:#777; font-size:13px; }
.tx-amount { text-align:right; font-weight:600; }
.badge { padding:4px 8px; border-radius:8px; font-size:12px; font-weight:600; color:#fff; }
.badge.success { background:#22c55e; }
.badge.failed { background:#ef4444; }
.badge.pending { background:#f59e0b; }
.load-more { background:var(--primary); color:#fff; font-weight:600; border-radius:10px; padding:12px; width:100%; margin-top:15px; }
</style>
</head>

<body>
<div class="max-w-lg mx-auto">
  <div class="header-bar">
    <a href="/app/virtual-card/"><i class="bi bi-arrow-left-circle"></i></a>
    <h1 class="font-bold text-lg"><?= esc_html($platform_name) ?></h1>
    <div class="header-avatar">
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="User Avatar" class="w-10 h-10 rounded-full">
    </div>
  </div>

  <div class="card">
    <h2 class="text-lg font-semibold mb-4" style="color: var(--primary)">Card Transactions</h2>
    <div id="txList">
      <div class="text-center py-4 text-gray-500" id="loadingTx">
        <i class="bi bi-arrow-repeat animate-spin"></i> Loading transactions...
      </div>
    </div>
    <button id="loadMoreBtn" class="load-more hidden">Load More</button>
  </div>
</div>

<script>
const card_id = "<?= $card_id ?>";
let page = 1;

// Toastify
function showToast(msg,type='info'){
  Toastify({
    text: msg,
    duration: 3500,
    close: true,
    gravity: "top",
    position: "center",
    style:{background:type==='error'?"#ff3860":"green",color:"#fff",borderRadius:"12px"}
  }).showToast();
}

// Fetch Transactions
async function fetchTransactions(loadMore=false){
  try{
    const res = await fetch("<?= admin_url('admin-ajax.php'); ?>", {
      method: "POST",
      body: new URLSearchParams({
        action: "pulsepoint_card_transactions",
        card_id: card_id,
        page: page,
        take: 10
      })
    });

    const data = await res.json();
    document.getElementById("loadingTx").remove();

    if(!data.success){
      showToast(data.message,"error");
      document.getElementById("txList").innerHTML = `<div class='text-center text-gray-500 py-4'>${data.message}</div>`;
      return;
    }

    const txList = document.getElementById("txList");

    if(!loadMore) txList.innerHTML = ""; // clear on first load

    data.transactions.forEach(tx=>{
      const statusClass = tx.status.toLowerCase() === 'successful' ? 'success'
                         : tx.status.toLowerCase() === 'pending' ? 'pending'
                         : 'failed';
      const sign = tx.type.toLowerCase() === 'credit' ? '+' : '-';

      txList.insertAdjacentHTML("beforeend", `
        <div class="tx-item">
          <div class="tx-info">
            <div class="title">${tx.narrative || 'Transaction'}</div>
            <div class="meta">${tx.date} &middot; <span class="badge ${statusClass}">${tx.status}</span></div>
          </div>
          <div class="tx-amount ${tx.type.toLowerCase() === 'credit' ? 'text-green-600' : 'text-red-500'}">
            ${sign}${tx.amount} ${tx.currency}
          </div>
        </div>
      `);
    });

    // Handle pagination
    if (data.transactions.length >= 10) {
      document.getElementById("loadMoreBtn").classList.remove("hidden");
    } else {
      document.getElementById("loadMoreBtn").classList.add("hidden");
    }

  } catch(e){
    showToast("Failed to load transactions.","error");
    document.getElementById("txList").innerHTML = `<div class='text-center text-gray-500 py-4'>Error loading transactions.</div>`;
  }
}

// Load more button
document.getElementById("loadMoreBtn").addEventListener("click",()=>{
  page++;
  fetchTransactions(true);
});

// Initial load
fetchTransactions();
</script>
</body>
</html>