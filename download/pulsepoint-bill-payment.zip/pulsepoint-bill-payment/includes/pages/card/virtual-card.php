<?php          
/**          
 * My Cards Page - Pulsepoint Plugin          
 * Author: Amaaavl          
 */          

if (!defined('ABSPATH')) exit;          

global $wpdb;          
$base_prefix = $wpdb->prefix . 'pulsepoint_';          

/* ================= SETTINGS ================= */          
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");          
$settings = [];          
foreach ($settings_rows as $row) {          
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);          
}          

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';          
$color_hex     = $settings['color_hex'] ?? '#0057ff';          

/* ================= USER ================= */          
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;          
if (!$user_id) return;          

$table_users = $base_prefix . 'users';          
$user = $wpdb->get_row($wpdb->prepare(          
    "SELECT * FROM {$table_users} WHERE id = %d",          
    $user_id          
));          

$firstname = esc_html($user->firstname ?? 'User');          

/* ================= VIRTUAL CARD ================= */          
$table_cards = $base_prefix . 'virtual_cards';          
$card = $wpdb->get_row($wpdb->prepare(          
    "SELECT * FROM {$table_cards} WHERE user_id = %d ORDER BY id DESC LIMIT 1",          
    $user_id          
));          

/* ================= CARD REDIRECT LOGIC ================= */      
$user_has_cardid     = !empty($user->cardid);
$virtual_card_exists = $card && !empty($card->card_number);

/**
 * Redirect rules:
 * - user has a cardid
 * - but virtual card is not yet created/activated
 */
if ($user_has_cardid && !$virtual_card_exists) {
    wp_safe_redirect('/app/card-activation');
    exit;
}

/* ================= TRANSACTIONS ================= */          
$table_tx = $base_prefix . 'virtualcard_transactions';          
$transactions = [];          

if ($virtual_card_exists) {          
    $tx_rows = $wpdb->get_results($wpdb->prepare(          
        "SELECT * FROM {$table_tx} WHERE card_id = %s ORDER BY created_at DESC LIMIT 10",          
        $card->card_id          
    ));          

    foreach ($tx_rows as $tx) {          
        $transactions[] = [          
            'name'   => esc_html($tx->narrative ?: 'Card Transaction'),          
            'date'   => date('M d, Y · h:i A', strtotime($tx->created_at)),          
            'amount' => ($tx->type === 'debit' ? '- ' : '+ ') . number_format($tx->amount, 2),          
            'status' => ucfirst($tx->status ?? 'completed')          
        ];          
    }          
}          
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Virtual Card - Dashboard</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>

<style>
  body {
    background: #f7f8fb;
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont;
    margin: 0;
    padding: 0;
  }

  .copy-box {
    border-radius: 14px;
    padding: 16px;
    background: #fff;
    box-shadow: 0 6px 18px rgba(20,30,60,0.06);
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
  }
</style>
</head>

<body>

<div id="app" class="max-w-6xl mx-auto px-6 pb-6 pt-1">

  <!-- HEADER (REPLACED AS REQUESTED) -->
  <div class="flex items-center justify-between mb-8">
    <div class="flex items-center gap-3">
      <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
      </button>
      <h2 class="text-xl font-bold text-gray-900">Virtual Card</h2>
    </div>

    <div class="flex items-center space-x-3 mt-1">
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>
      </button>
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>
      </button>
    </div>
  </div>

  <!-- Card Section -->
  <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">

    <!-- CARD AREA -->
    <div>

      <!-- HIDDEN CARD -->
<div
    v-if="!showCardDetails"
    class="h-56 rounded-2xl text-white p-6 relative overflow-hidden"
    style="background: linear-gradient(to bottom right, #3a3a3a, #1f1f1f, <?= $color_hex ?>);"
>
    <div class="absolute -right-10 -top-10 w-44 h-44 bg-white/5 rounded-full"></div>

    <div class="flex justify-between">
        <span class="text-sm opacity-80"><?= esc_html($card->card_type ?? 'Credit') ?></span>
        <span class="font-bold tracking-widest"><?= esc_html($card->card_brand ?? 'VISA') ?></span>
    </div>

    <div class="mt-12">
        <p class="text-lg font-medium"><?= esc_html($card->card_holder_name) ?></p>
        <p class="tracking-widest mt-2 text-sm">**** **** **** <?= esc_html($card->last4 ?? '0000') ?></p>
    </div>
</div>

      <!-- SHOW CARD DETAILS -->
      <div v-else class="bg-white rounded-2xl shadow-sm p-4 h-56">
        <div class="bg-gray-50 rounded-xl p-3 flex gap-3 h-full">

          <!-- Vertical Card -->
<div
    class="w-16 rounded-lg text-white flex flex-col justify-between p-2"
    style="background: linear-gradient(to bottom, #2f2f2f, <?= $color_hex ?>);"
>
    <span class="text-[9px] tracking-widest rotate-90 origin-left"><?= esc_html($card->card_brand ?? 'VISA') ?></span>
    <p class="text-[9px] opacity-70"><?= esc_html($card->card_type ?? 'Credit') ?></p>
</div>

          <!-- DETAILS -->
          <div class="flex-1 text-[10px] space-y-1 leading-tight">

            <div class="flex justify-between">
              <span class="text-gray-400">Cardholder</span>
              <span class="font-medium"><?= esc_html($card->card_holder_name) ?></span>
            </div>

            <div class="flex justify-between items-center gap-1">
              <span class="text-gray-400">Card Number</span>
              <span class="font-medium flex items-center gap-1">
                <?= esc_html($card->card_number) ?>
                <i
                  data-lucide="copy"
                  class="w-3 h-3 cursor-pointer text-gray-400 hover:text-black"
                  @click="copyCard"
                ></i>
              </span>
            </div>

            <div class="flex justify-between">
              <span class="text-gray-400">Expiry</span>
              <span class="font-medium"><?= esc_html($card->expiry) ?></span>
            </div>

            <div class="flex justify-between">
              <span class="text-gray-400">CVV</span>
              <span class="font-medium"><?= esc_html($card->cvv) ?></span>
            </div>

            <div class="flex justify-between">
              <span class="text-gray-400">Status</span>
              <span class="font-medium"><?= esc_html($card->card_status) ?></span>
            </div>

            <div class="flex justify-between">
              <span class="text-gray-400">Balance</span>
              <span class="font-medium">$<?= number_format($card->balance,2) ?></span>
            </div>

            <div class="pt-1 border-t border-gray-200">
              <span class="text-gray-400 block text-[9px]">Billing Address</span>
              <span class="font-medium text-[9px] leading-tight">
                <?= esc_html($card->billing_address_street) ?>,<br>
               <?= esc_html($card->billing_address_zipcode) ?> ,<br>
                <?= esc_html($card->billing_address_city) ?>, <?= esc_html($card->billing_address_country) ?>
              </span>
            </div>

          </div>

        </div>
      </div>

    </div>
<?php if (!empty($card->card_number)) : ?>
  <!-- Actions -->
  <div class="bg-white rounded-2xl shadow-sm p-6 grid grid-cols-3 gap-y-8 text-center text-sm text-gray-600">
    
    <!-- Show/Hide Card Details stays dynamic -->
    <div @click="toggleDetails" class="cursor-pointer">
      <i :data-lucide="showCardDetails ? 'eye-off' : 'eye'" class="mx-auto mb-2"></i>
      {{ showCardDetails ? 'Hide Details' : 'Show Details' }}
    </div>

    <!-- Other actions redirect via Vue method -->
    <div @click="goTo('/app/fund-card')" class="cursor-pointer">
      <i data-lucide="circle-arrow-out-down-left" class="mx-auto mb-2"></i>Fund
    </div>
    <div @click="goTo('/app/withdraw-card')" class="cursor-pointer">
      <i data-lucide="circle-arrow-out-up-right" class="mx-auto mb-2"></i>Withdraw
    </div>
    <div @click="goTo('/app/limit-card')" class="cursor-pointer">
      <i data-lucide="check-square" class="mx-auto mb-2"></i>Limit
    </div>
    <div @click="goTo('/app/freeze-card')" class="cursor-pointer">
      <i data-lucide="snowflake" class="mx-auto mb-2"></i>Freeze
    </div>
    <div @click="goTo('/app/delete-card')" class="cursor-pointer">
      <i data-lucide="trash-2" class="mx-auto mb-2"></i>Delete
    </div>
  </div>
<?php else: ?>
  <!-- If no card, show only Create Card button -->
  <div class="text-center mt-6">
    <button
  onclick="window.location.href='/app/create-card'"
  class="bg-blue-600 text-white px-20 py-3 rounded-xl shadow hover:bg-blue-700 transition"
>
  Create Card
</button>
  </div>
<?php endif; ?>

<!-- Transactions Section -->
<div class="bg-white rounded-2xl shadow-sm p-6 mt-6">
  <div class="flex justify-between items-center mb-6">
    <h2 class="font-semibold text-lg">Recent Transactions</h2>
    <span class="text-sm text-gray-400 cursor-pointer">View all</span>
  </div>

  <div class="space-y-5">
    <!-- Show transactions if there are any -->
    <div v-if="transactions.length > 0">
      <div v-for="t in transactions" :key="t.name" class="flex justify-between items-center">
        <div class="flex gap-4 items-center">
          <div class="w-11 h-11 bg-gray-100 rounded-xl flex items-center justify-center">
            <i data-lucide="shopping-cart" class="text-gray-500"></i>
          </div>
          <div>
            <p class="font-medium text-sm">{{ t.name }}</p>
            <p class="text-xs text-gray-400">{{ t.date }}</p>
          </div>
        </div>
        <div class="text-right">
          <p class="text-sm font-semibold">{{ t.amount }}</p>
          <p class="text-xs text-green-500">{{ t.status }}</p>
        </div>
      </div>
    </div>

    <!-- Show message if there are no transactions -->
    <div v-else class="text-center text-gray-400 py-4">
      Currently no transactions
    </div>
  </div>
</div>

<script>
Vue.createApp({
  data() {
    return {
      showCardDetails: false,
      // Inject PHP transactions into Vue
      transactions: <?= json_encode($transactions) ?> || []
    }
  },
  methods: {
    toggleDetails() {
      this.showCardDetails = !this.showCardDetails;
      this.$nextTick(() => lucide.createIcons());
    },
    copyCard() {
      navigator.clipboard.writeText('1234 5678 9123 456');
    },
    goBack() {
      window.history.back();
    },
    // <-- New method to handle button redirects
    goTo(path) {
      window.location.href = path;
    }
  },
  mounted() {
    lucide.createIcons();
  }
}).mount('#app');
</script>

</body>
</html>