<?php
/**      
 * Virtual Dollar Card Page - Pulsepoint Plugin      
 * Author: Amaaavl      
 */      
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : 'User';
$lastname  = $user ? esc_html($user->lastname) : '';
$card_holder = trim("$firstname $lastname");

$ajax_url = admin_url('admin-ajax.php');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Virtual Dollar Card - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root{
  --app-bg: #f7f8fb;
  --card-bg: #ffffff;
  --muted: #6b7280;
  --primary: <?= esc_html($color_hex) ?>;
}

html, body, #app { min-height: 100%; background: var(--app-bg); font-family: 'Inter', sans-serif; margin:0; padding:0; }

.rounded-card{ border-radius: 14px; background: var(--card-bg); }

.input-field {
  border-radius: 12px;
  border: 1.5px solid #e5e7eb;
  padding: 10px 14px;
  width: 100%;
  outline: none;
  font-weight:600;
}
.input-field:focus { border-color: var(--primary); }

.pay-btn {
  background: var(--primary);
  color: white;
  padding: 8px 20px;
  border-radius: 999px;
  font-weight: 400;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
  min-width: 60px;
}
.pay-btn:hover{ filter: brightness(90%); }

.card-preview {
  background: linear-gradient(135deg,#3b82f6,#9333ea);
  border-radius:16px;
  color:white;
  padding:20px;
  display:flex;
  flex-direction:column;
  justify-content:space-between;
  min-height:200px;
  height:auto;
  padding-bottom:28px;
  margin-bottom:16px;
}

.card-number { letter-spacing:3px; font-size:16px; font-weight:600; }
.card-footer { display:flex; justify-content:space-between; font-size:13px; }
.small-txt { font-size:12px; color:rgba(255,255,255,0.85); }

.quick-box {
  background:white;
  border-radius:12px;
  padding:12px;
  flex:1;
  text-align:center;
  cursor:pointer;
  transition:all 0.12s;
}
.quick-box:hover{ transform:translateY(-2px); }

.txn-item { display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #f1f1f1; }
.txn-name { font-weight:600; font-size:13px; }
.txn-date { font-size:12px; color:#888; }

.copy-btn { cursor:pointer; margin-left:8px; opacity:0.9; }
.mask { letter-spacing:3px; }

/* Desktop layout */
#app {
  max-width: 1000px;
  margin: 20px auto;
  padding: 20px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

.card-section, .actions-section { display: flex; flex-direction: column; }
.transactions-section { grid-column: span 2; }
</style>
</head>
<body>

<div id="app">
  <!-- Card Preview -->
  <div class="card-section">
    <div class="card-preview">
      <div class="flex justify-between items-start">
        <div>
          <div class="font-semibold text-base"><?= $card_holder ?></div>
          <div class="small-txt mt-1">Visa</div>
        </div>
        <div class="text-right small-txt">
          <div>Balance</div>
          <div class="font-semibold text-lg" id="card_balance_display">${{ balanceDisplay }}</div>
          <div class="text-xs mt-1">
            <span class="copy-btn" @click="copyToClipboard(balanceDisplay)">
              <i data-lucide="copy" class="w-4 h-4"></i>
            </span>
          </div>
        </div>
      </div>

      <div class="mt-3">
        <div class="flex items-center justify-between">
          <div class="card-number mask" v-html="displayCardNumber"></div>
          <div class="text-xs small-txt" style="text-align:right">
            <div class="mb-1">Expiry</div>
            <div class="font-semibold" v-text="displayExpiry"></div>
          </div>
        </div>
      </div>

      <div class="card-footer mt-2">
        <div>
          <div class="small-txt">Currency</div>
          <div class="font-semibold">USD</div>
        </div>
        <div class="text-right">
          <div class="small-txt">CVV</div>
          <div class="font-semibold" v-text="displayCvv"></div>
        </div>
      </div>
    </div>

    <!-- Actions -->
    <div class="actions-section flex gap-3 mb-4">
      <div class="quick-box" @click="toggleDetails">
        <div class="text-sm font-semibold" v-text="detailsVisible ? 'Hide Details' : 'View Details'"></div>
        <div class="text-xs text-gray-500 mt-1">Show card number & CVV</div>
      </div>
      <div class="quick-box" @click="toggleFreeze" :class="cardFrozen ? 'bg-red-50' : 'bg-green-50'">
        <div class="text-sm font-semibold" v-text="cardFrozen ? 'Unfreeze' : 'Freeze'"></div>
        <div class="text-xs text-gray-500 mt-1" v-text="cardFrozen ? 'Card is frozen' : 'Card is active'"></div>
      </div>
    </div>

    <!-- Fund / Withdraw / History -->
    <div class="grid grid-cols-3 gap-2 mb-4">
      <button class="pay-btn col-span-1 text-sm py-2" @click="fundCard">Fund</button>
      <button class="pay-btn col-span-1 text-sm py-2" style="background:#10b981" @click="withdrawCard">Withdraw</button>
      <button class="pay-btn col-span-1 text-sm py-2" style="background:#6b7280" @click="viewHistory">History</button>
    </div>

    <!-- Fund Inline -->
    <div v-if="showFundInline" class="bg-white p-3 rounded-card mb-4 shadow-sm">
      <div class="text-sm font-semibold mb-2">Fund Card</div>
      <input v-model.number="fundAmount" type="number" min="1" placeholder="Amount in USD" class="input-field mb-2">
      <div class="flex gap-2">
        <button class="pay-btn flex-1" @click="submitFund">Submit</button>
        <button class="pay-btn flex-1" style="background:#9CA3AF" @click="cancelFund">Cancel</button>
      </div>
    </div>

    <!-- No Card -->
    <div v-if="!cardExists" class="text-center py-6 bg-white rounded-card shadow mb-4">
      <h3 class="text-lg font-semibold mb-2">No Virtual Card Found</h3>
      <p class="text-gray-500 mb-2">
        You don’t have a dollar card yet. Create one to start making international payments, subscriptions, and more!
      </p>
      <button class="pay-btn w-full" @click="createCard">Create a Card</button>
    </div>
  </div>

  <!-- Transactions -->
  <div class="transactions-section">
    <div v-if="cardExists">
      <div class="section-title mb-2 font-semibold">Recent Transactions</div>
      <div class="bg-white rounded-2xl shadow-sm p-3 text-sm text-gray-700">
        <div v-if="transactions.length===0" class="text-center text-gray-500 py-3">No transactions found.</div>
        <div v-for="t in transactions" :key="t.reference" class="txn-item">
          <div>
            <div class="txn-name" v-text="t.narrative || 'Transaction'"></div>
            <div class="txn-date" v-text="formatDate(t.createdAt)"></div>
          </div>
          <div :class="t.status==='success' ? 'text-green-600' : t.status==='pending' ? 'text-yellow-500' : 'text-red-500'">
            {{ t.type==='debit' ? '-' : '+' }}${{ parseFloat(t.amount).toFixed(2) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
const { createApp } = Vue;
createApp({
  data(){
    return {
      cardExists: false,
      card: {},
      transactions: [],
      cardName: '',
      cardNumber: '',
      expiry: '',
      cvv: '',
      balance: 0,
      detailsVisible: false,
      cardFrozen: (localStorage.getItem('cardState') === 'freeze'),
      showFundInline: false,
      fundAmount: '',
      ajaxUrl: "<?= esc_js($ajax_url) ?>",
    }
  },
  computed:{
    displayCardNumber(){
      if(!this.cardExists && !this.cardNumber) return '**** **** **** ';
      if(this.detailsVisible){
        return this.card.card_number ? this.formatCardNumber(this.card.card_number) : (' **** **** ' + (this.card.last4 || '0000'));
      }
      return '**** **** **** ' + (this.card.last4 || '0000');
    },
    displayExpiry(){ return this.detailsVisible ? (this.card.expiry || this.expiry || 'MM/YY') : (this.card.expiry || 'MM/YY'); },
    displayCvv(){ return this.detailsVisible ? (this.card.cvv || this.cvv || '***') : '***'; },
    balanceDisplay(){ return (parseFloat(this.balance)||0).toFixed(2); }
  },
  mounted(){ this.fetchCardDetails(); if(localStorage.getItem('cardState')===null){ localStorage.setItem('cardState', this.cardFrozen?'freeze':'unfreeze'); } },
  methods:{
    goBack(){ window.history.back(); },
    showToast(msg,type='info'){ Toastify({ text:msg,duration:3000,close:true,gravity:'top',position:'center',stopOnFocus:true,style:{background:type==='error'?'#ff3860':'#16a34a',color:'#fff',borderRadius:'12px'}}).showToast(); },
    formatCardNumber(num){ return String(num).replace(/(.{4})/g,"$1 ").trim(); },
    formatDate(dt){ if(!dt) return ''; const d=new Date(dt); return d.toLocaleDateString(); },
    copyToClipboard(text){ navigator.clipboard.writeText(String(text||'')).then(()=>this.showToast('Copied to clipboard'),()=>this.showToast('Copy failed','error')); },
    toggleDetails(){ this.detailsVisible=!this.detailsVisible; },
    toggleFreeze(){
      this.cardFrozen=!this.cardFrozen;
      const state=this.cardFrozen?'freeze':'unfreeze';
      localStorage.setItem('cardState',state);
      fetch(this.ajaxUrl,{ method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body:new URLSearchParams({ action:'pulsepoint_card_freeze', state }) })
        .then(r=>r.json()).then(res=>{ if(res&&res.success){ this.showToast(res.message||(this.cardFrozen?'Card frozen':'Card unfrozen')); } else { this.showToast(res.message||'Server error','error'); } })
        .catch(()=>this.showToast('Network error','error'));
    },
    fetchCardDetails(){
      fetch(this.ajaxUrl,{ method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body:new URLSearchParams({ action:'pulsepoint_card_details' }) })
        .then(r=>r.json()).then(res=>{
          if(res&&res.success&&res.card){ this.cardExists=true; this.card=res.card; this.balance=res.card.balance||this.balance; if(!this.card.last4&&this.card.card_number){ this.card.last4=String(this.card.card_number).slice(-4); } this.transactions=Array.isArray(res.transactions)?res.transactions:(res.transactions||[]); }
          else if(res&&res.message&&res.message.toLowerCase().includes('no virtual card')){ this.cardExists=false; }
          else { this.showToast(res.message||'Failed to fetch card details','error'); }
        }).catch(()=>this.showToast('Network error','error'));
    },
    createCard(){ window.location.href='/app/create-card/'; },
    fundCard(){ this.showFundInline=true; },
    cancelFund(){ this.showFundInline=false; this.fundAmount=''; },
    submitFund(){
      if(!this.fundAmount||parseFloat(this.fundAmount)<1){ this.showToast('Enter an amount greater than 0','error'); return; }
      this.showToast('Processing funding...');
      fetch(this.ajaxUrl,{ method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body:new URLSearchParams({ action:'pulsepoint_virtual_card_fund', amount:this.fundAmount }) })
        .then(r=>r.json()).then(res=>{
          if(res&&res.success){ this.showToast(res.message||`Card funded $${this.fundAmount}`); setTimeout(()=>{ this.fetchCardDetails(); this.showFundInline=false; this.fundAmount=''; },900); }
          else{ this.showToast(res.message||'Funding failed','error'); }
        }).catch(()=>this.showToast('Network error','error'));
    },
    withdrawCard(){ window.location.href='/app/withdraw-card/'; },
    viewHistory(){ window.location.href='/app/card-transactions/'; }
  }
}).mount('#app');
</script>
<script>lucide.createIcons()</script>
</body>
</html>