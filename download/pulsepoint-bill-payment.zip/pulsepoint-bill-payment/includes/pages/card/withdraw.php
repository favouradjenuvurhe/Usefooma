<?php    
/**    
 * Withdraw Virtual Card Page for Pulsepoint Plugin    
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/withdraw-card.php    
 * Author: Amaaavl    
 */    

if (!defined('ABSPATH')) exit;    

global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    

// Start session    
if (!session_id()) session_start();    

// Validate user session    
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
if (!$user_id) {    
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';    
    exit;    
}    

// Fetch user record    
$user = $wpdb->get_row($wpdb->prepare("SELECT id, customerId, cardid, passcode FROM {$base_prefix}users WHERE id = %d", $user_id));    
if (!$user) {    
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">User not found.</div>';    
    exit;    
}    

// Redirect if customerId missing    
if (empty($user->customerId)) {    
    echo '<script>window.location.href="/app/customer/";</script>';    
    exit;    
}    

// Redirect if no card exists yet    
if (empty($user->cardid)) {    
    echo '<script>window.location.href="/app/create-card/";</script>';    
    exit;    
}    

// Fetch settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0d6efd';    
$flat_fee      = floatval($settings['card_withdraw_flat_fee'] ?? 1.00);    
$percent_fee   = floatval($settings['card_withdraw_percent_fee'] ?? 1.5);    
$passcode      = $user->passcode ?? '';    
?>    

<!doctype html>
<html lang="en">    
<head>    
<meta charset="utf-8" />    
<meta name="viewport" content="width=device-width,initial-scale=1" />    
<title>Withdraw from Card | <?= esc_html($platform_name) ?></title>    
<script src="https://cdn.tailwindcss.com"></script>    
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>    
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">    
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>    

<style>  
:root { --primary: <?= esc_attr($color_hex) ?>; }  
body { font-family:"Inter",sans-serif; background:#f9f9f9; padding:24px; min-height:100vh; }  
.card { background:#fff; border-radius:22px; box-shadow:0 3px 12px rgba(0,0,0,0.07); padding:32px; }  
.generate-btn { background:var(--primary); color:#fff; font-weight:600; border-radius:10px; padding:12px; width:100%; transition:.3s; }  
.generate-btn:hover { opacity:.9; }  
.header-bar { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }  
.header-bar i { font-size:1.6rem; color:var(--primary); }  
.info-box { background:#f3f4f6; border-left:5px solid var(--primary); padding:14px; border-radius:10px; color:#333; margin-top:10px; font-size:15px; }  
.info-box strong { color:var(--primary); }  

/* ✅ PIN Modal */  
.modal-bg { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.4); backdrop-filter:blur(5px); align-items:flex-end; justify-content:center; z-index:999; overflow:hidden; }  
.modal-bg.active { display:flex; }  
.modal-card { background:#fff; border-radius:26px 26px 0 0; width:100%; max-width:400px; padding:24px 16px; transform:translateY(100%); transition:transform 0.3s ease-in-out; }  
.modal-bg.active .modal-card { transform:translateY(0); }  
.pin-inputs { display:flex; justify-content:center; gap:10px; margin:18px 0; }  
.pin-inputs input { width:40px; height:40px; border-radius:10px; border:1px solid #ccc; text-align:center; font-size:20px; background:#f2f2f2; font-weight:600; }  
.keypad { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin-top:12px; }  
.keypad button { background:#f2f2f2; border-radius:10px; border:none; font-size:1.2rem; padding:14px 0; cursor:pointer; transition:.2s; }  
.keypad button:hover { background:var(--primary); color:#fff; }  
.keypad .delete { background:#ff6666; color:#fff; }  
.forgot-pin { display:block; text-align:center; margin-top:12px; color:var(--primary); }  
</style>  
</head>  

<body>  
<div class="max-w-lg mx-auto">  
  <div class="header-bar">  
    <a href="/app/virtual-card/"><i class="bi bi-arrow-left-circle"></i></a>  
    <h1 class="font-bold text-lg"><?= esc_html($platform_name) ?></h1>  
    <div class="header-avatar">  
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="User Avatar" class="w-10 h-10 rounded-full">  
    </div>  
  </div>  

  <div class="card">  
    <form id="withdrawForm" class="space-y-4">  

      <!-- Hidden Card ID -->
      <input type="hidden" name="card_id" id="card_id" value="<?= esc_attr($user->cardid) ?>">

      <div>  
        <label class="font-semibold block mb-1">Amount (USD)</label>  
        <input type="number" step="0.01" name="amount" id="amount" placeholder="Enter amount to withdraw" required class="w-full p-3 border rounded-lg">  
      </div>  

      <div class="info-box" id="feeInfo">  
        Withdrawals attract a <strong>$<?= number_format($flat_fee, 2) ?> + <?= number_format($percent_fee, 1) ?>%</strong> fee.  
      </div>  

      <button type="button" id="withdrawBtn" class="generate-btn">Proceed</button>  
    </form>
  </div>  
</div>  

<!-- ✅ PIN Modal -->  
<div class="modal-bg" id="pinModal">  
  <div class="modal-card text-center">  
    <div class="flex justify-end mb-4">  
      <i class="bi bi-x close-btn" onclick="closePinModal()"></i>  
    </div>  
    <h3 class="text-lg font-semibold mb-4" style="color: var(--primary)">Enter Payment PIN</h3>  
    <div class="pin-inputs">  
      <input type="password" maxlength="1" disabled>  
      <input type="password" maxlength="1" disabled>  
      <input type="password" maxlength="1" disabled>  
      <input type="password" maxlength="1" disabled>  
    </div>  
    <span class="forgot-pin"><a href="/app/reset-pin/">Forgot Payment PIN?</a></span>  
    <div class="keypad">  
      <button onclick="pressKey('1')">1</button>  
      <button onclick="pressKey('2')">2</button>  
      <button onclick="pressKey('3')">3</button>  
      <button onclick="pressKey('4')">4</button>  
      <button onclick="pressKey('5')">5</button>  
      <button onclick="pressKey('6')">6</button>  
      <button onclick="pressKey('7')">7</button>  
      <button onclick="pressKey('8')">8</button>  
      <button onclick="pressKey('9')">9</button>  
      <button class="delete" onclick="deleteKey()">⌫</button>  
      <button onclick="pressKey('0')">0</button>  
      <button onclick="clearPin()">C</button>  
    </div>  
  </div>  
</div>  

<script>  
let pinInputs = document.querySelectorAll(".pin-inputs input");  
let pinCode = "";  
let userPasscode = "<?= $passcode ?>";  

// Toastify
function showToast(msg,type='info'){
  Toastify({
    text: msg,
    duration: 3500,
    close: true,
    gravity: "top",
    position: "center",
    style:{background:type==='error'?"#ff3860":"green",color:"#fff",borderRadius:"12px"}
  }).showToast();
}

// Open/Close PIN Modal
function openPinModal(){ document.getElementById("pinModal").classList.add("active"); }
function closePinModal(){ document.getElementById("pinModal").classList.remove("active"); clearPin(); }

function pressKey(num){
  if(pinCode.length < 4){
    pinCode += num;
    pinInputs[pinCode.length-1].value = "•";
  }
  if(pinCode.length === 4){
    verifyPin();
  }
}

function deleteKey(){
  if(pinCode.length > 0){
    pinInputs[pinCode.length-1].value = "";
    pinCode = pinCode.slice(0,-1);
  }
}

function clearPin(){
  pinCode = "";
  pinInputs.forEach(i=>i.value="");
}

function verifyPin(){
  if(pinCode === userPasscode){
    closePinModal();
    withdrawCard(); // proceed
  }else{
    showToast("Incorrect PIN. Try again.","error");
    clearPin();
  }
}

// Calculate Fee Info dynamically
const amountField = document.getElementById("amount");
const feeInfo = document.getElementById("feeInfo");
const flat = <?= $flat_fee ?>;
const percent = <?= $percent_fee ?>;

amountField.addEventListener("input", () => {
  const amount = parseFloat(amountField.value || 0);
  if (amount > 0) {
    const fee = flat + (amount * (percent / 100));
    const final = amount - fee;
    feeInfo.innerHTML = `<i class="bi bi-info-circle-fill"></i> &nbsp; After fees ($${flat.toFixed(2)} + ${percent}%), you'll receive <strong>$${final.toFixed(2)}</strong>.`;
  } else {
    feeInfo.innerHTML = `<i class="bi bi-info-circle-fill"></i> &nbsp; Withdrawals attract a <strong>$${flat.toFixed(2)} + ${percent}%</strong> fee.`;
  }
});

// Proceed button
document.getElementById("withdrawBtn").addEventListener("click", ()=>{
  openPinModal();
});

// ✅ Withdraw AJAX
async function withdrawCard(){
  const btn = document.getElementById("withdrawBtn");
  const amount = parseFloat(amountField.value || 0);
  const card_id = document.getElementById("card_id").value;

  if(!amount || amount <= 0){ showToast("Enter a valid amount.","error"); return; }

  btn.disabled = true;
  btn.innerHTML = '<i class="bi bi-arrow-repeat animate-spin"></i> Processing...';

  try{
    const formData = new FormData();
    formData.append("action","pulsepoint_withdraw_card");
    formData.append("card_id",card_id);
    formData.append("amount",amount);

    const res = await fetch("<?= admin_url('admin-ajax.php'); ?>",{method:"POST",body:formData});
    const data = await res.json();

    if(data.success){
      showToast(data.message || "Withdrawal request submitted.","success");
      setTimeout(()=>window.location.href="/app/virtual-card/",2000);
    } else {
      showToast(data.message || "Withdrawal failed.","error");
    }
  } catch(e){
    showToast("Network error. Try again.","error");
  }

  btn.disabled = false;
  btn.innerHTML = "Proceed";
}
</script>  
</body>  
</html>