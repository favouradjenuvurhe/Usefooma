<?php
/**
 * My Cards Page - Pulsepoint Plugin
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

/* ================= SETTINGS ================= */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

/* ================= USER ================= */
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) return;

$table_users = $base_prefix . 'users';
$user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d",
    $user_id
));

$firstname = esc_html($user->firstname ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Card Activation</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>

<style>
  body {
    background: #f7f8fb;
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont;
    margin: 0;
    padding: 0;
  }
</style>
</head>

<body>

<div id="app" class="max-w-6xl mx-auto px-6 pb-6">

  <!-- HEADER (TOP SPACE REMOVED) -->
  <div class="flex items-center justify-between mb-8">
    <div class="flex items-center gap-3">
      <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
      </button>
      <h2 class="text-xl font-bold text-gray-900">Virtual Card</h2>
    </div>

    <div class="flex items-center space-x-3">
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>
      </button>
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>
      </button>
    </div>
  </div>

  <!-- ACTIVATION CARD -->
  <div class="max-w-xl mx-auto bg-white rounded-2xl shadow-sm p-8 text-center">
    <i data-lucide="check-circle" class="w-14 h-14 text-green-600 mx-auto mb-4"></i>

    <h3 class="text-lg font-semibold text-gray-900">
      Card creation was successful 🎉
    </h3>

    <p class="text-sm text-gray-500 mt-2">
      Click activate to make your card usable
    </p>

    <button
      @click="activateCard"
      :disabled="loading"
      class="mt-6 w-full py-3 rounded-xl bg-black text-white font-medium hover:opacity-90 transition"
    >
      <span v-if="!loading">Activate Card</span>
      <span v-else>Syncing...</span>
    </button>
  </div>

</div>

<script>
Vue.createApp({
  data() {
    return {
      loading: false
    }
  },
  methods: {
    activateCard() {
      if (this.loading) return;

      this.loading = true;

      fetch('<?= admin_url('admin-ajax.php') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'pulsepoint_card_sync',
          user_id: '<?= $user_id ?>',
          nonce: '<?= wp_create_nonce("pulsepoint_card_sync") ?>'
        })
      })
      .then(res => res.json())
      .then(res => {
        this.loading = false;
        if (res.success) {
          window.location.href = '/app/virtual-card';
        } else {
          alert(res.message || 'Activation failed');
        }
      })
      .catch(() => {
        this.loading = false;
        alert('Network error. Please try again.');
      });
    },
    goBack() {
      window.history.back();
    }
  },
  mounted() {
    lucide.createIcons();
  }
}).mount('#app')
</script>

</body>
</html>