<?php
/**
 * Create Virtual Card Page for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/create-card.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session
if (!session_id()) session_start();

// Validate user session
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Fetch user record
$user = $wpdb->get_row($wpdb->prepare("SELECT customerId, cardid FROM {$base_prefix}users WHERE id = %d", $user_id));
if (!$user) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">User not found.</div>';
    exit;
}

// Redirect logic
if (empty($user->customerId)) {
    echo '<script>window.location.href="/app/customer/";</script>';
    exit;
}

if (!empty($user->cardid)) {
    echo '<script>window.location.href="/app/virtual-card/";</script>';
    exit;
}

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0d6efd';
$flat_fee      = floatval($settings['card_creation_flat_fee'] ?? 2.5);
$percent_fee   = floatval($settings['card_creation_percent_fee'] ?? 1.5);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Create Virtual Card | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<style>
  :root { --primary: <?= esc_attr($color_hex) ?>; }
  body { font-family: "Inter", sans-serif; background: #f9f9f9; padding: 24px; min-height: 100vh; }
  .card { background: #fff; border-radius: 22px; box-shadow: 0 3px 12px rgba(0,0,0,0.07); padding: 32px; }
  .generate-btn { background: var(--primary); color: #fff; font-weight: 600; border-radius: 10px; padding: 12px; width: 100%; transition: .3s; }
  .generate-btn:hover { opacity: .9; }
  .form-label { font-weight: 600; color: #333; }
  .header-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
  .header-bar i { font-size: 1.6rem; color: var(--primary); }
  .header-avatar img { width: 38px; height: 38px; border-radius: 50%; }
  .info-box { background: #f3f4f6; border-left: 5px solid var(--primary); padding: 14px; border-radius: 10px; color: #333; margin-top: 10px; font-size: 15px; }
  .info-box strong { color: var(--primary); }
</style>
</head>
<body>
<div class="max-w-lg mx-auto space-y-6">

  <!-- Header -->
  <div class="header-bar">
    <a href="/app/dashboard"><i class="bi bi-arrow-left-circle"></i></a>
    <h1 class="font-bold text-lg"><?= esc_html($platform_name) ?></h1>
    <div class="header-avatar">
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="User Avatar">
    </div>
  </div>

  <!-- Card Form -->
  <div class="card">
    <form id="createCardForm" class="space-y-4">
      <div>
        <label class="form-label block mb-1">Select Card Type</label>
        <select name="card_type" id="card_type" required class="w-full p-3 border rounded-lg">
          <option value="">-- Choose Type --</option>
          <option value="visa">Visa (Recommended)</option>
          <option value="mastercard" disabled>Mastercard (Unavailable)</option>
        </select>
      </div>

      <div>
        <label class="form-label block mb-1">Amount (USD)</label>
        <input type="number" step="0.01" min="5" name="amount" id="amount" placeholder="Enter amount" required class="w-full p-3 border rounded-lg">
      </div>

      <!-- Info Box -->
      <div class="info-box" id="feeInfo">
        <i class="bi bi-info-circle-fill"></i>
        &nbsp; Creating a virtual card costs 
        <strong>$<?= number_format($flat_fee, 2) ?> + <?= number_format($percent_fee, 1) ?>%</strong>.
      </div>

      <button type="submit" id="createBtn" class="generate-btn">Create Card</button>
    </form>
  </div>
</div>

<script>
// Toastify helper
function showToast(msg, type='info') {
  Toastify({
    text: msg,
    duration: 3500,
    close: true,
    gravity: "top",
    position: "center",
    stopOnFocus: true,
    style: {
      background: type === 'error' ? "#ff3860" : "green",
      color: "#fff",
      borderRadius: "12px"
    }
  }).showToast();
}

document.addEventListener("DOMContentLoaded", function(){
  const form = document.getElementById("createCardForm");
  const createBtn = document.getElementById("createBtn");
  const amountField = document.getElementById("amount");
  const feeInfo = document.getElementById("feeInfo");

  const flat = <?= $flat_fee ?>;
  const percent = <?= $percent_fee ?>;

  amountField.addEventListener("input", () => {
    const amount = parseFloat(amountField.value || 0);
    if (amount > 0) {
      const fee = flat + (amount * (percent / 100));
      const total = amount + fee;
      feeInfo.innerHTML = `<i class="bi bi-info-circle-fill"></i> &nbsp; You’ll be deducted <strong>$${total.toFixed(2)}</strong> in total (includes $${flat.toFixed(2)} + ${percent}% fee).`;
    } else {
      feeInfo.innerHTML = `<i class="bi bi-info-circle-fill"></i> &nbsp; Creating a virtual card costs <strong>$${flat.toFixed(2)} + ${percent}%</strong>.`;
    }
  });

  // Submit form
  form.addEventListener("submit", async function(e){
    e.preventDefault();
    createBtn.disabled = true;
    createBtn.innerHTML = '<i class="bi bi-arrow-repeat animate-spin"></i> Creating...';

    try {
      const formData = new FormData(form);
      formData.append("action", "pulsepoint_create_card");

      const res = await fetch("<?= admin_url('admin-ajax.php'); ?>", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
      });

      const data = await res.json();

      if (data.success) {
        showToast(data.message || "Card created successfully!", "success");
        setTimeout(() => window.location.href = "/app/card-activation/", 2000);
      } else {
        showToast(data.message || "Failed to create card.", "error");
        if (data.message && (data.message.includes("Missing customerId") || data.message.includes("email"))) {
          setTimeout(() => window.location.href = "/app/customer/", 2000);
        }
      }
    } catch (err) {
      showToast("Network error. Please try again.", "error");
    }

    createBtn.disabled = false;
    createBtn.innerHTML = "Create Card";
  });
});
</script>
</body>
</html>