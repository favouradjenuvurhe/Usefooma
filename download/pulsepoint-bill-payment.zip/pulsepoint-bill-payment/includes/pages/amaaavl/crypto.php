<?php
/**
 * Crypto Wallet (USDT Receiver Balance Page)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/wallet/crypto-wallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session
if (!session_id()) session_start();

// User session check
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Get settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// Table
$table_wallet  = "{$base_prefix}wallets";

// Get user wallet (USDT)
$wallet = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_wallet} WHERE user_id = %d AND network = 'USDT' LIMIT 1", $user_id));

$balance = $wallet->balance ?? 0.00000000;
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Receiver Wallet | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<style>
:root {
  --primary: <?= esc_html($color_hex) ?>;
  --bg: #f9f9f9;
}
body {
  font-family: "Inter", sans-serif;
  background: var(--bg);
  padding: 24px;
  min-height: 100vh;
}
.card {
  background: #fff;
  border-radius: 22px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.07);
  padding: 24px;
  position: relative;
  overflow: hidden;
}
.card::after {
  content: "₮";
  position: absolute;
  right: 20px;
  top: 10px;
  font-size: 110px;
  font-weight: 800;
  color: rgba(0,0,0,0.05);
}
.crypto-label { color: var(--primary); font-weight: 700; font-size: 15px; }
.crypto-value { font-weight: 700; font-size: 18px; color: #000; }
.copy-icon {
  color: var(--primary);
  font-size: 20px;
  cursor: pointer;
  transition: .2s;
}
.copy-icon:hover { opacity: .7; }
.header-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.5rem;
}
.header-bar i {
  font-size: 22px;
  color: #000;
  cursor: pointer;
}
.header-avatar {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: var(--primary);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.header-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.generate-btn {
  background: var(--primary);
  color: #fff;
  font-weight: 600;
  border-radius: 10px;
  padding: 10px 20px;
  display: inline-block;
  margin-top: 12px;
  transition: .3s;
}
.generate-btn:hover { opacity: .85; }
.balance-box {
  background: rgba(108,99,255,0.05);
  border: 1px solid rgba(108,99,255,0.1);
  padding: 14px 20px;
  border-radius: 12px;
  margin-bottom: 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.balance-box span {
  font-weight: 700;
  color: var(--primary);
}
.badge-info {
  display: inline-block;
  background: rgba(108,99,255,0.1);
  color: var(--primary);
  font-weight: 600;
  border-radius: 8px;
  padding: 5px 10px;
  font-size: 13px;
  margin-top: 5px;
}
</style>
</head>
<body>
<div class="max-w-md mx-auto space-y-6">

  <!-- Header -->
  <div class="header-bar">
    <a href="/app/dashboard"><i class="bi bi-arrow-left-circle"></i></a>
    <div class="header-avatar">
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="User Avatar">
    </div>
  </div>

  <!-- USDT Wallet Card -->
  <div class="card" id="crypto-card">
    <?php if (empty($wallet) || empty($wallet->address)) : ?>
      <div class="text-center py-10">
        <i class="bi bi-wallet2 text-[var(--primary)] text-4xl mb-3"></i>
        <h2 class="font-bold text-lg mb-2">No USDT Wallet</h2>
        <p class="text-gray-600 text-sm mb-4">You don’t have a crypto wallet yet.</p>
        <button class="generate-btn" onclick="generateUSDT()">Generate USDT Wallet</button>
      </div>
    <?php else: ?>
      <div class="balance-box">
        <span>Receiver</span>
        <span><?= number_format($balance, 6) ?> USDT</span>
      </div>
      <div class="badge-info">Not your main wallet balance. It only tracks total received USDT deposits.</div>

      <div class="crypto-label mb-1 mt-5">Network</div>
      <div class="crypto-value mb-3"><?= esc_html($wallet->network) ?> 
        <span class="text-gray-500 text-sm">Type: TRON (TRC20)</span>
      </div>

      <div class="crypto-label mb-1">Wallet Address</div>
      <div class="flex items-center gap-2">
        <div class="crypto-value text-sm break-all"><?= esc_html($wallet->address) ?></div>
        <i class="bi bi-copy copy-icon" onclick="copyWallet('<?= esc_html($wallet->address) ?>')"></i>
      </div>

      <p class="text-sm text-gray-500 mt-4 leading-6">
        Use this address to receive USDT transfers.<br>
        Please ensure you are sending via the correct network (TRC20).
      </p>
    <?php endif; ?>
  </div>
</div>

<script>
function toast(msg){
  const el=document.createElement('div');
  el.textContent=msg;
  el.style.cssText='position:fixed;bottom:40px;left:50%;transform:translateX(-50%);background:var(--primary);color:#fff;padding:10px 18px;border-radius:8px;font-size:14px;z-index:9999;opacity:0;transition:.3s';
  document.body.appendChild(el);
  setTimeout(()=>{el.style.opacity=1;},50);
  setTimeout(()=>{el.style.opacity=0;el.remove();},3000);
}

// ✅ Copy wallet address
function copyWallet(addr){
  if (navigator.clipboard) {
    navigator.clipboard.writeText(addr).then(()=> toast('Wallet address copied!'));
  } else {
    const temp = document.createElement('textarea');
    temp.value = addr;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand('copy');
    document.body.removeChild(temp);
    toast('Wallet address copied!');
  }
}

// ✅ Generate USDT Wallet via AJAX
function generateUSDT(){
  const card = document.getElementById('crypto-card');
  card.innerHTML = `<div class='text-center py-10 text-gray-500'>
    <i class="bi bi-arrow-repeat animate-spin text-4xl text-[var(--primary)] mb-3"></i><br>
    Generating wallet address...
  </div>`;
  fetch('<?= admin_url('admin-ajax.php?action=pulsepoint_create_usdt') ?>', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: ''
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && data.wallet){
      card.innerHTML = `
        <div class='balance-box'>
          <span>Receiver Balance</span>
          <span>0.000000 USDT</span>
        </div>
        <div class='badge-info'>This is not your main wallet balance. It only tracks total received USDT deposits.</div>

        <div class='crypto-label mb-1 mt-5'>Network</div>
        <div class='crypto-value mb-3'>${data.wallet.network} 
          <span class='text-gray-500 text-sm'>Type: TRON (TRC20)</span>
        </div>

        <div class='crypto-label mb-1'>Wallet Address</div>
        <div class='flex items-center gap-2'>
          <div class='crypto-value text-sm break-all'>${data.wallet.address}</div>
          <i class='bi bi-copy copy-icon' onclick='copyWallet("${data.wallet.address}")'></i>
        </div>

        <p class='text-sm text-gray-500 mt-4 leading-6'>
          Use this address to receive USDT transfers.<br>
          Please ensure you are sending via the correct network (TRC20).
        </p>`;
      toast('USDT wallet created successfully!');
    } else {
      card.innerHTML = `<div class='text-center py-10'>
        <i class='bi bi-exclamation-circle text-[var(--primary)] text-4xl mb-3'></i>
        <h2 class='font-bold text-lg mb-2'>Failed to Create</h2>
        <p class='text-gray-600 text-sm mb-4'>${data.message || 'Could not create your wallet. Try again later.'}</p>
        <button class='generate-btn' onclick='generateUSDT()'>Try Again</button>
      </div>`;
    }
  })
  .catch(() => {
    card.innerHTML = `<div class='text-center py-10'>
      <i class='bi bi-exclamation-circle text-[var(--primary)] text-4xl mb-3'></i>
      <h2 class='font-bold text-lg mb-2'>Error</h2>
      <p class='text-gray-600 text-sm mb-4'>Unable to connect to server. Check your internet and try again.</p>
      <button class='generate-btn' onclick='generateUSDT()'>Try Again</button>
    </div>`;
  });
}
</script>
</body>
</html>