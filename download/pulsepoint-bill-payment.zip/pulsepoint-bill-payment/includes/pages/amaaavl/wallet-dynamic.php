<?php    
/**    
 * Fund Wallet Page - Dynamic Account (Pulsepoint Plugin)    
 * Auto Triggers Dynamic Account Creation    
 * Author: Amaaavl    
 */    
if (!defined('ABSPATH')) exit;    
    
global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
// Fetch settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0057ff';    
    
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
if (!$user_id) {    
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';    
    exit;    
}    
    
$table_users = $wpdb->prefix . 'pulsepoint_users';    
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));    
$firstname = $user ? esc_html($user->firstname) : 'User';    
?>  
<!doctype html>  
<html lang="en">    
<head>    
<meta charset="utf-8" />    
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />    
<title>Fund Wallet | <?= esc_html($platform_name) ?></title>    
<script src="https://cdn.tailwindcss.com"></script>    
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>    
<script src="https://unpkg.com/lucide@latest"></script>    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">    
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>    
<style>    
:root {    
  --app-bg: #f7f8fb;    
  --card-bg: #ffffff;    
  --muted: #6b7280;    
  --primary: <?= $color_hex ?>;    
}    
html, body, #app { min-height: 100%; background: var(--app-bg); }    
body { font-family: 'Inter', sans-serif; margin:0; padding:0; }    
.rounded-card{ border-radius: 14px; background: var(--card-bg); }    
.pay-btn { background: var(--primary); color: white; padding: 10px 22px; border-radius: 999px; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; min-width: 80px; }    
.pay-btn:hover{ filter: brightness(90%); }    
.card-inner { padding: 18px; }    
.amount-wrapper { display: flex; align-items: center; gap:6px; margin-top:6px; }    
.amount-wrapper span { font-weight: bold; font-size: 16px; }    
.amount-input { border: none; border-bottom: 2px solid #e5e7eb; padding: 6px 0; width: 100%; font-weight: 600; text-align: right; outline: none; font-size: 16px; }    
.amount-input:focus { border-bottom-color: var(--primary); }    
.fade-enter-active, .fade-leave-active { transition: all 0.3s ease; }    
.fade-enter-from, .fade-leave-to { opacity: 0; transform: translateY(-5px); }    
.copy-btn { display:flex; align-items:center; cursor:pointer; gap:4px; color: var(--primary); font-weight:600; }    
</style>    
</head>  
<body>    
<div id="app" class="px-4 max-w-md mx-auto mt-6">    

  <!-- HEADER -->    
  <div class="flex items-center justify-between mb-6 mt-2">    
    <div class="flex items-center gap-3">    
      <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">    
        <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>    
      </button>    
      <h2 class="text-xl font-bold text-gray-900">Checkout</h2>    
    </div>    
    <div class="flex items-center space-x-3 mt-1">    
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">    
        <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>    
      </button>    
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">    
        <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>    
      </button>    
    </div>    
  </div>    

  <!-- Amount Input -->    
  <div v-if="!account" class="mt-6 rounded-card p-4 border border-gray-200 shadow-sm card-inner">    
    <div class="mb-2 font-semibold text-sm text-[var(--primary)]">Enter Amount</div>    
    <div class="amount-wrapper">    
      <input type="number" v-model="amount" placeholder="0.00" class="amount-input" />    
      <span>NGN</span>    
    </div>    
    <button class="pay-btn mt-4 w-full" @click="generateDynamic">Generate Account</button>    
  </div>    

  <!-- Generated Account Info -->    
  <transition name="fade">  
  <div v-if="account" class="mt-4 rounded-card p-4 border border-gray-200 shadow-sm bg-gradient-to-r from-white to-gray-50">    
    <div class="flex justify-between items-center mb-3">  
      <h3 class="font-bold text-lg text-gray-800">Checkout</h3>  
      <span class="text-sm text-gray-500">{{ countdown }}</span>  
    </div>  

    <div class="grid grid-cols-2 gap-2 text-sm mb-2">  
      <div class="font-semibold text-gray-600">Account Name:</div>  
      <div class="font-bold text-gray-900">{{ account.accountName }}</div>  

      <div class="font-semibold text-gray-600">Account Number:</div>  
      <div class="font-bold text-gray-900">
        <span class="copy-btn" @click="copyAccount(account.accountNumber)">
          <i data-lucide="copy" class="w-4 h-4"></i> {{ account.accountNumber }}
        </span>
      </div>  

      <div class="font-semibold text-gray-600">Bank Name:</div>  
      <div class="font-bold text-gray-900">{{ account.bankName }}</div>  

      <div class="font-semibold text-gray-600">Amount:</div>  
      <div class="font-bold text-gray-900">{{ account.totalPayable | currency }}</div>  
    </div>  

    <button class="pay-btn mt-4 w-full bg-green-500 hover:bg-green-600" @click="checkPayment">Payment Sent</button>  
  </div>  
  </transition>  

</div>  

<script>    
const app = Vue.createApp({    
  data() {    
    return {    
      amount: null,    
      account: null,    
      countdown: '',    
      timer: null    
    }    
  },    
  methods: {    
    goBack() { window.history.back(); },    

    showToast(msg, type='success'){    
      Toastify({    
        text: msg,    
        duration: 3000,    
        close:true,    
        gravity:'top',    
        position:'center',    
        stopOnFocus:true,    
        style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }    
      }).showToast();    
    },    

    showLoading(){    
      const overlay=document.createElement('div');    
      overlay.id='loadingOverlay';    
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';    
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';    
      document.body.appendChild(overlay);    
    },    

    hideLoading(){ 
      const overlay=document.getElementById('loadingOverlay'); 
      if(overlay) overlay.remove(); 
    },

    copyAccount(number){
      navigator.clipboard.writeText(number).then(()=>{
        this.showToast("Account Number copied!", 'success');
      }).catch(()=>{
        this.showToast("Failed to copy", 'error');
      });
    },

    generateDynamic() {    
      if(!this.amount || this.amount <= 0) {    
        this.showToast("Enter a valid amount", 'error');    
        return;    
      }    

      const requestId = 'REQ-' + Date.now();    
      this.showLoading();

      fetch('<?= admin_url('admin-ajax.php?action=pulsepoint_dynamic_account') ?>', {    
        method:'POST',    
        headers:{'Content-Type':'application/x-www-form-urlencoded'},    
        body: new URLSearchParams({amount:this.amount, requestId})    
      })    
      .then(res=>res.json())    
      .then(data=>{    
        this.hideLoading();
        if(data.success && data.account){    
          // Use totalPayable as amount
          data.account.amount = data.account.totalPayable;
          this.account = data.account;    
          this.startCountdown(this.account.expiredMinutes || 30);    
        } else {    
          this.showToast(data.message || 'Failed to generate account', 'error');    
        }    
      })    
      .catch(()=>{    
        this.hideLoading();
        this.showToast("Unable to connect to server", 'error');    
      });    
    },    

    startCountdown(minutes){    
      let endTime = new Date().getTime() + minutes * 60 * 1000;    
      clearInterval(this.timer);    
      this.timer = setInterval(()=>{    
        let now = new Date().getTime();    
        let distance = endTime - now;    
        if(distance <= 0){    
          clearInterval(this.timer);    
          this.countdown = 'Expired';    
        } else {    
          let m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));    
          let s = Math.floor((distance % (1000 * 60)) / 1000);    
          this.countdown = m + "m " + s + "s";    
        }    
      }, 1000);    
    },    

    checkPayment(){    
      this.showLoading();
      fetch('<?= admin_url('admin-ajax.php?action=pulsepoint_check_payment') ?>', {    
        method:'POST',    
        headers:{'Content-Type':'application/x-www-form-urlencoded'},    
        body: new URLSearchParams({reference: this.account.requestId})    
      })    
      .then(res=>res.json())    
      .then(data=>{    
        this.hideLoading();
        if(data.success && data.status === 'success'){    
          this.showToast("Payment confirmed!", 'success');    
          this.account = null;    
          clearInterval(this.timer);    
        } else {    
          this.showToast("Payment not confirmed yet", 'error');    
        }    
      });    
    }    
  },    
  filters: {    
    currency(value){ return '₦' + parseFloat(value).toLocaleString(); }    
  }    
});    
app.mount('#app');    
</script>  
<script>lucide.createIcons();</script>  
</body>  
</html>