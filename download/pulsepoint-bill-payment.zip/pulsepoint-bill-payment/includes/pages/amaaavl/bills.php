<?php
/**
 * Services Page for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/services.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch platform settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// Logged-in user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users   = $wpdb->prefix . 'pulsepoint_users';

// Fetch user info
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname  = $user ? esc_html($user->firstname) : 'User';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Services | <?= $platform_name ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<style>
  :root {
    --primary: <?= $color_hex ?>;
    --bg: #f9f9f9;
  }
  body {
    font-family: "Inter", sans-serif;
    background: var(--bg);
    padding: 24px;
    min-height: 100vh;
  }
  .card {
    background: #fff;
    border-radius: 22px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.07);
    padding: 24px;
  }
  .header-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1.5rem;
  }
  .header-bar i {
    font-size: 22px;
    color: #000;
    cursor: pointer;
  }
  .header-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: var(--primary);
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }
  .header-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .service-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
  }
  .service-card {
    background: #fff;
    border-radius: 18px;
    padding: 22px 18px;
    text-align: center;
    box-shadow: 0 3px 8px rgba(0,0,0,0.06);
    transition: .25s ease;
    cursor: pointer;
  }
  .service-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 14px rgba(0,0,0,0.1);
  }
  .service-icon {
    width: 55px;
    height: 55px;
    border-radius: 50%;
    background: rgba(108,99,255,0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 12px;
    font-size: 26px;
    color: var(--primary);
  }
  .service-title {
    font-weight: 700;
    font-size: 15px;
    color: #222;
  }
</style>
</head>
<body>
<div class="max-w-md mx-auto space-y-6">

  <!-- Header -->
  <div class="header-bar">
    <a href="/app/dashboard"><i class="bi bi-arrow-left-circle"></i></a>
    <div class="header-avatar">
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="User Avatar">
    </div>
  </div>

  <!-- Greeting -->
  <div class="mb-4">
    <h2 class="text-xl font-extrabold text-gray-900 mb-1">Hello, <?= strtolower($firstname) ?>👋</h2>
    <p class="text-sm text-gray-500">What service would you like to use today?</p>
  </div>

  <!-- Services Grid -->
  <div class="service-grid">

    <!-- Data -->
    <div class="service-card" onclick="goService('data')">
      <div class="service-icon"><i class="bi bi-wifi"></i></div>
      <div class="service-title">Data</div>
    </div>

    <!-- Airtime -->
    <div class="service-card" onclick="goService('airtime')">
      <div class="service-icon"><i class="bi bi-phone"></i></div>
      <div class="service-title">Airtime</div>
    </div>

    <!-- Electricity -->
    <div class="service-card" onclick="goService('electricity')">
      <div class="service-icon"><i class="bi bi-lightning-charge"></i></div>
      <div class="service-title">Electricity</div>
    </div>

    <!-- Cable -->
    <div class="service-card" onclick="goService('cable')">
      <div class="service-icon"><i class="bi bi-tv"></i></div>
      <div class="service-title">Cable Tv</div>
    </div>

    <!-- Education -->
    <div class="service-card" onclick="goService('education')">
      <div class="service-icon"><i class="bi bi-book"></i></div>
      <div class="service-title">Education</div>
    </div>

  </div>
</div>

<script>
function goService(service) {
  // Redirect to the respective service page
  switch(service) {
    case 'data': window.location.href = '/app/data'; break;
    case 'airtime': window.location.href = '/app/airtime'; break;
    case 'electricity': window.location.href = '/app/electricity'; break;
    case 'cable': window.location.href = '/app/cable'; break;
    case 'education': window.location.href = '/app/education'; break;
  }
}
</script>
</body>
</html>