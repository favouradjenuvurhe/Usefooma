<?php
/**
 * Support Page - Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/support.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Detect device
function is_mobile_device() {
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);
}

$is_mobile = is_mobile_device();

// Load settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

// Defaults
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Support contacts
$phone_number = $settings['phone_number'] ?? '09064873505';
$email_number = $settings['email_number'] ?? 'favour-amaaavl@outlook.com';

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : "User";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>Support - <?php echo $platform_name; ?></title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>

<style>
body {
  background: #f7f8fb;
  font-family: 'Inter', sans-serif;
  margin: 0;
}
</style>
</head>
<body>

<div id="app" class="px-4 max-w-md mx-auto">    

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" class="w-6 h-6"/>
    <span class="font-semibold text-black">Support</span>
  </div>

  <div>
    <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg" class="w-5 h-5"/>
  </div>
</div>

<!-- SPACE FIX -->
<div class="mt-6"></div>
<!-- Airtime Service Box -->
<div class="mt-5">
  <h3 class="font-semibold text-gray-900 mb-3"> </h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
</div>

<!-- TITLE -->
<h2 class="text-black text-lg font-semibold mb-2">Talk to us</h2>

<!-- LIVE CHAT -->
<div class="flex items-center justify-between py-4 border-b border-gray-200 cursor-pointer">
  <div class="flex items-center gap-3">
    <img src="https://www.svgrepo.com/show/533249/message-circle-notification.svg" class="w-6 h-6" style="filter: hue-rotate(180deg);"/>
    <span class="text-black text-sm font-medium">Live Chat</span>
  </div>
  <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5"/>
</div>

<!-- PHONE -->
<div class="flex items-center justify-between py-4 border-b border-gray-200 cursor-pointer"
     onclick="window.location.href='tel:<?php echo $phone_number; ?>'">
  <div class="flex items-center gap-3">
    <img src="https://www.svgrepo.com/show/521544/call-receive.svg" class="w-6 h-6"/>
    <span class="text-black text-sm font-medium">Phone Number</span>
  </div>

  <div class="flex items-center gap-3">
    <span class="text-white text-xs px-4 py-1 rounded-full font-medium"
          style="background: <?php echo $color_hex; ?>">
      Call now
    </span>
    <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5"/>
  </div>
</div>

<!-- EMAIL -->
<div class="flex items-center justify-between py-4 border-b border-gray-200 cursor-pointer"
     onclick="window.location.href='mailto:<?php echo $email_number; ?>'">
  <div class="flex items-center gap-3">
    <img src="https://www.svgrepo.com/show/473944/email.svg" class="w-6 h-6"/>
    <span class="text-black text-sm font-medium">Email address</span>
  </div>

  <div class="flex items-center gap-3">
    <span class="text-white text-xs px-4 py-1 rounded-full font-medium"
          style="background: <?php echo $color_hex; ?>">
      Email us
    </span>
    <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5"/>
  </div>
</div>

<!-- WHATSAPP -->
<div class="flex items-center justify-between py-4 border-b border-gray-200 cursor-pointer"
     onclick="window.open('https://wa.me/<?php echo $phone_number; ?>', '_blank')">
  <div class="flex items-center gap-3">
    <img src="https://www.svgrepo.com/show/475692/whatsapp-color.svg" class="w-6 h-6"/>
    <span class="text-black text-sm font-medium">Whatsapp</span>
  </div>

  <div class="flex items-center gap-3">
    <span class="text-white text-xs px-4 py-1 rounded-full font-medium"
          style="background: <?php echo $color_hex; ?>">
      Reach out
    </span>
    <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5"/>
  </div>
</div>

<!-- TWITTER -->
<div class="flex items-center justify-between py-4 border-b border-gray-200 cursor-pointer">
  <span class="text-black text-sm font-medium">
    Contact us on Twitter (@username)
  </span>
  <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5"/>
</div>

<!-- INSTAGRAM -->
<div class="flex items-center justify-between py-4 cursor-pointer">
  <span class="text-black text-sm font-medium">
    Contact us on Instagram (@username)
  </span>
  <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5"/>
</div>

</div>

</body>
</html>