<?php
if (!defined('ABSPATH')) exit;

// Start session safely
if (!session_id()) {
    session_start();
}

// Destroy Pulsepoint session
unset($_SESSION['pulsepoint_user']);
session_destroy();

// OPTIONAL: Clear auth cookies if you set any
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Redirect immediately to login
wp_redirect(site_url('/app/login'));
exit;