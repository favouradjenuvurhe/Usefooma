<?php
/**
 * Airtime Purchase Page for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// ✅ Detect device type
function is_mobile_device() {
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);
}

$is_mobile = is_mobile_device();

// Fetch platform settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// Logged-in user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : 'User';
$wallet = $user ? number_format($user->wallet, 2) : '0.00';
$referral_balance = $user ? number_format($user->referral_balance, 2) : '0.00';
$passcode = $user ? $user->passcode : '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Convert Naira | <?= $platform_name ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<link rel="stylesheet" href="https://pulsepoint-plugin.vercel.app/style/airtime.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
</head>
<body>

<?php if ($is_mobile): ?>
<div class="w-full max-w-md mx-auto space-y-6">
    <!-- Mobile layout: your existing content -->
    <?php include __DIR__ . '/card/convert.php'; ?>
</div>

<?php else: ?>
<!-- Desktop: Sidebar left, Page right -->
<div class="flex min-h-screen">
    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-lg">
        <?php include __DIR__ . '/sidebar.php'; ?>
    </div>

    <!-- Main content -->
    <div class="flex-1 p-6 bg-gray-50">
        <?php include __DIR__ . '/card/convert.php'; ?>
    </div>
</div>
<?php endif; ?>

</body>
</html>