<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6A0DAD';
$favicon_url      = $settings['favicon_url'] ?? '';
$maintenance   = $settings['maintenance_mode'] ?? 0;

$token = sanitize_text_field($_GET['token'] ?? '');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title><?php echo esc_html($platform_name); ?> - Reset Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- Tailwind -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Vue -->
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

<!-- Toastify -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
body {
  background:#f9f9f9;
  font-family: Inter, system-ui, sans-serif;
}
.input-line {
  border-bottom: 1px solid rgba(0,0,0,.15);
}
.bg-purple-custom { background-color: <?php echo esc_attr($color_hex); ?> !important; }
.text-purple-custom { color: <?php echo esc_attr($color_hex); ?> !important; }
</style>
</head>

<body class="min-h-screen flex items-center justify-center">

<div id="app" class="w-full max-w-md px-6 py-10">

  <!-- LOGO -->
  <div class="flex items-center gap-2 mb-10">
    <?php if($favicon_url): ?>
      <img src="<?php echo esc_url($favicon_url); ?>" class="w-8 h-8 object-contain" />
    <?php else: ?>
      <svg width="26" height="26" viewBox="0 0 24 24" fill="<?php echo esc_attr($color_hex); ?>">
        <path d="M3 12L21 3l-9 18-2-7-7-2z"/>
      </svg>
    <?php endif; ?>
    <span class="font-semibold text-lg"><?php echo esc_html($platform_name); ?></span>
  </div>

  <!-- HEADER -->
  <h1 class="text-2xl font-semibold mb-1">Reset password</h1>
  <p class="text-sm text-gray-500 mb-10">
    Create a new password for your account
  </p>

  <?php if($maintenance == 1): ?>
    <div class="mb-6 p-3 bg-yellow-100 text-yellow-800 rounded text-sm">
      System is under maintenance. Please try again later.
    </div>
  <?php endif; ?>

  <!-- PASSWORD -->
  <div class="mb-8">
    <label class="text-xs text-gray-500">New password</label>
    <div class="input-line mt-2 pb-2">
      <input
        type="password"
        v-model="password"
        placeholder="••••••••"
        class="bg-transparent w-full outline-none text-sm"
      />
    </div>
  </div>

  <!-- CONFIRM PASSWORD -->
  <div class="mb-10">
    <label class="text-xs text-gray-500">Confirm password</label>
    <div class="input-line mt-2 pb-2">
      <input
        type="password"
        v-model="confirm_password"
        placeholder="••••••••"
        class="bg-transparent w-full outline-none text-sm"
      />
    </div>
  </div>

  <!-- RESET BUTTON -->
  <button
    @click="submit"
    :disabled="loading"
    class="w-full py-4 rounded-full bg-purple-custom text-white font-medium mb-6"
  >
    {{ loading ? 'Processing...' : 'Reset password' }}
  </button>

  <!-- BACK -->
  <div class="text-center text-sm text-gray-500">
    <span class="underline cursor-pointer" @click="goLogin">
      Back to login
    </span>
  </div>

</div>

<script>
const { createApp } = Vue;

function showToast(msg, type='success') {
  Toastify({
    text: msg,
    duration: 3000,
    gravity: "top",
    position: "center",
    style: {
      background: type === 'error' ? "#ff3860" : "#22c55e",
      color: "#fff",
      borderRadius: "12px"
    }
  }).showToast();
}

createApp({
  data() {
    return {
      password: '',
      confirm_password: '',
      token: '<?php echo esc_js($token); ?>',
      loading: false
    }
  },
  methods: {
    submit() {
      if (!this.password || !this.confirm_password) {
        showToast('All fields are required', 'error');
        return;
      }
      if (this.password !== this.confirm_password) {
        showToast('Passwords do not match', 'error');
        return;
      }

      this.loading = true;
      const formData = new FormData();
      formData.append('action', 'pulsepoint_reset_password');
      formData.append('token', this.token);
      formData.append('password', this.password);

      fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
      })
      .then(res => res.json())
      .then(res => {
        this.loading = false;
        if (res.success) {
          showToast(res.message);
          setTimeout(() => window.location.href = '/app/login', 1200);
        } else {
          showToast(res.message, 'error');
        }
      })
      .catch(() => {
        this.loading = false;
        showToast('Network error', 'error');
      });
    },
    goLogin() {
      window.location.href = '/app/login';
    }
  }
}).mount('#app');
</script>

<?php wp_footer(); ?>
</body>
</html>