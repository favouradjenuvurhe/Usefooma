<?php
/**
 * Pulsepoint Desktop Sidebar - Dynamic Services (Updated Style)
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

$core_enabled  = !(defined('PULSEPOINT_CORE') && PULSEPOINT_CORE);
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';

$base_prefix   = $wpdb->prefix . 'pulsepoint_';
$table_services = $base_prefix . 'services';

/* Fetch enabled services */
$services = $wpdb->get_results(
    "SELECT id, service_name FROM {$table_services} WHERE status = 1 ORDER BY id ASC"
);

/* Mapping same as All Services */
$service_map = [
    1  => ['icon' => 'phone', 'url' => '/app/airtime'],
    2  => ['icon' => 'signal', 'url' => '/app/data'],
    3  => ['icon' => 'lightbulb', 'url' => '/app/electricity'],
    4  => ['icon' => 'plane', 'url' => '/app/flights'],
    5  => ['icon' => 'wifi', 'url' => '/app/net'],
    6  => ['icon' => 'card-sim', 'url' => '/app/esim'],
    7  => ['icon' => 'gift', 'url' => '/app/giftcard'],
    8  => ['icon' => 'bus', 'url' => '/app/transport'],
    9  => ['icon' => 'send', 'url' => '/app/transfer'],
    10 => ['icon' => 'volleyball', 'url' => '/app/betting'],
    11 => ['icon' => 'tv', 'url' => '/app/cable'],
    12 => ['icon' => 'credit-card', 'url' => '/app/virtual-card'],
    13 => ['icon' => 'graduation-cap', 'url' => '/app/education'],
    14 => ['icon' => 'piggy-bank', 'url' => '/app/saving'],
    15 => ['icon' => 'ticket', 'url' => '/app/tickets'],
    16 => ['icon' => 'repeat', 'url' => '/app/currency'],
];
?>

<aside class="w-64 bg-white shadow-md p-6 flex flex-col gap-6 h-screen fixed left-0 top-0 overflow-y-auto">

    <!-- Logo -->
    <div class="flex items-center gap-3 mb-6">
        <img src="<?= site_url('/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png') ?>"
             alt="Logo" class="w-12 h-12 rounded-full object-cover" />
        <div>
            <p class="text-gray-400 text-sm">Welcome.</p>
            <p class="font-semibold text-lg"><?= esc_html($platform_name) ?></p>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="flex flex-col gap-1 flex-1">

        <!-- Dashboard Section -->
        <div class="text-gray-500 uppercase font-bold text-xs px-2 mt-2 mb-1">Dashboard</div>
        <a href="<?= site_url('/app/dashboard') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="home" class="w-5 h-5"></i> Home
        </a>

        <!-- Add Money Section -->
        <div class="text-gray-500 uppercase font-bold text-xs px-2 mt-4 mb-1">Add Money</div>
        <a href="<?= site_url('/app/fund') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="wallet" class="w-5 h-5"></i> Fund Wallet
        </a>
        <a href="<?= site_url('/app/receive') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="bitcoin" class="w-5 h-5"></i> Receive Crypto
        </a>

        <!-- Transfer Section -->
        <div class="text-gray-500 uppercase font-bold text-xs px-2 mt-4 mb-1">Transfer</div>
        <a href="<?= site_url('/app/users2') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="send" class="w-5 h-5"></i> To Wallet Users
        </a>
        <a href="<?= site_url('/app/transfer') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="landmark" class="w-5 h-5"></i> To Banking App
        </a>

        <!-- Services Section (Dynamic Styled) -->
        <div class="text-gray-500 uppercase font-bold text-xs px-2 mt-4 mb-1">Services</div>
        <?php if ($services): ?>
            <?php foreach ($services as $srv):
                $map = $service_map[$srv->id] ?? null;
                if (!$map) continue;
            ?>
                <a href="<?= site_url($map['url']) ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
                    <i data-lucide="<?= esc_attr($map['icon']) ?>" class="w-5 h-5"></i>
                    <?= esc_html($srv->service_name) ?>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Other Section -->
        <div class="text-gray-500 uppercase font-bold text-xs px-2 mt-4 mb-1">Other</div>
        <a href="<?= site_url('/app/transactions') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="circle-arrow-out-down-left" class="w-5 h-5"></i> Transactions
        </a>
        <a href="<?= site_url('/app/profile') ?>" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100">
            <i data-lucide="user" class="w-5 h-5"></i> Profile
        </a>

    </nav>

    <!-- Logout -->
    <div>
        <a href="<?= site_url('/app/logout') ?>" 
           class="flex items-center gap-3 p-2 rounded-lg text-red-600 hover:bg-red-50 mt-4">
            <i data-lucide="box-arrow-right" class="w-5 h-5"></i> Logout
        </a>
    </div>
</aside>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
document.addEventListener("DOMContentLoaded", function(){
    lucide.createIcons();
});
</script>

<style>
@media (max-width:768px){ aside{ display:none; } }
</style>