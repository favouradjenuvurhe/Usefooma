<?php  
/**  
 * Currency Dashboard for Pulsepoint Plugin  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/Currency.php  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// Fetch all settings  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  
  
// Fetch USD rate from settings or use default  
$usd_rate = isset($settings['rate_usd']) && is_numeric($settings['rate_usd']) ? floatval($settings['rate_usd']) : 1560; // Current rate per 1$  
  
function is_mobile_device() {  
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');  
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);  
}  
  
$is_mobile = is_mobile_device();  
  
// Defaults  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#000';  
$firstname     = 'User';  
$user_id       = $_SESSION['pulsepoint_user']['id'] ?? 0;  
  
$table_users = $wpdb->prefix . 'pulsepoint_users';  
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));  
  
$wallet_balance = $user ? number_format($user->wallet, 2) : '0.00';  
$dollar_balance = $user ? number_format($user->dollar, 2) : '0.00';  
$firstname      = $user ? esc_html($user->firstname) : 'User';  
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Currency Dashboard | <?= $platform_name ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <style>
    :root { --bg-white:#f9f9f9; --primary-color:<?= $color_hex ?>; }
    body { font-family:"Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; background:var(--bg-white); min-height:100vh; padding:20px; }
    .inner { display:flex; flex-direction:column; gap:18px; }
    .balance-card { transform:rotate(-1.6deg); width:calc(100%+20px); margin-left:-10px; position:relative; }
    .balance-card::after { content:""; position:absolute; width:86%; height:84px; right:22px; top:120px; background:<?= $color_hex ?>11; border-radius:16px; transform:rotate(-1.6deg); z-index:0; }
    .avatar { width:36px; height:36px; border-radius:50%; overflow:hidden; border:2px solid #fff; cursor:pointer; }
    .bottom-nav { position:fixed; left:0; right:0; bottom:0; background:var(--bg-white); border-radius:18px 18px 0 0; padding:12px 18px; display:flex; justify-content:space-around; align-items:center; gap:14px; }
    .action-pill { width:88px; height:88px; background:#fff; border-radius:18px; display:flex; align-items:center; justify-content:center; flex-direction:column; gap:8px; cursor:pointer; }
    .action-label { font-size:13px; color:<?= $color_hex ?>; }
    .available-label { font-size:13px; color:#fff; opacity:.95; }
    .big-amount { font-weight:800; font-size:44px; line-height:1; color:#fff; }
    .fund-btn, .convert-btn { background:#000; color:#fff; font-weight:600; padding:8px 18px; border-radius:8px; cursor:pointer; border:none; display:inline-block; text-align:center; margin-top:6px; }
    .section-title { font-weight:700; color:<?= $color_hex ?>; }
    .icon-bi { font-size:1.4rem; color:<?= $color_hex ?>; }

    /* Desktop Main */
    .main { margin-left:260px; padding:30px; flex:1; }
    .desktop-balance-card { background:<?= $color_hex ?>; border-radius:20px; padding:24px; color:#fff; box-shadow:0 8px 16px <?= $color_hex ?>33; margin-bottom:30px; }
    .desktop-big-amount { font-size:40px; font-weight:800; }
    .desktop-action-pill { width:140px; height:140px; background:#fff; border-radius:18px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; box-shadow:0 2px 6px rgba(0,0,0,0.06); transition:all .2s ease; }
    .desktop-action-pill:hover { transform:translateY(-3px); box-shadow:0 4px 10px rgba(0,0,0,0.1); }
    .desktop-action-label { font-size:15px; color:<?= $color_hex ?>; margin-top:6px; }
    @media (max-width:768px){ .main{margin-left:0;padding:16px;} .action-pill{width:88px;height:88px;} }
  </style>
</head>
<body>

<?php if ($is_mobile): ?>
<div id="app" class="inner relative max-w-md mx-auto pb-24">
  <!-- Header -->
  <div class="flex items-center justify-between z-10">
    <div class="flex items-center gap-3">
      <a href="/app/profile" class="avatar">
        <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="avatar" class="w-full h-full object-cover"/>
      </a>
      <div>
        <div class="text-sm text-gray-400">Hello,</div>
        <div class="text-lg font-semibold -mt-1"><?= strtolower($firstname) ?></div>
      </div>
    </div>
    <a href="#" class="rounded-full p-2"><i class="bi bi-bell icon-bi"></i></a>
  </div>

  <!-- Balance Card -->
  <div class="relative z-10">
    <div class="relative balance-card">
      <div class="rounded-2xl p-6" style="background: <?= $color_hex ?>; border-radius:22px;">
        <div class="available-label">Dollar Balance</div>
        <div class="big-amount mt-2">$<?= $dollar_balance ?></div>
        <div class="available-label mt-3">Dollar Rate</div>
        <div class="big-amount mt-1">(Rate: <?= $usd_rate ?>)</div>
        <button class="convert-btn" onclick="window.location.href='/app/convert1'">Convert</button>
      </div>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="mt-4 z-10"><div class="section-title text-center">Quick Actions</div></div>
  <div class="flex items-center justify-around mt-2 z-10">
    <a href="/app/virtual-card" class="action-pill"><i class="bi bi-credit-card icon-bi"></i><div class="action-label">Virtual Cards</div></a>
    <a href="/app/sell-dollar" class="action-pill"><i class="bi bi-currency-dollar icon-bi"></i><div class="action-label">Sell Dollar</div></a>
  </div>

  <!-- Footer -->
  <div class="bottom-nav z-20">
    <a href="/app/dashboard" class="rounded-xl p-3 bg-white text-center"><i class="bi bi-house icon-bi"></i><div class="text-xs mt-1">Home</div></a>
    <a href="/app/convert1" class="rounded-xl p-3 bg-white text-center"><i class="bi bi-wallet2 icon-bi"></i><div class="text-xs mt-1">Convert</div></a>
    <a href="/app/transactions" class="rounded-xl p-3 bg-white text-center"><i class="bi bi-list-task icon-bi"></i><div class="text-xs mt-1">History</div></a>
    <a href="/app/profile" class="rounded-xl p-3 bg-white text-center"><i class="bi bi-person icon-bi"></i><div class="text-xs mt-1">Profile</div></a>
  </div>
</div>

<?php else: ?>
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="main">
  <div class="flex justify-between items-center mb-8">
    <div>
      <div class="text-gray-400 text-sm">Welcome back,</div>
      <div class="text-2xl font-bold"><?= strtolower($firstname) ?></div>
    </div>
    <button class="p-3 bg-white rounded-full shadow-md hover:bg-gray-100"><i class="bi bi-bell icon-bi"></i></button>
  </div>

  <!-- Balance Card -->
  <div class="desktop-balance-card">
    <div class="text-sm opacity-90">Wallet Balance</div>
    <div class="desktop-big-amount mt-2">₦<?= $wallet_balance ?></div>
    <div class="text-sm opacity-90 mt-3">Dollar Balance</div>
    <div class="desktop-big-amount mt-1">$<?= $dollar_balance ?> (Rate: <?= $usd_rate ?>)</div>
    <button class="convert-btn" onclick="window.location.href='/app/convert1'">Convert</button>
  </div>

  <!-- Quick Actions -->
  <h2 class="font-bold text-lg text-<?= $color_hex ?> mb-4">Quick Actions</h2>
  <div class="grid grid-cols-2 gap-6 mb-10">
    <a href="/app/virtual-card" class="desktop-action-pill"><i class="bi bi-credit-card icon-bi"></i><div class="desktop-action-label">Virtual Cards</div></a>
    <a href="/app/sell-dollar" class="desktop-action-pill"><i class="bi bi-currency-dollar icon-bi"></i><div class="desktop-action-label">Sell Dollar</div></a>
  </div>
</div>
<?php endif; ?>
</body>
</html>