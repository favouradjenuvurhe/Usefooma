<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6A0DAD';
$logo_url      = $settings['logo_url'] ?? '';
$maintenance   = $settings['maintenance_mode'] ?? 0;

// START SESSION SAFELY
if (!session_id()) { session_start(); }

// Protect route
if (empty($_SESSION['pulsepoint_user']['id'])) {
    wp_redirect(site_url('/app/login'));
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title><?php echo esc_html($platform_name); ?> - Verify Email</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- Tailwind -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Vue -->
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

<!-- Toastify -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
body {
  background:#f9f9f9;
  font-family: Inter, system-ui, sans-serif;
}
.otp-input {
  letter-spacing: 10px;
  font-size: 1.5rem;
  text-align: center;
}
.input-line {
  border-bottom: 1px solid rgba(0,0,0,.15);
}
.bg-purple-custom { background-color: <?php echo esc_attr($color_hex); ?> !important; }
.text-purple-custom { color: <?php echo esc_attr($color_hex); ?> !important; }
</style>
</head>

<body class="min-h-screen flex items-center justify-center">

<div id="app" class="w-full max-w-md px-6 py-10">

  <!-- LOGO -->
  <div class="flex items-center gap-2 mb-10">
    <?php if($logo_url): ?>
      <img src="<?php echo esc_url($logo_url); ?>" class="w-8 h-8 object-contain" />
    <?php else: ?>
      <svg width="26" height="26" viewBox="0 0 24 24" fill="<?php echo esc_attr($color_hex); ?>">
        <path d="M3 12L21 3l-9 18-2-7-7-2z"/>
      </svg>
    <?php endif; ?>
    <span class="font-semibold text-lg"><?php echo esc_html($platform_name); ?></span>
  </div>

  <!-- HEADER -->
  <h1 class="text-2xl font-semibold mb-1">Verify your email</h1>
  <p class="text-sm text-gray-500 mb-10">
    Enter the 6-digit code sent to your email
  </p>

  <?php if($maintenance == 1): ?>
    <div class="mb-6 p-3 bg-yellow-100 text-yellow-800 rounded text-sm">
      System is under maintenance. Please try again later.
    </div>
  <?php endif; ?>

  <!-- OTP INPUT -->
  <div class="mb-10">
    <label class="text-xs text-gray-500">Verification code</label>
    <div class="input-line mt-3 pb-2">
      <input
        type="text"
        maxlength="6"
        v-model="code"
        @input="code = code.replace(/[^0-9]/g,'')"
        placeholder="••••••"
        class="otp-input bg-transparent w-full outline-none"
      />
    </div>
  </div>

  <!-- VERIFY BUTTON -->
  <button
    @click="verify"
    :disabled="loading"
    class="w-full py-4 rounded-full bg-purple-custom text-white font-medium mb-6"
  >
    {{ loading ? 'Verifying...' : 'Verify account' }}
  </button>

  <!-- RESEND -->
  <button
    @click="resendOtp"
    :disabled="resendDisabled"
    class="w-full text-sm text-gray-500 underline disabled:opacity-60"
  >
    {{ resendText }}
  </button>

</div>

<script>
const { createApp } = Vue;

function showToast(msg, type='success') {
  Toastify({
    text: msg,
    duration: 3000,
    gravity: "top",
    position: "center",
    style: {
      background: type === 'error' ? "#ff3860" : "#22c55e",
      color: "#fff",
      borderRadius: "12px"
    }
  }).showToast();
}

createApp({
  data() {
    return {
      code: '',
      loading: false,
      resendDisabled: false,
      resendText: 'Resend code',
      countdown: 30
    }
  },
  methods: {
    verify() {
      if (this.code.length !== 6) {
        showToast('Enter a valid 6-digit code', 'error');
        return;
      }

      this.loading = true;
      const fd = new FormData();
      fd.append('action', 'pulsepoint_email_verify');
      fd.append('code', this.code);

      fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      })
      .then(r => r.json())
      .then(r => {
        this.loading = false;
        if (r.success) {
          showToast(r.message);
          setTimeout(() => window.location.href = r.redirect, 800);
        } else {
          showToast(r.message, 'error');
        }
      })
      .catch(() => {
        this.loading = false;
        showToast('Network error', 'error');
      });
    },
    resendOtp() {
      if (this.resendDisabled) return;

      this.resendDisabled = true;
      this.resendText = 'Resending...';

      const fd = new FormData();
      fd.append('action', 'pulsepoint_resend_otp');

      fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      })
      .then(r => r.json())
      .then(r => {
        if (r.success) {
          showToast(r.message);
          this.startCountdown();
        } else {
          showToast(r.message, 'error');
          this.resendDisabled = false;
          this.resendText = 'Resend code';
        }
      })
      .catch(() => {
        showToast('Network error', 'error');
        this.resendDisabled = false;
        this.resendText = 'Resend code';
      });
    },
    startCountdown() {
      let sec = this.countdown;
      this.resendText = `Resend in ${sec}s`;
      const timer = setInterval(() => {
        sec--;
        if (sec <= 0) {
          clearInterval(timer);
          this.resendDisabled = false;
          this.resendText = 'Resend code';
        } else {
          this.resendText = `Resend in ${sec}s`;
        }
      }, 1000);
    }
  }
}).mount('#app');
</script>

<?php wp_footer(); ?>
</body>
</html>