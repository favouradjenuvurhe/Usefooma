<?php  
/**
 * View Giftcard Transaction Page for Pulsepoint Plugin - Updated UI
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex = $settings['color_hex'] ?? '#6C63FF';

// Logged-in User
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_giftcard_txn = $base_prefix . 'giftcard_transactions';
$table_users = $base_prefix . 'users';

// Fetch the last pending or completed giftcard transaction
$txn = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_giftcard_txn} 
     WHERE user_id = %d AND status IN ('pending','completed') 
     ORDER BY created_at DESC LIMIT 1",
    $user_id
));

if (!$txn) wp_die('<h2 style="font-family:Inter;text-align:center;margin-top:60px;">No gift card transaction found.</h2>');

// Recipient
$recipient_user = $wpdb->get_row($wpdb->prepare(
    "SELECT firstname, lastname FROM {$table_users} WHERE id = %d",
    $txn->user_id
));
$recipient_name = $recipient_user ? $recipient_user->firstname . ' ' . $recipient_user->lastname : 'N/A';

?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc_html($platform_name) ?> - Giftcard Transaction</title>

<!-- Tailwind & Vue -->
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
:root {
    --primary: <?= $color_hex ?>;
    --bg: #f7f8fb;
    --card: #f8f9fa;
    --muted: #6b7280;
}
body { font-family:'Inter',sans-serif; background: var(--bg); color:#111827; padding:18px; }
.muted { color: var(--muted); font-weight:500; }
.thin-line { height:1px; background: rgba(0,0,0,0.06); margin:18px 0; }
.copy-btn { width:44px; height:34px; border-radius:8px; display:flex; align-items:center; justify-content:center; background:linear-gradient(180deg, rgba(76,217,100,0.12), rgba(76,217,100,0.06)); }
.action-row:hover { background: rgba(0,0,0,0.03); }
.timeline-line { width:2px; background:rgba(0,0,0,0.1); left:18px; top:0; bottom:0; position:absolute; border-radius:4px; }
.timeline-icon { width:40px; height:40px; display:flex; align-items:center; justify-content:center; border-radius:9999px; background:white; font-size:1.4rem; color: <?= $color_hex ?>; font-weight:bold; }
.timestamp { font-size:0.75rem; color:#6b7280; }
</style>
</head>
<body>
<div id="app">

<!-- Header -->
<div class="flex items-center justify-between mb-6">
    <div class="flex items-center gap-3">
        <button @click="goBack" class="p-1 rounded-full bg-gray-100">
            <i class="bi bi-arrow-left-circle" style="font-size:1.2rem;color:<?= $color_hex ?>;"></i>
        </button>
        <div class="text-gray-900 text-lg font-semibold">Giftcard Sales</div>
    </div>
    <button @click="doShare" class="share-btn text-white px-4 py-2 rounded-md text-sm font-semibold shadow-lg flex items-center gap-2" :style="{background:'linear-gradient(180deg,'+primaryColor+','+primaryColor+')'}">
        <span>Share</span>
    </button>
</div>

<!-- Timeline -->
<div class="relative pl-12">
    <div class="timeline-line"></div>
    <div class="space-y-6 relative z-10">

        <!-- Initiated -->
        <div class="flex items-start gap-4 relative">
            <div class="timeline-icon">
                <i class="bi bi-clock-fill"></i>
            </div>
            <div class="flex-1">
                <div class="flex items-center justify-between">
                    <div class="font-semibold text-gray-900">Initiated</div>
                    <div class="timestamp"><?= date("M j, Y · g:i A", strtotime($txn->created_at)) ?></div>
                </div>
                <div class="muted mt-1">Giftcard Sent, In 20 mins</div>
            </div>
        </div>

        <!-- Sent / Processing -->
        <div class="flex items-start gap-4 relative">
            <div class="timeline-icon">
                <i class="bi bi-send-fill"></i>
            </div>
            <div class="flex-1">
                <div class="flex items-center justify-between">
                    <div class="font-semibold text-gray-900"><?= ucfirst($txn->status) === 'Completed' ? 'Completed' : 'On Hold' ?></div>
                    <div class="timestamp"><?= date("M j, Y · g:i A", strtotime($txn->created_at)) ?></div>
                </div>
                <div class="muted mt-1"><?= $txn->status === 'completed' ? 'Trader Completed' : 'Kindly Hold On' ?></div>
            </div>
        </div>

    </div>
</div>

<div class="thin-line"></div>

<!-- Details -->
<div class="space-y-4">
    <div class="text-sm muted">To</div>
    <div class="text-lg font-semibold text-gray-900"><?= esc_html($recipient_name) ?></div>
    <div class="thin-line"></div>

    <div>
        <div class="text-sm muted">Description / Note</div>
        <div class="text-base mt-2"><?= nl2br(esc_html($txn->note ?? 'Giftcard Purchase')) ?></div>
    </div>
    <div class="thin-line"></div>

    <div class="flex items-center justify-between">
        <div>
            <div class="text-sm muted">Payment Method</div>
            <div class="text-base font-semibold mt-1"><?= esc_html($txn->payment_method) ?></div>
        </div>
        <div class="text-right">
            <div class="text-sm muted">Amount</div>
            <div class="text-base font-semibold mt-1">
                <?= number_format($txn->selling_price, 2) ?>
            </div>
        </div>
    </div>

    <!-- Transaction Reference -->
    <div class="thin-line"></div>
    <div>
        <div class="text-sm muted">Transaction Reference</div>
        <div class="flex items-center justify-between mt-2">
            <div class="break-all font-bold text-[14px]"><?= esc_html($txn->reference ?? 'N/A') ?></div>
            <button @click="copy('<?= esc_js($txn->reference ?? '') ?>')" class="copy-btn">
                <i class="bi bi-copy"></i>
            </button>
        </div>
    </div>
</div>

<div class="thin-line"></div>

<!-- More Actions -->
<div class="text-lg font-semibold mb-3">More Actions</div>
<div class="space-y-2">
    <div class="rounded-md p-3 flex items-center justify-between action-row bg-gray-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center">
                <i class="bi bi-arrow-repeat text-<?= $color_hex ?> text-lg font-bold"></i>
            </div>
            <div>
                <div class="font-semibold text-gray-900">Repeat Transaction</div>
                <div class="muted text-sm">Make this payment again now.</div>
            </div>
        </div>
        <i class="bi bi-chevron-right text-gray-500"></i>
    </div>

    <div class="rounded-md p-3 flex items-center justify-between action-row bg-gray-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center">
                <i class="bi bi-exclamation-triangle-fill text-red-500 text-lg font-bold"></i>
            </div>
            <div>
                <div class="font-semibold text-gray-900">Report Transaction</div>
                <div class="muted text-sm">Report an issue with this payment.</div>
            </div>
        </div>
        <i class="bi bi-chevron-right text-gray-500"></i>
    </div>
</div>

</div>

<script>
const { createApp } = Vue;

createApp({
    data(){ return { primaryColor: "<?= $color_hex ?>" } },
    methods:{
        goBack(){ history.back(); },
        copy(text){ navigator.clipboard?.writeText(text); this.notify("Copied"); },
        doShare(){
            html2canvas(document.body).then(canvas=>{
                const link = document.createElement("a");
                link.download = "giftcard-transaction.png";
                link.href = canvas.toDataURL("image/png");
                link.click();
            });
        },
        notify(msg){
            const t=document.createElement("div");
            t.textContent=msg;
            Object.assign(t.style,{
                position:"fixed", left:"50%", transform:"translateX(-50%)",
                bottom:"28px", background:"rgba(0,0,0,0.7)", color:"#fff",
                padding:"8px 14px", borderRadius:"12px", fontSize:"13px", zIndex:9999
            });
            document.body.appendChild(t);
            setTimeout(()=>t.remove(),1500);
        }
    }
}).mount("#app");
</script>
</body>
</html>