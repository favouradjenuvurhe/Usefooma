<?php
/**
 * Pulsepoint Sell Giftcard Page - Vue 3 + Tailwind UI (No PIN)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/sell-giftcard.php
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session
if (!session_id()) session_start();

// Validate user session
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner slides
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

// Fetch giftcards
$giftcards = $wpdb->get_results("SELECT * FROM {$base_prefix}giftcard_settings WHERE status='active' ORDER BY category ASC, sub_category ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Sell Giftcard | <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root{
  --app-bg:#f7f8fb;
  --card-bg:#ffffff;
  --muted:#6b7280;
  --primary:<?= $color_hex ?>;
}
html,body,#app{min-height:100%;background:var(--app-bg);}
body{font-family:'Inter',sans-serif;margin:0;padding:0;}
.rounded-card{border-radius:14px;background:var(--card-bg);}
.topup-btn{border-radius:12px;border:1.5px solid rgba(99,102,241,0.08);padding:14px 18px;font-weight:600;}
.topup-btn.selected{background:var(--primary);color:#fff;border-color:var(--primary);}
.giftcard-scroll{display:flex;overflow-x:auto;gap:10px;padding:8px 0;}
.giftcard-card img{width:60px;height:60px;border-radius:50%;border:2px solid transparent;object-fit:cover;}
.giftcard-card.selected img{border-color:var(--primary);}
.amount-input{border:none;border-bottom:2px solid #e5e7eb;width:100%;font-weight:600;text-align:right;}
.pay-btn{background:var(--primary);color:#fff;padding:10px 22px;border-radius:999px;font-weight:600;}
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Sell Giftcard</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- Scrollable Banner -->    <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2 mt-4">        
    <?php foreach($banner_slides as $slide): ?>        
      <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">        
        <img src="<?= esc_url($slide) ?>" class="w-full h-full object-cover rounded-lg shadow-md">        
      </div>        
    <?php endforeach; ?>        
  </div>  

<!-- TYPE SELECTION -->
<div class="mt-4 flex gap-4">
  <button @click="selectedType='physical'"
          :class="{'bg-[var(--primary)] text-white': selectedType==='physical','bg-white text-black': selectedType!=='physical'}"
          class="flex-1 py-3 rounded-xl border border-gray-200 font-semibold">
    Physical
  </button>
  <button @click="selectedType='digital'"
          :class="{'bg-[var(--primary)] text-white': selectedType==='digital','bg-white text-black': selectedType!=='digital'}"
          class="flex-1 py-3 rounded-xl border border-gray-200 font-semibold">
    Digital
  </button>
</div>

<!-- SEARCH -->
<div class="mt-4">
  <label class="font-semibold text-black">Search Giftcards</label>
  <input v-model="searchQuery" placeholder="Search by category..." class="w-full mt-1 border rounded-lg p-2 text-gray-500"/>
</div>

<!-- NETWORKS / CATEGORIES -->
<div class="mt-4 overflow-x-auto whitespace-nowrap scrollbar-hide flex gap-3">
  <div v-for="cat in filteredGiftcards" :key="cat.category" 
       @click="selectGiftcard(cat)"
       :class="['p-3 rounded-lg border min-w-[90px] text-center cursor-pointer flex flex-col items-center justify-center',
                selectedCategory===cat.category ? 'border-[var(--primary)] bg-white' : 'border-gray-200']">
    <img :src="cat.image" class="w-10 h-10 object-contain mb-1">
    <span class="text-xs font-semibold">{{ cat.category }}</span>
  </div>
</div>

<!-- SUBCATEGORIES -->
<div v-if="subcategories.length" class="mt-3 overflow-x-auto whitespace-nowrap scrollbar-hide flex gap-3">
  <div v-for="sub in subcategories" :key="sub.sub"
       @click="selectSubCategory(sub.sub)"
       :class="['px-3 py-2 rounded-lg border cursor-pointer',
                selectedSubCategory===sub.sub ? 'bg-[var(--primary)] text-white border-[var(--primary)]' : 'border-gray-200 text-black']">
    {{ sub.sub }}
  </div>
</div>

<!-- AMOUNT INPUT -->
<div class="mt-4">
  <div class="text-black font-medium mb-2">Card Value ($)</div>
  <input type="number" v-model.number="amount" placeholder="Enter card amount" 
         class="w-full border rounded-lg p-2 text-gray-700"/>
</div>

<!-- CONDITIONAL INPUT: IMAGE OR NOTE -->
<div class="mt-4">

  <!-- IMAGE UPLOAD UI -->
<div v-if="selectedType==='physical'">
  
  <div class="text-black font-medium mb-3">Upload Card Image</div>

  <div class="border-2 border-dashed border-gray-200 rounded-2xl p-6 text-center bg-white">
    
    <!-- ICON -->
    <div class="flex justify-center mb-4">
      <div class="bg-[var(--primary)]/10 p-3 rounded-xl">
        <i data-lucide="image" class="w-6 h-6 text-[var(--primary)]"></i>
      </div>
    </div>

    <!-- TEXT -->
    <div class="text-[var(--primary)] text-lg font-medium mb-1">
      Click to upload image
    </div>

    <!-- STATUS -->
    <div v-if="physical_file" class="text-green-600 text-sm mb-3 font-medium">
      ✔ Image selected: {{ physical_file.name }}
    </div>

    <div v-else class="text-gray-500 text-sm mb-5">
      You can upload an image.
    </div>

    <!-- ✅ SAFE PREVIEW -->
    <div v-if="preview" class="mb-4">
      <img 
        :src="preview" 
        class="w-32 h-32 object-cover rounded-xl mx-auto border"
      />
    </div>

    <!-- BUTTON -->
    <label class="block cursor-pointer">
      <input type="file" accept="image/*" @change="handlePhysicalUpload" class="hidden"/>
      <div class="bg-[var(--primary)] text-white font-medium py-3 rounded-full">
        {{ physical_file ? 'Change Image' : 'Upload Image' }}
      </div>
    </label>

  </div>

</div>

  <!-- NOTE INPUT UI -->
  <div v-else>
    
    <div class="text-black font-medium mb-3">
      Add Comment <span class="text-gray-400 font-normal">(Optional)</span>
    </div>

    <textarea 
      v-model="digital_code" 
      placeholder="e.g You can enter ecode here"
      class="w-full bg-white border border-gray-200 rounded-2xl p-4 text-black placeholder-gray-400 focus:outline-none focus:border-[var(--primary)]"
      rows="5"
    ></textarea>

  </div>

</div>

<!-- PAYOUT INFO -->
<div class="muted mt-3 mb-4" v-html="calcInfo"></div>

<!-- SUBMIT BUTTON -->
<button class="mt-5 w-full py-3 rounded-xl text-white font-semibold" :style="{background:'var(--primary)'}"
        @click="submitGiftcard">
  Sell Giftcard
</button>

<div class="thin-hr mt-5"></div>
</div>
  

  </div>
  <!-- Airtime Service Box -->
<div class="mt-5">
  <h3 class="font-semibold text-gray-900 mb-3"> </h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
</div>
</div>

<script>
const { createApp } = Vue;

createApp({
data(){
return{
selectedType:'',
searchQuery:'',
selectedCategory:'',
selectedSubCategory:'',
amount:null,
digital_code:'',

physical_file:null,
preview:null, // ✅ NEW

giftcards:[
<?php foreach($giftcards as $g): ?>
{
id:<?= $g->id ?>,
category:"<?= esc_js($g->category) ?>",
sub:"<?= esc_js($g->sub_category) ?>",
rate:<?= $g->rate ?>,
type:"<?= $g->type ?>",
image:"<?= esc_url($g->image_url) ?>"
},
<?php endforeach; ?>
]
}
},

computed:{
filteredGiftcards(){
const map={};
this.giftcards
.filter(g=>this.selectedType?g.type===this.selectedType:true)
.filter(g=>g.category.toLowerCase().includes(this.searchQuery.toLowerCase()))
.forEach(g=>{
if(!map[g.category]) map[g.category]={category:g.category,image:g.image};
});
return Object.values(map);
},

subcategories(){
return this.giftcards
.filter(g=>g.category===this.selectedCategory && g.type===this.selectedType)
.map(g=>({sub:g.sub,image:g.image}));
},

calcInfo(){
if(!this.selectedSubCategory||!this.amount) return "Select card and amount to see payout.";
const g=this.giftcards.find(x=>x.category===this.selectedCategory&&x.sub===this.selectedSubCategory);
return `You'll receive approximately <strong>₦${(g.rate*this.amount).toFixed(2)}</strong>.`;
}
},

methods:{
goBack(){history.back();},

selectType(t){
this.selectedType=t;
this.selectedCategory='';
this.selectedSubCategory='';
this.digital_code='';

// ✅ CLEANUP FIX
if(this.preview){
URL.revokeObjectURL(this.preview);
}

this.physical_file=null;
this.preview=null;
},

selectGiftcard(cat){
this.selectedCategory=cat.category;
this.selectedSubCategory='';
},

selectSubCategory(s){
this.selectedSubCategory=s;
},

/* ✅ FIXED UPLOAD (MAIN FIX) */
handlePhysicalUpload(e){
const file = e.target.files[0];

if(!file) return;

// only allow images
if(!file.type.startsWith('image/')){
this.showToast('Only image files allowed','error');
return;
}

// cleanup old preview
if(this.preview){
URL.revokeObjectURL(this.preview);
}

this.physical_file = file;
this.preview = URL.createObjectURL(file);
},

showToast(msg,type='info'){
Toastify({
text:msg,
duration:3000,
close:true,
gravity:'top',
position:'center',
style:{
background:type==='error'?'#ff3860':'green',
color:'#fff',
borderRadius:'12px'
}
}).showToast();
},

showLoading(){
const overlay=document.createElement('div');
overlay.id='loadingOverlay';
overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
document.body.appendChild(overlay);
},

hideLoading(){
const overlay=document.getElementById('loadingOverlay');
if(overlay) overlay.remove();
},

async submitGiftcard(){

if(!this.selectedType){ this.showToast('Select card type','error'); return; }
if(!this.selectedCategory){ this.showToast('Select a giftcard','error'); return; }
if(!this.selectedSubCategory){ this.showToast('Select a sub-category','error'); return; }
if(!this.amount || this.amount<=0){ this.showToast('Enter valid amount','error'); return; }

if(this.selectedType==='digital' && !this.digital_code){
this.showToast('Enter the digital code','error'); return;
}

if(this.selectedType==='physical' && !this.physical_file){
this.showToast('Upload the physical card image','error'); return;
}

const gift = this.giftcards.find(g =>
g.category===this.selectedCategory &&
g.sub===this.selectedSubCategory &&
g.type===this.selectedType
);

if(!gift){
this.showToast('Invalid giftcard selection','error');
return;
}

const fd = new FormData();
fd.append('action','pulsepoint_sell_giftcard');
fd.append('giftcard_id', gift.id);
fd.append('sub_category', this.selectedSubCategory);
fd.append('type', this.selectedType);
fd.append('amount', this.amount);

if(this.selectedType==='digital') fd.append('digital_code',this.digital_code);
if(this.selectedType==='physical') fd.append('physical_image',this.physical_file);

try{
this.showLoading();

const res = await fetch("<?= admin_url('admin-ajax.php') ?>",{
method:'POST',
body:fd
});

const data = await res.json();
this.hideLoading();

if(data.success){
this.showToast(data.message||'Giftcard submitted successfully','success');
setTimeout(()=>window.location.href='/app/view-giftcard/',2000);
}else{
this.showToast(data.message||'Submission failed','error');
}

}catch(e){
this.hideLoading();
this.showToast('Network error','error');
}
}

},

/* ✅ EXTRA SAFETY CLEANUP */
beforeUnmount(){
if(this.preview){
URL.revokeObjectURL(this.preview);
}
}

}).mount('#app');
</script>

<script>lucide.createIcons();</script>

</body>
</html>