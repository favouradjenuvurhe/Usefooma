<?php
/**
 * Pulsepoint Sell Giftcard Page - Vue 3 + Tailwind UI (No PIN)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/sell-giftcard.php
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session
if (!session_id()) session_start();

// Validate user session
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner slides
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

// Fetch giftcards
$giftcards = $wpdb->get_results("SELECT * FROM {$base_prefix}giftcard_settings WHERE status='active' ORDER BY category ASC, sub_category ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Sell Giftcard | <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root{
  --app-bg:#f7f8fb;
  --card-bg:#ffffff;
  --muted:#6b7280;
  --primary:<?= $color_hex ?>;
}
html,body,#app{min-height:100%;background:var(--app-bg);}
body{font-family:'Inter',sans-serif;margin:0;padding:0;}
.rounded-card{border-radius:14px;background:var(--card-bg);}
.topup-btn{border-radius:12px;border:1.5px solid rgba(99,102,241,0.08);padding:14px 18px;font-weight:600;}
.topup-btn.selected{background:var(--primary);color:#fff;border-color:var(--primary);}
.giftcard-scroll{display:flex;overflow-x:auto;gap:10px;padding:8px 0;}
.giftcard-card img{width:60px;height:60px;border-radius:50%;border:2px solid transparent;object-fit:cover;}
.giftcard-card.selected img{border-color:var(--primary);}
.amount-input{border:none;border-bottom:2px solid #e5e7eb;width:100%;font-weight:600;text-align:right;}
.pay-btn{background:var(--primary);color:#fff;padding:10px 22px;border-radius:999px;font-weight:600;}
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- HEADER -->    <div class="flex items-center justify-between mb-6 mt-2">            
    <div class="flex items-center gap-3">            
      <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">            
        <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>            
      </button>            
      <h2 class="text-xl font-bold text-gray-900">Sell GiftCards</h2>            
    </div>            
    <div class="flex items-center space-x-3 mt-1">            
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">            
        <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>            
      </button>            
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">            
        <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>            
      </button>            
    </div>            
  </div>   

<div class="mt-6 rounded-card p-4 border shadow-sm">

<!-- CARD TYPE -->
<div class="mb-4">
  <label class="font-semibold">Card Type</label>
  <div class="flex gap-3 mt-2">
    <button class="topup-btn" :class="{selected:selectedType==='digital'}" @click="selectType('digital')">Digital</button>
    <button class="topup-btn" :class="{selected:selectedType==='physical'}" @click="selectType('physical')">Physical</button>
  </div>
</div>

<!-- SEARCH -->
<div class="mb-4">
  <label class="font-semibold">Search Giftcards</label>
  <input v-model="searchQuery" class="amount-input mt-1" placeholder="Search by category...">
</div>

<!-- CATEGORY SCROLL -->
<div class="giftcard-scroll mb-4">
  <div v-for="cat in filteredGiftcards" :key="cat.category"
       class="giftcard-card"
       :class="{selected:selectedCategory===cat.category}"
       @click="selectGiftcard(cat)">
    <img :src="cat.image">
    <span>{{ cat.category }}</span>
  </div>
</div>

<!-- SUBCATEGORY SCROLL -->
<div v-if="subcategories.length" class="giftcard-scroll mb-4">
  <div v-for="sub in subcategories" :key="sub.sub"
       class="giftcard-card"
       :class="{selected:selectedSubCategory===sub.sub}"
       @click="selectSubCategory(sub.sub)">
    <img :src="sub.image">
    <span>{{ sub.sub }}</span>
  </div>
</div>

<!-- DIGITAL -->
<div v-if="selectedType==='digital'" class="mb-4">
  <label class="font-semibold">Digital Code</label>
  <textarea v-model="digital_code" class="w-full border-b"></textarea>
</div>

<!-- PHYSICAL -->
<div v-if="selectedType==='physical'" class="mb-4">
  <label class="font-semibold">Upload Physical Card Image</label>
  <input type="file" @change="handlePhysicalUpload">
</div>

<!-- AMOUNT -->
<div class="mb-4">
  <label class="font-semibold">Amount (USD)</label>
  <input type="number" v-model.number="amount" class="amount-input">
</div>

<div class="muted mb-4" v-html="calcInfo"></div>

<button class="pay-btn w-full" @click="submitGiftcard">Sell Giftcard</button>
</div>

<!-- Scrollable Banner -->    <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2 mt-4">        
    <?php foreach($banner_slides as $slide): ?>        
      <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">        
        <img src="<?= esc_url($slide) ?>" class="w-full h-full object-cover rounded-lg shadow-md">        
      </div>        
    <?php endforeach; ?>        
  </div>  </div>

<script>  
const { createApp } = Vue;  
createApp({  
data(){  
return{  
selectedType:'',  
searchQuery:'',  
selectedCategory:'',  
selectedSubCategory:'',  
amount:null,  
digital_code:'',  
physical_file:null,  
giftcards:[  
<?php foreach($giftcards as $g): ?>  
{  
id:<?= $g->id ?>,  
category:"<?= esc_js($g->category) ?>",  
sub:"<?= esc_js($g->sub_category) ?>",  
rate:<?= $g->rate ?>,  
type:"<?= $g->type ?>",  
image:"<?= esc_url($g->image_url) ?>"  
},  
<?php endforeach; ?>  
]  
}  
},  

computed:{  
filteredGiftcards(){  
const map={};  
this.giftcards  
.filter(g=>this.selectedType?g.type===this.selectedType:true)  
.filter(g=>g.category.toLowerCase().includes(this.searchQuery.toLowerCase()))  
.forEach(g=>{  
if(!map[g.category]) map[g.category]={category:g.category,image:g.image};  
});  
return Object.values(map);  
},  

subcategories(){  
return this.giftcards  
.filter(g=>g.category===this.selectedCategory && g.type===this.selectedType)  
.map(g=>({sub:g.sub,image:g.image}));  
},  

calcInfo(){  
if(!this.selectedSubCategory||!this.amount) return "Select card and amount to see payout.";  
const g=this.giftcards.find(x=>x.category===this.selectedCategory&&x.sub===this.selectedSubCategory);  
return `You'll receive approximately <strong>₦${(g.rate*this.amount).toFixed(2)}</strong>.`;  
}  
},  

methods:{  
goBack(){history.back();},  

selectType(t){  
this.selectedType=t;  
this.selectedCategory='';  
this.selectedSubCategory='';  
this.digital_code='';  
this.physical_file=null;  
},  

selectGiftcard(cat){  
this.selectedCategory=cat.category;  
this.selectedSubCategory='';  
},  

selectSubCategory(s){  
this.selectedSubCategory=s;  
},  

handlePhysicalUpload(e){  
this.physical_file=e.target.files[0];  
},  

showToast(msg,type='info'){  
Toastify({  
text:msg,  
duration:3000,  
close:true,  
gravity:'top',  
position:'center',  
style:{  
background:type==='error'?'#ff3860':'green',  
color:'#fff',  
borderRadius:'12px'  
}  
}).showToast();  
},  

showLoading(){  
const overlay=document.createElement('div');  
overlay.id='loadingOverlay';  
overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';  
overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';  
document.body.appendChild(overlay);  
},  

hideLoading(){  
const overlay=document.getElementById('loadingOverlay');  
if(overlay) overlay.remove();  
},  

/* ✅ ONLY FUNCTION THAT WAS CHANGED */
async submitGiftcard(){  

/* VALIDATIONS — SAME BEHAVIOUR */
if(!this.selectedType){ this.showToast('Select card type','error'); return; }  
if(!this.selectedCategory){ this.showToast('Select a giftcard','error'); return; }  
if(!this.selectedSubCategory){ this.showToast('Select a sub-category','error'); return; }  
if(!this.amount || this.amount<=0){ this.showToast('Enter valid amount','error'); return; }  
if(this.selectedType==='digital' && !this.digital_code){  
this.showToast('Enter the digital code','error'); return;  
}  
if(this.selectedType==='physical' && !this.physical_file){  
this.showToast('Upload the physical card image','error'); return;  
}  

/* MAP TO REAL giftcard_id (NO STATE CHANGE) */
const gift = this.giftcards.find(g =>
g.category===this.selectedCategory &&
g.sub===this.selectedSubCategory &&
g.type===this.selectedType
);

if(!gift){  
this.showToast('Invalid giftcard selection','error');  
return;  
}

/* SUBMIT — SAME AS OLD CODE */
const fd = new FormData();  
fd.append('action','pulsepoint_sell_giftcard');  
fd.append('giftcard_id', gift.id);  
fd.append('sub_category', this.selectedSubCategory);  
fd.append('type', this.selectedType);  
fd.append('amount', this.amount);  

if(this.selectedType==='digital') fd.append('digital_code',this.digital_code);  
if(this.selectedType==='physical') fd.append('physical_image',this.physical_file);  

try{  
this.showLoading();  
const res = await fetch("<?= admin_url('admin-ajax.php') ?>",{  
method:'POST',  
body:fd  
});  
const data = await res.json();  
this.hideLoading();  

if(data.success){  
this.showToast(data.message||'Giftcard submitted successfully','success');  
setTimeout(()=>window.location.href='/app/view-giftcard/',2000);  
}else{  
this.showToast(data.message||'Submission failed','error');  
}  

}catch(e){  
this.hideLoading();  
this.showToast('Network error','error');  
}  
}  

}  
}).mount('#app');  
</script>  

<script>lucide.createIcons();</script>
</body>
</html>