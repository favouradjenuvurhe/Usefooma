<?php      
/**      
 * All Services Page - Pulsepoint Plugin      
 * Author: Amaaavl      
 */      

if (!defined('ABSPATH')) exit;      

global $wpdb;      
$base_prefix = $wpdb->prefix . 'pulsepoint_';  

// Fetch settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {      
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);      
}    

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0057ff';    

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
$table_users = $wpdb->prefix . 'pulsepoint_users';    
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));    
$firstname = $user ? esc_html($user->firstname) : 'User';    

// Fetch enabled services  
$table_services = $base_prefix . "services";    
$services = $wpdb->get_results("SELECT * FROM {$table_services} WHERE status = 1 ORDER BY id ASC");  

// Map service ID to icon full SVG URLs and URL  
$service_map = [  
    1 => ['icon' => 'https://www.svgrepo.com/show/380067/phone-call.svg', 'url' => '/app/airtime'],  
    2 => ['icon' => 'https://www.svgrepo.com/show/532893/wifi.svg', 'url' => '/app/data'],  
    3 => ['icon' => 'https://www.svgrepo.com/show/522492/bulb-2.svg', 'url' => '/app/electricity'],  
    4 => ['icon' => 'https://www.svgrepo.com/show/533615/plane.svg', 'url' => '/app/flights'],  
    5 => ['icon' => 'https://www.svgrepo.com/show/478288/internet.svg', 'url' => '/app/net'],  
    6 => ['icon' => 'https://www.svgrepo.com/show/533614/card-sim.svg', 'url' => '/app/esim'],  
    7 => ['icon' => 'https://www.svgrepo.com/show/496923/card-coin.svg', 'url' => '/app/sell-giftcard'],  
    8 => ['icon' => 'https://www.svgrepo.com/show/533613/bus.svg', 'url' => '/app/transport'],  
    9 => ['icon' => 'https://www.svgrepo.com/show/533607/send.svg', 'url' => '/app/type-transfer'],  
    10 => ['icon' => 'https://www.svgrepo.com/show/533609/volleyball.svg', 'url' => '/app/betting'],  
    11 => ['icon' => 'https://www.svgrepo.com/show/533157/tv.svg', 'url' => '/app/cable'],  
    12 => ['icon' => 'https://www.svgrepo.com/show/524368/card.svg', 'url' => '/app/virtual-card'],  
    13 => ['icon' => 'https://www.svgrepo.com/show/532912/graduation-hat-alt-2.svg', 'url' => '/app/education'],  
    14 => ['icon' => 'https://www.svgrepo.com/show/533620/piggy-bank.svg', 'url' => '/app/saving'],  
    15 => ['icon' => 'https://www.svgrepo.com/show/533621/tickets.svg', 'url' => '/app/tickets'],  
    16 => ['icon' => 'https://www.svgrepo.com/show/533625/circle-pound-sterling.svg', 'url' => '/app/currency'],  
    17 => ['icon' => 'https://www.svgrepo.com/show/533626/bitcoin.svg', 'url' => '/app/send'],  
    18 => ['icon' => 'https://www.svgrepo.com/show/533627/hand-coins.svg', 'url' => '/app/receive'],  
    19 => ['icon' => 'https://www.svgrepo.com/show/489160/store.svg', 'url' => '/app/market'],  
];  
?>    

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Services UI</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

<style>
body {
  background: #f2f2f2;
  font-family: ui-sans-serif, system-ui;
  margin: 0;
  padding-bottom: calc(80px + env(safe-area-inset-bottom));
  overflow-x: hidden;
}

/* Reduce height by 15% */
.service-card {
  background: white;
  border-radius: 16px;
  padding: 10px 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  cursor: pointer;
  transition: transform 0.15s ease;
}
.service-card:hover { transform: translateY(-2px); }

.icon { width: 20px; height: 20px; }
.icon-circle {
  width: 44px;
  height: 44px;
  border-radius: 999px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.service-name { font-size: 16px; font-weight: 500; color: #1f2937; }

.badge {
  background: #ff7a00;
  color: white;
  font-size: 10px;
  padding: 3px 6px;
  border-radius: 6px;
  font-weight: 600;
}
</style>
</head>

<body>

<div id="app" class="max-w-md mx-auto px-4 pt-3 overflow-x-hidden">

  <!-- Header -->
  <div class="flex justify-between items-center mb-6">
    <h1 class="text-[20px] font-semibold text-gray-800">Services</h1>
  </div>

  <!-- Services List -->
  <div class="space-y-3 mb-24">

    <?php foreach($services as $service): 
        $map = $service_map[$service->id] ?? ['icon'=>'https://www.svgrepo.com/show/533633/question.svg','url'=>'#']; ?>
    <a href="<?= esc_url($map['url']) ?>" class="service-card">
      <div class="flex items-center gap-4">
        <div class="icon-circle" style="background: <?= $color_hex ?>;">
          <img src="<?= esc_url($map['icon']) ?>" class="icon invert">
        </div>
        <span class="service-name"><?= esc_html($service->service_name) ?></span>
      </div>
      <?php if(!empty($service->badge)): ?>
        <span class="badge"><?= esc_html($service->badge) ?></span>
      <?php endif; ?>
    </a>
    <?php endforeach; ?>

  </div>

<!-- Bottom Nav -->    <div class="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-3">  <div onclick="window.location.href='/app/home'"  
     class="flex flex-col items-center text-gray-400 cursor-pointer">  
  <img src="https://www.svgrepo.com/show/529022/home-smile-angle.svg" class="w-5">  
  <span class="text-xs">Home</span>  
</div>  

<div onclick="window.location.href='/app/transactions'"  
     class="flex flex-col items-center text-gray-400 cursor-pointer">  
  <img src="https://www.svgrepo.com/show/523270/chart-square.svg" class="w-5">  
  <span class="text-xs">Transactions</span>  
</div>  

<!-- ACTIVE -->  
<div onclick="window.location.href='/app/services'"  
     class="flex flex-col items-center cursor-pointer"  
     style="color: <?= $color_hex ?>;">  
  <img src="https://www.svgrepo.com/show/497333/more-square.svg" class="w-5">  
  <span class="text-xs font-medium">Services</span>  
</div>  

<div onclick="window.location.href='/app/more'"  
     class="flex flex-col items-center text-gray-400 cursor-pointer">  
  <img src="https://www.svgrepo.com/show/499608/grid-aspect-ratio.svg" class="w-5">  
  <span class="text-xs">More</span>  
</div>

  </div>  </div>  <script> 
const { createApp } = Vue;
createApp({}).mount('#app');
</script>

</body>
</html>