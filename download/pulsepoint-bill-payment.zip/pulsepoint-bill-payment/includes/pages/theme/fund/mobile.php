<?php  
/**
 * Fund Wallet Page - Pulsepoint Plugin
 * Auto Triggers Virtual Account Creation
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';
$pay_fee     = $settings['pay_fee'] ?? '1';

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

$table_users   = $wpdb->prefix . 'pulsepoint_users';
$table_account = $base_prefix . 'account';

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d",
    $user_id
));

$acct = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_account} WHERE user_id = %d ORDER BY id DESC LIMIT 1",
    $user_id
));

$bank_name = $acct->bank ?? '---';
$acct_name = $acct->name ?? ($user->firstname . ' ' . $user->lastname);
$acct_num  = $acct->number ?? '';
$provider  = $acct->provider ?? '9PSB';
$firstname = $user ? esc_html($user->firstname) : 'User';

/**
 * =====================================
 * SERVICE VISIBILITY (Receive Crypto)
 * =====================================
 */
$services_table = $base_prefix . 'services';

$show_receive_crypto = (bool) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM {$services_table}
         WHERE service_key = %s AND status = 1",
        'hand-coins'
    )
);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Fund Wallet | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root {
  --app-bg: #f7f8fb;
  --card-bg: #ffffff;
  --muted: #6b7280;
  --primary: <?= $color_hex ?>;
}
html, body, #app { min-height: 100%; background: var(--app-bg); }
body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
.rounded-card{ border-radius: 14px; background: var(--card-bg); }
.pay-btn { background: var(--primary); color: white; padding: 10px 22px; border-radius: 999px; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; min-width: 80px; }
.pay-btn:hover{ filter: brightness(90%); }
.card-inner { padding: 18px; }
.muted { color: var(--muted); }
.amount-wrapper { display: flex; align-items: center; gap:6px; margin-top:6px; }
.amount-wrapper span { font-weight: bold; font-size: 16px; }
.amount-input { border: none; border-bottom: 2px solid #e5e7eb; padding: 6px 0; width: 100%; font-weight: 600; text-align: right; outline: none; font-size: 16px; }
.amount-input:focus { border-bottom-color: var(--primary); }
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Fund wallet</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- Virtual Account UI -->
<div class="mt-6 text-gray-800">

  <!-- NO ACCOUNT -->
  <template v-if="!acct && !loading">
    <div class="text-center py-12 text-gray-400">
      <i class="bi bi-bank text-4xl mb-3"></i><br>
      No Virtual Account
      <p class="mt-2 text-sm text-gray-500">You don’t have a virtual account yet.</p>
      <button class="mt-5 px-6 py-3 rounded-xl bg-blue-500 text-white font-semibold" @click="generateAcct">
        Generate Virtual Account
      </button>
    </div>
  </template>

  <!-- LOADING -->
  <template v-if="loading">
    <div class="text-center py-12 text-gray-400">
      <i class="bi bi-arrow-repeat animate-spin text-4xl mb-3"></i><br>
      Generating virtual account...
    </div>
  </template>

  <!-- ERROR -->
  <template v-if="error">
    <div class="text-center py-12 text-gray-400">
      <i class="bi bi-exclamation-circle text-4xl mb-3"></i>
      <h2 class="font-bold text-lg mb-2">Failed to Create</h2>
      <p class="text-sm mb-4">{{ error }}</p>
      <button class="mt-3 px-6 py-3 rounded-xl bg-red-500 text-white" @click="generateAcct">
        Try Again
      </button>
    </div>
  </template>

  <!-- ACCOUNT EXISTS -->
  <template v-if="acct && !loading">

    <div class="px-[3%]">

      <!-- Account Name -->
      <div class="py-3">
        <div class="text-[10px] text-gray-400 uppercase mb-1">Account Holder</div>
        <div class="flex justify-between items-center">
          <span class="text-lg font-semibold"><?= esc_html($acct_name) ?></span>
          <i class="bi bi-copy cursor-pointer text-blue-500 text-lg"
             @click="copyAcct('<?= esc_html($acct_name) ?>')"></i>
        </div>
      </div>

      <!-- Account Number -->
      <div class="py-3">
        <div class="text-[10px] text-gray-400 uppercase mb-1">Account Number</div>
        <div class="flex justify-between items-center">
          <span class="text-2xl font-bold tracking-widest"><?= esc_html($acct_num) ?></span>
          <i class="bi bi-copy cursor-pointer text-blue-500 text-lg"
             @click="copyAcct('<?= esc_html($acct_num) ?>')"></i>
        </div>
      </div>

      <!-- Bank Name -->
      <div class="py-3">
        <div class="text-[10px] text-gray-400 uppercase mb-1">Bank Name</div>
        <div class="flex justify-between items-center">
          <span class="text-lg font-semibold"><?= esc_html($bank_name) ?></span>
          <i class="bi bi-copy cursor-pointer text-blue-500 text-lg"
             @click="copyAcct('<?= esc_html($bank_name) ?>')"></i>
        </div>
      </div>

      <!-- Info Box -->
      <div class="mt-4 border border-yellow-400/40 rounded-lg p-3 text-yellow-700 bg-yellow-50 text-xs leading-5">
        <ul class="space-y-1 list-disc pl-4">
          <li>Deposits to this account carry a <?= esc_html($pay_fee) ?>% fee.</li>
          <li>Sender name must match your Account Name.</li>
          <li>Multiple deposits in 24hrs may flag account.</li>
        </ul>

        <div class="mt-2 underline cursor-pointer text-yellow-600 text-xs">
          More about account topup
        </div>
      </div>

      <!-- Copy Button -->
      <button 
        class="mt-5 w-full py-3 rounded-xl bg-blue-500 text-white text-sm font-semibold flex items-center justify-center gap-2"
        @click="copyAcct('<?= esc_html($acct_num) ?>')"
      >
        Copy Details
        <i class="bi bi-copy text-base"></i>
      </button>

    </div>

  </template>

</div>

<?php if ($show_receive_crypto): 
    $crypto_url = site_url('/app/receive');
?>

<!-- Receive Crypto Card -->
<div
  class="mt-4 rounded-card p-4 flex items-center cursor-pointer shadow-sm hover:shadow-md transition"
  onclick="window.location.href='<?php echo esc_url($crypto_url); ?>'">

  <div class="w-12 h-12 rounded-full bg-[var(--primary)] flex items-center justify-center text-white text-xl">
      <i class="bi bi-wallet2"></i>
  </div>

  <div class="ml-4 flex-1">
      <div class="font-bold text-lg">
          Receive Crypto
          <span class="text-xs bg-orange-500 text-white rounded px-2 py-0.5">New</span>
      </div>
      <div class="text-sm text-gray-600">Receive crypto directly into your wallet</div>
  </div>

  <i class="bi bi-chevron-right text-gray-400 text-xl"></i>
</div>

<?php endif; ?>

</div>

<script>
const app = Vue.createApp({
  data() {
    return {
      acct: <?= empty($acct) ? 'false' : 'true' ?>,
      loading: false,
      error: null
    }
  },
  methods: {

    goBack() { 
      window.history.back(); 
    },

    copyAcct(num) {
      navigator.clipboard.writeText(num);
      Toastify({
        text: "Copied!",
        duration: 3000,
        gravity: "bottom",
        position: "center",
        backgroundColor: "<?= $color_hex ?>"
      }).showToast();
    },

    generateAcct() {
      this.loading = true;
      this.error = null;

      fetch('<?= admin_url('admin-ajax.php?action=pulsepoint_virtual_account') ?>', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:''
      })
      .then(res => res.json())
      .then(data => {
        this.loading = false;

        if (data.success && data.account) {
          location.reload();
        } else {
          this.error = data.message || 'Could not create your virtual account.';
        }
      })
      .catch(() => {
        this.loading = false;
        this.error = 'Unable to connect to server. Check your internet.';
      });
    },

    gotoCrypto() { 
      window.location.href='/app/receive'; 
    }

  }
});

app.mount('#app');
</script>
<script>lucide.createIcons();</script>
</body>
</html>