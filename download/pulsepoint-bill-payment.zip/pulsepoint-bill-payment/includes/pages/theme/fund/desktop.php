<?php  
/**
 * Fund Wallet Page - Pulsepoint Plugin
 * Auto Triggers Virtual Account Creation
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

$table_users   = $wpdb->prefix . 'pulsepoint_users';
$table_account = $base_prefix . 'account';

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d",
    $user_id
));

$acct = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_account} WHERE user_id = %d ORDER BY id DESC LIMIT 1",
    $user_id
));

$bank_name = $acct->bank ?? '---';
$acct_name = $acct->name ?? ($user->firstname . ' ' . $user->lastname);
$acct_num  = $acct->number ?? '';
$provider  = $acct->provider ?? '9PSB';
$firstname = $user ? esc_html($user->firstname) : 'User';

/**
 * =====================================
 * SERVICE VISIBILITY (Receive Crypto)
 * =====================================
 */
$services_table = $base_prefix . 'services';

$show_receive_crypto = (bool) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM {$services_table}
         WHERE service_key = %s AND status = 1",
        'hand-coins'
    )
);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Fund Wallet | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root {
  --app-bg: #f7f8fb;
  --card-bg: #ffffff;
  --muted: #6b7280;
  --primary: <?= $color_hex ?>;
}
html, body, #app { min-height: 100%; background: var(--app-bg); }
body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
.rounded-card{ border-radius: 14px; background: var(--card-bg); }
.pay-btn { background: var(--primary); color: white; padding: 10px 22px; border-radius: 999px; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; min-width: 80px; }
.pay-btn:hover{ filter: brightness(90%); }
.card-inner { padding: 18px; }
.muted { color: var(--muted); }
.amount-wrapper { display: flex; align-items: center; gap:6px; margin-top:6px; }
.amount-wrapper span { font-weight: bold; font-size: 16px; }
.amount-input { border: none; border-bottom: 2px solid #e5e7eb; padding: 6px 0; width: 100%; font-weight: 600; text-align: right; outline: none; font-size: 16px; }
.amount-input:focus { border-bottom-color: var(--primary); }
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

  <!-- HEADER -->
  <div class="flex items-center justify-between mb-6 mt-2">
    <div class="flex items-center gap-3">
      <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
      </button>
      <h2 class="text-xl font-bold text-gray-900">Fund Wallet</h2>
    </div>
    <div class="flex items-center space-x-3 mt-1">
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>
      </button>
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>
      </button>
    </div>
  </div>

  <!-- Virtual Account Card -->
  <div class="mt-6 rounded-card p-4 border border-gray-200 shadow-sm card-inner">
    <template v-if="!acct">
      <div class="text-center py-10 text-gray-500">
        <i class="bi bi-bank text-[var(--primary)] text-4xl mb-3"></i><br>
        No Virtual Account
        <p class="mt-2 text-sm text-gray-600">You don’t have a virtual account yet.</p>
        <button class="pay-btn mt-4" @click="generateAcct">Generate Virtual Account</button>
      </div>
    </template>

    <template v-else>
      <div class="mb-2 font-semibold text-sm text-[var(--primary)]">Bank Name</div>
      <div class="mb-3 font-bold text-lg"><?= esc_html($bank_name) ?> <span class="text-gray-400 text-sm">(<?= esc_html($provider) ?>)</span></div>

      <div class="mb-2 font-semibold text-sm text-[var(--primary)]">Account Name</div>
      <div class="mb-3 font-bold text-lg"><?= esc_html($acct_name) ?></div>

      <div class="mb-2 font-semibold text-sm text-[var(--primary)]">Account Number</div>
      <div class="flex items-center gap-2">
        <div class="font-bold text-lg"><?= esc_html($acct_num) ?></div>
        <i class="bi bi-copy cursor-pointer text-[var(--primary)] text-xl" @click="copyAcct('<?= esc_html($acct_num) ?>')"></i>
      </div>

      <p class="mt-4 text-sm text-gray-500 leading-6">
        Transfer from your verified bank account only for instant wallet funding.<br>
        Transactions are processed automatically and credited within seconds.
      </p>
    </template>
  </div>

<?php if ($show_receive_crypto): 
    $crypto_url = site_url('/app/receive');
?>

<!-- Receive Crypto Card -->
<div
  class="mt-4 rounded-card p-4 flex items-center cursor-pointer shadow-sm hover:shadow-md transition"
  onclick="window.location.href='<?php echo esc_url($crypto_url); ?>'">

  <div class="w-12 h-12 rounded-full bg-[var(--primary)] flex items-center justify-center text-white text-xl">
      <i class="bi bi-wallet2"></i>
  </div>

  <div class="ml-4 flex-1">
      <div class="font-bold text-lg">
          Receive Crypto
          <span class="text-xs bg-orange-500 text-white rounded px-2 py-0.5">New</span>
      </div>
      <div class="text-sm text-gray-600">Receive crypto directly into your wallet</div>
  </div>

  <i class="bi bi-chevron-right text-gray-400 text-xl"></i>
</div>

<?php endif; ?>

</div>

<script>
const app = Vue.createApp({
  data() {
    return {
      acct: <?= empty($acct) ? 'null' : 'true' ?>,
    }
  },
  methods: {
    goBack() { window.history.back(); },
    copyAcct(num) {
      navigator.clipboard.writeText(num);
      Toastify({text:"Account number copied!", duration:3000, gravity:"bottom", position:"center", backgroundColor:"<?= $color_hex ?>"}).showToast();
    },
    generateAcct() {
      const card = document.querySelector('.card-inner');
      card.innerHTML = `<div class='text-center py-10 text-gray-500'>
        <i class="bi bi-arrow-repeat animate-spin text-4xl text-[var(--primary)] mb-3"></i><br>
        Generating virtual account...
      </div>`;
      fetch('<?= admin_url('admin-ajax.php?action=pulsepoint_virtual_account') ?>', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:''
      }).then(res=>res.json())
      .then(data=>{
        if(data.success && data.account){
          location.reload();
        }else{
          card.innerHTML = `<div class='text-center py-10'>
            <i class='bi bi-exclamation-circle text-[var(--primary)] text-4xl mb-3'></i>
            <h2 class='font-bold text-lg mb-2'>Failed to Create</h2>
            <p class='text-gray-600 text-sm mb-4'>${data.message || 'Could not create your virtual account. Try again later.'}</p>
            <button class='pay-btn' @click='generateAcct'>Try Again</button>
          </div>`;
        }
      }).catch(()=>{
        card.innerHTML = `<div class='text-center py-10'>
          <i class='bi bi-exclamation-circle text-[var(--primary)] text-4xl mb-3'></i>
          <h2 class='font-bold text-lg mb-2'>Error</h2>
          <p class='text-gray-600 text-sm mb-4'>Unable to connect to server. Check your internet and try again.</p>
          <button class='pay-btn' @click='generateAcct'>Try Again</button>
        </div>`;
      });
    },
    gotoCrypto() { window.location.href='/app/receive'; }
  }
});
app.mount('#app');
</script>
<script>lucide.createIcons();</script>
</body>
</html>