<?php  
/**
 * Wallet-to-Wallet Transfer Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner flyer image URLs
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

// User
if (!session_id()) session_start();
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';
?>  
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Wallet Transfer - <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<style>
:root{
  --app-bg: #f7f8fb;
  --card-bg: #ffffff;
  --muted: #6b7280;
  --primary: <?= $color_hex ?>;
}
html, body, #app { min-height: 100%; background: var(--app-bg); }
body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
.rounded-card{ border-radius:14px; background:var(--card-bg); }
.muted { color: var(--muted); }
.pay-btn { background: var(--primary); color:white; padding:10px 22px; border-radius:999px; font-weight:600; cursor:pointer; }
input, select { outline:none; }
.thin-hr { height:1px; background:#e6e9ef; margin-top:18px; }
.account-name { color: green; text-align: left; font-weight:600; margin-top:4px; }
</style>
</head>
<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- HEADER -->
<div class="flex items-center justify-between mb-6 mt-2">
    <div class="flex items-center gap-3">
        <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
        </button>
        <h2 class="text-xl font-bold text-gray-900">Wallet Transfer</h2>
    </div>
    <div class="flex items-center space-x-3 mt-1">
        <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>
        </button>
        <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>
        </button>
    </div>
</div>

<!-- TRANSFER FORM CARD -->
<div class="rounded-card p-4 border border-gray-200 shadow-sm">

<!-- RECIPIENT PHONE -->
<div class="mt-2">
    <label class="font-semibold text-sm">Recipient</label>
    <input v-model="phone" maxlength="15" @input="clearAccountName" class="w-full p-3 rounded border border-gray-300" placeholder="Enter phone number without leading 0">
</div>

<!-- AMOUNT -->
<div class="mt-4">
    <label class="font-semibold text-sm">Amount (₦)</label>
    <input v-model="amount" type="number" class="w-full mt-1 p-3 rounded border border-gray-300 bg-transparent" placeholder="Enter amount">
</div>

<!-- NARRATION -->
<div class="mt-4">
    <label class="font-semibold text-sm">Narration</label>
    <input v-model="narration" class="w-full mt-1 p-3 rounded border border-gray-300 bg-transparent" placeholder="Optional">
</div>

<!-- BUTTON -->
<div class="mt-5">
    <button class="pay-btn w-full" @click="makeTransfer">Transfer Now</button>
</div>

<div class="thin-hr"></div>
</div>

<!-- BANNERS -->
<div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-3 mt-4">
    <?php foreach ($banner_slides as $slide): ?>
        <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">
            <img src="<?= esc_url($slide); ?>" class="w-full h-full object-cover rounded-lg shadow-md">
        </div>
    <?php endforeach; ?>
</div>

</div>

<script>
const { createApp } = Vue;

createApp({
data() {
return {
phone: "",
amount: "",
narration: "",
defaultLogo: "https://pulsepoint-plugin.vercel.app/img/bank-placeholder.png",
};
},

methods: {
goBack(){ window.history.back(); },

clearAccountName(){},

showLoading(){
let overlay = document.createElement('div');
overlay.id = 'loadingOverlay';
overlay.style = 'position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
overlay.innerHTML = '<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
document.body.appendChild(overlay);
},

hideLoading(){
const overlay = document.getElementById('loadingOverlay');
if(overlay) overlay.remove();
},

showToast(msg,type='info'){
Toastify({
text: msg,
duration:3000,
close:true,
gravity:'top',
position:'center',
style:{
background: type==='error'?'#ff3860':'green',
color:'#fff',
borderRadius:'12px'
}
}).showToast();
},

makeTransfer(){
if(!this.phone) return this.showToast("Enter recipient phone",'error');
if(!this.amount || this.amount<=0) return this.showToast("Enter valid amount",'error');

this.showLoading();
let formData = new FormData();
formData.append("action","pulsepoint_wallet_transfer");
formData.append("phone",this.phone);
formData.append("amount",this.amount);
formData.append("narration",this.narration);

fetch("<?= admin_url('admin-ajax.php') ?>",{method:"POST",body:formData})
.then(r=>r.json())
.then(res=>{
this.hideLoading();
if(res.success){
this.showToast("Transfer successful!");
setTimeout(()=>{ window.location.href="/app/success"; },800);
} else {
this.showToast(res.message,"error");
}
})
.catch(()=>{
this.hideLoading();
this.showToast("Network error","error");
});
}
}
}).mount("#app");
</script>
<script>lucide.createIcons();</script>
</body>
</html>