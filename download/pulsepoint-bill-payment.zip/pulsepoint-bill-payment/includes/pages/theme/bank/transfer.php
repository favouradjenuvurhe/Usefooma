<?php  
/**
 * Bank Transfer Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner flyer image URLs
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

// User
if (!session_id()) session_start();
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';
?>  
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Bank Transfer - <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<style>
:root{
  --app-bg: #f7f8fb;
  --card-bg: #ffffff;
  --muted: #6b7280;
  --primary: <?= $color_hex ?>;
}
html, body, #app { min-height: 100%; background: var(--app-bg); }
body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
.rounded-card{ border-radius:14px; background:var(--card-bg); }
.muted { color: var(--muted); }
.pay-btn { background: var(--primary); color:white; padding:10px 22px; border-radius:999px; font-weight:600; cursor:pointer; }
input, select { outline:none; }
.thin-hr { height:1px; background:#e6e9ef; margin-top:18px; }

/* UPDATED STYLE FOR ACCOUNT NAME - LEFT ALIGN */
.account-name { color: green; text-align: left; font-weight:600; margin-top:4px; }

/* Bank logo carousel styles */
.bank-carousel {
    display:flex;
    gap:14px;
    overflow-x:auto;
    -webkit-overflow-scrolling:touch;
    padding:12px 4px;
    scroll-behavior:smooth;
}
.bank-item {
    flex:0 0 auto;
    width:72px;
    text-align:center;
    cursor:pointer;
}
.bank-logo {
    width:64px;
    height:64px;
    border-radius:999px;
    object-fit:cover;
    border:2px solid transparent;
    box-shadow:0 6px 12px rgba(16,24,40,0.06);
    display:block;
    margin:0 auto;
    background:#fff;
}
.bank-item.selected .bank-logo {
    border-color: var(--primary);
    box-shadow:0 8px 20px rgba(0,87,255,0.12);
    transform:translateY(-3px);
}
/* TEXT UNDER LOGO */
.bank-name-small {
    font-size:11px;
    color:var(--muted);
    margin-top:6px;
    max-width:80px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}
/* hide native scrollbar */
.bank-carousel::-webkit-scrollbar { height:8px; }
.bank-carousel::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.08); border-radius:999px; }
/* Responsive */
@media (min-width: 768px) {
    .bank-item { width:84px; }
    .bank-logo{ width:72px; height:72px;}
}
</style>
</head>
<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Transfer</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>


<!-- TRANSFER FORM CARD -->
<div class="">

<!-- Receiver / Account Number -->
<div class="flex justify-between mt-6 mb-1">
  <div class="text-black text-sm font-medium">
      </p>   Receiver's details
  </div>
  <!-- optional right side button can go here if needed -->
</div>

<div class="rounded-card card-inner py-3 px-3 flex items-center">
  <input 
    type="text"
    v-model="accountNumber"
    @input="tryResolve"
    maxlength="10"
    placeholder="Enter 10-digit account number"
    class="w-full bg-transparent outline-none text-base text-gray-500"
  />
  <img src="https://www.svgrepo.com/show/523239/camera.svg" class="w-5 h-5 opacity-60 ml-2"/>
</div>

  <!-- Account Verification -->
  <div v-if="accountNumber.length >= 10" class="mt-2">
    <div v-if="!accountSuccess" class="bg-red-50 border border-red-200 text-red-600 text-sm px-3 py-2 rounded-xl mt-1 flex items-center justify-between">
      <span>{{ accountName || 'Account not found' }}</span>
      <img src="https://img.icons8.com/ios-filled/50/fa314a/cancel.png" class="w-4 h-4"/>
    </div>
    <div v-else class="bg-green-50 border border-green-200 text-green-700 text-sm px-3 py-2 rounded-xl mt-1 flex items-center justify-between">
      <span class="font-medium">{{ accountName }}</span>
      <img src="https://img.icons8.com/ios-filled/50/4CAF50/checkmark.png" class="w-4 h-4"/>
    </div>
  </div>

<!-- Amount (keep original style) -->    
<div class="rounded-card card-inner py-3 px-3 mt-4 bg-gray-50">    
  <div class="text-gray-400 text-sm mb-1">    
    Amount    
  </div>    
  <div class="flex items-center">    
    <span class="text-xl font-semibold text-gray-700 mr-1">₦</span>    
    <input     
      type="number"    
      v-model="amount"    
      placeholder="0.00"    
      class="w-full bg-transparent outline-none text-2xl font-medium text-gray-800 tracking-tight"    
    />    
  </div>  
</div>

<!-- Transfer Card -->
<div
  class="rounded-card card-inner p-4 mt-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer"
  @click="window.location.href='/app/user2user'"
>
  <div class="flex items-center gap-3">
    <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/529896/smile-circle.svg" class="w-5 h-5"/>
    </div>
    <div>
      <div class="font-medium text-gray-800">
        Transfer via wallets
      </div>
      <div class="text-sm text-gray-400">
        Send money via wallets
      </div>
    </div>
  </div>
  <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5 opacity-60"/>
</div>

  <!-- Bank Selection (keep original style) -->
<div v-if="accountNumber.length === 10" class="bg-white mt-6 rounded-3xl border border-gray-200 p-4 shadow-sm">
  <div class="text-gray-800 font-medium mb-3">
    Select Bank
  </div>

  <!-- Search -->
  <div class="bg-gray-100 rounded-xl flex items-center px-3 py-3 mb-4">
    <img src="https://www.svgrepo.com/show/520924/search-4.svg" class="w-4 h-4 opacity-60"/>
    <input 
      type="text" 
      v-model="searchText"
      @input="filterBanks"
      placeholder="Search bank..."
      class="bg-transparent outline-none ml-2 text-sm w-full text-gray-600"
    />
  </div>

  <!-- Bank List -->
  <div class="space-y-4 max-h-64 overflow-y-auto" ref="carousel">
    <div v-for="b in filteredBanks" 
         :key="b.bankCode"
         @click="selectBankLogo(b)"
         class="flex items-center justify-between cursor-pointer p-2 rounded-xl hover:bg-gray-50 transition"
         :class="selectedBank===b.bankCode ? 'bg-blue-50' : ''">
      <div class="flex items-center gap-3">
        <div class="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
          <img :src="getLogo(b.logo_url)" :alt="b.bankName" class="w-7 h-7"/>
        </div>
        <div class="text-gray-800 font-medium">{{ b.bankName }}</div>
      </div>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="w-5 h-5 opacity-60"/>
    </div>
  </div>

  <div class="text-center mt-6 text-yellow-700 font-medium">
  
  </div>
</div>

  <!-- Send Money Button (match airtime style) -->
  <button 
    class="mt-5 w-full h-[48px] rounded-xl text-white text-sm font-semibold"
    :style="{ background: accountSuccess && amount && selectedBank ? 'var(--primary)' : '#ccc', cursor: accountSuccess && amount && selectedBank ? 'pointer' : 'not-allowed' }"
    @click="makeTransfer"
    :disabled="!accountSuccess || !amount || !selectedBank"
  >
    Transfer Now
  </button>


<div class="thin-hr mt-5"></div>
</div>

<!-- Send Money Box -->
<div class="mt-4">
  <h3 class="text-black text-sm font-medium mb-2">Send Money</h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-1">
    
    <!-- Bulk Transfer -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="window.location.href='/app/bulk-transfer'">
      <h4 class="text-xs font-medium text-black">Bulk Transfer</h4>
      <p class="text-[11px] text-gray-400 mt-1">Send to multiple accounts</p>
    </div>

    <!-- Rate Transfer -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="window.location.href='/app/rate-transfer'">
      <h4 class="text-xs font-medium text-black">Rate Checker</h4>
      <p class="text-[11px] text-gray-400 mt-1">Check transfer fees & rates</p>
    </div>

    <!-- USSD Transfer -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="window.location.href='/app/ussd-transfer'">
      <h4 class="text-xs font-medium text-black">USSD Code</h4>
      <p class="text-[11px] text-gray-400 mt-1">Send via USSD codes</p>
    </div>

    <!-- QR Payment -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="window.location.href='/app/qr-transfer'">
      <h4 class="text-xs font-medium text-black">QR Code</h4>
      <p class="text-[11px] text-gray-400 mt-1">Send money via QR scan</p>
    </div>

  </div>
</div>

<!-- BANNERS -->
<div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-3 mt-4">
    <?php foreach ($banner_slides as $slide): ?>
        <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">
            <img src="<?= esc_url($slide); ?>" class="w-full h-full object-cover rounded-lg shadow-md">
        </div>
    <?php endforeach; ?>
</div>

</div>

<script>
const { createApp } = Vue;

createApp({
data() {
  return {
    selectedBank: "",
    accountNumber: "",
    accountName: "",
    accountSuccess: true,
    narration: "",
    amount: "",
    banks: [],
    filteredBanks: [],
    showSearch: false,
    searchText: "",
    defaultLogo: "https://pulsepoint-plugin.vercel.app/img/bank-placeholder.png",
    whoGoPayToken: "sk_xaqajx5u7xn36qjf9jz7ve5s"
  }
},

mounted() {
  fetch("https://pulsepoint-plugin.vercel.app/api/banks.json")
    .then(r => r.json())
    .then(data => {
      if (Array.isArray(data.data)) {
        this.banks = data.data.map(b => ({
          bankCode: String(b.bankCode ?? b.code ?? ""),
          bankName: b.bankName ?? b.name ?? "",
          logo_url: b.logo_url ?? b.logo ?? ""
        }));
      } else {
        this.banks = [];
      }
      this.filteredBanks = this.banks;
    })
    .catch(err => {
      console.error("Failed to fetch banks", err);
      this.banks = [];
      this.filteredBanks = [];
    });
},

methods: {
  goBack(){ window.history.back(); },

  filterBanks(){
    let t = (this.searchText||"").toLowerCase();
    if(!t) { this.filteredBanks = this.banks; return; }
    this.filteredBanks = this.banks.filter(b => (b.bankName||"").toLowerCase().includes(t));
  },

  clearAccountName(){ this.accountName = ""; this.accountSuccess = true; },

  tryResolve(){
    // Only verify if account number is 10 AND a bank is selected
    if(this.accountNumber.length === 10 && this.selectedBank){
      this.resolveAccount();
    } else {
      this.accountName = "";
    }
  },

  resolveAccount(){
    this.showLoading();
    fetch("https://whogopay.com.ng/api/v1/verify-account-number", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + this.whoGoPayToken
      },
      body: JSON.stringify({
        bankCode: this.selectedBank,
        accountNumber: this.accountNumber
      })
    })
    .then(r => r.json())
    .then(res => {
      this.hideLoading();
      if(res && res.message){
        this.accountName = res.message;
        this.accountSuccess = true;
      } else {
        this.accountName = "Account not found";
        this.accountSuccess = false;
      }
    })
    .catch(() => {
      this.hideLoading();
      this.accountName = "Server error";
      this.accountSuccess = false;
    });
  },

  makeTransfer(){
    if(!this.selectedBank) return this.showToast("Select bank",'error');
    if(!this.accountNumber || this.accountNumber.length!==10) return this.showToast("Enter valid account number",'error');
    if(!this.amount || this.amount<=0) return this.showToast("Enter valid amount",'error');

    this.showLoading();
    let formData = new FormData();
    formData.append("action","pulsepoint_bank_transfer");
    formData.append("bank_code",this.selectedBank);
    formData.append("account_number",this.accountNumber);
    formData.append("account_name", this.accountName); 
    formData.append("amount",this.amount);
    formData.append("narration",this.narration);

    fetch("<?= admin_url('admin-ajax.php') ?>",{method:"POST",body:formData})
      .then(r=>r.json())
      .then(res=>{
        this.hideLoading();
        if(res.success){
          this.showToast("Transfer successful!");
          setTimeout(()=>{ window.location.href="/app/success"; },800);
        } else {
          this.showToast(res.message,"error");
        }
      })
      .catch(()=>{
        this.hideLoading();
        this.showToast("Network error","error");
      });
  },

  selectBankLogo(b){
    this.selectedBank = String(b.bankCode||"");
    this.accountName = "";
    this.accountSuccess = true;

    // Trigger verification if account number is already 10 digits
    if(this.accountNumber.length === 10){
      this.tryResolve();
    }

    this.$nextTick(() => {
      try {
        const items = this.$refs.carousel.querySelectorAll('.bank-item');
        for(const it of items){
          if(it && it.classList.contains('selected')){
            it.scrollIntoView({behavior:'smooth', inline:'center'});
            break;
          }
        }
      } catch(e){}
    });
  },

  getLogo(url){ if(!url) return this.defaultLogo; return url; },
  onLogoError(ev){ ev.target.src = this.defaultLogo; },

  showLoading(){
    let overlay = document.createElement('div');
    overlay.id = 'loadingOverlay';
    overlay.style = 'position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
    overlay.innerHTML = '<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
    document.body.appendChild(overlay);
  },

  hideLoading(){
    const overlay = document.getElementById('loadingOverlay');
    if(overlay) overlay.remove();
  },

  showToast(msg,type='info'){
    Toastify({
      text: msg,
      duration:3000,
      close:true,
      gravity:'top',
      position:'center',
      style:{
        background: type==='error'?'#ff3860':'green',
        color:'#fff',
        borderRadius:'12px'
      }
    }).showToast();
  }
}
}).mount("#app");
</script>
<script>lucide.createIcons();</script>
</body>
</html>