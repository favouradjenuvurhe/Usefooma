<?php
/**
 * Airtime Purchase Page - Desktop Mode (Full Form + Banner Slider)
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner flyers
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Airtime - <?= esc_html($platform_name) ?></title>

  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

  <style>
    :root {
      --app-bg: #f5f6fa;
      --card-bg: #ffffff;
      --primary: <?= $color_hex ?>;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--app-bg);
      margin: 0;
      padding: 0;
    }

    .content-wrapper {
      max-width: 900px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .form-card {
      background: white;
      padding: 28px;
      border-radius: 18px;
      box-shadow: 0 4px 18px rgba(0,0,0,0.08);
      border: 1px solid #ececec;
      width: 100%;
    }

    .topup-btn {
      border-radius: 14px;
      border: 1.5px solid rgba(99,102,241,0.08);
      padding: 14px 20px;
      font-weight: 600;
      transition: 0.2s;
    }

    .topup-btn.selected {
      background: var(--primary);
      color: white;
      border-color: var(--primary);
    }

    .amount-input {
      border: none;
      border-bottom: 2px solid #ddd;
      width: 100%;
      text-align: right;
      font-weight: 600;
      outline: none;
    }

    .amount-input:focus {
      border-bottom-color: var(--primary);
    }

    /* SLIDER */
    .slider-container {
      position: relative;
      width: 100%;
      height: 200px;
      overflow: hidden;
      border-radius: 14px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.12);
    }

    .slider-track {
      display: flex;
      width: 100%;
      height: 100%;
      transition: transform 0.6s ease;
    }

    .slide {
      min-width: 100%;
      height: 200px;
    }

    .slide img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    /* Slider dots */
    .slider-dots {
      text-align: center;
      margin-top: 10px;
    }
    .slider-dots span {
      display: inline-block;
      width: 10px;
      height: 10px;
      background: #ccc;
      border-radius: 50%;
      margin: 0 4px;
      cursor: pointer;
    }
    .slider-dots .active {
      background: var(--primary);
    }
  </style>
</head>

<body>
<div id="app">

  <div class="content-wrapper">

    <div class="form-card">

      <div class="flex items-center justify-between mb-7">
        <h1 class="text-3xl font-bold text-gray-900">Airtime Purchase</h1>

        <button @click="goBack"
                class="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
          <i data-lucide="arrow-left" class="w-5 h-5"></i>
        </button>
      </div>

      <div class="mb-6">
        <div class="text-gray-600 font-semibold mb-2">Select Service Provider</div>

        <div class="border p-4 rounded-xl flex gap-3 items-center bg-white shadow-sm">
          <img :src="selectedProvider.img" class="w-12 h-12 rounded-lg bg-gray-100 p-2" />
          <select v-model="selectedProvider" class="font-semibold text-sm outline-none w-full">
            <option v-for="net in networks" :value="net">{{ net.name }}</option>
          </select>
        </div>
      </div>

      <div class="mb-6">
        <input v-model="phone" placeholder="Enter phone number"
               class="amount-input py-3 text-lg">
      </div>

      <div class="text-lg font-semibold mb-2">Topup</div>

      <div class="grid grid-cols-3 gap-3 mb-4">
        <button v-for="amt in amounts"
                :key="amt"
                class="topup-btn"
                :class="{selected: phoneAmount == amt}"
                @click="selectAmount(amt)">
          ₦{{ amt }}
        </button>
      </div>

      <div class="flex items-center gap-2">
        <span class="font-bold text-xl">₦</span>
        <input type="number" v-model="phoneAmount" class="amount-input text-xl py-1">
      </div>

      <button class="mt-7 w-full py-3 rounded-xl text-white font-semibold text-lg"
              :style="{ background: '<?= $color_hex ?>' }"
              @click="pay">
        Pay Now
      </button>

    </div>

    <!-- SLIDER -->
    <div class="mt-10">
      <div class="slider-container" id="slider">
        <div class="slider-track" id="sliderTrack">
          <?php foreach ($banner_slides as $slide): ?>
          <div class="slide">
            <img src="<?= esc_url($slide) ?>">
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="slider-dots" id="sliderDots">
        <?php for ($i = 0; $i < count($banner_slides); $i++): ?>
          <span data-index="<?= $i ?>"></span>
        <?php endfor; ?>
      </div>
    </div>

  </div>

</div>

<script>    
const { createApp } = Vue;    
createApp({    
  data(){    
    return {    
      phone:'',    
      phoneAmount:'',    
      saveAsBeneficiary:false,    
      networks:[    
        {name:'MTN', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/MTN.png'},    
        {name:'AIRTEL', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/AIRTEL.png'},    
        {name:'GLO', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/GLO.png'},    
        {name:'9MOBILE', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/9MOBILE.png'},    
      ],    
      selectedProvider:{name:'MTN', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/MTN.png'},    
      amounts:[100,200,500,1000,2000,5000]    
    };    
  },    
  methods:{    
    goBack(){ window.history.back(); },    
    showToast(msg,type='info'){    
      Toastify({    
        text: msg,    
        duration: 3000,    
        close:true,    
        gravity:'top',    
        position:'center',    
        stopOnFocus:true,    
        style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }    
      }).showToast();    
    },    
    showLoading(){    
      const overlay=document.createElement('div');    
      overlay.id='loadingOverlay';    
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';    
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';    
      document.body.appendChild(overlay);    
    },    
    hideLoading(){ const overlay=document.getElementById('loadingOverlay'); if(overlay) overlay.remove(); },    
    toggleSave(){ this.saveAsBeneficiary = !this.saveAsBeneficiary; },    
    selectAmount(amount){ this.phoneAmount = amount; },    
    pay(){    
      if(!this.phone){ this.showToast('Enter phone number','error'); return; }    
      if(!this.selectedProvider.name){ this.showToast('Select provider','error'); return; }    
      if(!this.phoneAmount || this.phoneAmount < 50){ this.showToast('Enter valid amount','error'); return; }    
      this.showLoading();    
      const formData = new FormData();    
      formData.append('action','pulsepoint_airtime_purchase');    
      formData.append('network', this.selectedProvider.name);    
      formData.append('phone', this.phone);    
      formData.append('amount', this.phoneAmount);    
      formData.append('reference','');    

      fetch("<?= admin_url('admin-ajax.php') ?>", { method:'POST', body:formData })    
      .then(res=>res.json())    
      .then(res=>{    
        this.hideLoading();    
        if(res.success){    
          this.showToast(`₦${res.new_wallet} remaining. Phone: ${this.phone}`);    
          setTimeout(()=>{ window.location.href='/app/success'; },1000);    
        } else{    
          this.showToast(res.message || 'Purchase failed','error');    
        }    
      })    
      .catch(err=>{ this.hideLoading(); this.showToast('Network error','error'); });    
    }
  }
}).mount('#app');
</script>  

<!-- SLIDER JS -->
<script>
let index = 0;
const track = document.getElementById("sliderTrack");
const dots  = document.querySelectorAll("#sliderDots span");
const total = dots.length;

function updateSlider(){
    track.style.transform = `translateX(-${index * 100}%)`;

    dots.forEach(d => d.classList.remove("active"));
    dots[index].classList.add("active");
}

dots.forEach(dot => {
    dot.onclick = () => {
        index = parseInt(dot.dataset.index);
        updateSlider();
    };
});

setInterval(() => {
    index = (index + 1) % total;
    updateSlider();
}, 3500);

updateSlider();
</script>

<script>lucide.createIcons();</script>

</body>
</html>