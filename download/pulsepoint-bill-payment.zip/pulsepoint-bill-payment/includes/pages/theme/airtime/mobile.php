<?php          
/**    
 * Airtime Purchase Page - Pulsepoint Plugin    
 * Author: Amaaavl    
 */    
if (!defined('ABSPATH')) exit;    
    
global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
// Fetch settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner flyer image URLs from settings
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];    
    
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
$table_users = $wpdb->prefix . 'pulsepoint_users';    
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));    
$firstname = $user ? esc_html($user->firstname) : 'User';    
?>    
<!doctype html>  
<html lang="en">    
<head>    
  <meta charset="utf-8" />    
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />    
  <title>Airtime - <?= esc_html($platform_name) ?></title>    
  <script src="https://cdn.tailwindcss.com"></script>    
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>    
  <script src="https://unpkg.com/lucide@latest"></script>    
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">    
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>    
  <style>    
    :root{    
      --app-bg: #f7f8fb;    
      --card-bg: #ffffff;    
      --muted: #6b7280;    
      --primary: <?= $color_hex ?>;    
    }    
    html, body, #app { min-height: 100%; background: var(--app-bg); }    
    body { font-family: 'Inter', sans-serif; margin: 0; padding: 0; }    
    .rounded-card{ border-radius: 14px; background: var(--card-bg); }    
    .topup-btn{    
      border-radius: 12px; border: 1.5px solid rgba(99,102,241,0.08);    
      padding: 14px 18px; min-width: 88px; text-align: center;    
      font-weight: 600; background: transparent; cursor: pointer;    
      transition: all 0.2s;    
    }    
    .topup-btn.selected{ background: var(--primary); color: white; border-color: var(--primary); }    
    .topup-btn:hover{ background: rgba(37,99,235,0.08); border-color: rgba(37,99,235,0.2); }    
    .muted { color: var(--muted); }    

    .provider-row{ display: flex; align-items: center; gap: 8px; width: 100%; }    
    .provider-logo{ width: 100px; height: 50px; border-radius: 10px; display: flex; align-items: center; justify-content: center; background: #eee; font-weight: 700; font-size: 18px; }    
    select.provider-select{ border:none; outline:none; font-weight:600; background:transparent; cursor:pointer; font-size:13px; width:100%; }    

    .card-inner { padding: 18px; }    
    .toggle { width: 52px; height: 30px; border-radius: 999px; background: #111827; padding: 4px; display: flex; align-items: center; justify-content: flex-end; }    
    .toggle .knob { width: 22px; height: 22px; border-radius: 999px; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }    

    .pay-btn { background: var(--primary); color: white; padding: 10px 22px; border-radius: 999px; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; min-width: 80px; }    
    .pay-btn:hover{ filter: brightness(90%); }    

    .thin-hr { height: 1px; background: #e6e9ef; margin-top: 16px; }    

    /* Custom Amount Input - LINE STYLE */    
    .amount-input {    
      border: none;    
      border-bottom: 2px solid #e5e7eb;    
      padding: 6px 0;    
      width: 100%;    
      font-weight: 600;    
      text-align: right;    
      outline: none;    
      font-size: 16px;    
    }    
    .amount-input:focus { border-bottom-color: var(--primary); }    
    .amount-wrapper { display: flex; align-items: center; gap:6px; margin-top:6px; }    
    .amount-wrapper span { font-weight: bold; font-size: 16px; }
  </style>  
  <style>
/* Hide scrollbar for all browsers */
.scrollbar-hide::-webkit-scrollbar {
    display: none;
}
.scrollbar-hide {
    -ms-overflow-style: none;  /* IE and Edge */
    scrollbar-width: none;  /* Firefox */
}
</style>

</head>

<body>    
<div id="app" class="px-4 max-w-md mx-auto">    
<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Airtime</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

</br>
<!-- Scrollable Banner Flyer Without Card (Using Settings URLs) -->
<div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
    <?php foreach ($banner_slides as $slide): ?>
        <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">
            <img src="<?php echo esc_url($slide); ?>" alt="Flyer Slide" class="w-full h-full object-cover rounded-lg shadow-md">
        </div>
    <?php endforeach; ?>
</div>  

<!-- Recent Airtime -->
<div v-if="recentList.length" class="mt-3">
  <h3 class="font-semibold text-gray-900 mb-3">Recent</h3>

  <div class="flex overflow-x-auto scrollbar-hide gap-3 py-1">

    <div 
      v-for="(item,index) in recentList" 
      :key="index"
      @click="selectRecent(item)"
      class="w-1/4 min-w-[25%] flex-shrink-0 text-center cursor-pointer"
    >

      <!-- Icon -->
      <div :class="[
        'w-10 h-10 mx-auto rounded-full flex items-center justify-center border-2',
        getBg(item.img),
        selectedRecent === item.phone ? 'border-blue-500' : 'border-transparent'
      ]">
        <img :src="item.img" class="w-6 h-6">
      </div>

      <!-- Phone -->
      <p class="text-[11px] mt-1 text-gray-700 truncate">
        {{ item.phone }}
      </p>

    </div>

  </div>
</div>

  <!-- MAIN CARD -->
<div class="mt-4">

  <!-- Choose Amount -->
  <div class="text-black text-sm font-medium mb-3">
    Choose an amount
  </div>

  <!-- Amount Grid -->
  <div class="grid grid-cols-3 gap-2">
    <button 
      v-for="amt in amounts" 
      :key="amt"
      @click="selectAmount(amt)"
      class="topup-btn w-full py-2 text-sm"
      :class="{ selected: phoneAmount == amt }"
    >
      ₦{{ Number(amt).toLocaleString() }}
    </button>
  </div>

  <!-- Amount + Balance -->
  <div class="flex justify-between mt-4 mb-1">
    <div class="text-black text-sm font-medium">
      Amount
    </div>
    <div class="text-xs text-gray-400">
      Balance: ₦<?= number_format($user->balance ?? 0, 2) ?>
    </div>
  </div>

  <!-- Amount Input -->
  <div class="rounded-card card-inner py-3 px-3">
    <input 
      type="number"
      min="50"
      max="50000"
      v-model.number="phoneAmount"
      placeholder="₦0.00"
      class="w-full bg-transparent outline-none text-base text-gray-500"
    />
  </div>

  <!-- Network -->
  <div class="mt-6 mb-3 text-black text-sm font-medium">
    Choose Network
  </div>

  <div class="grid grid-cols-4 gap-2">
    <div 
      v-for="network in networks" 
      :key="network.name"
      @click="selectedProvider = network"
      class="rounded-card py-3 px-2 flex flex-col items-center justify-center cursor-pointer border"
      :class="selectedProvider.name === network.name ? 'border-[var(--primary)] bg-white' : 'border-gray-100'"
    >
      <div :class="['w-9 h-9 rounded-full flex items-center justify-center', getBg(network.img)]">
        <img :src="network.img" class="w-6 h-6 object-contain" />
      </div>

      <span class="text-[11px] font-medium mt-1">
        {{ network.name }}
      </span>
    </div>
  </div>

<!-- Phone -->
<div class="flex justify-between mt-6 mb-1">
  <div class="text-black text-sm font-medium">
    Phone Number
  </div>
  <button @click="pickContact" class="text-[var(--primary)] text-sm font-medium">
    Choose Contact
  </button>
</div>

<div class="rounded-card card-inner py-3 px-3">
  <input 
    v-model="phone"
    @input="autoDetectNetwork"
    placeholder="0801 234 5678"
    maxlength="15"
    class="w-full bg-transparent outline-none text-base text-gray-500"
  />
</div>

  <!-- Pay Button -->
  <button 
    class="mt-5 w-full h-[48px] rounded-xl text-white text-sm font-semibold"
    :style="{ background: 'var(--primary)' }"
    @click="pay"
  >
    Pay
  </button>

<div class="thin-hr mt-5"></div>
</div>
  
<!-- Airtime Service Box -->
<div class="mt-4">
  <h3 class="text-black text-sm font-medium mb-2">Services</h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-1">
    
    <!-- Schedule Topup -->
    <div onclick="window.location.href='/app/schedule-topup';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">Auto Top-up</h4>
      <p class="text-[11px] text-gray-400 mt-1">Set automatic recharge</p>
    </div>

    <!-- Airtime Coupon -->
    <div onclick="window.location.href='/app/recharge-card';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">Recharge Cards</h4>
      <p class="text-[11px] text-gray-400 mt-1">Print recharge vouchers</p>
    </div>

    <!-- Airtime Bulk -->
    <div onclick="window.location.href='#';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">Bulk Airtime</h4>
      <p class="text-[11px] text-gray-400 mt-1">Buy for multiple numbers</p>
    </div>

    <!-- USSD Enquiry -->
    <div onclick="window.location.href='/app/airtime-ussd';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">USSD Codes</h4>
      <p class="text-[11px] text-gray-400 mt-1">Check network short codes</p>
    </div>

  </div>
  <!-- Airtime Service Box -->
<div class="mt-5">
  <h3 class="font-semibold text-gray-900 mb-3"> </h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
</div>
</div>


<script>
const { createApp } = Vue;
createApp({
  data(){
    return {
      phone:'',
      phoneAmount:'',
      saveAsBeneficiary:false,

      // ✅ NEW: recent list
      recentList: [],

      networks:[
        {name:'MTN', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/MTN.png'},
        {name:'AIRTEL', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/AIRTEL.png'},
        {name:'GLO', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/GLO.png'},
        {name:'9MOBILE', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/9MOBILE.png'},
      ],

      selectedProvider:{name:'MTN', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/MTN.png'},
      amounts:[100,200,500,1000,2000,5000],

      // ✅ Track selected recent for UI highlight
      selectedRecent: null,
    };
  },

  mounted(){
    const saved = localStorage.getItem('recent_numbers');
    if(saved){
      this.recentList = JSON.parse(saved);
    }
  },

  methods:{

    /* ✅ ✅ ADDED: NETWORK PREFIX MAP */
    detectNetwork(phone){
      const networks = {
        MTN: ["0803","0806","0703","0706","0810","0813","0814","0816","0903","0906","0913","0916"],
        AIRTEL: ["0802","0808","0708","0812","0701","0902","0907","0901","0912"],
        GLO: ["0805","0807","0705","0811","0815","0905"],
        "9MOBILE": ["0809","0817","0818","0908","0909"]
      };

      if(!phone) return null;

      phone = phone.replace(/\D/g,'');

      if(phone.startsWith("234")){
        phone = "0" + phone.slice(3);
      }

      if(phone.length < 4) return null;

      const prefix = phone.substring(0,4);

      for(const net in networks){
        if(networks[net].includes(prefix)){
          return net;
        }
      }

      return null;
    },

    /* ✅ ✅ ADDED: AUTO SELECT NETWORK */
    autoDetectNetwork(){
      const net = this.detectNetwork(this.phone);

      if(net){
        const found = this.networks.find(n => n.name === net);
        if(found){
          this.selectedProvider = found;
        }
      }
    },

    goBack(){ window.history.back(); },

    showToast(msg,type='info'){
      Toastify({
        text: msg,
        duration: 3000,
        close:true,
        gravity:'top',
        position:'center',
        stopOnFocus:true,
        style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }
      }).showToast();
    },

    showLoading(){
      const overlay=document.createElement('div');
      overlay.id='loadingOverlay';
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
      document.body.appendChild(overlay);
    },

    hideLoading(){
      const overlay=document.getElementById('loadingOverlay');
      if(overlay) overlay.remove();
    },

    toggleSave(){ this.saveAsBeneficiary = !this.saveAsBeneficiary; },

    selectAmount(amount){ this.phoneAmount = amount; },

    saveRecent(){
      if(!this.phone) return;

      let list = JSON.parse(localStorage.getItem('recent_numbers')) || [];
      list = list.filter(item => item.phone !== this.phone);
      list.unshift({
        phone: this.phone,
        img: this.selectedProvider.img
      });
      if(list.length > 12) list = list.slice(0,12);

      localStorage.setItem('recent_numbers', JSON.stringify(list));
      this.recentList = list;
    },

    // ✅ Updated: click to autofill phone AND network + highlight
    selectRecent(item){
      this.phone = item.phone;
      const network = this.networks.find(n => n.img === item.img);
      if(network) this.selectedProvider = network;

      this.selectedRecent = item.phone;

      /* ✅ ADDED: ensure detection runs */
      this.autoDetectNetwork();
    },

    async pickContact() {
      if (!('contacts' in navigator) || !('ContactsManager' in window)) {
        this.showToast('Not supported on this device', 'error');
        return;
      }

      try {
        const contacts = await navigator.contacts.select(['tel'], { multiple: false });

        if (!contacts.length) return;

        let rawNumber = contacts[0].tel ? contacts[0].tel[0] : '';

        if (!rawNumber) {
          this.showToast('No number found', 'error');
          return;
        }

        let cleaned = rawNumber
          .replace(/\s+/g, '')
          .replace(/-/g, '')
          .replace(/\(/g, '')
          .replace(/\)/g, '');

        if (cleaned.startsWith('+234')) {
          cleaned = '0' + cleaned.slice(4);
        } else if (cleaned.startsWith('234')) {
          cleaned = '0' + cleaned.slice(3);
        }

        if (!cleaned.startsWith('0')) {
          cleaned = '0' + cleaned;
        }

        cleaned = cleaned.slice(0, 11);

        this.phone = cleaned;

        /* ✅ ADDED: auto detect after picking contact */
        this.autoDetectNetwork();

      } catch (err) {
        this.showToast('Failed to pick contact', 'error');
      }
    },

    pay(){
      if(!this.phone){ this.showToast('Enter phone number','error'); return; }
      if(!this.selectedProvider.name){ this.showToast('Select provider','error'); return; }
      if(!this.phoneAmount || this.phoneAmount < 50){ this.showToast('Enter valid amount','error'); return; }

      this.showLoading();

      const formData = new FormData();
      formData.append('action','pulsepoint_airtime_purchase');
      formData.append('network', this.selectedProvider.name);
      formData.append('phone', this.phone);
      formData.append('amount', this.phoneAmount);
      formData.append('reference','');

      fetch("<?= admin_url('admin-ajax.php') ?>", { method:'POST', body:formData })
      .then(res=>res.json())
      .then(res=>{
        this.hideLoading();

        if(res.success){
          this.saveRecent();
          this.showToast('Airtime Top-up Successful 🎉');
          setTimeout(()=>{ window.location.href='/app/success'; },1000);
        } else{
          this.showToast(res.message || 'Purchase failed','error');
        }
      })
      .catch(err=>{
        this.hideLoading();
        this.showToast('Network error','error');
      });
    },

    getBg(img){
      if(!img) return 'bg-gray-100';
      if(img.includes('MTN')) return 'bg-yellow-100';
      if(img.includes('AIRTEL')) return 'bg-pink-100';
      if(img.includes('GLO')) return 'bg-green-100';
      if(img.includes('9MOBILE')) return 'bg-gray-100';
      return 'bg-gray-100';
    }

  }

}).mount('#app');
</script>

<script>lucide.createIcons();</script>  
</body>
</html>