<?php
/**
 * Dashboard loader for Pulsepoint Plugin
 * Upgraded with account_type, status, KYC, and bank account support
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

/* ================= SETTINGS ================= */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#2563eb';
$bank_transfer     = $settings['bank_transfer'] ?? 'disabled';

$banner_slides = [
    $settings['ads1_url'] ?? null,
    $settings['ads2_url'] ?? null,
    $settings['ads3_url'] ?? null,
];

/* ================= USER ================= */
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

$table_users   = $wpdb->prefix . 'pulsepoint_users';
$table_trnx    = $base_prefix . 'trnx';
$table_account = $base_prefix . 'account';

/* ================= FETCH USER ================= */
$user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d",
    $user_id
));

/* ================= USER DATA ================= */
$wallet_balance = $user ? number_format($user->wallet, 2) : '0.00';
$dollar_balance = $user ? number_format($user->dollar, 2) : '0.00';
$referral_balance = $user ? number_format($user->referral_balance, 2) : '0.00';
$firstname      = $user ? esc_html($user->firstname) : 'User';

/* ✅ NEW FIELDS */
$account_type = $user->account_type ?? 'Customer'; // Customer | Agent | API
$status       = isset($user->status) ? (int)$user->status : 0;
$statuskyc    = isset($user->statuskyc) ? (int)$user->statuskyc : 0;

/* ================= STATUS HANDLING ================= */

/* Account Status */
$status_label = $status === 1 ? 'Active' : 'Disabled';
$status_color = $status === 1 ? 'text-white' : 'text-red-500';

/* KYC Level */
$kyc_label = $statuskyc == 1 ? 'Verified' : 'Unverified';
$kyc_color = $statuskyc == 1 ? 'bg-green-400' : 'bg-yellow-400';

/* Account Type Badge */
$account_badge = match ($account_type) {
    'Agent'   => 'bg-purple-100 text-purple-600',
    'API'     => 'bg-blue-100 text-blue-600',
    default   => 'bg-gray-100 text-gray-600',
};

/* ================= FETCH ACCOUNT ================= */
$account = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_account} WHERE user_id = %d ORDER BY id DESC LIMIT 1",
    $user_id
));

$account_number = $account->number ?? '----------';
$account_name   = $account->name ?? $firstname;
$bank_name      = $account->bank ?? 'No Bank';

/* ================= TRANSACTIONS ================= */
$transactions = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_trnx} WHERE user_id = %d ORDER BY id DESC LIMIT 3",
    $user_id
));

/* ================= HELPER ================= */
function truncate_description($desc, $length = 22) {
    $desc = esc_html($desc);
    return strlen($desc) > $length ? substr($desc, 0, $length) . '...' : $desc;
}
?>

<!DOCTYPE html>  
<html lang="en">  
<head>    
<meta charset="UTF-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0">  
<title><?php echo esc_html($platform_name); ?> Wallet UI Clone</title>  

<script src="https://cdn.tailwindcss.com"></script>  
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>  

<style>    
body {    
  background: #f7f8fb;    
  font-family: 'Inter', sans-serif;        
}

/* Card shadow style */
.card {
  background: white;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  border-radius: 16px;
}

/* Force Quick Access icons white */
.quick-access-icon img {
  filter: brightness(0) invert(1);
}

/* Force Hide icon to white */
.hide-btn img {
  filter: brightness(0) invert(1);
}

/* ✅ FIXED: Home icon now follows dynamic color */
.footer-home img {
  filter: none; /* remove orange */
}

.footer-home {
  color: <?php echo $color_hex; ?>;
}
</style>  
</head>

<body>  
<div id="app" class="pb-24">    

<!-- HEADER -->    
<div class="px-4 pt-6 pb-4 flex items-center justify-between">    
  <div class="flex items-center gap-3">    

    <div class="w-10 h-10 rounded-full overflow-hidden">    
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" class="w-full h-full object-cover">    
    </div>    

    <div>    
      <p class="font-semibold text-sm">
        Hi, <?php echo strtolower($firstname); ?>
      </p>    

      <p class="text-xs text-gray-500 flex items-center gap-1">    
        <span class="w-2 h-2 <?php echo $kyc_color; ?> rounded-full"></span>    
        <?php echo $kyc_label; ?>
      </p>    

      

    </div>    

  </div>    

  <img src="https://www.svgrepo.com/show/522763/bell.svg" class="w-5 h-5">    
</div>    


<!-- BALANCE -->
<div class="px-4 -mt-2">  

<div class="text-white p-4 shadow rounded-t-2xl rounded-b-none" style="background-color: <?php echo $color_hex; ?>;">    

  <div class="flex justify-between items-center mb-2">    
    <p class="text-xs text-white/80">Balance</p>    

    <!-- STATUS -->
    <p class="text-xs <?php echo $status_color; ?>">
      Currency: NGN
    </p>    
  </div>    

  <div class="flex items-center justify-between">    

    <div>    
      <h2 class="text-2xl font-bold">
        ₦<?php echo $wallet_balance; ?>
      </h2>    

      <div class="mt-2 inline-flex items-center bg-white/20 text-xs px-3 py-1 rounded-full">    
        Commissions ₦<?php echo $referral_balance; ?>    
      </div>    
    </div>    

    <button class="flex items-center gap-1 text-xs bg-white/20 px-3 py-1 rounded-full hide-btn">    
      <img src="https://www.svgrepo.com/show/528958/eye-closed.svg" class="w-4">    
      Hide    
    </button>    

  </div>    
</div>    


<!-- ACCOUNT -->
<div class="card p-3 flex justify-between items-center mt-0 rounded-t-none rounded-b-2xl">    

  <div>    
    <p class="text-xs text-gray-500">Account Number</p>    

    <div class="flex items-center gap-2 font-semibold">    
      <?php echo $account_number; ?>    
      <img src="https://www.svgrepo.com/show/524469/copy.svg" class="w-4">    
    </div>    

    

  </div>    

  <!-- BANK NAME -->
  <div class="text-sm font-semibold" style="color: <?php echo $color_hex; ?>;">    
    <?php echo $bank_name; ?>    
  </div>    

</div>    

</div>

<!-- QUICK ACCESS -->
<div class="px-4 mt-6">

  <div class="flex justify-between mb-3">
    <h3 class="font-semibold text-gray-700">Quick Access</h3>

    <p class="text-sm cursor-pointer"
       style="color: <?php echo $color_hex; ?>;"
       onclick="window.location.href='/app/services'">
       View More
    </p>
  </div>

  <div class="grid grid-cols-4 gap-5 text-center">

    <?php
    $bank_transfer = $settings['bank_transfer'] ?? 'enabled';

    $quick_access = [];

    // ✅ SHOW Convert ONLY when disabled
    // ✅ OTHERWISE show Transfer
    if ($bank_transfer === 'disabled') {

        $quick_access[] = [
            'icon'  => 'https://www.svgrepo.com/show/470985/arrow-circle-broken-down-right.svg',
            'label' => 'Convert',
            'link'  => '/app/convert'
        ];

    } else {

        $quick_access[] = [
            'icon'  => 'https://www.svgrepo.com/show/499642/send.svg',
            'label' => 'Transfer',
            'link'  => '/app/transfer'
        ];
    }

    // ALWAYS AVAILABLE FEATURES
    $quick_access[] = [
        'icon'  => 'https://www.svgrepo.com/show/380067/phone-call.svg',
        'label' => 'Airtime',
        'link'  => '/app/airtime'
    ];

    $quick_access[] = [
        'icon'  => 'https://www.svgrepo.com/show/532893/wifi.svg',
        'label' => 'Data',
        'link'  => '/app/data'
    ];

    $quick_access[] = [
        'icon'  => 'https://www.svgrepo.com/show/497429/receipt-1.svg',
        'label' => 'Bills',
        'link'  => '/app/services'
    ];
    ?>

    <?php foreach ($quick_access as $item): ?>
      <div class="flex flex-col items-center gap-1 cursor-pointer"
           onclick="window.location.href='<?= $item['link'] ?>'">

        <div class="p-3 rounded-full quick-access-icon"
             style="background-color: <?php echo $color_hex; ?>;">

          <img src="<?php echo $item['icon']; ?>" class="w-5">

        </div>

        <p class="text-xs"><?php echo $item['label']; ?></p>

      </div>
    <?php endforeach; ?>

  </div>
</div>

<?php if (!(!empty($account_number) && $account_number !== '----------' && $statuskyc == 1)): ?>
<div class="px-4 mt-6">

  <?php
    // Determine URL based on progress
    if (empty($account_number) || $account_number === '----------') {
        $href = '/app/fund';
        $progress = '4/6';
        $message = 'Generate your virtual account';
    } elseif ($statuskyc == 0) {
        $href = '/app/customer';
        $progress = '5/6';
        $message = 'Complete KYC';
    }
  ?>

  <a href="<?php echo $href; ?>" class="block">
    <div class="card p-4 flex items-center justify-between hover:bg-gray-50 cursor-pointer transition">
      
      <div class="flex items-center gap-3">

        <div class="w-12 h-12 border-4 rounded-full flex items-center justify-center text-sm font-bold"
             style="border-color: <?php echo $color_hex; ?>; color: <?php echo $color_hex; ?>;">
          <?php echo $progress; ?>
        </div>

        <div>
          <p class="font-semibold text-sm">Complete your Setup</p>
          <p class="text-xs text-gray-500"><?php echo $message; ?></p>
        </div>

      </div>

      <img src="https://img.icons8.com/ios-glyphs/30/000000/chevron-right.png" class="w-4">

    </div>
  </a>

</div>
<?php endif; ?>

<!-- TRANSACTIONS -->
<div class="px-4 mt-6">    
  <div class="flex justify-between items-center mb-3">    
    <h3 class="font-semibold">Recent Transactions</h3>    
    <p class="text-sm cursor-pointer"
   style="color: <?php echo $color_hex; ?>;"
   onclick="window.location.href='/app/transactions'">
   See All
</p>    
  </div>    

  <?php if($transactions): ?>
    <?php foreach($transactions as $txn): ?>

      <?php
        $type = strtolower($txn->type); // credit / debit
        $status = strtolower($txn->status); // success / failed / pending / processing

        // Default from type
        $isCredit = $type === 'credit';
        $sign = $isCredit ? '+' : '-';
        $color = $isCredit ? 'text-green-500' : 'text-red-500';

        // Status overrides
        if ($status === 'failed') {
          $color = 'text-gray-400';
        } elseif ($status === 'pending' || $status === 'processing') {
          $color = 'text-orange-500';
        }

        // Format transaction date
        $txnDate = new DateTime($txn->date ?? $txn->updated_at ?? current_time('mysql'));
        $formattedDate = $txnDate->format('M d, Y g:i A');
      ?>

      <a href="/app/view-transaction?id=<?= esc_attr($txn->id) ?>" class="block">
        <div class="card p-3 flex justify-between items-center rounded-2xl mb-3 hover:shadow-lg transition">
          <div class="flex items-center gap-3">    
            <div class="bg-gray-100 p-2 rounded-full">    
              <img src="https://www.svgrepo.com/show/379273/transaction.svg" class="w-4">    
            </div>    
            <div>    
              <p class="text-sm font-medium"><?= truncate_description($txn->description ?: 'Transaction') ?></p>    
              <p class="text-xs text-gray-400"><?= esc_html($formattedDate) ?></p>    
            </div>    
          </div>    

          <p class="text-sm font-semibold <?= $color ?>">
            <?= $sign ?>₦<?= number_format($txn->amount,2) ?>
          </p>    

        </div>
      </a>

    <?php endforeach; ?>
<?php else: ?>
  <p class="text-gray-400 text-sm">No recent transactions.</p>
<?php endif; ?>
</div>

<!-- FOOTER -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-3">

  <div class="flex flex-col items-center footer-home cursor-pointer" style="color: <?php echo $color_hex; ?>;" onclick="window.location.href='/app/home'">
    <img src="https://www.svgrepo.com/show/529022/home-smile-angle.svg" class="w-5">
    <p class="text-xs">Home</p>
  </div>

  <div class="flex flex-col items-center text-gray-400 cursor-pointer" onclick="window.location.href='/app/transactions'">
    <img src="https://www.svgrepo.com/show/523270/chart-square.svg" class="w-5">
    <p class="text-xs">Transactions</p>
  </div>

  <div class="flex flex-col items-center text-gray-400 cursor-pointer" onclick="window.location.href='/app/services'">
    <img src="https://www.svgrepo.com/show/497333/more-square.svg" class="w-5">
    <p class="text-xs">Services</p>
  </div>

  <div class="flex flex-col items-center text-gray-400 cursor-pointer" onclick="window.location.href='/app/more'">
    <img src="https://www.svgrepo.com/show/499608/grid-aspect-ratio.svg" class="w-5">
    <p class="text-xs">More</p>
  </div>

</div>
</div>  

<script>    
const { createApp } = Vue    
createApp({}).mount('#app')    
</script> 

<script>
let isNGN = localStorage.getItem('currency') !== 'USD';
let isHidden = localStorage.getItem('hidden') === 'true';

// --- Balance Card Elements ---
const currencyEl = document.querySelector('p.text-xs.<?php echo $status_color; ?>'); // Currency display
const balanceEl = document.querySelector('.text-2xl.font-bold'); // Balance <h2>
const commissionEl = document.querySelector('.inline-flex.items-center'); // Commissions div
const hideBtn = document.querySelector('.hide-btn'); // Hide button
const hideIcon = hideBtn.querySelector('img'); // Eye icon inside button

// --- Account Section Elements ---
const accountDiv = document.querySelector('.card.p-3.flex.justify-between.items-center'); // Account card
const accountNumberEl = accountDiv.querySelector('.flex.items-center.gap-2.font-semibold'); // Account number + icon
const copyIcon = accountNumberEl.querySelector('img'); // Copy icon

// Backend values
const nairaBalance = "<?php echo $wallet_balance; ?>";
const dollarBalance = "<?php echo $dollar_balance; ?>";
const nairaCommission = "<?php echo $referral_balance; ?>";
const accountNumber = "<?php echo $account_number; ?>";

// --- Update Balance UI ---
function updateUI() {
  // Currency switch
  const balanceText = isNGN ? '₦' + nairaBalance : '$' + dollarBalance;
  const commissionText = 'Commissions ₦' + nairaCommission;

  // Update currency display
  currencyEl.innerText = 'Currency: ' + (isNGN ? 'NGN' : 'USD');
  localStorage.setItem('currency', isNGN ? 'NGN' : 'USD');

  // Hide/show logic
  if (isHidden) {
    balanceEl.innerText = '****';
    commissionEl.innerText = 'Commissions ****';
    hideIcon.src = 'https://www.svgrepo.com/show/528958/eye-closed.svg'; // Eye closed
  } else {
    balanceEl.innerText = balanceText;
    commissionEl.innerText = commissionText;
    hideIcon.src = 'https://www.svgrepo.com/show/521143/eye-hide.svg'; // Eye open
  }

  localStorage.setItem('hidden', isHidden);
}

// --- Currency toggle ---
currencyEl.addEventListener('click', () => {
  isNGN = !isNGN;
  updateUI();
});

// --- Hide toggle ---
hideBtn.addEventListener('click', () => {
  isHidden = !isHidden;
  updateUI();
});

// --- Copy account number ---
copyIcon.addEventListener('click', () => {
  navigator.clipboard.writeText(accountNumber)
    .then(() => {
      // Optional: show temporary tooltip or change icon
      copyIcon.src = 'https://www.svgrepo.com/show/529489/check-read.svg'; // Success icon
      setTimeout(() => {
        copyIcon.src = 'https://www.svgrepo.com/show/524469/copy.svg'; // Restore original
      }, 1500);
    })
    .catch(err => console.error('Failed to copy: ', err));
});

// --- Initialize ---
updateUI();
</script>

</body>  
</html>