<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];

foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">

<title>Education</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

<style>
:root{
  --app-bg:#f7f8fb;
  --card-bg:#fff;
  --primary:<?= $color_hex ?>;
}

html,body,#app{
  min-height:100%;
  background:var(--app-bg);
  margin:0;
  padding:0;
  font-family:Inter;
}

/* AIRTIME STYLE CONTAINER */
#app{
  padding: 0 16px;
  max-width:420px;
  margin:auto;
}

/* HEADER FIX (NO EXTRA SPACE) */
.header{
  margin-top:12px;
  display:flex;
  justify-content:space-between;
  align-items:center;
}

/* EXAM SCROLL (SMALL SQUARE LIKE RECENT AIRTIME) */
.exam-scroll{
  display:flex;
  gap:10px;
  overflow-x:auto;
  padding:6px 0;
}

.exam-scroll::-webkit-scrollbar{display:none;}

.exam-box{
  min-width:92px;
  height:100px;
  border-radius:14px;
  background:#fff;
  border:1.5px solid rgba(0,0,0,0.06);
  display:flex;
  flex-direction:column;
  justify-content:center;
  align-items:center;
  cursor:pointer;
  transition:.2s;
  flex-shrink:0;
}

.exam-box.selected{
  border-color:var(--primary);
  background:rgba(0,0,0,0.02);
}

.exam-box img{
  width:34px;
  height:34px;
  margin-bottom:4px;
}

.pay-btn{
  background:var(--primary);
  color:#fff;
  padding:12px;
  border-radius:14px;
  width:100%;
  font-weight:600;
  margin-top:16px;
}

.thin-hr{
  height:1px;
  background:#e6e9ef;
  margin-top:16px;
}
</style>
</head>

<body>

<div id="app" class="px-4 max-w-md mx-auto">
</br>
<!-- HEADER -->
<div class="header">
  <div class="flex gap-2 items-center cursor-pointer" onclick="history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" class="w-6 h-6">
    <span class="font-semibold">Education</span>
  </div>

  <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg" class="w-5 h-5">
</div>
</br>
<!-- BANNER -->
<div class="overflow-x-auto whitespace-nowrap py-2">
  <?php foreach ($banner_slides as $slide): ?>
    <div class="inline-block mr-3 w-64 h-24">
      <img src="<?= esc_url($slide) ?>" class="w-full h-full object-cover rounded-lg shadow-md">
    </div>
  <?php endforeach; ?>
</div>

<!-- EXAM SCROLL -->
<div class="mt-2">
  <div class="text-sm font-semibold mb-2">Choose Exam</div>

  <div class="exam-scroll">

    <div
      v-for="plan in plans"
      :key="plan.id"
      class="exam-box"
      :class="{selected:selectedPlan && selectedPlan.id===plan.id}"
      @click="selectPlan(plan)"
    >
      <img :src="getExamLogo(plan.servicename || plan.name)">
      <div class="text-xs font-semibold text-center">
        {{ plan.servicename || plan.name }}
      </div>
      <div class="text-[11px] text-gray-500">
        ₦{{ plan.price }}
      </div>
    </div>

  </div>
</div>

<!-- QUANTITY -->
<div class="mt-3 bg-white rounded-lg p-3">
  <div class="flex justify-between text-sm">
    <span>Quantity</span>
    <span class="text-gray-400">Balance: ₦<?= number_format($user->balance ?? 0, 2) ?></span>
  </div>

  <input type="number" v-model.number="quantity"
    class="w-full mt-2 outline-none bg-transparent text-gray-600">
</div>

<!-- PAY -->
<button class="pay-btn" @click="purchase">
  Pay
</button>

<div class="thin-hr mt-5"></div>

<!-- Education Service Box (AIRTIME STYLE) -->
<div class="mt-4">
  <h3 class="text-black text-sm font-medium mb-2">Education Services</h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-1">

    <!-- Result Checker -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="openService('result_checker')">

      <h4 class="text-xs font-medium text-black">Result Checker</h4>
      <p class="text-[11px] text-gray-400 mt-1">Check WAEC/NECO results</p>
    </div>

    <!-- Admission Status -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="openService('admission')">

      <h4 class="text-xs font-medium text-black">Admission</h4>
      <p class="text-[11px] text-gray-400 mt-1">Check JAMB admission</p>
    </div>

    <!-- Scholarship -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="openService('scholarship')">

      <h4 class="text-xs font-medium text-black">Scholarship</h4>
      <p class="text-[11px] text-gray-400 mt-1">Find scholarships</p>
    </div>

    <!-- Past Questions -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="openService('past_questions')">

      <h4 class="text-xs font-medium text-black">Past Questions</h4>
      <p class="text-[11px] text-gray-400 mt-1">Study materials access</p>
    </div>

    <!-- CBT Practice -->
    <div class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm cursor-pointer"
         @click="openService('cbt')">

      <h4 class="text-xs font-medium text-black">CBT Practice</h4>
      <p class="text-[11px] text-gray-400 mt-1">Mock exams online</p>
    </div>

  </div>
</div>

<script>
const { createApp } = Vue;

createApp({
  data(){
    return{
      plans:[],
      selectedPlan:null,
      quantity:1
    }
  },

  mounted(){
    this.fetchPlans();
  },

  methods:{

    getExamLogo(name){
      name=(name||'').toLowerCase();

      if(name.includes('waec'))
        return '/wp-content/plugins/pulsepoint-bill-payment/assets/img/waec.png';

      if(name.includes('neco'))
        return '/wp-content/plugins/pulsepoint-bill-payment/assets/img/neco.png';

      if(name.includes('jamb'))
        return '/wp-content/plugins/pulsepoint-bill-payment/assets/img/jamb.png';
     
      if(name.includes('nabteb'))
        return '/wp-content/plugins/pulsepoint-bill-payment/assets/img/nabteb.png';

      return 'https://cdn-icons-png.flaticon.com/512/4727/4727496.png';
    },

    selectPlan(plan){
      this.selectedPlan = plan;
    },

    fetchPlans(){
      fetch("<?= admin_url('admin-ajax.php'); ?>?action=pulsepoint_get_education")
      .then(r=>r.json())
      .then(d=>this.plans=d||[]);
    },

    showToast(msg,type='success'){
      Toastify({
        text:msg,
        duration:3000,
        gravity:"top",
        position:"center",
        style:{
          background:type==='error'?'#ff3860':'green'
        }
      }).showToast();
    },

    showLoading(){
      const el=document.createElement('div');
      el.style='position:fixed;inset:0;background:rgba(255,255,255,.4);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;z-index:9999';
      el.innerHTML=`<b style="color:<?= $color_hex ?>">Processing...</b>`;
      document.body.appendChild(el);
    },

    purchase(){
      if(!this.selectedPlan){
        this.showToast("Select exam","error");
        return;
      }

      this.showLoading();

      const fd=new FormData();
      fd.append('action','pulsepoint_education_purchase');
      fd.append('plan',this.selectedPlan.id);
      fd.append('quantity',this.quantity);

      fetch("<?= admin_url('admin-ajax.php'); ?>",{method:'POST',body:fd})
      .then(r=>r.json())
      .then(res=>{
        if(res.success){
          this.showToast("Success 🎉");

          setTimeout(()=>{
            window.location.href="/app/success";
          },1000);

        }else{
          this.showToast(res.message||"Failed","error");
        }
      });
    }

  }
}).mount('#app');
</script>

</body>
</html>