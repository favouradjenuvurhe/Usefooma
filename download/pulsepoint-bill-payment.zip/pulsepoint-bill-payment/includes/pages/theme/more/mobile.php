<?php  
if (!defined('ABSPATH')) exit;  

global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : 'User';
$lastname  = $user ? esc_html($user->lastname) : '';
$initials  = strtoupper(substr($firstname,0,1) . substr($lastname,0,1));
$fullname  = trim("$firstname $lastname");

/* NEW FIELDS */
$account_type = $user->account_type ?? 'Customer';
$status       = isset($user->status) ? (int)$user->status : 0;
$statuskyc    = isset($user->statuskyc) ? (int)$user->statuskyc : 0;

/* STATUS */
$status_label = $status === 1 ? 'Active' : 'Disabled';
$status_color = $status === 1 ? 'text-green-500' : 'text-red-500';

$kyc_label = $statuskyc == 1 ? 'Verified' : 'Unverified';
$kyc_color = $statuskyc == 1 ? 'bg-green-400' : 'bg-yellow-400';

$account_badge = match ($account_type) {
    'Agent'   => 'bg-purple-100 text-purple-600',
    'API'     => 'bg-blue-100 text-blue-600',
    default   => 'bg-gray-100 text-gray-600',
};
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= esc_html($platform_name) ?> - More UI</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

<style>
:root {
  --primary: <?= esc_attr($color_hex) ?>;
}

* {
  box-sizing: border-box;
}

body {
  background: #f2f2f2;
  font-family: ui-sans-serif, system-ui;
  margin: 0;
  overflow-x: hidden;
  padding-bottom: 110px; /* FIXED bottom nav spacing */
}

/* FIX: consistent spacing system */
.section {
  margin-bottom: 14px;
}

.card {
  background: white;
  border-radius: 20px;
  padding: 16px;
  box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

.icon {
  width: 16px;
  height: 16px;
}

/* Toggle */
.toggle {
  width: 40px;
  height: 22px;
  border-radius: 999px;
  background: #d1d5db;
  position: relative;
  cursor: pointer;
  transition: background 0.2s;
}

.toggle.active {
  background: var(--primary);
}

.toggle-knob {
  width: 18px;
  height: 18px;
  background: white;
  border-radius: 50%;
  position: absolute;
  top: 2px;
  left: 2px;
  transition: left 0.2s;
}

.toggle.active .toggle-knob {
  left: 20px;
}

/* FIX: clean row spacing */
.row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
}

.row + .row {
  border-top: 1px solid #f1f1f1;
}
</style>
</head>

<body>

<div id="app" class="max-w-md mx-auto px-4 pt-3">

  <!-- PROFILE -->
<div class="section flex items-center gap-3">

  <div class="w-12 h-12 rounded-full overflow-hidden border border-gray-200">
    <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png"
         class="w-full h-full object-cover"
         alt="Profile">
  </div>

  <div>
    <p class="font-semibold text-gray-800"><?= $fullname ?></p>
    <div class="flex items-center gap-1 mt-1 text-xs bg-gray-100 px-2 py-1 rounded-full w-fit">
      <img src="https://www.svgrepo.com/show/529201/shield-user.svg" class="icon">
      <?= $kyc_label ?>
    </div>
  </div>

</div>

<!-- UPGRADE -->
<div class="section">
  <div
    onclick="window.location.href='/app/customer';"
    class="text-white px-4 py-3 rounded-xl flex justify-between items-center cursor-pointer"
    style="background: var(--primary);">

    <span class="text-sm font-medium">Upgrade Your Account</span>

    <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon">

  </div>
</div>

  <!-- PROFILE SETTINGS -->
  <div class="section card">

    <div class="row" onclick="window.location.href='/app/profile-edit'">
      <span class="text-sm">Profile Information</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

    <div class="row" onclick="window.location.href='/app/business-info'">
      <span class="text-sm">Business Information</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

  </div>

  <!-- SECURITY -->
  <div class="section card">

    <div class="row" onclick="window.location.href='/app/devices'">
      <span class="text-sm">Devices & Terminals</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

    <div class="row" onclick="window.location.href='/app/change-pin'">
      <span class="text-sm">Change Transaction PIN</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

    <div class="row" onclick="window.location.href='/app/change-password'">
      <span class="text-sm">Change Password</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

  </div>

  <!-- NOTIFICATION (FIXED ALIGNMENT) -->
  <div class="section card">

    <div class="row">
      <span class="text-sm">Notification</span>

      <div :class="['toggle', notification && 'active']"
           @click="notification = !notification">
        <div class="toggle-knob"></div>
      </div>
    </div>

  </div>

  <!-- SUPPORT -->
  <div class="section card">

    <div class="row" onclick="window.location.href='/app/support'">
      <span class="text-sm">Customer Service</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

    <div class="row" onclick="window.location.href='/app/refer'">
      <span class="text-sm">Refer a friend</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

    <div class="row" onclick="window.location.href='/privacy-policy'">
      <span class="text-sm">Privacy Policy</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

    <div class="row" onclick="window.location.href='/app/logout'">
      <span class="text-sm text-red-500">Logout</span>
      <img src="https://www.svgrepo.com/show/521477/arrow-next.svg" class="icon opacity-50">
    </div>

  </div>

</div>

<!-- Bottom Nav (FIXED SAFE SPACE) -->
<div class="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-3">

  <div class="flex flex-col items-center text-gray-400 cursor-pointer" onclick="window.location.href='/app/home'">
    <img src="https://www.svgrepo.com/show/529022/home-smile-angle.svg" class="w-5">
    <span class="text-xs">Home</span>
  </div>

  <div class="flex flex-col items-center text-gray-400 cursor-pointer" onclick="window.location.href='/app/transactions'">
    <img src="https://www.svgrepo.com/show/523270/chart-square.svg" class="w-5">
    <span class="text-xs">Transactions</span>
  </div>

  <div class="flex flex-col items-center text-gray-400 cursor-pointer" onclick="window.location.href='/app/services'">
    <img src="https://www.svgrepo.com/show/497333/more-square.svg" class="w-5">
    <span class="text-xs">Services</span>
  </div>

  <div class="flex flex-col items-center cursor-pointer" style="color: var(--primary);" onclick="window.location.href='/app/more'">
    <img src="https://www.svgrepo.com/show/499608/grid-aspect-ratio.svg" class="w-5">
    <span class="text-xs font-medium">More</span>
  </div>

</div>

<script>
const { createApp } = Vue;

createApp({
  data() {
    return {
      notification: false
    }
  }
}).mount('#app');
</script>

</body>
</html>