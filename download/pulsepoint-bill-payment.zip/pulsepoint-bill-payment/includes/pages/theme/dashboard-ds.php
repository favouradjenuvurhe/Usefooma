<?php
/**
 * Dashboard loader for Pulsepoint Plugin
 * Upgraded with account_type, status, KYC, and bank account support
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

/* ================= SETTINGS ================= */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#2563eb';

$banner_slides = [
    $settings['ads1_url'] ?? null,
    $settings['ads2_url'] ?? null,
    $settings['ads3_url'] ?? null,
];

/* ================= USER ================= */
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

$table_users   = $wpdb->prefix . 'pulsepoint_users';
$table_trnx    = $base_prefix . 'trnx';
$table_account = $base_prefix . 'account';

/* ================= FETCH USER ================= */
$user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d",
    $user_id
));

/* ================= USER DATA ================= */
$wallet_balance = $user ? number_format($user->wallet, 2) : '0.00';
$dollar_balance = $user ? number_format($user->dollar, 2) : '0.00';
$referral_balance = $user ? number_format($user->referral_balance, 2) : '0.00';
$firstname      = $user ? esc_html($user->firstname) : 'User';
$lastname      = $user ? esc_html($user->lastname) : 'User';

// build initials safely
if (!empty($firstname) && !empty($lastname)) {
    $firstLetter = strtoupper($firstname[0]);
    $lastLetter  = strtoupper($lastname[0]);
    $avatarText  = $firstLetter . $lastLetter;
} elseif (!empty($firstname)) {
    $avatarText = strtoupper($firstname[0]);
} else {
    $avatarText = 'US';
}

/* âœ… NEW FIELDS */
$account_type = $user->account_type ?? 'Customer'; // Customer | Agent | API
$status       = isset($user->status) ? (int)$user->status : 0;
$statuskyc    = isset($user->statuskyc) ? (int)$user->statuskyc : 0;

/* ================= STATUS HANDLING ================= */

/* Account Status */
$status_label = $status === 1 ? 'Active' : 'Disabled';
$status_color = $status === 1 ? 'text-white' : 'text-red-500';

/* KYC Level */
$kyc_label = $statuskyc == 1 ? 'Verified' : 'Unverified';
$kyc_color = $statuskyc == 1 ? 'bg-green-400' : 'bg-yellow-400';

/* Account Type Badge */
$account_badge = match ($account_type) {
    'Agent'   => 'bg-purple-100 text-purple-600',
    'API'     => 'bg-blue-100 text-blue-600',
    default   => 'bg-gray-100 text-gray-600',
};

/* ================= FETCH ACCOUNT ================= */
$account = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_account} WHERE user_id = %d ORDER BY id DESC LIMIT 1",
    $user_id
));

$account_number = $account->number ?? '----------';
$account_name   = $account->name ?? $firstname;
$bank_name      = $account->bank ?? 'No Bank';

/* ================= TRANSACTIONS ================= */
$transactions = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_trnx} WHERE user_id = %d ORDER BY id DESC LIMIT 3",
    $user_id
));

/* ================= HELPER ================= */
function truncate_description($desc, $length = 22) {
    $desc = esc_html($desc);
    return strlen($desc) > $length ? substr($desc, 0, $length) . '...' : $desc;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Peplepay Dashboard</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

<style>
.icon-white {
  filter: brightness(0) invert(1);
}

body {
  background: #0a0a0a;
  overflow-x: hidden;
}
</style>
</head>

<body class="text-white">

<div id="app" class="flex min-h-screen">

  <!-- LEFT SIDEBAR (DESKTOP) -->
  <div class="hidden lg:flex lg:flex-col w-64 bg-[#0f0f0f] border-r border-gray-800 p-5">

    <div class="text-2xl font-bold mb-10">
      <span style="color:#775bfe;">Peple</span>pay
    </div>

    <div class="space-y-4 text-gray-400">

      <div class="flex items-center gap-3 cursor-pointer hover:text-white">
        <img src="https://www.svgrepo.com/show/530047/wallet-money.svg" class="w-5 h-5 icon-white"/>
        Dashboard
      </div>

      <div class="flex items-center gap-3 cursor-pointer hover:text-white">
        <img src="https://www.svgrepo.com/show/529468/chart-square.svg" class="w-5 h-5 icon-white"/>
        Bills
      </div>

      <div class="flex items-center gap-3 cursor-pointer hover:text-white">
        <img src="https://www.svgrepo.com/show/414225/win.svg" class="w-5 h-5 icon-white"/>
        Gigs
      </div>

      <div class="flex items-center gap-3 cursor-pointer hover:text-white">
        <img src="https://www.svgrepo.com/show/529896/smile-circle.svg" class="w-5 h-5 icon-white"/>
        Profile
      </div>

    </div>
  </div>

  <!-- MAIN CONTENT -->
  <div class="flex-1 p-6 lg:p-10">

    <!-- TOP BAR -->
    <div class="flex justify-between items-center mb-8">

      <h1 class="text-2xl font-semibold">Dashboard</h1>

      <div class="flex items-center gap-4">
        <img src="https://www.svgrepo.com/show/528866/bell.svg" class="w-6 h-6 icon-white"/>

        <div class="w-10 h-10 rounded-full bg-gray-300 text-black flex items-center justify-center font-bold">
          <?= $avatarText ?>
        </div>
      </div>

    </div>

    <!-- BALANCE CARD -->
    <div class="bg-[#111] rounded-2xl p-6 mb-8 border border-gray-800">

      <p class="text-gray-400">Account Balance</p>
      <h2 class="text-4xl font-bold mt-2">₦<?= $wallet_balance ?></h2>

      <div class="flex gap-4 mt-6">

        <button onclick="window.location.href='/app/fund'"
          class="flex-1 bg-[#775bfe] py-3 rounded-xl font-semibold hover:opacity-90">
          Add Money
        </button>

        <button onclick="window.location.href='/app/transfer'"
          class="flex-1 bg-gray-800 py-3 rounded-xl text-gray-300 hover:bg-gray-700">
          Transfer
        </button>

      </div>
    </div>

    <!-- GRID LAYOUT -->
    <div class="grid lg:grid-cols-3 gap-8">

      <!-- LEFT COLUMN -->
      <div class="lg:col-span-2 space-y-8">

        <!-- PAY BILLS -->
        <div>
          <h3 class="text-xl font-semibold mb-4">Pay Bills</h3>

          <div class="space-y-4">

            <!-- ITEM -->
            <a href="/app/data" class="block bg-[#111] p-4 rounded-xl hover:bg-[#1a1a1a] border border-gray-800">
              Buy Data
            </a>

            <a href="/app/airtime" class="block bg-[#111] p-4 rounded-xl hover:bg-[#1a1a1a] border border-gray-800">
              Buy Airtime
            </a>

            <a href="/app/recharge-card" class="block bg-[#111] p-4 rounded-xl hover:bg-[#1a1a1a] border border-gray-800">
              Recharge Card
            </a>

            <a href="/app/cable" class="block bg-[#111] p-4 rounded-xl hover:bg-[#1a1a1a] border border-gray-800">
              TV Subscription
            </a>

          </div>
        </div>

      </div>

      <!-- RIGHT COLUMN -->
      <div class="space-y-6">

        <!-- TRANSACTIONS -->
        <div class="bg-[#111] p-5 rounded-2xl border border-gray-800">

          <h3 class="text-lg font-semibold mb-4">Recent Transactions</h3>

          <div class="space-y-4">

            <?php if(!empty($transactions)): ?>
              <?php foreach($transactions as $txn): ?>

                <?php
                  $type = strtolower($txn->type ?? '');
                  $status = strtolower($txn->status ?? '');

                  $isCredit = $type === 'credit';
                  $sign = $isCredit ? '+' : '-';

                  if ($status === 'failed') {
                    $color = 'text-gray-400';
                  } elseif ($status === 'pending' || $status === 'processing') {
                    $color = 'text-orange-500';
                  } elseif ($isCredit) {
                    $color = 'text-green-500';
                  } else {
                    $color = 'text-red-500';
                  }

                  $desc = $txn->description ?: 'Transaction';
                  if (strlen($desc) > 25) {
                    $desc = substr($desc, 0, 22) . '...';
                  }

                  $amount = number_format($txn->amount ?? 0, 2);
                ?>

                <div class="flex justify-between items-center">

                  <div>
                    <p class="text-sm font-medium"><?= htmlspecialchars($desc) ?></p>
                    <p class="text-xs text-gray-500">Just now</p>
                  </div>

                  <p class="text-sm font-semibold <?= $color ?>">
                    <?= $sign ?>₦<?= $amount ?>
                  </p>

                </div>

              <?php endforeach; ?>
            <?php else: ?>
              <p class="text-gray-500">No transactions</p>
            <?php endif; ?>

          </div>

        </div>

      </div>

    </div>

  </div>

</div>

</body>
</html>