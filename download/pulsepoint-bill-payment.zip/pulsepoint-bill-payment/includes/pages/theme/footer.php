<?php if (!defined('ABSPATH')) exit; ?>

<?php
$current = $_SERVER['REQUEST_URI'];

function is_active($path){
    return strpos($_SERVER['REQUEST_URI'], $path) !== false;
}
?>

<!-- BOTTOM NAV -->
<div class="bottom-nav px-6 py-2 flex items-center justify-between">

  <!-- HOME -->
  <a href="/app/dashboard/" class="flex flex-col items-center gap-1">
    <div class="rounded-full p-3 <?= is_active('/app/dashboard') ? 'shadow-lg' : '' ?>"
         style="<?= is_active('/app/dashboard') ? "background-color:$color_hex;color:#fff;" : '' ?>">
      <i data-lucide="home" class="w-5 h-5"></i>
    </div>
    <div class="text-xs">Home</div>
  </a>

  <!-- REFER -->
  <a href="/app/refer/" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full <?= is_active('/app/refer') ? 'shadow-lg' : '' ?>"
         style="<?= is_active('/app/refer') ? "background-color:$color_hex;color:#fff;" : '' ?>">
      <i data-lucide="send" class="w-5 h-5"></i>
    </div>
  </a>

  <!-- SUPPORT -->
  <a href="/app/support/" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full <?= is_active('/app/support') ? 'shadow-lg' : '' ?>"
         style="<?= is_active('/app/support') ? "background-color:$color_hex;color:#fff;" : '' ?>">
      <i data-lucide="headphones" class="w-5 h-5"></i>
    </div>
  </a>

  <!-- PROFILE -->
  <a href="/app/profile/" class="flex flex-col items-center gap-1">
    <div class="p-3 rounded-full <?= is_active('/app/profile') ? 'shadow-lg' : '' ?>"
         style="<?= is_active('/app/profile') ? "background-color:$color_hex;color:#fff;" : '' ?>">
      <i data-lucide="user" class="w-5 h-5"></i>
    </div>
  </a>

</div>

<script>
lucide.createIcons();

// balance toggle
const bal = document.getElementById('balanceText');
const eye = document.getElementById('eyeToggle');

if(bal && eye){
const real = bal.textContent;
let show = false;

eye.onclick = () => {
  show = !show;
  bal.textContent = show ? real : 'NGN ****';
  eye.setAttribute('data-lucide', show ? 'eye' : 'eye-off');
  lucide.createIcons();
};
}
</script>

</body>
</html>