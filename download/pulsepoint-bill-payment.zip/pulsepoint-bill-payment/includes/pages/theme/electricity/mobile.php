<?php
/**
 * Electricity Purchase Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner flyer image URLs
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

// Get current user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';

// Dynamic Disco list from bill table
$disco_rows = $wpdb->get_results("SELECT DISTINCT provider, details FROM {$base_prefix}bill");
$discos = [];
foreach ($disco_rows as $row) {
    // Try to get logo image from details field (assume JSON or a known mapping)
    $logo_path = '/wp-content/plugins/pulsepoint-bill-payment/assets/img/' . strtoupper($row->details) . '.png';
    $discos[] = [
        'name' => $row->details,
        'img'  => file_exists(ABSPATH . $logo_path) ? $logo_path : '/wp-content/plugins/pulsepoint-bill-payment/assets/img/default.png'
    ];
}

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
  <title>Electricity Purchase - <?= esc_html($platform_name) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>
    :root{
      --app-bg: #f7f8fb;
      --card-bg: #ffffff;
      --muted: #6b7280;
      --primary: <?= $color_hex ?>;
    }
    html, body, #app { min-height: 100%; background: var(--app-bg); }
    body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
    .rounded-card{ border-radius:14px; background:var(--card-bg); }
    .topup-btn{ border-radius:12px; border:1.5px solid rgba(99,102,241,0.08); padding:14px 18px; min-width:88px; text-align:center; font-weight:600; background:transparent; cursor:pointer; transition:all 0.2s; }
    .topup-btn.selected{ background: var(--primary); color:white; border-color: var(--primary); }
    .topup-btn:hover{ background: rgba(37,99,235,0.08); border-color: rgba(37,99,235,0.2); }
    .muted { color: var(--muted); }
    .provider-row{ display:flex; align-items:center; gap:8px; width:100%; }
    .provider-logo{ width:100px; height:50px; border-radius:10px; display:flex; align-items:center; justify-content:center; background:#eee; font-weight:700; font-size:18px; }
    select.provider-select{ border:none; outline:none; font-weight:600; background:transparent; cursor:pointer; font-size:13px; width:100%; }
    .card-inner { padding:18px; }
    .pay-btn { background: var(--primary); color:white; padding:10px 22px; border-radius:999px; font-weight:600; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; min-width:80px; }
    .thin-hr { height:1px; background:#e6e9ef; margin-top:16px; }
    .network-card{ cursor:pointer; padding:8px; border:1px solid #e5e7eb; border-radius:12px; text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; transition:all 0.2s; }
    .network-card.active{ border-color: var(--primary); background: rgba(37,99,235,0.1); }
  </style>
</head>
<body>
<div id="app" class="px-4 max-w-md mx-auto">

    <!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Electricity</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

  <!-- Banner Flyers -->
  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2 mt-4">
    <?php foreach ($banner_slides as $slide): ?>
      <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">
        <img src="<?php echo esc_url($slide); ?>" alt="Flyer Slide" class="w-full h-full object-cover rounded-lg shadow-md">
      </div>
    <?php endforeach; ?>
  </div>

  <!-- MAIN CARD -->
  <div class="mt-6 rounded-card p-4 border border-gray-200 shadow-sm">

    <div class="muted font-semibold mb-2">Select Disco</div>

    <div class="rounded-card card-inner flex items-center gap-3 border border-gray-100">
      <div class="provider-row w-full flex items-center gap-2">
        <div class="flex items-center gap-2" style="flex:35%">
          <div class="provider-logo">
            <img :src="selectedDisco.img" :alt="selectedDisco.name" class="w-8 h-8 rounded" />
          </div>
          <select v-model="selectedDisco" class="provider-select w-full" @change="onDiscoChange">
            <option v-for="disco in discos" :key="disco.name" :value="disco">
              {{ disco.name }}
            </option>
          </select>
        </div>

        <input v-model="meterNumber" placeholder="Enter Meter Number"
               class="bg-transparent outline-none border-b border-gray-300 pb-1 w-full"
               style="flex:65%" />
      </div>
    </div>

    <!-- Meter Type -->
    <div class="mt-3">
      <label class="font-semibold text-sm">Meter Type</label>
      <select v-model="meterType" class="w-full mt-1 p-2 rounded border border-gray-300">
        <option value="">Select Meter Type</option>
        <option value="prepaid">Prepaid</option>
        <option value="postpaid">Postpaid</option>
      </select>
    </div>

    <!-- Amount -->
    <div class="mt-3">
      <label class="font-semibold text-sm">Amount</label>
      <input v-model="amount" type="number" placeholder="Enter Amount" class="w-full mt-1 p-2 rounded border border-gray-300"/>
    </div>

    <!-- Pay button -->
    <div class="mt-5 flex flex-col sm:flex-row items-center gap-2">
      <button class="pay-btn w-full sm:w-auto mt-2 sm:mt-0" @click="payElectricity">Pay</button>
    </div>

    <div class="thin-hr"></div>
  </div>



<script>
const { createApp } = Vue;

createApp({
  data(){
    return {
      discos: <?= json_encode($discos) ?>,
      selectedDisco: <?= json_encode($discos[0]) ?>,
      meterType:'',
      meterNumber:'',
      amount:'',
      bypass:false,
      requestId:'',
    }
  },
  methods:{
    goBack(){ window.history.back(); },

    showLoading(){
      const overlay=document.createElement('div');
      overlay.id='loadingOverlay';
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
      document.body.appendChild(overlay);
    },

    hideLoading(){
      const overlay=document.getElementById('loadingOverlay');
      if(overlay) overlay.remove();
    },

    showToast(msg,type='info'){
      Toastify({
        text: msg,
        duration: 3000,
        close:true,
        gravity:'top',
        position:'center',
        stopOnFocus:true,
        style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }
      }).showToast();
    },

    onDiscoChange(){
      this.amount = '';
    },

    payElectricity(){
      if(!this.meterNumber){ this.showToast('Enter meter number','error'); return; }
      if(!this.meterType){ this.showToast('Select meter type','error'); return; }
      if(!this.amount){ this.showToast('Enter amount','error'); return; }

      this.showLoading();
      this.requestId = `ELEC${Date.now()}${Math.floor(Math.random()*9000+1000)}`;

      const formData = new FormData();
      formData.append('action','pulsepoint_electricity_purchase');
      formData.append('disco', this.selectedDisco.name);
      formData.append('meter_type', this.meterType);
      formData.append('meter_number', this.meterNumber);
      formData.append('amount', this.amount);
      formData.append('bypass', this.bypass ? 1 : 0);
      formData.append('request_id', this.requestId);

      fetch("<?= admin_url('admin-ajax.php') ?>",{method:'POST',body:formData})
      .then(res=>res.json())
      .then(res=>{
        this.hideLoading();
        if(res.success){
          this.showToast(`₦${res.new_wallet} remaining. Meter: ${this.meterNumber}`);
          setTimeout(()=>{ window.location.href='/app/success'; },1000);
        }else{
          this.showToast(res.message || 'Purchase failed','error');
        }
      })
      .catch(()=>{
        this.hideLoading();
        this.showToast('Network error','error');
      });
    }
  }
}).mount('#app');
</script>
<script>lucide.createIcons();</script>
</body>
</html>