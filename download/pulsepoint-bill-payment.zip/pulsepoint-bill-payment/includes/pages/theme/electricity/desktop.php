<?php
/**
 * Electricity Purchase Page - Desktop Mode
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner slides
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

// Get current user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';

// Dynamic Disco list from bill table
$disco_rows = $wpdb->get_results("SELECT DISTINCT provider, details FROM {$base_prefix}bill");
$discos = [];
foreach ($disco_rows as $row) {
    $logo_path = '/wp-content/plugins/pulsepoint-bill-payment/assets/img/' . strtoupper($row->details) . '.png';
    $discos[] = [
        'name' => $row->details,
        'img'  => file_exists(ABSPATH . $logo_path) ? $logo_path : '/wp-content/plugins/pulsepoint-bill-payment/assets/img/default.png'
    ];
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Electricity Purchase - <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root {
  --app-bg: #f5f6fa;
  --card-bg: #ffffff;
  --primary: <?= $color_hex ?>;
  --muted: #6b7280;
}
body { font-family:'Inter',sans-serif; background:var(--app-bg); margin:0; }
.content-wrapper { max-width:900px; margin:40px auto; padding:0 20px; }
.form-card { background:var(--card-bg); padding:28px; border-radius:18px; box-shadow:0 4px 18px rgba(0,0,0,0.08); border:1px solid #ececec; width:100%; }
.provider-row { display:flex; align-items:center; gap:12px; }
.provider-logo { width:60px; height:60px; border-radius:12px; background:#eee; display:flex; align-items:center; justify-content:center; }
select.provider-select, input.input-field { border:1px solid #ccc; border-radius:8px; padding:10px; width:100%; margin-top:12px; font-weight:600; }
.pay-btn { background:var(--primary); color:white; padding:12px 22px; border-radius:12px; font-weight:600; cursor:pointer; width:100%; margin-top:20px; text-align:center; }
/* Slider */
.slider-container { position:relative; width:100%; height:200px; overflow:hidden; border-radius:14px; margin-top:40px; }
.slider-track { display:flex; width:100%; height:100%; transition:transform 0.6s ease; }
.slide { min-width:100%; height:200px; }
.slide img { width:100%; height:100%; object-fit:cover; border-radius:14px; }
.slider-dots { text-align:center; margin-top:10px; }
.slider-dots span { display:inline-block; width:10px; height:10px; background:#ccc; border-radius:50%; margin:0 4px; cursor:pointer; }
.slider-dots .active { background:var(--primary); }
</style>
</head>

<body>
<div id="app">
  <div class="content-wrapper">
    <div class="form-card">
      <div class="flex items-center justify-between mb-7">
        <h1 class="text-3xl font-bold text-gray-900">Electricity Purchase</h1>
        <button @click="goBack" class="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
          <i data-lucide="arrow-left" class="w-5 h-5"></i>
        </button>
      </div>

      <!-- Disco -->
      <div class="mb-6">
        <div class="text-gray-600 font-semibold mb-2">Select Disco</div>
        <div class="provider-row">
          <div class="provider-logo">
            <img :src="selectedDisco.img" :alt="selectedDisco.name" class="w-12 h-12 rounded-lg"/>
          </div>
          <select v-model="selectedDisco" @change="onDiscoChange" class="provider-select">
            <option v-for="disco in discos" :value="disco">{{ disco.name }}</option>
          </select>
        </div>
      </div>

      <!-- Meter Number -->
      <div class="mb-4">
        <input v-model="meterNumber" type="text" placeholder="Enter Meter Number" class="input-field"/>
      </div>

      <!-- Meter Type -->
      <div class="mb-4">
        <select v-model="meterType" class="provider-select">
          <option value="">Select Meter Type</option>
          <option value="prepaid">Prepaid</option>
          <option value="postpaid">Postpaid</option>
        </select>
      </div>

      <!-- Amount -->
      <div class="mb-4">
        <input v-model="amount" type="number" placeholder="Enter Amount" class="input-field"/>
      </div>

      <button class="pay-btn" @click="payElectricity">Buy Electricity</button>
    </div>

    <!-- Slider -->
    <div class="slider-container">
      <div class="slider-track" id="sliderTrack">
        <?php foreach ($banner_slides as $slide): ?>
        <div class="slide"><img src="<?= esc_url($slide) ?>" alt="Banner"></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="slider-dots" id="sliderDots">
      <?php for ($i=0;$i<count($banner_slides);$i++): ?>
      <span data-index="<?= $i ?>"></span>
      <?php endfor; ?>
    </div>
  </div>
</div>

<script>
const { createApp } = Vue;
createApp({
  data(){
    return {
      discos: <?= json_encode($discos) ?>,
      selectedDisco: <?= json_encode($discos[0] ?? ['name'=>'Select','img'=>'/wp-content/plugins/pulsepoint-bill-payment/assets/img/default.png']) ?>,
      meterType:'',
      meterNumber:'',
      amount:'',
      bypass:false,
      requestId:''
    }
  },
  methods:{
    goBack(){ window.history.back(); },
    showLoading(){ 
      const overlay=document.createElement('div');
      overlay.id='loadingOverlay';
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
      document.body.appendChild(overlay);
    },
    hideLoading(){ const overlay=document.getElementById('loadingOverlay'); if(overlay) overlay.remove(); },
    showToast(msg,type='info'){ Toastify({ text: msg, duration: 3000, close:true, gravity:'top', position:'center', style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }}).showToast(); },
    onDiscoChange(){ this.amount=''; },
    payElectricity(){
      if(!this.meterNumber){ this.showToast('Enter meter number','error'); return; }
      if(!this.meterType){ this.showToast('Select meter type','error'); return; }
      if(!this.amount){ this.showToast('Enter amount','error'); return; }

      this.showLoading();
      this.requestId = `ELEC${Date.now()}${Math.floor(Math.random()*9000+1000)}`;

      const formData = new FormData();
      formData.append('action','pulsepoint_electricity_purchase');
      formData.append('disco', this.selectedDisco.name);
      formData.append('meter_type', this.meterType);
      formData.append('meter_number', this.meterNumber);
      formData.append('amount', this.amount);
      formData.append('bypass', this.bypass ? 1 : 0);
      formData.append('request_id', this.requestId);

      fetch("<?= admin_url('admin-ajax.php') ?>",{method:'POST',body:formData})
      .then(res=>res.json())
      .then(res=>{
        this.hideLoading();
        if(res.success){
          this.showToast(`₦${res.new_wallet} remaining. Meter: ${this.meterNumber}`);
          setTimeout(()=>{ window.location.href='/app/success'; },1000);
        } else this.showToast(res.message || 'Purchase failed','error');
      })
      .catch(()=>{ this.hideLoading(); this.showToast('Network error','error'); });
    }
  }
}).mount('#app');
</script>

<!-- Slider Script -->
<script>
let index=0;
const track=document.getElementById("sliderTrack");
const dots=document.querySelectorAll("#sliderDots span");
const total=dots.length;
function updateSlider(){ track.style.transform=`translateX(-${index*100}%)`; dots.forEach(d=>d.classList.remove("active")); dots[index].classList.add("active"); }
dots.forEach(dot=>{ dot.onclick=()=>{ index=parseInt(dot.dataset.index); updateSlider(); }; });
setInterval(()=>{ index=(index+1)%total; updateSlider(); },3500);
updateSlider();
</script>

<script>lucide.createIcons();</script>
</body>
</html>