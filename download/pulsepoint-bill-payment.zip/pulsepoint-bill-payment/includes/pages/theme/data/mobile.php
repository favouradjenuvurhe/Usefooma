<?php 
/**  
 * Data Purchase Page - Pulsepoint Plugin  
 * Author: Amaaavl  
 */  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// Fetch settings  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  
  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#0057ff';  
  
// Banner flyer image URLs from settings  
$banner_slides = [  
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',  
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'  
];  
  
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;  
$table_users = $wpdb->prefix . 'pulsepoint_users';  
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));  
$firstname = $user ? esc_html($user->firstname) : 'User';  
?>  

<!doctype html>
<html lang="en">  
<head>  
  <meta charset="utf-8" />  
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />  
  <title>Data - <?= esc_html($platform_name) ?></title>  
  <script src="https://cdn.tailwindcss.com"></script>  
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>  
  <script src="https://unpkg.com/lucide@latest"></script>  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">  
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>  

  <style>  
    :root{  
      --app-bg: #f7f8fb;  
      --card-bg: #ffffff;  
      --muted: #6b7280;  
      --primary: <?= $color_hex ?>;  
    }  
    html, body, #app { min-height: 100%; background: var(--app-bg); }  
    body { font-family: 'Inter', sans-serif; margin:0; padding:0; }  
    .rounded-card{ border-radius:14px; background:var(--card-bg); }  
    .topup-btn{  
      border-radius:12px; border:1.5px solid rgba(99,102,241,0.08);  
      padding:14px 18px; min-width:88px; text-align:center;  
      font-weight:600; background:transparent; cursor:pointer;  
      transition:all 0.2s;  
    }  
    .topup-btn.selected{ background: var(--primary); color:white; border-color: var(--primary); }  
    .topup-btn:hover{ background: rgba(37,99,235,0.08); border-color: rgba(37,99,235,0.2); }  
    .muted { color: var(--muted); }  
    .provider-row{ display:flex; align-items:center; gap:8px; width:100%; }  
    .provider-logo{ width:100px; height:50px; border-radius:10px; display:flex; align-items:center; justify-content:center; background:#eee; font-weight:700; font-size:18px; }  
    select.provider-select{ border:none; outline:none; font-weight:600; background:transparent; cursor:pointer; font-size:13px; width:100%; }  
    .card-inner { padding:18px; }  
    .pay-btn { background: var(--primary); color:white; padding:10px 22px; border-radius:999px; font-weight:600; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; min-width:80px; }  
    .thin-hr { height:1px; background:#e6e9ef; margin-top:16px; }  
    .network-card{ cursor:pointer; padding:8px; border:1px solid #e5e7eb; border-radius:12px; text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; transition:all 0.2s; }  
    .network-card.active{ border-color: var(--primary); background: rgba(37,99,235,0.1); }  
  </style>  
</head>  

<body>  
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Data</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- Banners -->
<div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2 mt-4">  
<?php foreach ($banner_slides as $slide): ?>  
  <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">  
    <img src="<?php echo esc_url($slide); ?>" alt="Flyer Slide" class="w-full h-full object-cover rounded-lg shadow-md">  
  </div>  
<?php endforeach; ?>  
</div> 

<!-- Recent Data -->
<div v-if="recentList.length" class="mt-3">
  <h3 class="font-semibold text-gray-900 mb-3">Recent</h3>

  <div class="flex overflow-x-auto scrollbar-hide gap-3 py-1">

    <div 
      v-for="(item,index) in recentList" 
      :key="index"
      @click="selectRecent(item)"
      class="w-1/4 min-w-[25%] flex-shrink-0 text-center cursor-pointer"
    >

      <!-- Network Icon -->
      <div :class="[
        'w-10 h-10 mx-auto rounded-full flex items-center justify-center border-2',
        getBg(item.img),
        selectedRecent === item.phone ? 'border-blue-500' : 'border-transparent'
      ]">
        <img :src="item.img" class="w-6 h-6">
      </div>

      <!-- Phone -->
      <p class="text-[11px] mt-1 text-gray-700 truncate">
        {{ item.phone }}
      </p>

    </div>

  </div>
</div>

<!-- MAIN CARD -->
<div class="mt-4">

  <!-- NETWORK -->
  <div class="mt-2 mb-3 text-black text-sm font-medium">
    Choose Network
  </div>

  <div class="grid grid-cols-4 gap-2">
    <div 
      v-for="net in networks" 
      :key="net.name"
      @click="selectNetwork(net)"
      class="rounded-card py-3 px-2 flex flex-col items-center justify-center cursor-pointer border"
      :class="selectedProvider.name === net.name ? 'border-[var(--primary)] bg-white' : 'border-gray-100'"
    >
      <div :class="['w-9 h-9 rounded-full flex items-center justify-center', getBg(net.img)]">
        <img :src="net.img" class="w-6 h-6 object-contain" />
      </div>

      <span class="text-[11px] font-medium mt-1">
        {{ net.name }}
      </span>
    </div>
  </div>

 <!-- PHONE -->
<div class="flex justify-between mt-6 mb-1">
  <div class="text-black text-sm font-medium">
    Phone Number
  </div>
  <button @click="pickContact" class="text-[var(--primary)] text-sm font-medium">
    Choose Contact
  </button>
</div>

<div class="rounded-card card-inner py-3 px-3">
  <input 
  v-model="phone"
  @input="autoDetectNetwork"
  placeholder="0801 234 5678"
  maxlength="15"
  class="w-full bg-transparent outline-none text-base text-gray-500"
/>
</div>

  <!-- DATA TITLE -->
  <div class="mt-8 text-black text-sm font-medium">
    Select Data
  </div>

  <!-- TABS -->
<div class="flex gap-4 mt-3 mb-5 overflow-x-auto scrollbar-hide">
  <div
    v-for="tab in tabs"
    @click="changeTab(tab)"
    :class="[
      'tab pb-2 cursor-pointer text-[14px] font-semibold whitespace-nowrap',
      activeTab === tab ? 'border-b-2 border-[var(--primary)] text-blue-600' : 'border-b-2 border-transparent text-gray-700'
    ]"
  >
    {{ tab }}
  </div>
</div>

  <!-- DATA CARDS (UPDATED COMPACT GRID) -->
<div class="grid grid-cols-3 sm:grid-cols-4 gap-3">
  <div
    v-for="plan in filteredPlans"
    :key="plan.id"
    @click="selectPlan(plan)"
    :class="[
      'card flex flex-col justify-start items-start p-2 min-h-[80px] border rounded-lg cursor-pointer',
      selectedPlan.id === plan.id ? 'border-[var(--primary)]' : 'border-gray-200'
    ]"
  >
    <!-- Discount badge stays on top -->
    <div v-if="plan.discount" class="badge text-[10px] font-bold text-white bg-red-500 px-2 py-0.5 rounded mb-1">
      {{ plan.discount }}%
    </div>

    <!-- Hidden plan data (accessible for screen readers) -->
    <div class="sr-only">{{ plan.data }}</div>

    <!-- Price -->
    <div class="text-left text-[12px] font-bold mb-1">{{ plan.extra }}</div>

    <!-- Cashback -->
    <div class="text-left text-[10px] text-gray-500">₦{{ plan.price }}</div>

    <!-- Extra info -->
    <div v-if="plan.extra" class="text-left text-[9px] font-semibold mt-1 px-2 py-1 bg-gray-100 rounded">
      ₦{{ plan.cashback }}
    </div>
  </div>
</div>

  <!-- PAY BUTTON -->
  <button 
    class="mt-6 w-full h-[48px] rounded-xl text-white text-sm font-semibold"
    :style="{ background: 'var(--primary)' }"
    @click="payData"
  >
    Buy Data
  </button>

  <div class="thin-hr mt-5"></div>
</div>

<!-- Data Service Box -->
<div class="mt-4">
  <h3 class="text-black text-sm font-medium mb-2">Data Services</h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-1">
    
    <!-- Auto Data Top-up -->
    <div onclick="window.location.href='/app/schedule-data';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">Auto Data Top-up</h4>
      <p class="text-[11px] text-gray-400 mt-1">Set automatic data recharge</p>
    </div>

    <!-- Data Voucher -->
    <div onclick="window.location.href='/app/data-vouchers';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">Data Vouchers</h4>
      <p class="text-[11px] text-gray-400 mt-1">Print vouchers for any network</p>
    </div>

    <!-- Bulk Data -->
    <div onclick="window.location.href='#';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">Bulk Data</h4>
      <p class="text-[11px] text-gray-400 mt-1">Multiple numbers at once</p>
    </div>

    <!-- Data USSD Codes -->
    <div onclick="window.location.href='#';" class="inline-block mr-3 w-40 flex-shrink-0 bg-white rounded-xl px-3 py-2 shadow-sm">
      <h4 class="text-xs font-medium text-black">USSD Codes</h4>
      <p class="text-[11px] text-gray-400 mt-1">Check network short codes</p>
    </div>

  </div>
</div>

<!-- Optional: Recent Data or Popular Plans Section -->
<div class="mt-5">
  <h3 class="font-semibold text-gray-900 mb-3"> </h3>

  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2">
    <!-- Data plan cards will go here -->
  </div>
</div>

<script>
const { createApp } = Vue;

createApp({
  data() {
    return {
      phone: '',
      phoneAmount: '',
      recentList: [],
      selectedRecent: null,
      networks: [
        { name: 'MTN', img: '/wp-content/plugins/pulsepoint-bill-payment/assets/img/MTN.png' },
        { name: 'AIRTEL', img: '/wp-content/plugins/pulsepoint-bill-payment/assets/img/AIRTEL.png' },
        { name: 'GLO', img: '/wp-content/plugins/pulsepoint-bill-payment/assets/img/GLO.png' },
        { name: '9MOBILE', img: '/wp-content/plugins/pulsepoint-bill-payment/assets/img/9MOBILE.png' }
      ],
      selectedProvider: { name: 'MTN', img: '/wp-content/plugins/pulsepoint-bill-payment/assets/img/MTN.png' },
      selectedNetwork: 'MTN',
      tabs: [],
      activeTab: '',
      selectedPlan: {},
      selectedType: '',
      selectedPlanId: '',
      planAmount: 0,
      selectedDetails: '',
      allPlans: []
    };
  },

  mounted() {
    const saved = localStorage.getItem('recent_data_numbers');
    if (saved) this.recentList = JSON.parse(saved);
    this.fetchPlans(this.selectedNetwork);
  },

  computed: {
    filteredPlans() {
      if (!this.allPlans.length) return [];
      return this.allPlans
        .filter(p => p.type.toUpperCase() === this.activeTab.toUpperCase())
        .map(p => ({
          id: p.id,
          data: p.plan,
          validity: p.validity || '',
          price: p.amount,
          cashback: p.cashback || 0,
          oldPrice: p.old_price || null,
          discount: p.old_price ? true : false,
          extra: p.details || ''
        }));
    }
  },

  methods: {
    selectNetwork(net) {
      this.selectedProvider = net;
      this.selectedNetwork = net.name;
      this.fetchPlans(this.selectedNetwork);
      this.selectedPlan = {};
      this.activeTab = '';
    },

    changeTab(tab) {
      this.activeTab = tab;
      this.selectedPlan = {};
    },

    selectPlan(plan) {
      this.selectedPlan = plan;
      this.selectedType = this.activeTab;
      this.selectedPlanId = plan.id;
      this.planAmount = plan.price;
      this.selectedDetails = plan.extra;
    },

    fetchPlans(network) {
      fetch(`<?= esc_url(admin_url('admin-ajax.php')) ?>?action=pulsepoint_get_data_plans&network=${network}`)
        .then(res => res.json())
        .then(plans => {
          this.allPlans = plans || [];
          const types = [...new Set(this.allPlans.map(p => p.type.toUpperCase()))];
          this.tabs = types;
          this.activeTab = types[0] || '';
        });
    },

    pickContact: async function() {
      if (!('contacts' in navigator) || !('ContactsManager' in window)) {
        this.showToast('Not supported on this device', 'error');
        return;
      }
      try {
        const contacts = await navigator.contacts.select(['tel'], { multiple: false });
        if (!contacts.length) return;
        let rawNumber = contacts[0].tel ? contacts[0].tel[0] : '';
        let cleaned = rawNumber.replace(/\s+/g, '').replace(/-/g, '');
        if (cleaned.startsWith('+234')) cleaned = '0' + cleaned.slice(4);
        else if (cleaned.startsWith('234')) cleaned = '0' + cleaned.slice(3);
        else if (!cleaned.startsWith('0')) cleaned = '0' + cleaned;
        this.phone = cleaned.slice(0, 11);

        /* ✅ AUTO-DETECT NETWORK AFTER PICKING CONTACT */
        this.autoDetectNetwork();

      } catch (err) {
        this.showToast('Failed to pick contact', 'error');
      }
    },

    payData() {
      if (!this.phone) { this.showToast('Enter phone number', 'error'); return; }
      if (!this.selectedType) { this.showToast('Select a plan category', 'error'); return; }
      if (!this.selectedPlanId) { this.showToast('Select a plan', 'error'); return; }

      this.showLoading();
      const reference = `PSNG${Math.floor(1000000 + Math.random() * 9000000)}${this.selectedNetwork}DATAQ`;

      const formData = new FormData();
      formData.append('action', 'pulsepoint_data_purchase');
      formData.append('network', this.selectedNetwork);
      formData.append('type', this.selectedType);
      formData.append('plan', this.selectedPlanId);
      formData.append('details', this.selectedDetails);
      formData.append('amount', this.planAmount);
      formData.append('phone', this.phone);
      formData.append('reference', reference);

      fetch("<?= admin_url('admin-ajax.php') ?>", { method: 'POST', body: formData })
        .then(res => res.json())
        .then(res => {
          this.hideLoading();
          if (res.success) {
            this.saveRecent();
            this.showToast('Data Purchase Successful 🎉');
            setTimeout(() => { window.location.href = '/app/success'; }, 1000);
          } else {
            this.showToast(res.message || 'Purchase failed', 'error');
          }
        })
        .catch(() => { this.hideLoading(); this.showToast('Network error', 'error'); });
    },

    /* ✅ RECENT MANAGEMENT */
    saveRecent(){
      if(!this.phone) return;

      let list = JSON.parse(localStorage.getItem('recent_data_numbers')) || [];
      list = list.filter(item => item.phone !== this.phone);
      list.unshift({
        phone: this.phone,
        img: this.selectedProvider.img
      });
      if(list.length > 12) list = list.slice(0,12);

      localStorage.setItem('recent_data_numbers', JSON.stringify(list));
      this.recentList = list;
    },

    selectRecent(item){
      this.phone = item.phone;
      const network = this.networks.find(n => n.img === item.img);
      if(network) this.selectedProvider = network;
      this.selectedNetwork = network.name;

      this.selectedRecent = item.phone;

      /* ✅ AUTO-DETECT NETWORK WHEN SELECTING RECENT */
      this.autoDetectNetwork();
    },

    /* ✅ NETWORK DETECTION LOGIC */
    detectNetwork(phone){
      const networks = {
        MTN: ["0803","0806","0703","0706","0810","0813","0814","0816","0903","0906","0913","0916"],
        AIRTEL: ["0802","0808","0708","0812","0701","0902","0907","0901","0912"],
        GLO: ["0805","0807","0705","0811","0815","0905"],
        "9MOBILE": ["0809","0817","0818","0908","0909"]
      };

      if(!phone) return null;

      phone = phone.replace(/\D/g,'');

      if(phone.startsWith("234")){
        phone = "0" + phone.slice(3);
      }

      if(phone.length < 4) return null;

      const prefix = phone.substring(0,4);

      for(const net in networks){
        if(networks[net].includes(prefix)){
          return net;
        }
      }

      return null;
    },

    autoDetectNetwork(){
      const net = this.detectNetwork(this.phone);
      if(net){
        const found = this.networks.find(n => n.name === net);
        if(found){
          this.selectedProvider = found;
          this.selectedNetwork = found.name;
        }
      }
    },

    showLoading() {
      const overlay = document.createElement('div');
      overlay.id = 'loadingOverlay';
      overlay.style = 'position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
      overlay.innerHTML = '<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
      document.body.appendChild(overlay);
    },

    hideLoading() { const overlay = document.getElementById('loadingOverlay'); if (overlay) overlay.remove(); },

    showToast(msg, type = 'info') {
      Toastify({
        text: msg,
        duration: 3000,
        close: true,
        gravity: 'top',
        position: 'center',
        stopOnFocus: true,
        style: { background: type === 'error' ? '#ff3860' : 'green', color: '#fff', borderRadius: '12px' }
      }).showToast();
    },

    getBg(img) {
      if (!img) return 'bg-gray-100';
      if (img.includes('MTN')) return 'bg-yellow-100';
      if (img.includes('AIRTEL')) return 'bg-pink-100';
      if (img.includes('GLO')) return 'bg-green-100';
      if (img.includes('9MOBILE')) return 'bg-gray-100';
      return 'bg-gray-100';
    }
  }
}).mount('#app');
</script>

<script>lucide.createIcons();</script>

</body>
</html>