<?php
/**
 * Cable Purchase Page - Desktop Mode
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cable Subscription - <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root {
  --app-bg: #f5f6fa;
  --card-bg: #ffffff;
  --primary: <?= $color_hex ?>;
  --muted: #6b7280;
}
body { font-family:'Inter',sans-serif; background:var(--app-bg); margin:0; }
.content-wrapper { max-width:900px; margin:40px auto; padding:0 20px; }
.form-card { background:var(--card-bg); padding:28px; border-radius:18px; box-shadow:0 4px 18px rgba(0,0,0,0.08); border:1px solid #ececec; width:100%; }
.provider-row { display:flex; align-items:center; gap:12px; }
.provider-logo { width:60px; height:60px; border-radius:12px; background:#eee; display:flex; align-items:center; justify-content:center; }
select.provider-select { border:1px solid #ccc; border-radius:8px; padding:8px; font-weight:600; cursor:pointer; width:100%; }
input.smartcard-input { border:1px solid #ccc; border-radius:8px; padding:10px; width:100%; margin-top:12px; }
.pay-btn { background:var(--primary); color:white; padding:12px 22px; border-radius:12px; font-weight:600; cursor:pointer; width:100%; margin-top:20px; text-align:center; }
/* Slider */
.slider-container { position:relative; width:100%; height:200px; overflow:hidden; border-radius:14px; margin-top:40px; }
.slider-track { display:flex; width:100%; height:100%; transition:transform 0.6s ease; }
.slide { min-width:100%; height:200px; }
.slide img { width:100%; height:100%; object-fit:cover; border-radius:14px; }
.slider-dots { text-align:center; margin-top:10px; }
.slider-dots span { display:inline-block; width:10px; height:10px; background:#ccc; border-radius:50%; margin:0 4px; cursor:pointer; }
.slider-dots .active { background:var(--primary); }
</style>
</head>

<body>
<div id="app">
  <div class="content-wrapper">
    <div class="form-card">
      <div class="flex items-center justify-between mb-7">
        <h1 class="text-3xl font-bold text-gray-900">Cable Subscription</h1>
        <button @click="goBack" class="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
          <i data-lucide="arrow-left" class="w-5 h-5"></i>
        </button>
      </div>

      <!-- Provider -->
      <div class="mb-6">
        <div class="text-gray-600 font-semibold mb-2">Select Provider</div>
        <div class="provider-row">
          <div class="provider-logo">
            <img :src="selectedProvider.img" :alt="selectedProvider.name" class="w-12 h-12 rounded-lg"/>
          </div>
          <select v-model="selectedProvider" @change="onProviderChange" class="provider-select">
            <option v-for="provider in providers" :value="provider">{{ provider.name }}</option>
          </select>
        </div>
      </div>

      <!-- Smartcard -->
      <div class="mb-6">
        <input v-model="smartcard" type="text" placeholder="Enter Smartcard Number" class="smartcard-input"/>
      </div>

      <!-- Plan -->
      <div class="mb-4">
        <label class="font-semibold text-gray-700">Select Plan</label>
        <select v-model="selectedPlan" @change="onPlanChange" class="provider-select">
          <option value="">Select plan</option>
          <option v-for="plan in allPlans" :key="plan.id" :value="plan.id">
            {{ plan.details ? plan.details+' | ₦'+plan.amount : plan.type+' '+plan.plan+' | ₦'+plan.amount }}
          </option>
        </select>
      </div>

      <button class="pay-btn" @click="payCable">Subscribe</button>
    </div>

    <!-- Slider -->
    <div class="slider-container">
      <div class="slider-track" id="sliderTrack">
        <?php foreach ($banner_slides as $slide): ?>
        <div class="slide"><img src="<?= esc_url($slide) ?>" alt="Banner"></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="slider-dots" id="sliderDots">
      <?php for ($i=0;$i<count($banner_slides);$i++): ?>
      <span data-index="<?= $i ?>"></span>
      <?php endfor; ?>
    </div>
  </div>
</div>

<script>
const { createApp } = Vue;
createApp({
  data(){
    return {
      smartcard:'',
      cableAmount:'',
      providers:[
        {name:'DSTV', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/DSTV.png'},
        {name:'GOTV', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/GOTV.png'},
        {name:'STARTIMES', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/STARTIMES.png'}
      ],
      selectedProvider:{name:'DSTV', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/DSTV.png'},
      selectedPlan:'',
      planAmount:0,
      selectedDetails:'',
      allPlans:[]
    }
  },
  mounted(){ this.fetchPlans(this.selectedProvider.name); },
  methods:{
    goBack(){ window.history.back(); },
    showLoading(){ 
      const overlay=document.createElement('div');
      overlay.id='loadingOverlay';
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
      document.body.appendChild(overlay);
    },
    hideLoading(){ const overlay=document.getElementById('loadingOverlay'); if(overlay) overlay.remove(); },
    showToast(msg,type='info'){ Toastify({ text: msg, duration: 3000, close:true, gravity:'top', position:'center', style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }}).showToast(); },
    fetchPlans(provider){
      fetch(`<?= esc_url(admin_url('admin-ajax.php')) ?>?action=pulsepoint_get_cable_plans&type=${provider}`)
      .then(res=>res.json())
      .then(plans=>{ this.allPlans = plans; this.selectedPlan=''; this.cableAmount=''; this.selectedDetails=''; });
    },
    onProviderChange(){ this.fetchPlans(this.selectedProvider.name); },
    onPlanChange(){
      const selected=this.allPlans.find(p=>p.id==this.selectedPlan);
      if(selected){ this.planAmount=parseFloat(selected.amount); this.cableAmount=this.planAmount; this.selectedDetails=selected.details||''; }
    },
    payCable(){
      if(!this.smartcard){ this.showToast('Enter Smartcard number','error'); return; }
      if(!this.selectedPlan){ this.showToast('Select a plan','error'); return; }
      this.showLoading();
      const reference=`PSNG${Math.floor(1000000+Math.random()*9000000)}${this.selectedProvider.name}CABLEQ`;
      const formData=new FormData();
      formData.append('action','pulsepoint_cable_purchase');
      formData.append('provider', this.selectedProvider.name);
      formData.append('plan', this.selectedPlan);
      formData.append('details', this.selectedDetails);
      formData.append('amount', this.planAmount);
      formData.append('smartcard', this.smartcard);
      formData.append('reference', reference);

      fetch("<?= admin_url('admin-ajax.php') ?>",{method:'POST',body:formData})
      .then(res=>res.json())
      .then(res=>{
        this.hideLoading();
        if(res.success){ this.showToast(`₦${res.new_wallet} remaining. Smartcard: ${this.smartcard}`); setTimeout(()=>{ window.location.href='/app/success'; },1000); }
        else{ this.showToast(res.message || 'Purchase failed','error'); }
      })
      .catch(()=>{ this.hideLoading(); this.showToast('Network error','error'); });
    }
  }
}).mount('#app');
</script>

<!-- Slider Script -->
<script>
let index=0;
const track=document.getElementById("sliderTrack");
const dots=document.querySelectorAll("#sliderDots span");
const total=dots.length;
function updateSlider(){ track.style.transform=`translateX(-${index*100}%)`; dots.forEach(d=>d.classList.remove("active")); dots[index].classList.add("active"); }
dots.forEach(dot=>{ dot.onclick=()=>{ index=parseInt(dot.dataset.index); updateSlider(); }; });
setInterval(()=>{ index=(index+1)%total; updateSlider(); },3500); updateSlider();
</script>

<script>lucide.createIcons();</script>
</body>
</html>