<?php
/**
 * Cable Purchase Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Banner flyer image URLs
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
  <title>Cable Purchase - <?= esc_html($platform_name) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>
    :root{
      --app-bg: #f7f8fb;
      --card-bg: #ffffff;
      --muted: #6b7280;
      --primary: <?= $color_hex ?>;
    }
    html, body, #app { min-height: 100%; background: var(--app-bg); }
    body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
    .rounded-card{ border-radius:14px; background:var(--card-bg); }
    .topup-btn{
      border-radius:12px; border:1.5px solid rgba(99,102,241,0.08);
      padding:14px 18px; min-width:88px; text-align:center;
      font-weight:600; background:transparent; cursor:pointer;
      transition:all 0.2s;
    }
    .topup-btn.selected{ background: var(--primary); color:white; border-color: var(--primary); }
    .topup-btn:hover{ background: rgba(37,99,235,0.08); border-color: rgba(37,99,235,0.2); }
    .muted { color: var(--muted); }
    .provider-row{ display:flex; align-items:center; gap:8px; width:100%; }
    .provider-logo{ width:100px; height:50px; border-radius:10px; display:flex; align-items:center; justify-content:center; background:#eee; font-weight:700; font-size:18px; }
    select.provider-select{ border:none; outline:none; font-weight:600; background:transparent; cursor:pointer; font-size:13px; width:100%; }
    .card-inner { padding:18px; }
    .pay-btn { background: var(--primary); color:white; padding:10px 22px; border-radius:999px; font-weight:600; display:inline-flex; align-items:center; justify-content:center; cursor:pointer; min-width:80px; }
    .thin-hr { height:1px; background:#e6e9ef; margin-top:16px; }
    .network-card{ cursor:pointer; padding:8px; border:1px solid #e5e7eb; border-radius:12px; text-align:center; display:flex; flex-direction:column; align-items:center; justify-content:center; transition:all 0.2s; }
    .network-card.active{ border-color: var(--primary); background: rgba(37,99,235,0.1); }
  </style>
</head>
<body>
<div id="app" class="px-4 max-w-md mx-auto">
  
  <!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Cable Tv</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

  <!-- Banner Flyers -->
  <div class="overflow-x-auto whitespace-nowrap scrollbar-hide py-2 mt-4">
    <?php foreach ($banner_slides as $slide): ?>
      <div class="inline-block mr-4 w-64 h-24 flex-shrink-0">
        <img src="<?php echo esc_url($slide); ?>" alt="Flyer Slide" class="w-full h-full object-cover rounded-lg shadow-md">
      </div>
    <?php endforeach; ?>
  </div>


  <!-- MAIN CARD -->
  <div class="mt-6 rounded-card p-4 border border-gray-200 shadow-sm">

    <div class="muted font-semibold mb-2">Select Provider</div>

    <div class="rounded-card card-inner flex items-center gap-3 border border-gray-100">
      <div class="provider-row w-full flex items-center gap-2">
        <div class="flex items-center gap-2" style="flex:35%">
          <div class="provider-logo">
            <img :src="selectedProvider.img" :alt="selectedProvider.name" class="w-8 h-8 rounded" />
          </div>
          <select v-model="selectedProvider" class="provider-select w-full" @change="onProviderChange">
            <option v-for="provider in providers" :key="provider.name" :value="provider">
              {{ provider.name }}
            </option>
          </select>
        </div>

        <input v-model="smartcard" placeholder="Enter Smartcard Number"
               class="bg-transparent outline-none border-b border-gray-300 pb-1 w-full"
               style="flex:65%" />
      </div>
    </div>

    <!-- Plan -->
    <div class="mt-3">
      <label class="font-semibold text-sm">Select Plan</label>
      <select id="planSelect" v-model="selectedPlan" class="w-full mt-1 p-2 rounded border border-gray-300" @change="onPlanChange">
        <option value="">Select plan</option>
        <option v-for="plan in allPlans" :value="plan.id" :data-amount="plan.amount" :data-plan="plan.plan" :data-details="plan.details">
          {{ plan.details ? `${plan.details} | ₦${plan.amount}` : `${plan.type} ${plan.plan} | ₦${plan.amount}` }}
        </option>
      </select>
    </div>

    <!-- Pay button -->
    <div class="mt-5 flex flex-col sm:flex-row items-center gap-2">
      <button class="pay-btn w-full sm:w-auto mt-2 sm:mt-0" @click="payCable">Subscribe</button>
    </div>

    <div class="thin-hr"></div>

  </div>


<script>
const { createApp } = Vue;

createApp({
  data(){
    return {
      smartcard:'',
      cableAmount:'',
      providers:[
        {name:'DSTV', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/DSTV.png'},
        {name:'GOTV', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/GOTV.png'},
        {name:'STARTIMES', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/STARTIMES.png'},
      ],
      selectedProvider:{name:'DSTV', img:'/wp-content/plugins/pulsepoint-bill-payment/assets/img/DSTV.png'},
      selectedPlan:'',
      planAmount:0,
      selectedDetails:'',
      allPlans:[]
    }
  },
  mounted(){
    this.fetchPlans(this.selectedProvider.name);
  },
  methods:{

    goBack(){ window.history.back(); },

    showLoading(){
      const overlay=document.createElement('div');
      overlay.id='loadingOverlay';
      overlay.style='position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
      overlay.innerHTML='<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
      document.body.appendChild(overlay);
    },

    hideLoading(){
      const overlay=document.getElementById('loadingOverlay');
      if(overlay) overlay.remove();
    },

    showToast(msg,type='info'){
      Toastify({
        text: msg,
        duration: 3000,
        close:true,
        gravity:'top',
        position:'center',
        stopOnFocus:true,
        style:{ background:type==='error'?'#ff3860':'green', color:'#fff', borderRadius:'12px' }
      }).showToast();
    },

    fetchPlans(provider){
      fetch(`<?= esc_url(admin_url('admin-ajax.php')) ?>?action=pulsepoint_get_cable_plans&type=${provider}`)
      .then(res=>res.json())
      .then(plans=>{
        this.allPlans = plans;
        this.selectedPlan = '';
        this.cableAmount = '';
        this.selectedDetails = '';
      });
    },

    onProviderChange(){
      this.fetchPlans(this.selectedProvider.name);
    },

    onPlanChange(){
      const selected = this.allPlans.find(p=>p.id == this.selectedPlan);
      if(selected){
        this.planAmount = parseFloat(selected.amount);
        this.cableAmount = this.planAmount;
        this.selectedDetails = selected.details || '';
      }
    },

    payCable(){
      if(!this.smartcard){ this.showToast('Enter Smartcard number','error'); return; }
      if(!this.selectedPlan){ this.showToast('Select a plan','error'); return; }

      this.showLoading();

      const reference = `PSNG${Math.floor(1000000+Math.random()*9000000)}${this.selectedProvider.name}CABLEQ`;

      const formData = new FormData();
      formData.append('action','pulsepoint_cable_purchase');
      formData.append('provider', this.selectedProvider.name);
      formData.append('plan', this.selectedPlan);
      formData.append('details', this.selectedDetails);
      formData.append('amount', this.planAmount);
      formData.append('smartcard', this.smartcard);
      formData.append('reference', reference);

      fetch("<?= admin_url('admin-ajax.php') ?>",{method:'POST',body:formData})
      .then(res=>res.json())
      .then(res=>{
        this.hideLoading();

        if(res.success){
          this.showToast(`₦${res.new_wallet} remaining. Smartcard: ${this.smartcard}`);
          setTimeout(()=>{ window.location.href='/app/success'; },1000);
        }else{
          this.showToast(res.message || 'Purchase failed','error');
        }
      })
      .catch(()=>{
        this.hideLoading();
        this.showToast('Network error','error');
      });
    }
  }
}).mount('#app');
</script>

<script>lucide.createIcons();</script>
</body>
</html>