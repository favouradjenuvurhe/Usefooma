<?php        
if (!defined('ABSPATH')) exit;        

global $wpdb;        
$base_prefix = $wpdb->prefix . 'pulsepoint_';        

// Fetch all settings from DB        
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");        
$settings = [];        
foreach ($settings_rows as $row) {        
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);        
}        

// Default fallback        
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';        
$color_hex     = $settings['color_hex'] ?? '#6A0DAD';        
$phone_number  = $settings['phone_number'] ?? '';        
$email_number  = $settings['email_number'] ?? '';        
$favicon_url      = $settings['favicon_url'] ?? '';        
$livechat      = $settings['livechat_script'] ?? '';        
$maintenance   = $settings['maintenance_mode'] ?? 0;        
?>    
<!DOCTYPE html>    
<html lang="en">      
<head>        
<meta charset="UTF-8" />        
<title>Dashboard login - <?php echo esc_html($platform_name); ?></title>        
<meta name="viewport" content="width=device-width, initial-scale=1" />    

<!-- Tailwind -->    
<script src="https://cdn.tailwindcss.com"></script>    
<!-- Vue 3 -->    
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>    
<!-- Lucide -->    
<script src="https://unpkg.com/lucide@latest"></script>    
<!-- Toastify -->    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">        
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>        

<style>        
body {        
  background:#f9f9f9;        
  font-family: Inter, system-ui, sans-serif;        
}        
.input-line {        
  border-bottom: 1px solid rgba(0,0,0,.15);        
}        
.fade-slide-enter-active,        
.fade-slide-leave-active {        
  transition: all .25s ease;        
}        
.fade-slide-enter-from {        
  opacity: 0;        
  transform: translateY(6px);        
}        
.fade-slide-leave-to {        
  opacity: 0;        
  transform: translateY(-6px);        
}        
.bg-purple-custom { background-color: <?php echo esc_js($color_hex); ?> !important; }        
.text-purple-custom { color: <?php echo esc_js($color_hex); ?> !important; }        
.accent-purple-custom { accent-color: <?php echo esc_js($color_hex); ?> !important; }        
</style>    
</head>    
<body class="min-h-screen flex flex-col items-center justify-center">        

<div id="app" class="w-full max-w-md px-6 py-10 text-gray-900">      

  <!-- LOGO -->      
  <div class="flex items-center gap-2 mb-10">        
    <?php if($favicon_url): ?>        
      <img src="<?php echo esc_url($favicon_url); ?>" alt="logo" class="w-8 h-8 object-contain"/>        
    <?php else: ?>        
      <svg width="26" height="26" viewBox="0 0 24 24" fill="<?php echo esc_attr($color_hex); ?>">        
        <path d="M3 12L21 3l-9 18-2-7-7-2z"/>        
      </svg>        
    <?php endif; ?>        
    <span class="font-semibold text-lg"><?php echo esc_html($platform_name); ?></span>        
  </div>      

  <!-- HEADER -->      
  <h1 class="text-2xl font-semibold mb-1">Log in to your account</h1>        
  <p class="text-sm text-gray-500 mb-10">Welcome back! Please enter your details</p>      

  <!-- EMAIL / PHONE -->      
  <div class="mb-8">        
    <div class="flex items-center justify-between text-xs mb-2">        
      <label class="text-gray-500">{{ mode === 'email' ? 'Email address' : 'Phone number' }}</label>        
      <span @click="toggleMode" class="text-purple-custom font-medium cursor-pointer select-none">{{ mode === 'email' ? 'Use number' : 'Use email' }}</span>        
    </div>        
    <div class="input-line pb-2">        
      <transition name="fade-slide" mode="out-in">        
        <input v-model="emailOrPhone" :key="mode" :type="mode === 'email' ? 'email' : 'tel'" :placeholder="mode === 'email' ? 'you@example.com' : '080xxxxxxxx'" class="bg-transparent w-full outline-none text-sm"/>        
      </transition>        
    </div>        
  </div>      

  <!-- PASSWORD -->      
  <div class="mb-6">        
    <label class="text-xs text-gray-500">Password</label>        
    <div class="flex items-center justify-between input-line mt-2 pb-2">        
      <input v-model="password" :type="show ? 'text' : 'password'" placeholder="••••••••" class="bg-transparent w-full outline-none text-sm tracking-widest" ref="passwordInput"/>        
      <svg xmlns="http://www.w3.org/2000/svg" @click="toggleShow" class="w-5 h-5 cursor-pointer opacity-70" fill="none" viewBox="0 0 24 24" stroke="<?php echo esc_js($color_hex); ?>">        
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>        
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>        
      </svg>        
    </div>        
  </div>      

  <!-- OPTIONS -->      
  <div class="flex justify-between items-center text-xs text-gray-500 mb-10">        
    <label class="flex items-center gap-2"><input type="checkbox" v-model="remember" class="accent-purple-custom"> Remember me</label>        
    <span class="underline cursor-pointer" @click="forgot">Forgot password</span>        
  </div>      

  <!-- LOGIN -->    
  <button @click="login" :disabled="loading" class="w-full py-4 rounded-full bg-purple-custom text-white font-medium mb-4">{{ loading ? 'Logging in...' : 'Log in' }}</button>

  <!-- GOOGLE SIGN-IN -->    
  <button @click="googleLogin" class="w-full py-4 rounded-full bg-white border border-gray-200 flex items-center justify-center gap-3 text-sm shadow-sm mb-4">
    <img src="https://www.svgrepo.com/show/475656/google-color.svg" class="w-5"> Continue with Google
  </button>

  <!-- FOOTER -->      
  <div class="text-center text-sm text-gray-500 mt-10">Don’t have an account? <span class="text-purple-custom font-medium cursor-pointer" @click="signup">Sign up</span></div>    
</div>    

<script>
const { createApp } = Vue;

function showToast(msg, type='info') {
  Toastify({
    text: msg,
    duration: 2500,
    close: true,
    gravity: "top",
    position: "center",
    stopOnFocus: true,
    style: { 
      background: type === 'error' ? "#ff3860" : "#2ecc71", 
      color: "#fff", 
      borderRadius: "12px" 
    }
  }).showToast();
}

createApp({
  data() {
    return {
      show: false,
      mode: 'email',
      emailOrPhone: '',
      password: '',
      remember: true,
      loading: false
    }
  },
  methods: {
    toggleMode() {
      this.mode = this.mode === 'email' ? 'phone' : 'email';
      this.emailOrPhone = '';

      // Auto refill saved data for switched mode
      const saved = JSON.parse(localStorage.getItem('pulsepoint-login-data') || '{}');

      if(this.mode === 'email' && saved.email){
        this.emailOrPhone = saved.email;
      }

      if(this.mode === 'phone' && saved.phone){
        this.emailOrPhone = saved.phone;
      }

      if(saved.password){
        this.password = saved.password;
      }
    },

    toggleShow() {
      this.show = !this.show;
    },

    login() {
      if (!this.emailOrPhone || !this.password) {
        showToast('Email/Phone and Password required','error');
        return;
      }

      this.loading = true;

      const formData = new FormData();
      formData.append('action','pulsepoint_user_login');
      formData.append('email', this.emailOrPhone);
      formData.append('password', this.password);

      fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
      })
      .then(res => res.json())
      .then(res => {
        this.loading = false;

        if(res.success){

          showToast(res.message,'success');

          // ✅ Save auth data
          if(res.user){
            localStorage.setItem('auth-token', res.user.token);
            localStorage.setItem('transaction-pin', res.user.passcode);
            localStorage.setItem('pulsepoint-user', JSON.stringify(res.user));
          }

          // ✅ Save login credentials for autofill
          let saved = {};

          if(this.mode === 'email'){
            saved.email = this.emailOrPhone;
          } else {
            saved.phone = this.emailOrPhone;
          }

          saved.password = this.password;

          localStorage.setItem('pulsepoint-login-data', JSON.stringify(saved));

          setTimeout(() => window.location.href = res.redirect, 500);

        } else {
          showToast(res.message,'error');
        }
      })
      .catch(() => {
        this.loading = false;
        showToast('Network error','error');
      });
    },

    googleLogin() {
      const clientId = '963442018052-3d7k7b3omdu7p39h9snn1018ep4mp92r.apps.googleusercontent.com';
      const redirectUri = '<?php echo esc_url(site_url("/callback/google-auth/")); ?>';
      const scope = 'openid email profile';

      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=${encodeURIComponent(scope)}&prompt=select_account`;

      window.location.href = authUrl;
    },

    signup() {
      window.location.href='/app/register';
    },

    forgot() {
      window.location.href='/app/recovery';
    }
  },

  mounted() {
    if(window.lucide) window.lucide.createIcons();

    // ✅ Auto Load Saved Login
    const saved = JSON.parse(localStorage.getItem('pulsepoint-login-data') || '{}');

    if(saved.email){
      this.mode = 'email';
      this.emailOrPhone = saved.email;
    } 
    else if(saved.phone){
      this.mode = 'phone';
      this.emailOrPhone = saved.phone;
    }
  }
}).mount('#app');
</script>

<?php wp_footer(); ?>    
</body>    
</html>