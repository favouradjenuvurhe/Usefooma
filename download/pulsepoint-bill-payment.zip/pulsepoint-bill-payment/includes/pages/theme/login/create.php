<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6A0DAD';
$favicon_url      = $settings['favicon_url'] ?? '';
?>
<!DOCTYPE html>    
<html lang="en">      
<head>        
<meta charset="UTF-8" />        
<title><?php echo esc_html($platform_name); ?> - Create Account</title>        
<meta name="viewport" content="width=device-width, initial-scale=1" />    

<!-- Tailwind -->    
<script src="https://cdn.tailwindcss.com"></script>    
<!-- Vue 3 -->    
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>    
<!-- Lucide -->    
<script src="https://unpkg.com/lucide@latest"></script>    
<!-- Toastify -->    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">        
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>        

<style>        
body {        
  background:#f9f9f9;        
  font-family: Inter, system-ui, sans-serif;        
}        
.input-line {        
  border-bottom: 1px solid rgba(0,0,0,.15);        
}        
.fade-slide-enter-active,        
.fade-slide-leave-active {        
  transition: all .25s ease;        
}        
.fade-slide-enter-from {        
  opacity: 0;        
  transform: translateY(6px);        
}        
.fade-slide-leave-to {        
  opacity: 0;        
  transform: translateY(-6px);        
}        
.bg-purple-custom { background-color: <?php echo esc_js($color_hex); ?> !important; }        
.text-purple-custom { color: <?php echo esc_js($color_hex); ?> !important; }        
.accent-purple-custom { accent-color: <?php echo esc_js($color_hex); ?> !important; }        
</style>    
</head>    
<body class="min-h-screen flex flex-col items-center justify-center">        

<div id="app" class="w-full max-w-md px-6 py-10 text-gray-900">      

  <!-- LOGO -->      
  <div class="flex items-center gap-2 mb-10">        
    <?php if($favicon_url): ?>        
      <img src="<?php echo esc_url($favicon_url); ?>" alt="logo" class="w-8 h-8 object-contain"/>        
    <?php else: ?>        
      <svg width="26" height="26" viewBox="0 0 24 24" fill="<?php echo esc_attr($color_hex); ?>">        
        <path d="M3 12L21 3l-9 18-2-7-7-2z"/>        
      </svg>        
    <?php endif; ?>        
    <span class="font-semibold text-lg"><?php echo esc_html($platform_name); ?></span>        
  </div>      

  <!-- HEADER -->
  <h1 class="text-2xl font-semibold mb-1">Create your account</h1>
  <p class="text-sm text-gray-500 mb-10">
    Already have an account?
    <span class="text-purple-custom font-medium cursor-pointer" @click="login">Log in</span>
  </p>

  <!-- FULL NAME -->
  <div class="mb-6">
    <label class="text-xs text-gray-500">Full Name</label>
    <div class="input-line mt-2 pb-2">
      <input v-model="fullname" placeholder="firstname lastname" class="w-full bg-transparent outline-none text-sm">
    </div>
  </div>

  <!-- PHONE -->
  <div class="mb-6">
    <label class="text-xs text-gray-500">Phone Number</label>
    <div class="input-line mt-2 pb-2">
      <input v-model="phone" placeholder="0801 234 5678" class="w-full bg-transparent outline-none text-sm">
    </div>
  </div>

  <!-- EMAIL -->
  <div class="mb-6">
    <label class="text-xs text-gray-500">Email</label>
    <div class="input-line mt-2 pb-2">
      <input v-model="email" type="email" placeholder="example@gmail.com" class="w-full bg-transparent outline-none text-sm">
    </div>
  </div>

  <!-- PASSWORD -->
  <div class="mb-6">
    <label class="text-xs text-gray-500">Password</label>
    <div class="input-line mt-2 pb-2">
      <input v-model="password" type="password" placeholder="********" class="w-full bg-transparent outline-none text-sm tracking-widest">
    </div>
  </div>

  <!-- PIN -->
  <div class="mb-6">
    <label class="text-xs text-gray-500">Transaction PIN (4 digits)</label>
    <div class="input-line mt-2 pb-2">
      <input v-model="pin" maxlength="4" placeholder="****" class="w-full bg-transparent outline-none text-sm tracking-widest">
    </div>
  </div>

  <!-- REFERRAL -->
  <div class="mb-8">
    <label class="text-xs text-gray-500">Referral (Optional)</label>
    <div class="input-line mt-2 pb-2">
      <input v-model="refer" placeholder="Referral Code" class="w-full bg-transparent outline-none text-sm">
    </div>
  </div>

  <!-- SIGN UP -->
  <button @click="register" :disabled="loading"
    class="w-full py-4 rounded-full bg-purple-custom text-white font-medium mb-4">
    {{ loading ? 'Signing up...' : 'Sign Up' }}
  </button>

  <!-- GOOGLE SIGN UP -->
  <button @click="googleSignup"
    class="w-full py-4 rounded-full bg-white border border-gray-200 flex items-center justify-center gap-3 text-sm shadow-sm">
    <img src="https://www.svgrepo.com/show/475656/google-color.svg" class="w-5">
    Continue with Google
  </button>

</div>

<script>
const { createApp } = Vue;

function showToast(msg, type='info') {
  Toastify({
    text: msg,
    duration: 2500,
    gravity: "top",
    position: "center",
    style: {
      background: type === 'error' ? "#ff3860" : "#2ecc71",
      color: "#fff",
      borderRadius: "12px"
    }
  }).showToast();
}

createApp({
  data() {
    return {
      fullname:'',
      phone:'',
      email:'',
      password:'',
      pin:'',
      refer:'',
      loading:false
    }
  },
  methods: {
    register() {
      if(!this.fullname || !this.phone || !this.password || !this.pin){
        showToast('All required fields must be filled','error');
        return;
      }

      const parts = this.fullname.trim().split(' ');
      const firstname = parts[0];
      const lastname = parts.slice(1).join(' ') || 'User';

      this.loading = true;
      const fd = new FormData();
      fd.append('action','pulsepoint_user_register');
      fd.append('firstname',firstname);
      fd.append('lastname',lastname);
      fd.append('phone',this.phone);
      fd.append('email',this.email);
      fd.append('password',this.password);
      fd.append('passcode',this.pin);
      fd.append('refer',this.refer);

      fetch('<?php echo admin_url("admin-ajax.php"); ?>',{
        method:'POST',
        body:fd,
        credentials:'same-origin'
      })
      .then(r=>r.json())
      .then(r=>{
        this.loading=false;
        if(r.success){
          showToast(r.message);

          // ✅ Save auth data to localStorage
          if(r.user){
            localStorage.setItem('auth-token', r.user.token);
            localStorage.setItem('transaction-pin', r.user.passcode);
            localStorage.setItem('pulsepoint-user', JSON.stringify(r.user));
          }

          setTimeout(()=>location.href=r.redirect,500);
        } else showToast(r.message,'error');
      })
      .catch(()=>{ this.loading=false; showToast('Network error','error'); });
    },
    googleSignup() {
      const clientId = '963442018052-3d7k7b3omdu7p39h9snn1018ep4mp92r.apps.googleusercontent.com';
      const redirectUri = '<?php echo esc_url(site_url("/callback/google-auth/")); ?>';
      const scope = 'openid email profile';

      location.href =
        'https://accounts.google.com/o/oauth2/v2/auth' +
        '?client_id=' + clientId +
        '&redirect_uri=' + encodeURIComponent(redirectUri) +
        '&response_type=code' +
        '&scope=' + encodeURIComponent(scope) +
        '&prompt=select_account';
    },
    login() {
      location.href = '/app/login';
    }
  }
}).mount('#app');
</script>

<?php wp_footer(); ?>
</body>
</html>