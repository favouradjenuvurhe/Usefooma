<?php if (!defined('ABSPATH')) exit;  

global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  

// Settings  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  

$color_hex = $settings['color_hex'] ?? '#0057ff';  

// User  
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;  
$table_txn = $base_prefix . 'trnx';  

// Transactions  
$transactions = $wpdb->get_results(  
    $wpdb->prepare("SELECT * FROM {$table_txn} WHERE user_id = %d ORDER BY id DESC LIMIT 50", $user_id)  
);  

// Format  
$txn_data = [];  
foreach ($transactions as $txn) {  
    $txn_date = new DateTime($txn->date ?? $txn->updated_at ?? current_time('mysql'));  

    $txn_data[] = [  
        'id'     => $txn->id,  
        'title'  => substr($txn->description, 0, 23),  
        'ref'    => $txn_date->format('M d, Y g:i A'),  
        'raw_date' => $txn_date->format('Y-m-d H:i:s'),  
        'amount' => (float)$txn->amount,  
        'type'   => $txn->type,  
        'status' => $txn->status  
    ];  
}  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
<meta charset="UTF-8">  
<meta name="viewport" content="width=device-width, initial-scale=1.0">  

<title>Transactions</title>  

<script src="https://cdn.tailwindcss.com"></script>  
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>  

<style>  
:root {  
  --primary: <?= esc_attr($color_hex) ?>;  
}  

* { box-sizing: border-box; }  

body {  
  background: #f5f5f5;  
  font-family: ui-sans-serif, system-ui;  
  margin: 0;  
  padding-bottom: calc(90px + env(safe-area-inset-bottom));  
  overflow-x: hidden;  
}  

.icon { width: 16px; height: 16px; }  

.card {  
  background: white;  
  border-radius: 20px;  
  box-shadow: 0 3px 10px rgba(0,0,0,0.05);  
}  
</style>  
</head>  

<body>  

<div id="app" class="max-w-md mx-auto px-4 pt-3">  

  <!-- HEADER -->
  <div class="mb-3">  
    <h1 class="text-xl font-semibold">Transactions</h1>  
  </div>  

  <!-- SEARCH -->
  <div class="mb-4 flex gap-2">  
    <div class="flex items-center gap-2 bg-gray-100 px-3 py-3 rounded-xl flex-1">  
      <img src="https://www.svgrepo.com/show/532552/search-alt-2.svg" class="icon opacity-50">  
      <input type="text" v-model="search"  
        placeholder="Search"  
        class="bg-transparent outline-none text-sm w-full text-gray-600 placeholder-gray-400">  
    </div>  

    <div class="bg-gray-100 px-3 rounded-xl flex items-center justify-center">  
      <img src="https://www.svgrepo.com/show/488941/filter-list.svg" class="icon">  
    </div>  
  </div>  

  <!-- TRANSACTIONS -->
  <div class="space-y-3 mb-24">  

    <template v-if="Object.keys(groupedTransactions).length">  

      <template v-for="(items, group) in groupedTransactions" :key="group">

        <!-- GROUP TITLE -->
        <p class="text-xs font-semibold text-gray-500 mt-3 mb-2 uppercase">
          {{ group }}
        </p>

        <!-- ITEMS -->
        <a v-for="item in items"  
           :key="item.id"  
           :href="'/app/view-transaction?id=' + item.id"  
           class="card px-4 py-4 flex justify-between items-center w-full">  

          <div class="flex gap-3 items-center flex-1 min-w-0">  

            <div class="bg-gray-100 p-3 rounded-full flex-shrink-0">  
              <img src="https://www.svgrepo.com/show/379273/transaction.svg" class="icon">  
            </div>  

            <div class="min-w-0">  
              <p class="text-[15px] font-medium text-gray-800 truncate">  
                {{ item.title }}  
              </p>  
              <p class="text-xs text-gray-400 truncate mt-0.5">  
                {{ item.ref }}  
              </p>  
            </div>  

          </div>  

          <p class="text-[15px] font-semibold ml-3"
             :style="{
               color: item.status === 'failed'
                 ? '#9ca3af'
                 : item.type === 'credit'
                   ? 'var(--primary)'
                   : '#ef4444'
             }">
            {{ item.type === 'credit' ? '+' : '-' }} ₦{{ Math.abs(item.amount).toFixed(2) }}
          </p>  

        </a>  

      </template>

    </template>  

    <!-- EMPTY -->
    <div v-else class="text-center text-gray-500 mt-10 text-base">  
      No transactions found  
    </div>  

  </div>  

  <!-- FOOTER -->
  <div class="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-3">  

    <div onclick="window.location.href='/app/home'"  
         class="flex flex-col items-center text-gray-400 cursor-pointer">  
      <img src="https://www.svgrepo.com/show/529022/home-smile-angle.svg" class="w-5">  
      <p class="text-xs">Home</p>  
    </div>  

    <div class="flex flex-col items-center cursor-pointer"  
         style="color: var(--primary);">  
      <img src="https://www.svgrepo.com/show/523270/chart-square.svg" class="w-5">  
      <p class="text-xs">Transactions</p>  
    </div>  

    <div onclick="window.location.href='/app/services'"  
         class="flex flex-col items-center text-gray-400 cursor-pointer">  
      <img src="https://www.svgrepo.com/show/497333/more-square.svg" class="w-5">  
      <p class="text-xs">Services</p>  
    </div>  

    <div onclick="window.location.href='/app/more'"  
         class="flex flex-col items-center text-gray-400 cursor-pointer">  
      <img src="https://www.svgrepo.com/show/499608/grid-aspect-ratio.svg" class="w-5">  
      <p class="text-xs">More</p>  
    </div>  

  </div>  

</div>  

<script>  
const { createApp } = Vue;  

createApp({  
  data() {  
    return {  
      search: '',  
      transactions: <?= json_encode($txn_data) ?>  
    }  
  },  
  computed: {  

    filteredTransactions() {  
      return this.transactions.filter(txn =>  
        txn.title.toLowerCase().includes(this.search.toLowerCase()) ||  
        txn.ref.toLowerCase().includes(this.search.toLowerCase())  
      );  
    },  

    groupedTransactions() {  
      const groups = { Today: [], Yesterday: [], 'This Month': [] };  

      const now = new Date();  
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());  
      const yesterday = new Date(today);  
      yesterday.setDate(today.getDate() - 1);  

      this.filteredTransactions.forEach(txn => {  
        const d = new Date(txn.raw_date);  
        const txnDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());  

        if (txnDay.getTime() === today.getTime()) {  
          groups.Today.push(txn);  
        } else if (txnDay.getTime() === yesterday.getTime()) {  
          groups.Yesterday.push(txn);  
        } else {  
          groups['This Month'].push(txn);  
        }  
      });  

      return groups;  
    }  

  }  
}).mount('#app');  
</script>  

</body>  
</html>