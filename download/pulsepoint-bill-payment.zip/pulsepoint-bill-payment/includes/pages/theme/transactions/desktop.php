<?php
/**
 * Transaction History Page - Desktop Mode with Search & Load More
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// Get current user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$table_txn   = $base_prefix . 'trnx';

$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : 'User';

// Fetch latest 50 transactions
$transactions = $wpdb->get_results(
    $wpdb->prepare("SELECT * FROM {$table_txn} WHERE user_id = %d ORDER BY id DESC LIMIT 50", $user_id)
);

// Banner slides for desktop UI
$banner_slides = [
    $settings['ads1_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads2_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png',
    $settings['ads3_url'] ?? 'https://pulsepoint-plugin.vercel.app/img/ads.png'
];
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Transactions - <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root {
  --app-bg: #f5f6fa;
  --card-bg: #ffffff;
  --primary: <?= $color_hex ?>;
  --muted: #6b7280;
}
body { font-family:'Inter',sans-serif; background:var(--app-bg); margin:0; }
.content-wrapper { max-width:900px; margin:40px auto; padding:0 20px; }
.card { background:var(--card-bg); padding:28px; border-radius:18px; box-shadow:0 4px 18px rgba(0,0,0,0.08); border:1px solid #ececec; width:100%; }
.txn-card { background: var(--card-bg); border-radius: 16px; padding: 16px; border: 1px solid #e5e7eb; margin-bottom: 12px; display:flex; justify-content: space-between; align-items:center; transition: .15s; }
.txn-card:hover { transform: translateY(-2px); }
.thin-hr { height: 1px; background: #e6e9ef; margin-top: 16px; }
.input-search { border:1px solid #ccc; border-radius:8px; padding:10px; width:100%; margin-bottom:16px; font-weight:600; }
.load-btn { background:var(--primary); color:#fff; padding:10px 16px; border-radius:10px; font-weight:600; cursor:pointer; margin-top:12px; display:block; width:100%; text-align:center; }
.slider-container { position:relative; width:100%; height:200px; overflow:hidden; border-radius:14px; margin-top:40px; }
.slider-track { display:flex; width:100%; height:100%; transition:transform 0.6s ease; }
.slide { min-width:100%; height:200px; }
.slide img { width:100%; height:100%; object-fit:cover; border-radius:14px; }
.slider-dots { text-align:center; margin-top:10px; }
.slider-dots span { display:inline-block; width:10px; height:10px; background:#ccc; border-radius:50%; margin:0 4px; cursor:pointer; }
.slider-dots .active { background:var(--primary); }
</style>
</head>

<body>
<div id="app">
  <div class="content-wrapper">
    
    <!-- Header -->
    <div class="flex items-center justify-between mb-6 mt-2">
      <div class="flex items-center gap-3">
        <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
          <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
        </button>
        <h2 class="text-xl font-bold text-gray-900">Transactions</h2>
      </div>
    </div>

    <!-- Search Box -->
    <input v-model="searchQuery" type="text" placeholder="Search by reference..." class="input-search" />

    <!-- Transactions List -->
    <div class="card mt-4 p-6">
      <div v-if="filteredTransactions.length === 0" class="text-center text-gray-500 mt-10 text-base">
        <i data-lucide="receipt-text" class="w-10 h-10 mx-auto mb-3 text-gray-400"></i>
        No transactions found
      </div>

      <a v-for="txn in paginatedTransactions" :key="txn.id" :href="`/app/view-transaction?id=${txn.id}`" class="block txn-card">
        <div>
          <div class="font-semibold text-gray-900 text-sm">{{ txn.reference }}</div>
          <div class="text-xs text-gray-500 mt-1">{{ txn.date }}</div>
        </div>
        <div class="text-right font-bold text-[var(--primary)]">₦{{ parseFloat(txn.amount).toLocaleString('en-NG', {minimumFractionDigits:2}) }}</div>
      </a>

      <!-- Load More Button -->
      <button v-if="showLoadMore" @click="loadMore" class="load-btn">Load More</button>
    </div>

    <div class="thin-hr"></div>

    <!-- Banner Slider -->
    <div class="slider-container mt-6">
      <div class="slider-track" id="sliderTrack">
        <?php foreach ($banner_slides as $slide): ?>
        <div class="slide"><img src="<?= esc_url($slide) ?>" alt="Banner"></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="slider-dots" id="sliderDots">
      <?php for ($i=0;$i<count($banner_slides);$i++): ?>
      <span data-index="<?= $i ?>"></span>
      <?php endfor; ?>
    </div>

  </div>
</div>

<script>
const { createApp } = Vue;
createApp({
  data(){
    return {
      searchQuery: '',
      transactions: <?= json_encode(array_map(function($t){
        return [
          'id' => $t->id,
          'reference' => ucfirst($t->description),
          'date' => date("M j, Y · g:i A", strtotime($t->date)),
          'amount' => $t->amount
        ];
      }, $transactions)) ?>,
      displayCount: 7
    }
  },
  computed: {
    filteredTransactions(){
      if(!this.searchQuery) return this.transactions;
      return this.transactions.filter(t => t.reference.toLowerCase().includes(this.searchQuery.toLowerCase()));
    },
    paginatedTransactions(){
      return this.filteredTransactions.slice(0, this.displayCount);
    },
    showLoadMore(){
      return this.displayCount < this.filteredTransactions.length;
    }
  },
  methods:{
    goBack(){ window.history.back(); },
    loadMore(){ this.displayCount += 7; }
  }
}).mount('#app');
</script>

<script>
// Slider Script
let index=0;
const track=document.getElementById("sliderTrack");
const dots=document.querySelectorAll("#sliderDots span");
const total=dots.length;
function updateSlider(){ track.style.transform=`translateX(-${index*100}%)`; dots.forEach(d=>d.classList.remove("active")); dots[index].classList.add("active"); }
dots.forEach(dot=>{ dot.onclick=()=>{ index=parseInt(dot.dataset.index); updateSlider(); }; });
setInterval(()=>{ index=(index+1)%total; updateSlider(); },3500);
updateSlider();
</script>

<script>lucide.createIcons();</script>
</body>
</html>