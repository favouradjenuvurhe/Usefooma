<?php  
/**
 * View Transaction Page for Pulsepoint Plugin - Desktop Mode
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex = $settings['color_hex'] ?? '#6C63FF';

// Logged-in User
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_txn = $base_prefix . 'trnx';
$table_users = $base_prefix . 'users';

// Transaction
$txn_id = intval($_GET['id'] ?? 0);
$txn = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_txn} WHERE id = %d AND user_id = %d",
    $txn_id,
    $user_id
));

if (!$txn) wp_die('<h2 style="font-family:Inter;text-align:center;margin-top:60px;">Transaction not found.</h2>');

$recipient_user = $wpdb->get_row($wpdb->prepare("SELECT firstname, lastname FROM {$table_users} WHERE id = %d", $txn->user_id));
$recipient_name = $recipient_user ? $recipient_user->firstname . ' ' . $recipient_user->lastname : $txn->recipient;

// Extract USD
$dollar_amount = null;
if (preg_match('/\$([\d.,]+)/', $txn->description, $matches)) {
    $dollar_amount = number_format((float)str_replace(',', '', $matches[1]), 2);
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc_html($platform_name) ?> - Transaction</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
:root {
    --primary: <?= $color_hex ?>;
    --bg: #f5f6fa;
    --card: #ffffff;
    --muted: #6b7280;
}
body { font-family:'Inter',sans-serif; background: var(--bg); color:#111827; margin:0; }
.container { max-width: 900px; margin:40px auto; padding:0 20px; }
.card { background:var(--card); padding:28px; border-radius:18px; box-shadow:0 4px 18px rgba(0,0,0,0.08); border:1px solid #ececec; }
.thin-line { height:1px; background: rgba(0,0,0,0.06); margin:18px 0; }
.muted { color: var(--muted); font-weight:500; }
.copy-btn { width:44px; height:34px; border-radius:8px; display:flex; align-items:center; justify-content:center; background:linear-gradient(180deg, rgba(76,217,100,0.12), rgba(76,217,100,0.06)); cursor:pointer; }
.action-row:hover { background: rgba(0,0,0,0.03); }
.timeline-line { width:2px; background:rgba(0,0,0,0.1); left:18px; top:0; bottom:0; position:absolute; border-radius:4px; }
.timeline-icon { width:40px; height:40px; display:flex; align-items:center; justify-content:center; border-radius:9999px; background:white; font-size:1.4rem; color: <?= $color_hex ?>; font-weight:bold; }
.timestamp { font-size:0.75rem; color:#6b7280; }
</style>
</head>
<body>
<div id="app" class="container">

<!-- Header -->
<div class="flex items-center justify-between mb-6">
    <div class="flex items-center gap-3">
        <button @click="goBack" class="p-2 rounded-full bg-gray-100">
            <i class="bi bi-arrow-left-circle" style="font-size:1.4rem;color:<?= $color_hex ?>;"></i>
        </button>
        <div class="text-gray-900 text-lg font-semibold">Transaction</div>
    </div>
    <button @click="doShare" class="share-btn text-white px-4 py-2 rounded-md text-sm font-semibold shadow-lg flex items-center gap-2" :style="{background:'linear-gradient(180deg,'+primaryColor+','+primaryColor+')'}">
        <span>Share</span>
    </button>
</div>

<!-- Timeline -->
<div class="relative pl-12 mb-6">
    <div class="timeline-line"></div>
    <div class="space-y-6 relative z-10">

        <div class="flex items-start gap-4 relative">
            <div class="timeline-icon"><i class="bi bi-clock-fill"></i></div>
            <div class="flex-1">
                <div class="flex items-center justify-between">
                    <div class="font-semibold text-gray-900">Initiated</div>
                    <div class="timestamp"><?= date("M j, Y · g:i A", strtotime($txn->date)) ?></div>
                </div>
                <div class="muted mt-1">You made this transaction</div>
            </div>
        </div>

        <div class="flex items-start gap-4 relative">
            <div class="timeline-icon"><i class="bi bi-send-fill"></i></div>
            <div class="flex-1">
                <div class="flex items-center justify-between">
                    <div class="font-semibold text-gray-900">Sent</div>
                    <div class="timestamp"><?= date("M j, Y · g:i A", strtotime($txn->date)) ?></div>
                </div>
                <div class="muted mt-1">Your transaction is on its way.</div>
            </div>
        </div>

        <div class="flex items-start gap-4 relative">
            <div class="timeline-icon"><i class="bi bi-check-circle-fill"></i></div>
            <div class="flex-1">
                <div class="flex items-center justify-between">
                    <div class="font-semibold text-gray-900">Completed</div>
                    <div class="timestamp"><?= date("M j, Y · g:i A", strtotime($txn->date)) ?></div>
                </div>
                <div class="muted mt-1">Has received your transaction.</div>
            </div>
        </div>

    </div>
</div>

<div class="thin-line"></div>

<!-- Details -->
<div class="card mb-6 space-y-4">
    <div>
        <div class="text-sm muted">To</div>
        <div class="text-lg font-semibold text-gray-900"><?= esc_html($recipient_name) ?></div>
    </div>
    <div class="thin-line"></div>

    <div>
        <div class="text-sm muted">Description</div>
        <div class="text-base mt-2"><?= nl2br(esc_html($txn->description)) ?></div>
    </div>
    <div class="thin-line"></div>

    <div class="flex items-center justify-between">
        <div>
            <div class="text-sm muted">Payment Method</div>
            <div class="text-base font-semibold mt-1"><?= esc_html($txn->payment) ?></div>
        </div>
        <div class="text-right">
            <div class="text-sm muted">Amount</div>
            <div class="text-base font-semibold mt-1">
                <?php
                $amount = $txn->amount;
                $currency = ($amount < 2 || floor($amount) != $amount) ? '$' : '₦';
                $formatted_amount = number_format($amount, 2);
                echo $currency . $formatted_amount;
                ?>
            </div>
        </div>
    </div>

    <div class="thin-line"></div>

    <div>
        <div class="text-sm muted">Recipient</div>
        <div class="flex items-center justify-between mt-2">
            <div class="text-base font-semibold"><?= esc_html($txn->recipient ?? 'N/A') ?></div>
            <button @click="copy('<?= esc_js($txn->recipient ?? '') ?>')" class="copy-btn">
                <i class="bi bi-clipboard"></i>
            </button>
        </div>
    </div>

    <div class="thin-line"></div>

    <div>
        <div class="text-sm muted">Transaction Reference</div>
        <div class="flex items-center justify-between mt-2">
            <div class="break-all font-bold text-[14px]"><?= esc_html($txn->reference) ?></div>
            <button @click="copy('<?= esc_js($txn->reference) ?>')" class="copy-btn">
                <i class="bi bi-clipboard"></i>
            </button>
        </div>
    </div>
</div>

<!-- More Actions -->
<div class="text-lg font-semibold mb-3">More Actions</div>
<div class="space-y-2">
    <div class="rounded-md p-3 flex items-center justify-between action-row bg-gray-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center">
                <i class="bi bi-person-plus-fill text-<?= $color_hex ?> text-lg font-bold"></i>
            </div>
            <div>
                <div class="font-semibold text-gray-900">Add as Beneficiary</div>
                <div class="muted text-sm">Save the account details for quicker transfers.</div>
            </div>
        </div>
        <i class="bi bi-chevron-right text-gray-500"></i>
    </div>

    <div class="rounded-md p-3 flex items-center justify-between action-row bg-gray-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center">
                <i class="bi bi-arrow-repeat text-<?= $color_hex ?> text-lg font-bold"></i>
            </div>
            <div>
                <div class="font-semibold text-gray-900">Repeat Transaction</div>
                <div class="muted text-sm">Make this payment again now.</div>
            </div>
        </div>
        <i class="bi bi-chevron-right text-gray-500"></i>
    </div>

    <div class="rounded-md p-3 flex items-center justify-between action-row bg-gray-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center">
                <i class="bi bi-exclamation-triangle-fill text-red-500 text-lg font-bold"></i>
            </div>
            <div>
                <div class="font-semibold text-gray-900">Report Transaction</div>
                <div class="muted text-sm">Report an issue with this payment.</div>
            </div>
        </div>
        <i class="bi bi-chevron-right text-gray-500"></i>
    </div>
</div>

</div>

<script>
const { createApp } = Vue;
createApp({
    data(){ return { primaryColor: "<?= $color_hex ?>" } },
    methods:{
        goBack(){ history.back(); },
        copy(text){ navigator.clipboard?.writeText(text); this.notify("Copied"); },
        doShare(){
            html2canvas(document.body).then(canvas=>{
                const link = document.createElement("a");
                link.download = "transaction.png";
                link.href = canvas.toDataURL("image/png");
                link.click();
            });
        },
        notify(msg){
            const t=document.createElement("div");
            t.textContent=msg;
            Object.assign(t.style,{
                position:"fixed", left:"50%", transform:"translateX(-50%)",
                bottom:"28px", background:"rgba(0,0,0,0.7)", color:"#fff",
                padding:"8px 14px", borderRadius:"12px", fontSize:"13px", zIndex:9999
            });
            document.body.appendChild(t);
            setTimeout(()=>t.remove(),1500);
        }
    }
}).mount("#app");
</script>
</body>
</html>