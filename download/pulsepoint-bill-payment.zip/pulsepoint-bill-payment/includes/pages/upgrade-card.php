<?php
/**
 * Auto Freeze/Unfreeze Card Action Page
 * Path: /app/upgrade-card.php
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;
?>

<script>
document.addEventListener("DOMContentLoaded", () => {
  // 🔄 Get current state from localStorage
  let currentState = localStorage.getItem("cardState") || "freeze";
  const newState = currentState === "freeze" ? "unfreeze" : "freeze";

  // 💾 Immediately save the new state
  localStorage.setItem("cardState", newState);

  // 🚀 Send AJAX request instantly
  fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      action: "pulsepoint_card_action",
      action_type: newState
    })
  })
  .then(res => res.json())
  .then(data => {
    console.log("Freeze/Unfreeze Response:", data);
    // ✅ Redirect back to virtual card page after action completes
    window.location.href = "/app/virtual-card/";
  })
  .catch(err => {
    console.error("Freeze/Unfreeze Error:", err);
    // 🔁 Still redirect even if error occurs
    window.location.href = "/app/virtual-card/";
  });
});
</script>