<?php
/**
 * Giftcard Rates Page - Pulsepoint Plugin
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// User
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : "User";

// Fetch all giftcard settings
$table_gift = $base_prefix . "giftcard_settings";
$giftcards = $wpdb->get_results("SELECT * FROM {$table_gift} WHERE status='active' ORDER BY category, sub_category, type ASC");

// Extract unique categories for the top selector
$categories = array_unique(array_map(fn($g) => $g->category, $giftcards));
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
  <title>Giftcard Rates - <?= esc_html($platform_name) ?></title>

  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    body { background: #f7f8fb; font-family: 'Inter', sans-serif; margin: 0; padding: 0; }
    .rate-box { border-radius: 14px; padding: 16px; background: #fff; box-shadow: 0 6px 18px rgba(20,30,60,0.06); margin-bottom: 14px; }
    .bg-main-10 { background-color: <?= $color_hex ?>1A; }
    .text-main { color: <?= $color_hex ?>; }
    .category-selector { display: flex; overflow-x: auto; gap: 8px; padding-bottom: 10px; margin-bottom: 16px; }
    .category-selector button { flex: 0 0 auto; padding: 8px 16px; border-radius: 8px; border: none; cursor: pointer; font-weight: 600; }
    .category-selected { background-color: <?= $color_hex ?>; color: #fff; }
    .category-unselected { background-color: #e5e7eb; color: #111827; }
  </style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- HEADER -->
<div class="flex items-center justify-between mb-6 mt-2">
    <div class="flex items-center gap-3">
        <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
        </button>
        <h2 class="text-xl font-bold text-gray-900">Giftcard Rates</h2>
    </div>
    <div class="flex items-center space-x-3 mt-1">
        <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>
        </button>
        <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>
        </button>
    </div>
</div>

<!-- CATEGORY SELECTOR -->
<div class="category-selector">
    <button
        v-for="cat in categories"
        :key="cat"
        :class="selectedCategory === cat ? 'category-selected' : 'category-unselected'"
        @click="selectedCategory = cat"
    >{{ cat }}</button>
</div>

<!-- RATES LIST -->
<h2 class="text-xl font-bold mb-3">Available Giftcard Rates</h2>
<p class="text-gray-500 text-sm mb-5">View all active giftcard categories and payout rates.</p>

<div v-if="filteredGiftcards.length === 0" class="text-center text-gray-500 py-10">
    No active giftcard rates found for this category.
</div>

<div v-else>
    <div class="rate-box" v-for="g in filteredGiftcards" :key="g.id">
        <div class="flex justify-between items-center">
            <div>
                <p class="text-xs text-gray-500 mb-1">Category</p>
                <p class="text-lg font-semibold text-gray-900">{{ g.category }}</p>

                <p class="text-xs text-gray-500 mt-2 mb-1">Sub Category</p>
                <p class="text-base font-medium text-gray-900">{{ g.sub_category }}</p>

                <p class="text-xs text-gray-500 mt-2 mb-1">Type</p>
                <span class="px-3 py-1 rounded-full text-sm font-medium bg-main-10 text-main capitalize">
                    {{ g.type }}
                </span>
            </div>

            <div class="text-right">
                <p class="text-xs text-gray-500 mb-1">Rate</p>
                <p class="text-2xl font-extrabold text-main">
                    1$ / ₦{{ parseFloat(g.rate).toLocaleString() }}
                </p>

                <p class="text-xs text-gray-500 mt-2" v-if="g.min_amount > 0 || g.max_amount > 0">
                    Min: ${{ parseFloat(g.min_amount).toLocaleString() }}<br>
                    Max: ${{ parseFloat(g.max_amount).toLocaleString() }}
                </p>
            </div>
        </div>
    </div>
</div>

</div>

<script>
lucide.createIcons();
const { createApp } = Vue;

createApp({
    data() {
        return {
            categories: <?= json_encode(array_values($categories)) ?>,
            selectedCategory: <?= json_encode($categories[0] ?? '') ?>,
            giftcards: <?= json_encode($giftcards) ?>
        }
    },
    computed: {
        filteredGiftcards() {
            return this.giftcards.filter(g => g.category === this.selectedCategory);
        }
    },
    methods: {
        goBack() { window.history.back(); }
    }
}).mount('#app');
</script>

</body>
</html>