<?php
/**
 * Profile Edit Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// User
if (!session_id()) session_start();
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : '';
$lastname = $user ? esc_html($user->lastname) : '';
$full_name = trim($firstname . ' ' . $lastname);
$email = $user ? esc_html($user->email) : '';
$current_phone = $user ? esc_html($user->phone) : '';
$avatar = $user->avatar ?? 'https://pulsepoint-plugin.vercel.app/img/avatar-placeholder.png';

$account_type = $user->account_type ?? 'Customer'; // Customer | Agent | API
$status       = isset($user->status) ? (int)$user->status : 0;
$statuskyc    = isset($user->statuskyc) ? (int)$user->statuskyc : 0;

/* Account Status */
$status_label = $status === 1 ? 'Active' : 'Disabled';
$status_color = $status === 1 ? 'text-white' : 'text-red-500';

/* KYC Level */
$kyc_label = $statuskyc == 1 ? 'Verified' : 'Unverified';
$kyc_color = $statuskyc == 1 ? 'bg-green-400' : 'bg-yellow-400';

/* Account Type Badge */
$account_badge = match ($account_type) {
    'Agent'   => 'bg-purple-100 text-purple-600',
    'API'     => 'bg-blue-100 text-blue-600',
    default   => 'bg-gray-100 text-gray-600',
};  
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Edit Profile - <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<style>
:root{
  --app-bg: #f7f8fb;
  --card-bg: #ffffff;
  --muted: #6b7280;
  --primary: <?= $color_hex ?>;
}
html, body, #app { min-height: 100%; background: var(--app-bg); }
body { font-family: 'Inter', sans-serif; margin:0; padding:0; }
.rounded-card{ border-radius:14px; background:var(--card-bg); }
.muted { color: var(--muted); }
.pay-btn { background: var(--primary); color:white; padding:10px 22px; border-radius:999px; font-weight:600; cursor:pointer; }
input { outline:none; }
.avatar { width:80px; height:80px; border-radius:999px; object-fit:cover; }
</style>
</head>
<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Profile settings</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- MAIN WRAPPER -->
<div class="min-h-screen px-4 py-6" style="background: var(--app-bg);">

  <!-- AVATAR -->
  <div class="flex justify-center mb-6 relative">
    <div class="relative">
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" class="w-24 h-24 rounded-full object-cover shadow-sm" />
      
      
    </div>
  </div>

  <!-- FORM -->
  <div class="space-y-5">

    <!-- FULL NAME -->
    <div>
      <p class="text-black text-sm font-medium mb-1">Full Name</p>
      <div class="flex justify-between items-center border-b border-gray-200 py-3">
        <p class="text-sm text-gray-500">{{ fullName }}</p>
        <img src="https://www.svgrepo.com/show/532323/lock-alt.svg" class="w-4 h-4 opacity-50"/>
      </div>
    </div>

    <!-- EMAIL -->
    <div>
      <p class="text-black text-sm font-medium mb-1">Email</p>
      <div class="flex justify-between items-center border-b border-gray-200 py-3">
        <p class="text-sm text-gray-500">{{ email }}</p>
        <img src="https://www.svgrepo.com/show/532323/lock-alt.svg" class="w-4 h-4 opacity-50"/>
      </div>
    </div>

    <!-- PHONE -->
    <div>
      <p class="text-black text-sm font-medium mb-1">Phone Number</p>

      <div class="flex gap-2 border-b border-gray-200 py-3">

        <!-- COUNTRY CODE -->
        <div class="flex items-center gap-1 text-sm text-gray-700">
          +234
          <img src="https://img.icons8.com/ios-glyphs/30/expand-arrow.png" class="w-4 h-4 opacity-50"/>
        </div>

        <!-- INPUT -->
        <input 
          v-model="phone"
          maxlength="15"
          class="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-400"
          placeholder="0801 234 5678"
        />

      </div>
    </div>

    <!-- USERNAME -->
    <div>
      <p class="text-black text-sm font-medium mb-1">Username</p>
      <div class="flex justify-between items-center border-b border-gray-200 py-3">
        <p class="text-sm text-gray-500">{{ username }}</p>
        <img src="https://www.svgrepo.com/show/532323/lock-alt.svg" class="w-4 h-4 opacity-50"/>
      </div>
    </div>

  </div>

  <!-- UPDATE BUTTON -->
  <button 
    class="mt-6 w-full h-[48px] rounded-xl text-white text-sm font-semibold"
    :style="{ background: 'var(--primary)' }"
    @click="updatePhone"
  >
    Update Profile
  </button>

  <!-- DIVIDER -->
  <div class="thin-hr mt-6"></div>

  <!-- KYC -->
  <div class="flex justify-between items-center mt-4">
    <div>
      <p class="text-black text-sm font-medium">KYC - Validation</p>
      <p class="text-xs text-gray-400">Complete your registration by verifying your account</p>
    </div>

    <div 
      class="px-3 py-1 rounded-full text-xs text-white flex items-center gap-1"
      :style="{ background: 'var(--primary)' }"
    >
      <?php echo $kyc_label; ?>
      <img src="https://www.svgrepo.com/show/532154/check.svg" class="w-3 h-3 invert"/>
    </div>
  </div>

  <!-- DELETE -->
  <div class="mt-10 flex items-center gap-2 text-red-500 justify-center">
    <img src="https://www.svgrepo.com/show/502614/delete.svg" class="w-5 h-5"/>
    <span class="text-sm font-medium">Delete Account</span>
  </div>

</div>
<script>
const { createApp } = Vue;
createApp({
data() {
return {
fullName: "<?= esc_js($full_name) ?>",
email: "<?= esc_js($email) ?>",
phone: "<?= esc_js($current_phone) ?>",
avatar: "<?= esc_js($avatar) ?>",
};
},
methods: {
goBack(){ window.history.back(); },

showLoading(){
let overlay = document.createElement('div');
overlay.id = 'loadingOverlay';
overlay.style = 'position:fixed;inset:0;backdrop-filter:blur(6px);background:rgba(255,255,255,0.4);z-index:2000;display:flex;justify-content:center;align-items:center;';
overlay.innerHTML = '<div style="font-weight:600;color:<?= $color_hex ?>;font-size:18px;">Processing...</div>';
document.body.appendChild(overlay);
},

hideLoading(){
const overlay = document.getElementById('loadingOverlay');
if(overlay) overlay.remove();
},

showToast(msg,type='info'){
Toastify({
text: msg,
duration:3000,
close:true,
gravity:'top',
position:'center',
style:{
background: type==='error'?'#ff3860':'green',
color:'#fff',
borderRadius:'12px'
}
}).showToast();
},

updatePhone(){
if(!this.phone) return this.showToast("Enter your phone",'error');

this.showLoading();
let formData = new FormData();
formData.append("action","pulsepoint_edit_phone");
formData.append("phone",this.phone);

fetch("<?= admin_url('admin-ajax.php') ?>",{method:"POST",body:formData})
.then(r=>r.json())
.then(res=>{
this.hideLoading();
if(res.success){
this.showToast("Phone updated successfully!");
} else {
this.showToast(res.message,"error");
}
})
.catch(()=>{
this.hideLoading();
this.showToast("Network error","error");
});
}
}
}).mount("#app");
</script>
<script>lucide.createIcons();</script>
</body>
</html>