<?php    
if (!defined('ABSPATH')) exit;    
    
global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
// Settings    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    
$color_hex     = $settings['color_hex'] ?? '#0057ff';    
    
// User    
if (!session_id()) session_start();    
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;    
    
$table_users = $wpdb->prefix . 'pulsepoint_users';    
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));    
    
$account_type = $user->account_type ?? 'Customer';    
    
// FETCH DATA    
$data_plans = $wpdb->get_results("SELECT * FROM {$base_prefix}data LIMIT 50");    
$cable_plans = $wpdb->get_results("SELECT * FROM {$base_prefix}cable LIMIT 50");    
$bill_plans = $wpdb->get_results("SELECT * FROM {$base_prefix}bill LIMIT 50");    
$betting = $wpdb->get_results("SELECT * FROM {$base_prefix}betting LIMIT 50");    
$education = $wpdb->get_results("SELECT * FROM {$base_prefix}education LIMIT 50");    
?>  

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Pricing - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>

<style>
:root{
  --app-bg:#f7f8fb;
  --card-bg:#fff;
  --primary:<?= $color_hex ?>;
}
body{background:var(--app-bg);font-family:Inter;}
.card{background:#fff;border-radius:16px;padding:14px;}
.tab{padding:6px 12px;border-radius:999px;font-size:12px;}
.active{background:var(--primary);color:#fff;}
.badge{
  font-size:10px;
  padding:2px 8px;
  border-radius:999px;
  background:#dcfce7;
  color:#16a34a;
}
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Pricing</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- TITLE -->
<div class="mt-6">
  <h2 class="text-lg font-semibold">Pricing page</h2>
  <p class="text-xs text-gray-400">Search and view service pricing</p>
</div>

<!-- SEARCH -->
<div class="flex gap-2 mt-3">
  <input 
    v-model="search"
    placeholder="Search ID..."
    class="flex-1 px-3 py-2 rounded-xl border text-sm outline-none"
  />
</div>

<!-- TABS -->
<div class="flex gap-2 overflow-x-auto py-3 text-xs">
  <button @click="tab='data'" :class="['tab', tab==='data' && 'active']">Data</button>
  <button @click="tab='cable'" :class="['tab', tab==='cable' && 'active']">Cable</button>
  <button @click="tab='bill'" :class="['tab', tab==='bill' && 'active']">Electricity</button>
  <button @click="tab='betting'" :class="['tab', tab==='betting' && 'active']">Betting</button>
  <button @click="tab='education'" :class="['tab', tab==='education' && 'active']">Education</button>
</div>

<!-- CONTENT -->
<div class="space-y-3 pb-10">

<!-- ================= DATA ================= -->
<template v-if="tab==='data'">
  <div v-for="(d,index) in filteredData" :key="index" class="card shadow-sm">

    <div class="flex justify-between items-start">

      <div>
        <p class="text-sm font-medium flex items-center gap-2">
          ID: {{ d.id }}
          <span v-if="isBestData(d)" class="badge">Best Deal</span>
        </p>
        <p class="text-xs text-gray-400">Network: {{ d.network }}</p>
      </div>

      <div class="text-right">
        <p class="text-sm font-semibold">₦{{ d.amount }}</p>
        <p v-if="isApi" class="text-xs text-gray-400">API: ₦{{ d.apiamount }}</p>
      </div>

    </div>

    <div class="mt-2 text-xs text-blue-500 cursor-pointer" @click="toggle(index)">
      {{ open === index ? 'Hide details' : 'View details' }}
    </div>

    <div v-if="open === index" class="mt-2 text-xs text-gray-500">
      {{ d.details }}
    </div>

  </div>
</template>

<!-- ================= CABLE ================= -->
<template v-if="tab==='cable'">
  <div v-for="(c,index) in filteredCable" :key="index" class="card shadow-sm">

    <div class="flex justify-between">
      <div>
        <p class="text-sm font-medium">ID: {{ c.id }}</p>
        <p class="text-xs text-gray-400">{{ c.type }}</p>
      </div>

      <div class="text-right">
        <p class="text-sm font-semibold">₦{{ c.amount }}</p>
        <p v-if="isApi" class="text-xs text-gray-400">API: ₦{{ c.apiamount }}</p>
      </div>
    </div>

    <div class="mt-2 text-xs text-blue-500 cursor-pointer" @click="toggle(index)">
      {{ open === index ? 'Hide details' : 'View details' }}
    </div>

    <div v-if="open === index" class="text-xs text-gray-500 mt-2">
      {{ c.details }}
    </div>

  </div>
</template>

<!-- ================= BILL ================= -->
<template v-if="tab==='bill'">
  <div v-for="(b,index) in filteredBill" :key="index" class="card shadow-sm">

    <div class="flex justify-between">
      <div>
        <p class="text-sm font-medium">ID: {{ b.id }}</p>
        <p class="text-xs text-gray-400">{{ b.details }}</p>
      </div>

      <div class="text-right">
        <p class="text-sm font-semibold">₦{{ b.fee }}</p>
        <p v-if="isApi" class="text-xs text-gray-400">API: ₦{{ b.fee_api }}</p>
      </div>
    </div>

  </div>
</template>

<!-- ================= BETTING ================= -->
<template v-if="tab==='betting'">
  <div v-for="(bt,index) in filteredBetting" :key="index" class="card shadow-sm">

    <div class="flex justify-between">
      <p class="text-sm font-medium">ID: {{ bt.id }}</p>

      <div class="text-right">
        <p class="text-sm font-semibold">₦{{ bt.fee }}</p>
        <p v-if="isApi" class="text-xs text-gray-400">API: ₦{{ bt.fee_api }}</p>
      </div>
    </div>

  </div>
</template>

<!-- ================= EDUCATION ================= -->
<template v-if="tab==='education'">
  <div v-for="(ed,index) in filteredEducation" :key="index" class="card shadow-sm">

    <div class="flex justify-between">
      <p class="text-sm font-medium">ID: {{ ed.id }}</p>
      <p class="text-xs text-gray-400">{{ ed.servicename }}</p>
       
      <div class="text-right">
        <p class="text-sm font-semibold">₦{{ ed.price }}</p>
        <p v-if="isApi" class="text-xs text-gray-400">API: ₦{{ ed.price_api }}</p>
      </div>
    </div>

  </div>
</template>

</div>
</div>

<script>
const { createApp } = Vue;

createApp({
data(){
return{
tab:'data',
search:'',
open:null,
isApi: <?= $account_type === 'API' ? 'true' : 'false' ?>,

data: <?= json_encode($data_plans) ?>,
cable: <?= json_encode($cable_plans) ?>,
bill: <?= json_encode($bill_plans) ?>,
betting: <?= json_encode($betting) ?>,
education: <?= json_encode($education) ?>
}
},

methods:{
toggle(i){
this.open = this.open === i ? null : i;
},

isBestData(item){
if(!this.data.length) return false;
return Number(item.amount) === Math.min(...this.data.map(d=>Number(d.amount)));
}
},

computed:{

filteredData(){
return this.data.filter(i =>
String(i.id).includes(this.search)
);
},

filteredCable(){
return this.cable.filter(i =>
String(i.id).includes(this.search)
);
},

filteredBill(){
return this.bill.filter(i =>
String(i.id).includes(this.search)
);
},

filteredBetting(){
return this.betting.filter(i =>
String(i.id).includes(this.search)
);
},

filteredEducation(){
return this.education.filter(i =>
String(i.id).includes(this.search)
);
}

}
}).mount("#app");

lucide.createIcons();
</script>

</body>
</html>