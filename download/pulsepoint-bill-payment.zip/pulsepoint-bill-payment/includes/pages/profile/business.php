<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// User
if (!session_id()) session_start();
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$account_type = $user->account_type ?? 'Customer';

$token = $user->token ?? '';
$customerId = $user->customerId ?? '';
$cardid = $user->cardid ?? '';
$account_limit = $user->account_limit ?? '0';
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Business Information - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root{
  --app-bg:#f7f8fb;
  --card-bg:#fff;
  --primary:<?= $color_hex ?>;
}
body{background:var(--app-bg);font-family:Inter;}
.card{background:#fff;border-radius:16px;padding:16px;}
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Business Info</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>

<!-- BUSINESS HEADER -->
<div class="mt-6">
  <h2 class="text-lg font-semibold text-black">Business Settings</h2>
  <p class="text-xs text-gray-400">Manage your business account, API access and integration</p>
</div>

<!-- MAIN -->
<div class="py-6 space-y-4">

  <!-- ACCOUNT CARD -->
  <div class="card space-y-4 shadow-sm">

    <div class="flex justify-between text-sm">
      <span class="text-gray-400">Type</span>
      <span class="font-medium"><?= esc_html($account_type) ?></span>
    </div>

    <div class="flex justify-between text-sm">
      <span class="text-gray-400">Daily Transaction limit</span>
      <span class="font-medium">₦<?= number_format($account_limit) ?></span>
    </div>

  </div>

  <?php if($account_type === 'API'): ?>

  <!-- API CARD -->
  <div class="card space-y-5 shadow-sm">

    <div>
      <p class="text-sm font-semibold">API Access</p>
      <p class="text-xs text-gray-400">Use these credentials to integrate with our system</p>
    </div>

    <!-- TOKEN -->
    <div>
      <p class="text-xs text-gray-400 mb-1">API Token</p>
      <div class="flex items-center justify-between bg-gray-50 px-3 py-2 rounded-xl">

        <p class="text-xs truncate">
          {{ showToken ? token : '••••••••••••••••••••••••' }}
        </p>

        <div class="flex items-center gap-2">
          <button @click="toggleToken">
            <i :data-lucide="showToken ? 'eye-off' : 'eye'" class="w-4 h-4"></i>
          </button>

          <button @click="copy(token)">
            <i data-lucide="copy" class="w-4 h-4"></i>
          </button>
        </div>

      </div>
    </div>

    <!-- CUSTOMER ID -->
    <div>
      <p class="text-xs text-gray-400 mb-1">Customer ID</p>
      <div class="flex justify-between items-center bg-gray-50 px-3 py-2 rounded-xl">
        <p class="text-sm">{{ customerId }}</p>
        <button @click="copy(customerId)">
          <i data-lucide="copy" class="w-4 h-4"></i>
        </button>
      </div>
    </div>

    

    <!-- ACTIONS -->
    <div class="flex gap-2 pt-2">

      <button 
        @click="regenerateToken"
        class="flex-1 py-2 rounded-xl text-white text-sm font-semibold"
        style="background:var(--primary)"
      >
        Regenerate Token
      </button>

    </div>

  </div>

  <?php endif; ?>

  <!-- LINKS -->
  <div class="space-y-3 pt-2">

    <a href="/app/pricing" 
       class="block text-center py-3 rounded-xl text-white font-semibold"
       style="background:var(--primary)">
       View Pricing
    </a>

    <a href="/app/documentation" 
       class="block text-center py-3 rounded-xl border font-semibold">
       API Documentation
    </a>

  </div>

</div>

</div>

<script>
const { createApp } = Vue;

createApp({
data(){
return{
token:"<?= esc_js($token) ?>",
customerId:"<?= esc_js($customerId) ?>",
cardid:"<?= esc_js($cardid) ?>",
showToken:false
}
},
methods:{
toggleToken(){
this.showToken = !this.showToken;
this.$nextTick(()=>lucide.createIcons());
},

copy(text){
navigator.clipboard.writeText(text);
Toastify({
text:"Copied!",
duration:2000,
gravity:"top",
position:"center",
style:{background:"green",borderRadius:"10px"}
}).showToast();
},

regenerateToken(){

Toastify({
text:"Token regeneration coming soon ⚡",
duration:3000,
gravity:"top",
position:"center",
style:{background:"black",borderRadius:"10px"}
}).showToast();
}
}
}).mount("#app");

lucide.createIcons();
</script>

</body>
</html>