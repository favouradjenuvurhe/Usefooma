<?php
/**
 * Profile Page for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/profile.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// Logged-in user session
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : 'User';
$lastname  = $user ? esc_html($user->lastname) : '';
$avatar    = $user && !empty($user->avatar) ? esc_url($user->avatar) : '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Profile | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
  :root {
    --primary: <?= esc_html($color_hex) ?>;
  }
  body {
    font-family: 'Inter', sans-serif;
    background: #f9fafb;
    padding: 16px;
    min-height: 100vh;
  }
  .header-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
  }
  .header-bar i {
    font-size: 22px;
    color: #000;
    cursor: pointer;
  }
  .header-avatar {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    overflow: hidden;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--primary);
    color: #fff;
    font-weight: 600;
    font-size: 16px;
    text-transform: uppercase;
  }
  .header-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .menu-card {
    background: #fff;
    border-radius: 18px;
    padding: 14px 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 3px 10px rgba(0,0,0,0.06);
    transition: all 0.2s ease;
  }
  .menu-card:active {
    transform: scale(0.98);
  }
  .menu-left {
    display: flex;
    align-items: center;
    gap: 14px;
  }
  .menu-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(108,99,255,0.08);
    color: var(--primary);
    font-size: 20px;
  }
  .menu-title {
    font-weight: 600;
    font-size: 15px;
    color: #111;
  }
  .menu-desc {
    font-size: 13px;
    color: #6b7280;
  }
  .logout-btn {
    display: block;
    text-align: center;
    padding: 14px;
    border-radius: 12px;
    border: 2px solid var(--primary);
    color: var(--primary);
    font-weight: 600;
    margin-top: 1.8rem;
    transition: all 0.3s ease;
  }
  .logout-btn:active {
    transform: scale(0.98);
  }
  .logout-btn:hover {
    background: var(--primary);
    color: #fff;
  }
</style>
</head>

<body>
<div class="max-w-md mx-auto space-y-4">

  <!-- Header -->
  <div class="header-bar">
    <a href="/app/dashboard"><i class="bi bi-arrow-left-circle"></i></a>
     <div class="header-avatar">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkRoTuUFfHZ4yMl5ew-nnYgsn47chDt5yHdsjeEPXxrA&s=10" alt="User Avatar">
    </div>
  </div>

  <h1 class="text-lg font-semibold mb-3">Hi, <?= $firstname ?> <?= $lastname ?></h1>

  <!-- Menu Items -->
  <a href="/app/profile-edit" class="menu-card">
    <div class="menu-left">
      <div class="menu-icon"><i class="bi bi-person"></i></div>
      <div>
        <div class="menu-title">Personal Information</div>
        <div class="menu-desc">Edit your information</div>
      </div>
    </div>
    <i class="bi bi-chevron-right text-gray-400"></i>
  </a>

  <a href="/app/settings" class="menu-card">
    <div class="menu-left">
      <div class="menu-icon"><i class="bi bi-gear"></i></div>
      <div>
        <div class="menu-title">Settings</div>
        <div class="menu-desc">Account, notification</div>
      </div>
    </div>
    <i class="bi bi-chevron-right text-gray-400"></i>
  </a>

  <a href="/app/refer" class="menu-card">
    <div class="menu-left">
      <div class="menu-icon"><i class="bi bi-people"></i></div>
      <div>
        <div class="menu-title">Refer & Earn</div>
        <div class="menu-desc">Invite your friends and get a bonus</div>
      </div>
    </div>
    <i class="bi bi-chevron-right text-gray-400"></i>
  </a>

  <a href="/app/legal" class="menu-card">
    <div class="menu-left">
      <div class="menu-icon"><i class="bi bi-file-earmark-text"></i></div>
      <div>
        <div class="menu-title">Legal & Policies</div>
        <div class="menu-desc">Privacy policy, terms of service</div>
      </div>
    </div>
    <i class="bi bi-chevron-right text-gray-400"></i>
  </a>

  <a href="/app/support" class="menu-card">
    <div class="menu-left">
      <div class="menu-icon"><i class="bi bi-headphones"></i></div>
      <div>
        <div class="menu-title">Help & Support</div>
        <div class="menu-desc">Have an issue? Speak to our team</div>
      </div>
    </div>
    <i class="bi bi-chevron-right text-gray-400"></i>
  </a>

  <!-- Sign Out -->
  <a href="/logout" class="logout-btn">Sign Out</a>

</div>
</body>
</html>