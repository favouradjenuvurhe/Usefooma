<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];

foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// BASE URL (AUTO cPanel DOMAIN)
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$base_url .= "://" . $_SERVER['HTTP_HOST'];
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>API Docs - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>

<style>
:root{
  --primary: <?= $color_hex ?>;
}
body{
  background:#f7f8fb;
  font-family: Inter;
}
.card{
  background:#fff;
  border-radius:16px;
  padding:14px;
  margin-bottom:12px;
}
pre{
  background:#0f172a;
  color:#e2e8f0;
  padding:10px;
  border-radius:12px;
  overflow-x:auto;
  font-size:11px;
}
h2{font-size:18px;font-weight:600;}
h3{font-size:14px;font-weight:600;margin-top:10px;}
.badge{
  background:var(--primary);
  color:#fff;
  font-size:10px;
  padding:2px 8px;
  border-radius:999px;
}
</style>
</head>

<body>

<div class="max-w-md mx-auto px-4 py-6">

  <!-- HEADER -->
  <div class="flex items-center gap-2 mb-4">
    <button onclick="window.history.back()">
      <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" class="w-6 h-6"/>
    </button>
    <h2>API Documentation</h2>
  </div>

  <p class="text-xs text-gray-500 mb-4">
    Base URL: <span class="font-semibold"><?= $base_url ?>/api</span>
  </p>

  <!-- DATA API -->
  <div class="card">
    <div class="flex justify-between items-center">
      <h3>Data API</h3>
      <span class="badge">POST</span>
    </div>

<pre>
curl -X POST <?= $base_url ?>/api/data \
-H "Content-Type: application/json" \
-H "Authorization: Token YOUR_USER_TOKEN_HERE" \
-d '{
  "network": "MTN",
  "plan": "131",
  "mobile_number": "09064873505",
  "Ported_number": false
}'
</pre>

<pre>
Response:
{
  "success": true,
  "message": "Data plan purchased successfully",
  "data": {
    "transaction_id": "TXN987654321",
    "status": "completed",
    "balance": "₦4,500.00"
  }
}
</pre>
  </div>

  <!-- AIRTIME -->
  <div class="card">
    <div class="flex justify-between items-center">
      <h3>Airtime API</h3>
      <span class="badge">POST</span>
    </div>

<pre>
curl -X POST <?= $base_url ?>/api/airtime \
-H "Content-Type: application/json" \
-H "Authorization: Token YOUR_USER_TOKEN_HERE" \
-d '{
  "network": "MTN",
  "amount": 1000,
  "mobile_number": "09064876505",
  "Ported_number": false,
  "airtime_type": "VTU"
}'
</pre>
  </div>

  <!-- CABLE -->
  <div class="card">
    <div class="flex justify-between items-center">
      <h3>Cable API</h3>
      <span class="badge">POST</span>
    </div>

<pre>
curl -X POST <?= $base_url ?>/api/cable \
-H "Content-Type: application/json" \
-H "Authorization: Token YOUR_USER_TOKEN_HERE" \
-d '{
  "plan": 123,
  "smartcard": "12345678901",
  "details": "DSTV Compact",
  "amount": 5000,
  "reference": "INV20251219001"
}'
</pre>
  </div>

  <!-- ELECTRICITY -->
  <div class="card">
    <div class="flex justify-between items-center">
      <h3>Electricity API</h3>
      <span class="badge">POST</span>
    </div>

<pre>
curl -X POST <?= $base_url ?>/api/electricity \
-H "Content-Type: application/json" \
-H "Authorization: Token YOUR_USER_TOKEN_HERE" \
-d '{
  "disco": "EKEDC",
  "meter_type": "prepaid",
  "meter_number": "1234567890",
  "amount": 5000,
  "bypass": false,
  "reference": "ELEC20251219001"
}'
</pre>
  </div>

</div>

</body>
</html>