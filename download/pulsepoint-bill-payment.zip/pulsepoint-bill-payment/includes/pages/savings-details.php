<?php
/**
 * Pulsepoint Savings Pocket Details
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pocket/savings-details.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;
global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// ✅ Session check
if (!session_id()) session_start();
if (empty($_SESSION['pulsepoint_user']['id'])) {
    wp_die('<h3 style="text-align:center;margin-top:50px;">You must be logged in to continue.</h3>');
}

$user_id = intval($_SESSION['pulsepoint_user']['id']);

// ✅ Detect device
function pulsepoint_is_mobile_device() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|mobile)/i', $ua);
}
$is_mobile = pulsepoint_is_mobile_device();

// ✅ Platform settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#000';

// ✅ Get pocket
$pocket_id = intval($_GET['pocket'] ?? 0);
$pocket = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$base_prefix}savings_pocket WHERE id=%d AND user_id=%d", $pocket_id, $user_id));
if (!$pocket) wp_die('<h3 style="text-align:center;margin-top:50px;">Invalid or unauthorized pocket.</h3>');

// ✅ Wallet balance
$user_data = $wpdb->get_row($wpdb->prepare("SELECT wallet FROM {$base_prefix}users WHERE id=%d", $user_id));
$wallet_balance = $user_data ? $user_data->wallet : 0.00;

// ✅ Progress
$percent = min(100, ($pocket->current_amount / max(1, $pocket->target_amount)) * 100);
$goal_completed = $pocket->current_amount >= $pocket->target_amount;

// ✅ Interest (if any)
$interest = ($pocket->interest_rate / 100) * $pocket->current_amount;

// ✅ Transactions
$transactions = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$base_prefix}savings_transactions WHERE pocket_id=%d AND user_id=%d ORDER BY id DESC LIMIT 10",
    $pocket_id, $user_id
));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title><?= esc_html($pocket->title) ?> | <?= esc_html($platform_name) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<style>
:root { --primary: <?= $color_hex ?>; }
body { font-family: 'Inter', sans-serif; background: #f9f9fb; min-height: 100vh; padding: 20px; }
.header-bar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
.header-bar i { font-size: 22px; color: #000; cursor: pointer; }
.header-avatar { width: 38px; height: 38px; border-radius: 50%; background: var(--primary); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.header-avatar img { width: 100%; height: 100%; object-fit: cover; }
.progress-bar { background: #eee; height: 8px; border-radius: 5px; overflow: hidden; }
.progress-fill { height: 100%; background: var(--primary); transition: width .3s ease; }
label { font-weight: 600; color: #333; font-size: 0.9rem; }
.btn { background: var(--primary); color: #fff; border-radius: 12px; padding: 10px 14px; font-weight: 600; transition: 0.2s; }
.btn:hover { opacity: 0.9; }
.btn:disabled { opacity: 0.5; cursor: not-allowed; }
.action-box { display: flex; gap: 12px; justify-content: space-between; flex-wrap: wrap; }
.action-box button { flex: 1; min-width: 140px; }
.trx-item { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
.trx-item span { font-size: 0.9rem; }
</style>
</head>
<body>
<div class="<?= $is_mobile ? 'max-w-md' : 'max-w-3xl' ?> mx-auto pb-24">
  <div class="header-bar">
    <a href="/app/saving"><i class="bi bi-arrow-left-circle"></i></a>
    <div class="header-avatar"><img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt=""></div>
  </div>

  <!-- Pocket Summary -->
  <div class="p-6 rounded-2xl text-white mb-6" style="background: <?= $color_hex ?>;">
    <div class="text-lg font-semibold"><?= esc_html($pocket->title) ?></div>
    <div class="opacity-80 text-sm">Target: ₦<?= number_format($pocket->target_amount, 2) ?></div>
    <div class="opacity-80 text-sm">Current: ₦<?= number_format($pocket->current_amount, 2) ?></div>
    <div class="opacity-80 text-sm">Interest Rate: <?= number_format($pocket->interest_rate,2) ?>%</div>
    <div class="opacity-80 text-sm">Earned Interest: ₦<?= number_format($interest,2) ?></div>
    <div class="opacity-80 text-sm">Status: <?= ucfirst($pocket->status) ?></div>
    <div class="progress-bar mt-3"><div class="progress-fill" style="width: <?= $percent ?>%;"></div></div>
    <?php if($goal_completed): ?>
      <div class="mt-3 bg-white/20 rounded-lg p-2 text-center font-semibold text-sm">🎉 Goal completed!</div>
    <?php endif; ?>
  </div>

  <!-- Wallet Info -->
  <div class="bg-white p-4 mb-4 rounded-xl shadow-sm text-center text-gray-700 font-medium">
    Wallet Balance: ₦<?= number_format($wallet_balance, 2) ?><br>
    Auto-Save: <b><?= $pocket->auto_save ? 'Enabled' : 'Disabled' ?></b><br>
    <?php if(!$pocket->withdrawable && !$goal_completed): ?>
      <span class="text-red-600 text-sm block mt-1">❌ Withdrawal locked until goal completion</span>
    <?php endif; ?>
  </div>

  <!-- Actions -->
  <div class="bg-white rounded-2xl shadow-sm p-6 mb-6 space-y-5">
    <div>
      <label>Withdraw Amount (₦)</label>
      <input type="number" id="withdrawAmount" min="1" placeholder="Enter amount" <?= ($pocket->locked || (!$pocket->withdrawable && !$goal_completed)) ? 'disabled' : '' ?>>
    </div>
    <div class="action-box">
      <button id="withdrawBtn" class="btn" <?= ($pocket->locked || (!$pocket->withdrawable && !$goal_completed)) ? 'disabled' : '' ?>>
        <i class="bi bi-wallet2"></i> Withdraw
      </button>
      <button id="toggleAutoSave" class="btn bg-gray-800">
        <?= $pocket->auto_save ? 'Disable Auto-Save' : 'Enable Auto-Save' ?>
      </button>
    </div>
    <button id="breakSaving" class="btn bg-red-600 w-full mt-2">💥 Break Saving</button>
    <?php if($goal_completed): ?>
      <button id="transferSaving" class="btn bg-green-700 w-full mt-2">🔁 Transfer Saving</button>
    <?php endif; ?>
  </div>

  <!-- Transactions -->
  <div class="bg-white rounded-2xl shadow-sm p-5">
    <h3 class="font-semibold text-gray-800 mb-3">Recent Transactions</h3>
    <?php if ($transactions): foreach ($transactions as $trx): ?>
      <div class="trx-item">
        <span><?= ucfirst($trx->type) ?></span>
        <span><?= $trx->status == 'success' ? '✅' : '❌' ?></span>
        <span>₦<?= number_format($trx->amount,2) ?></span>
      </div>
    <?php endforeach; else: ?>
      <p class="text-sm text-gray-500 text-center py-3">No transactions yet.</p>
    <?php endif; ?>
  </div>
</div>

<script>
function showToast(msg, type='info') {
  Toastify({ text: msg, duration: 3500, close: true, gravity:"top", position:"center",
  style:{ background: type==='error'?'#ff3860':'green', borderRadius:'12px' } }).showToast();
}

document.getElementById('withdrawBtn').addEventListener('click', async ()=>{
  const amount=document.getElementById('withdrawAmount').value.trim();
  if(!amount) return showToast('Enter amount to withdraw','error');
  const fd=new FormData();
  fd.append('action','pulsepoint_withdraw_from_pocket');
  fd.append('pocket_id','<?= $pocket_id ?>');
  fd.append('amount',amount);
  const res=await fetch("<?= admin_url('admin-ajax.php'); ?>",{method:"POST",body:fd});
  const j=await res.json(); showToast(j.message,j.success?'success':'error');
  if(j.success) setTimeout(()=>location.reload(),1000);
});

document.getElementById('toggleAutoSave').addEventListener('click', async ()=>{
  const fd=new FormData();
  fd.append('action','pulsepoint_toggle_auto_save');
  fd.append('pocket_id','<?= $pocket_id ?>');
  const res=await fetch("<?= admin_url('admin-ajax.php'); ?>",{method:"POST",body:fd});
  const j=await res.json(); showToast(j.message,j.success?'success':'error');
  if(j.success) setTimeout(()=>location.reload(),1000);
});

document.getElementById('breakSaving').addEventListener('click', async ()=>{
  if(!confirm('Are you sure to break this saving and withdraw all?')) return;
  const fd=new FormData();
  fd.append('action','pulsepoint_break_saving');
  fd.append('pocket_id','<?= $pocket_id ?>');
  const res=await fetch("<?= admin_url('admin-ajax.php'); ?>",{method:"POST",body:fd});
  const j=await res.json(); showToast(j.message,j.success?'success':'error');
  if(j.success) setTimeout(()=>location.reload(),1000);
});
</script>
</body>
</html>