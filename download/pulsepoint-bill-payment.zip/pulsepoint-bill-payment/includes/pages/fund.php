<?php
/**
 * Airtime Purchase Page for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// ✅ Detect device type
function pulsepoint_is_mobile() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $ua);
}

$is_mobile = pulsepoint_is_mobile();

// Fetch platform settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// Logged-in user
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));

$firstname = $user ? esc_html($user->firstname) : 'User';
$wallet = $user ? number_format($user->wallet, 2) : '0.00';
$referral_balance = $user ? number_format($user->referral_balance, 2) : '0.00';
$passcode = $user ? $user->passcode : '';
?>
<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Fund wallet | <?= $platform_name ?></title>

</head>

<body class="bg-gray-50">

<?php if ($is_mobile): ?>

    <!-- 📱 MOBILE VERSION -->
    <?php include pulsepoint_theme_file('fund/mobile.php'); ?>

<?php else: ?>

    <!-- 🖥️ DESKTOP VERSION -->
    <div class="flex min-h-screen">

        <!-- Sidebar (Desktop Only) -->
        <div class="w-64 bg-white shadow-lg border-r">
            <?php include pulsepoint_theme_file('sidebar.php'); ?>
        </div>

        <!-- Main Desktop Content -->
        <div class="flex-1 p-6">
            <?php include pulsepoint_theme_file('fund/desktop.php'); ?>
        </div>

    </div>

<?php endif; ?>

</body>
</html>