<?php
/**
 * User Settings Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// User info
if (!session_id()) session_start();
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$firstname = $user ? esc_html($user->firstname) : "User";
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Settings - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>

<style>
body {
    background: #f7f8fb;
    font-family: 'Inter', sans-serif;
    margin: 0;
    padding: 0;
}
.copy-box {
    border-radius: 14px;
    padding: 16px;
    background: #fff;
    box-shadow: 0 6px 18px rgba(20,30,60,0.06);
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
}
.bg-main-10 { background-color: <?= $color_hex ?>1A; }
.text-main { color: <?= $color_hex ?>; }
</style>
</head>

<body>
<div id="app" class="px-4 max-w-md mx-auto">

<!-- HEADER -->
<div class="flex items-center justify-between mb-6 mt-2">
    <div class="flex items-center gap-3">
        <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
        </button>
        <h2 class="text-xl font-bold text-gray-900">Settings</h2>
    </div>

    <div class="flex items-center space-x-3 mt-1">
        <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="chart-no-axes-gantt" class="w-5 h-5 text-gray-800"></i>
        </button>
        <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
            <i data-lucide="bell" class="w-5 h-5 text-gray-800"></i>
        </button>
    </div>
</div>

<!-- TITLE -->
<h2 class="text-xl font-bold mb-3">Manage Your Account</h2>
<p class="text-gray-500 text-sm mb-5">
    Update your profile and account settings.
</p>

<!-- SETTINGS LIST -->

<!-- CHANGE PASSWORD -->
<div class="copy-box mb-4" onclick="window.location.href='/app/change-password'">
    <div>
        <p class="text-xs text-gray-500 mb-1">Security</p>
        <p class="text-lg font-semibold text-gray-900">Change Password</p>
    </div>
    <button class="p-2 rounded-full bg-main-10">
        <i data-lucide="key" class="w-5 h-5 text-main"></i>
    </button>
</div>

<!-- SECURITY QUESTIONS -->
<div class="copy-box mb-4" onclick="window.location.href='/app/security-questions'">
    <div>
        <p class="text-xs text-gray-500 mb-1">Security</p>
        <p class="text-lg font-semibold text-gray-900">Security Questions</p>
    </div>
    <button class="p-2 rounded-full bg-main-10">
        <i data-lucide="shield" class="w-5 h-5 text-main"></i>
    </button>
</div>

<!-- DAILY LIMIT -->
<div class="copy-box mb-4" onclick="window.location.href='/app/daily-limit'">
    <div>
        <p class="text-xs text-gray-500 mb-1">Account</p>
        <p class="text-lg font-semibold text-gray-900">Daily Limit</p>
    </div>
    <button class="p-2 rounded-full bg-main-10">
        <i data-lucide="activity" class="w-5 h-5 text-main"></i>
    </button>
</div>

<!-- NOTIFICATIONS -->
<div class="copy-box mb-4" onclick="window.location.href='/app/notifications'">
    <div>
        <p class="text-xs text-gray-500 mb-1">Alerts</p>
        <p class="text-lg font-semibold text-gray-900">Notifications</p>
    </div>
    <button class="p-2 rounded-full bg-main-10">
        <i data-lucide="bell" class="w-5 h-5 text-main"></i>
    </button>
</div>

<!-- CLOSE ACCOUNT -->
<div class="copy-box mb-4" onclick="window.location.href='/app/close-account'">
    <div>
        <p class="text-xs text-gray-500 mb-1">Account</p>
        <p class="text-lg font-semibold text-gray-900">Close Account</p>
    </div>
    <button class="p-2 rounded-full bg-main-10">
        <i data-lucide="x-circle" class="w-5 h-5 text-main"></i>
    </button>
</div>

</div>

<script>
lucide.createIcons();
const { createApp } = Vue;
createApp({
    methods: {
        goBack() { window.history.back(); }
    }
}).mount('#app');
</script>
</body>
</html>