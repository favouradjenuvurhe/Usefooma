<?php
/**
 * Transaction Successful Page - Pulsepoint Plugin
 * Author: Amaaavl
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

/**
 * Fetch settings
 */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#4f46e5';

/**
 * Get current user ID
 */
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
$table_trnx = $base_prefix . 'trnx';

$transaction = null;

if ($user_id > 0) {
    $transaction = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, amount, recipient, description, reference 
             FROM {$table_trnx} 
             WHERE user_id = %d AND status = 'success' 
             ORDER BY id DESC LIMIT 1",
            $user_id
        )
    );
}

if (!$transaction) {
    wp_redirect('/app/dashboard/');
    exit;
}

$amount      = number_format((float)$transaction->amount, 2);
$recipient   = esc_html($transaction->recipient ?? '—');
$description = esc_html($transaction->description ?? 'Transaction completed');
$trnx_id     = (int)$transaction->id;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Transaction Successful - <?php echo esc_html($platform_name); ?></title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Vue 3 -->
  <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    body { background:#fff; }
  </style>
</head>
<body>

<div id="app" class="h-screen w-screen flex flex-col items-center justify-center text-center px-6">

  <!-- Close -->
  <div class="absolute top-6 right-6 cursor-pointer"
       onclick="window.location.href='/app/dashboard/'">
    <i data-lucide="x" class="w-6 h-6 text-gray-700"></i>
  </div>

  <!-- Success Icon -->
  <div class="mb-8">
    <svg width="90" height="90" viewBox="0 0 100 100">
      <defs>
        <linearGradient id="successGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#4f46e5"/>
          <stop offset="50%" stop-color="#22c55e"/>
          <stop offset="100%" stop-color="#eab308"/>
        </linearGradient>
      </defs>
      <path d="M18 55 L40 76 L82 24"
            fill="none"
            stroke="url(#successGrad)"
            stroke-width="10"
            stroke-linecap="round"
            stroke-linejoin="round"/>
    </svg>
  </div>

  <!-- Content -->
  <h1 class="text-2xl font-semibold text-gray-900 mb-3">
    Transaction successful
  </h1>

  <p class="text-gray-700 text-sm mb-1">
    You sent <span class="font-semibold" style="color:<?php echo esc_attr($color_hex); ?>">
      ₦<?php echo $amount; ?>
    </span>
  </p>

  <p class="text-gray-600 text-sm mb-8">
    <?php echo $description; ?>
  </p>

  <!-- Bottom Actions -->
  <div class="absolute bottom-10 w-full px-10 flex justify-between">

    <!-- Report Issue -->
    <div class="flex flex-col items-center gap-2 cursor-pointer"
         onclick="window.location.href='/app/support/?ref=<?php echo esc_attr($transaction->reference); ?>'">
      <div class="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center">
        <i data-lucide="alert-circle" class="w-6 h-6" style="color:<?php echo esc_attr($color_hex); ?>"></i>
      </div>
      <span class="text-xs text-gray-700 text-center">
        Report<br>Issue
      </span>
    </div>

    <!-- View Transaction -->
    <div class="flex flex-col items-center gap-2 cursor-pointer"
         onclick="window.location.href='/app/view-transaction/?id=<?php echo $trnx_id; ?>'">
      <div class="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center">
        <i data-lucide="file-text" class="w-6 h-6" style="color:<?php echo esc_attr($color_hex); ?>"></i>
      </div>
      <span class="text-xs text-gray-700 text-center">
        View<br>Transaction
      </span>
    </div>

    <!-- Back Home -->
    <div class="flex flex-col items-center gap-2 cursor-pointer"
         onclick="window.location.href='/app/dashboard/'">
      <div class="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center">
        <i data-lucide="home" class="w-6 h-6" style="color:<?php echo esc_attr($color_hex); ?>"></i>
      </div>
      <span class="text-xs text-gray-700 text-center">
        Back to<br>Home
      </span>
    </div>

  </div>

</div>

<script>
  Vue.createApp({}).mount('#app');
  lucide.createIcons();
</script>

</body>
</html>