<?php  
/**
 * Pulsepoint Create Savings Pocket Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pocket/create-pocket.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  

// ✅ Detect device  
function is_mobile_device() {  
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');  
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);  
}  
$is_mobile = is_mobile_device();  

// ✅ Platform Settings  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#000';  
?>  

<!doctype html>
<html lang="en">  
<head>  
  <meta charset="utf-8" />  
  <meta name="viewport" content="width=device-width,initial-scale=1" />  
  <title>Create Savings | <?= esc_html($platform_name) ?></title>  
  <script src="https://cdn.tailwindcss.com"></script>  
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>  
    :root { --primary: <?= $color_hex ?>; }  
    body { font-family: 'Inter', sans-serif; background: #f9f9fb; min-height: 100vh; padding: 20px; }  
    .header-bar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }  
    .header-bar i { font-size: 22px; color: #000; cursor: pointer; }  
    .header-avatar { width: 38px; height: 38px; border-radius: 50%; background: var(--primary); display: flex; align-items: center; justify-content: center; overflow: hidden; }  
    .header-avatar img { width: 100%; height: 100%; object-fit: cover; }  
    input, select { border: 1px solid #ddd; border-radius: 10px; padding: 10px 14px; width: 100%; outline: none; transition: 0.2s; }  
    input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(0,0,0,0.05); }  
    label { font-weight: 600; color: #333; font-size: 0.9rem; }  
  </style>  
</head>  
<body>  

<?php if ($is_mobile): ?>  

<!-- ✅ MOBILE VERSION -->
<div class="max-w-md mx-auto pb-24">  
  <div class="header-bar">  
    <a href="/app/savings"><i class="bi bi-arrow-left-circle"></i></a>  
    <div class="header-avatar"><img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt=""></div>  
  </div>  

  <div class="p-6 rounded-2xl text-white" style="background: <?= $color_hex ?>;">  
    <div class="text-lg font-semibold">Create New Savings Plan</div>  
    <div class="opacity-80 text-sm mt-1">Set your goal and start saving today.</div>  
  </div>  

  <form id="createSavingsForm" class="mt-6 space-y-5 bg-white p-5 rounded-2xl shadow-sm">  
    <div>  
      <label>Plan Title</label>  
      <input type="text" name="title" placeholder="e.g. Rent Savings, iPhone Goal" required>  
    </div>  

    <div>  
      <label>Target Amount (₦)</label>  
      <input type="number" name="target_amount" placeholder="Enter target amount" required>  
    </div>  

    <div>  
      <label>Start Date</label>  
      <input type="date" name="start_date" required>  
    </div>  

    <div>  
      <label>Maturity Date</label>  
      <input type="date" name="maturity_date" required>  
    </div>  

    <div>  
      <label>Savings Frequency</label>  
      <select name="frequency">  
        <option value="manual">Manual</option>  
        <option value="daily">Daily</option>  
        <option value="weekly">Weekly</option>  
        <option value="monthly">Monthly</option>  
      </select>  
    </div>  

    <div>  
      <label>Amount Per Cycle (₦)</label>  
      <input type="number" name="amount_per_cycle" placeholder="Enter amount per saving cycle">  
    </div>  

    <div class="flex items-center space-x-2">  
      <input type="checkbox" name="auto_save" id="auto_save" class="w-4 h-4 rounded text-[<?= $color_hex ?>]">  
      <label for="auto_save">Enable Auto Save</label>  
    </div>  

    <div>  
      <label>Withdrawable</label>  
      <select name="withdrawable">  
        <option value="0">Locked until maturity</option>  
        <option value="1">Withdraw anytime</option>  
      </select>  
    </div>  

    <button type="submit" class="w-full py-3 mt-4 rounded-xl font-semibold text-white" style="background: <?= $color_hex ?>;">  
      Create Savings Plan  
    </button>  
  </form>  
</div>  

<?php else: ?>  

<!-- ✅ DESKTOP VERSION -->
<div class="max-w-4xl mx-auto pb-24">  
  <div class="header-bar">  
    <a href="/app/savings"><i class="bi bi-arrow-left-circle"></i></a>  
    <div class="header-avatar"><img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt=""></div>  
  </div>  

  <div class="p-8 rounded-2xl text-white mb-8" style="background: <?= $color_hex ?>;">  
    <div class="text-2xl font-bold">Create a New Savings Plan</div>  
    <div class="opacity-80 mt-1">Customize your saving goal and get started instantly.</div>  
  </div>  

  <form id="createSavingsForm" class="bg-white rounded-2xl shadow-sm p-8 space-y-6">  
    <div class="grid grid-cols-2 gap-6">  
      <div>  
        <label>Plan Title</label>  
        <input type="text" name="title" placeholder="e.g. Rent Savings, iPhone Goal" required>  
      </div>  
      <div>  
        <label>Target Amount (₦)</label>  
        <input type="number" name="target_amount" placeholder="Enter target amount" required>  
      </div>  
    </div>  

    <div class="grid grid-cols-2 gap-6">  
      <div>  
        <label>Start Date</label>  
        <input type="date" name="start_date" required>  
      </div>  
      <div>  
        <label>Maturity Date</label>  
        <input type="date" name="maturity_date" required>  
      </div>  
    </div>  

    <div class="grid grid-cols-2 gap-6">  
      <div>  
        <label>Savings Frequency</label>  
        <select name="frequency">  
          <option value="manual">Manual</option>  
          <option value="daily">Daily</option>  
          <option value="weekly">Weekly</option>  
          <option value="monthly">Monthly</option>  
        </select>  
      </div>  

      <div>  
        <label>Amount Per Cycle (₦)</label>  
        <input type="number" name="amount_per_cycle" placeholder="Enter amount per saving cycle">  
      </div>  
    </div>  

    <div class="flex items-center space-x-2">  
      <input type="checkbox" name="auto_save" id="auto_save" class="w-4 h-4 rounded text-[<?= $color_hex ?>]">  
      <label for="auto_save">Enable Auto Save</label>  
    </div>  

    <div>  
      <label>Withdrawable</label>  
      <select name="withdrawable">  
        <option value="0">Locked until maturity</option>  
        <option value="1">Withdraw anytime</option>  
      </select>  
    </div>  

    <div class="pt-6">  
      <button type="submit" class="w-full py-3 rounded-xl font-semibold text-white text-lg hover:opacity-90 transition" style="background: <?= $color_hex ?>;">  
        Create Savings Plan  
      </button>  
    </div>  
  </form>  
</div>  
<?php endif; ?>  

<script>
function showToast(msg, type='info') {
  Toastify({
    text: msg,
    duration: 3000,
    close: true,
    gravity: "top",
    position: "center",
    stopOnFocus: true,
    style: {
      background: type === 'error' ? "#ff3860" : "green",
      color: "#fff",
      borderRadius: "12px"
    }
  }).showToast();
}

document.getElementById('createSavingsForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  try {
    const response = await fetch("<?= admin_url('admin-ajax.php?action=pulsepoint_create_savings'); ?>", {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (data.success) {
      showToast(data.message, 'success');
      setTimeout(() => { window.location.href = "/app/saving"; }, 1500);
    } else {
      showToast(data.message, 'error');
    }
  } catch (err) {
    showToast("Network error. Try again.", 'error');
  }
});
</script>

</body>  
</html>