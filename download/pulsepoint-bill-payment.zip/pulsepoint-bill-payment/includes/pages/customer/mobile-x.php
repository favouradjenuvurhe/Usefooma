<?php
/**
 * XIXAPAY Customer KYC Frontend UI (UPDATED FIXED VERSION)
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

if (!session_id()) session_start();

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in.</div>';
    exit;
}

$table_users = $base_prefix . 'users';

$user = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id)
);


$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");

$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'XIXAPAY';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

$nonce = wp_create_nonce('pulsepoint_xixa');
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>

<title>KYC Verification - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root{
    --primary: <?= esc_attr($color_hex) ?>;
}

body{
    margin:0;
    padding:0 18px 18px;
    font-family:Inter,system-ui;
    background:#f7f8fb;
}

.card{
    background:#fff;
    border-radius:18px;
    padding:16px;
}

.primary-btn{
    background:var(--primary);
    color:#fff;
    width:100%;
    padding:12px;
    border-radius:12px;
}

.input{
    width:100%;
    padding:12px;
    border:1px solid #ddd;
    border-radius:12px;
}

.step-dot{
    width:10px;
    height:10px;
    border-radius:50%;
    background:#ddd;
}

.step-dot.active{
    background:var(--primary);
}

.overlay{
    position:fixed;
    inset:0;
    background:rgba(255,255,255,.8);
    display:flex;
    align-items:center;
    justify-content:center;
    z-index:9999;
}
</style>

</head>

<body>

<div id="app" class="max-w-md mx-auto">
<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Compliance</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>
</br>

<div class="card">

    
    <!-- STEP DOTS -->
    <div class="flex gap-2 mb-4">
        <div v-for="n in steps" :key="n" :class="['step-dot',{active:currentStep>=n-1}]"></div>
    </div>

    <div class="text-sm mb-4">
        Step {{ currentStep + 1 }} of {{ steps }}
    </div>

    <form @submit.prevent="submit">

    <!-- STEP 1: ADDRESS -->
    <div v-show="currentStep === 0" class="space-y-4">

        <div>
            <label class="block text-sm font-medium mb-1">Address</label>
            <input class="input" v-model="form.address" placeholder="Enter your address">
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">State</label>
            <input class="input" v-model="form.state" placeholder="Enter your state">
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">City</label>
            <input class="input" v-model="form.city" placeholder="Enter your city">
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Postal Code</label>
            <input class="input" v-model="form.postal_code" placeholder="Enter postal code">
        </div>

    </div>

    <!-- STEP 2: ID -->
    <div v-show="currentStep === 1" class="space-y-4">

        <div>
            <label class="block text-sm font-medium mb-1">Date of Birth</label>
            <input type="date" class="input" v-model="form.date_of_birth">
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">ID Type</label>
            <select class="input" v-model="form.id_type">
                <option value="">Select ID Type</option>
                <option value="nin">NIN</option>
                <option value="bvn">BVN</option>
            </select>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">ID Number</label>
            <input class="input" v-model="form.id_number" placeholder="Enter ID number">
        </div>

    </div>

    <!-- STEP 3: FILES -->
    <div v-show="currentStep === 2" class="space-y-4">

        <div>
            <label class="block text-sm font-medium mb-1">Government ID Card</label>
            <input type="file" @change="handleFile($event,'id_card')" class="input">
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Utility Bill</label>
            <input type="file" @change="handleFile($event,'utility_bill')" class="input">
        </div>

    </div>

    <div class="flex gap-2 mt-5">

        <button type="button"
                class="primary-btn"
                @click="prev"
                :disabled="currentStep===0"
                style="background:#999">
            Back
        </button>

        <button v-if="currentStep < steps-1"
                type="button"
                class="primary-btn"
                @click="next">
            Continue
        </button>

        <button v-else
                type="submit"
                class="primary-btn">
            {{ loading ? 'Submitting...' : 'Submit KYC' }}
        </button>

    </div>

</form>

</div>

<!-- LOADING FIXED -->
<div v-if="loading" class="overlay">
    <div class="text-center">
        <svg class="animate-spin w-10 h-10 mx-auto mb-2" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="var(--primary)" stroke-width="4" opacity="0.2"/>
            <path d="M22 12A10 10 0 0012 2" stroke="var(--primary)" stroke-width="4"/>
        </svg>
        <div>Submitting KYC...</div>
    </div>
</div>

</div>

<script>
const { createApp } = Vue;

createApp({

data() {
    return {

        currentStep: 0,
        steps: 3,
        loading: false,

        // AUTO FILLED FROM PHP (HIDDEN STEP 1 REMOVED)
        form: {
            first_name: "<?= esc_js($user->firstname ?? '') ?>",
            last_name: "<?= esc_js($user->lastname ?? '') ?>",
            email: "<?= esc_js($user->email ?? '') ?>",
            phone_number: "<?= esc_js($user->phone ?? '') ?>",

            address: '',
            state: '',
            city: '',
            postal_code: '',
            date_of_birth: '',
            id_type: '',
            id_number: ''
        },

        files: {
            id_card: null,
            utility_bill: null
        }
    }
},

methods: {

next() {
    if (this.currentStep < this.steps - 1) this.currentStep++;
},

prev() {
    if (this.currentStep > 0) this.currentStep--;
},

handleFile(e, key) {
    const file = e.target.files[0];
    if (!file) return;
    this.files[key] = file;
},

async submit() {

    this.loading = true;

    let fd = new FormData();

    for (let k in this.form) {
        fd.append(k, this.form[k]);
    }

    fd.append('id_card', this.files.id_card);
    fd.append('utility_bill', this.files.utility_bill);
    fd.append('action', 'pulsepoint_xixa_customer');

    try {

        let res = await fetch("<?= admin_url('admin-ajax.php') ?>", {
            method: "POST",
            body: fd
        });

        let data = await res.json();

        if (data.success) {

            Toastify({
                text: "KYC Submitted Successfully",
                backgroundColor: "green"
            }).showToast();

            setTimeout(() => {
                window.location.href = "/app/dashboard";
            }, 1000);

        } else {

            Toastify({
                text: data.message || "Failed",
                backgroundColor: "red"
            }).showToast();
        }

    } catch (e) {

        Toastify({
            text: "Network Error",
            backgroundColor: "red"
        }).showToast();

    } finally {
        // ✅ FIX: THIS STOPS INFINITE "SUBMITTING..."
        this.loading = false;
    }
}

}

}).mount('#app');
</script>

</body>
</html>