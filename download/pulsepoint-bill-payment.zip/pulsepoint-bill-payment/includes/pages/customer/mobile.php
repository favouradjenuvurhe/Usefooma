<?php
/**
 * KYC Verification Page — Vue / Airtime-Style UI clone
 * Auto Uploads Image & Triggers Strowallet API
 * Author: Amaaavl (converted to Vue UI)
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session if not started
if (!session_id()) session_start();

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// User info
$table_users = $base_prefix . 'users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$statuskyc = $user->statuskyc ?? 0;

// If KYC already done, redirect to account status page
if ($statuskyc == 1) {
    wp_redirect(site_url('/app/status-acct'));
    exit;
}

// create a nonce for ajax submit
$kyc_nonce = wp_create_nonce('pulsepoint_kyc');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
  <title>KYC Verification - <?= esc_html($platform_name) ?></title>

  <!-- Tailwind, Vue3, Lucide, Toastify -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

  <style>
    :root {
      --app-bg: #f7f8fb;
      --card-bg: #ffffff;
      --muted: #6b7280;
      --primary: <?= esc_attr($color_hex) ?>;
    }
    html, body, #app { min-height: 100%; background: var(--app-bg); }
    body { font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; margin: 0; padding: 18px; }
    .rounded-card{ border-radius: 14px; background: var(--card-bg); }
    .muted { color: var(--muted); }
    .generate-btn { background: var(--primary); color: #fff; font-weight:600; border-radius: 10px; padding: 10px 14px; }
    .generate-btn.ghost { background: transparent; color: var(--primary); border: 1px solid rgba(0,0,0,0.06); }
    .file-preview { max-height: 120px; border-radius: 8px; display:block; margin-top:8px; object-fit:cover; }
    .step-indicator { display:flex; gap:8px; align-items:center; }
    .step-dot { width:10px; height:10px; border-radius:999px; background:#e6e9ef; }
    .step-dot.active { background: var(--primary); box-shadow: 0 2px 6px rgba(0,0,0,0.08); }
    .amount-input { border: none; border-bottom: 2px solid #e5e7eb; padding: 6px 0; width: 100%; font-weight: 600; outline: none; font-size: 16px; }
    .thin-hr { height: 1px; background: #e6e9ef; margin-top: 16px; }
    /* loading overlay */
    #loadingOverlay { position:fixed; inset:0; background: rgba(255,255,255,0.6); display:flex; align-items:center; justify-content:center; z-index:9999; }
  </style>
</head>
<body>
<div id="app" class="max-w-md mx-auto">

<!-- Header -->
<div class="mt-6 flex justify-between items-center">
  <!-- Left: Back button + Title -->
  <div class="flex gap-2 items-center cursor-pointer" onclick="window.history.back()">
    <img src="https://www.svgrepo.com/show/521480/arrow-prev.svg" 
         class="w-6 h-6" 
         alt="Back Icon"/>
    <span class="font-semibold text-black">Compliance</span>
  </div>

  <!-- Right: Calendar only -->
  <div class="flex items-center">
    <button class="p-1 flex items-center justify-center">
      <img src="https://www.svgrepo.com/show/506132/calendar-minus.svg"
           class="w-5 h-5"
           alt="Calendar"/>
    </button>
  </div>
</div>
</br>


  <!-- Main Card -->
  <div class="rounded-card p-4 border border-gray-200 shadow-sm">
    <div class="text-center mb-4">
      <i data-lucide="user-check" class="text-[var(--primary)] text-4xl mb-2"></i>
      <h3 class="font-bold text-lg">Verify your identity</h3>
      <p class="muted text-sm">Upload a government ID and a selfie. Processing usually takes <strong>up to 3 hours</strong>.</p>
    </div>

    <!-- Step indicator -->
    <div class="flex items-center justify-between mb-3">
      <div class="step-indicator">
        <div v-for="n in totalSteps" :key="n" :class="['step-dot', {active: currentStep+1 >= n}]"></div>
      </div>
      <div class="text-sm muted">Step {{ currentStep+1 }} of {{ totalSteps }}</div>
    </div>

    <!-- Vue-form (not actual form submit; uses FormData for ajax) -->
    <form id="kycForm" @submit.prevent="submit" enctype="multipart/form-data" novalidate>
      <input type="hidden" name="action" value="pulsepoint_customer_kyc">
      <input type="hidden" name="nonce" :value="nonce">

      <!-- STEP VIEWS -->
      <div v-show="currentStep === 0" class="space-y-3">
        <label class="block font-semibold text-sm">Date of Birth</label>
        <input type="date" v-model="form.dob" class="w-full p-2 border rounded-md" required>
        <label class="block font-semibold text-sm mt-2">ID Type</label>
        <select v-model="form.idType" class="w-full p-2 border rounded-md" required>
          <option value="">Select</option>
          <option value="nin">NIN</option>
          <option value="bvn">BVN</option>        
        </select>
      </div>

      <div v-show="currentStep === 1" class="space-y-3">
        <label class="block font-semibold text-sm">ID Number</label>
        <input type="text" v-model="form.idNumber" class="w-full p-2 border rounded-md" required>

        <label class="block font-semibold text-sm mt-2">ID Image (PNG only)</label>
        <input type="file" @change="onFileChange($event,'idImage')" accept="image/png" class="w-full" required>
        <img v-if="previews.idImage" :src="previews.idImage" class="file-preview" alt="id preview">
        <div class="text-xs muted">PNG only. Max 5MB.</div>
      </div>

      <div v-show="currentStep === 2" class="space-y-3">
        <label class="block font-semibold text-sm">Selfie Photo (PNG only)</label>
        <input type="file" @change="onFileChange($event,'userPhoto')" accept="image/png" class="w-full" required>
        <img v-if="previews.userPhoto" :src="previews.userPhoto" class="file-preview" alt="selfie preview">
        <div class="text-xs muted">Take a clear PNG selfie (face visible). Max 5MB.</div>

        <label class="block font-semibold text-sm mt-2">House Number</label>
        <input type="text" v-model="form.houseNumber" class="w-full p-2 border rounded-md" required>
      </div>

      <div v-show="currentStep === 3" class="space-y-3">
        <label class="block font-semibold text-sm">Street / Line 1</label>
        <input type="text" v-model="form.line1" class="w-full p-2 border rounded-md" required>

        <label class="block font-semibold text-sm mt-2">City</label>
        <input type="text" v-model="form.city" class="w-full p-2 border rounded-md" required>
      </div>

      <div v-show="currentStep === 4" class="space-y-3">
        <label class="block font-semibold text-sm">State</label>
        <input type="text" v-model="form.state" class="w-full p-2 border rounded-md" required>

        <label class="block font-semibold text-sm mt-2">ZIP / Postal Code</label>
        <input type="text" v-model="form.zipCode" class="w-full p-2 border rounded-md" required>
      </div>

      <div v-show="currentStep === 5" class="space-y-3">
        <label class="block font-semibold text-sm">Country</label>
        <input type="text" v-model="form.country" class="w-full p-2 border rounded-md" required>
        <div class="text-xs muted mt-2">Please confirm your address details before submitting.</div>
      </div>

      <!-- Nav -->
      <div class="flex items-center gap-3 mt-4">
        <button type="button" class="generate-btn ghost w-1/2" @click="prevStep" :disabled="currentStep===0">Previous</button>
        <button type="button" class="generate-btn w-1/2" @click="nextStep" v-if="!isLastStep">{{ nextLabel }}</button>
        <button type="submit" class="generate-btn w-1/2" v-if="isLastStep">{{ submitting ? 'Submitting...' : 'Submit' }}</button>
      </div>

      <div v-if="errorMessage" class="text-red-600 font-semibold mt-3">{{ errorMessage }}</div>
    </form>

    <div class="thin-hr"></div>
    <p class="text-sm muted text-center mt-3">We take your privacy seriously. Your data is securely encrypted and processed through NDPR.</p>
  </div>

  <!-- Small banner gallery to match Airtime style -->
  <div class="overflow-x-auto whitespace-nowrap py-3 mt-4">
    <div class="inline-block mr-4 w-64 h-20 flex-shrink-0">
      <img src="<?= esc_url($settings['ads1_url'] ?? '/wp-content/plugins/pulsepoint-bill-payment/assets/img/ads.png') ?>" alt="ad" class="w-full h-full object-cover rounded-lg shadow-sm">
    </div>
    <div class="inline-block mr-4 w-64 h-20 flex-shrink-0">
      <img src="<?= esc_url($settings['ads2_url'] ?? '/wp-content/plugins/pulsepoint-bill-payment/assets/img/ads.png') ?>" alt="ad" class="w-full h-full object-cover rounded-lg shadow-sm">
    </div>
    <div class="inline-block mr-4 w-64 h-20 flex-shrink-0">
      <img src="<?= esc_url($settings['ads3_url'] ?? '/wp-content/plugins/pulsepoint-bill-payment/assets/img/ads.png') ?>" alt="ad" class="w-full h-full object-cover rounded-lg shadow-sm">
    </div>
  </div>

</div>

<!-- Loading overlay -->
<div id="loadingOverlay" style="display:none">
  <div class="text-center">
    <svg class="animate-spin w-12 h-12 mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <circle cx="12" cy="12" r="10" stroke-width="4" stroke="var(--primary)" stroke-opacity="0.25"></circle>
      <path d="M22 12a10 10 0 00-10-10" stroke-width="4" stroke="var(--primary)"></path>
    </svg>
    <div style="font-weight:700;color:var(--primary)">Submitting KYC...</div>
  </div>
</div>

<script>
const { createApp } = Vue;

createApp({
  data() {
    return {
      nonce: "<?= esc_js($kyc_nonce) ?>",
      currentStep: 0,
      totalSteps: 6,
      submitting: false,
      errorMessage: '',
      previews: {
        idImage: null,
        userPhoto: null
      },
      form: {
        dob: '',
        idType: '',
        idNumber: '',
        idImage: null,
        userPhoto: null,
        houseNumber: '',
        line1: '',
        city: '',
        state: '',
        zipCode: '',
        country: 'Nigeria'
      }
    };
  },
  computed: {
    isLastStep() { return this.currentStep === this.totalSteps - 1; },
    nextLabel() { return 'Next'; }
  },
  methods: {
    goBack(){ window.location.href = '/app/dashboard'; },
    prevStep(){
      if(this.currentStep > 0) { this.currentStep--; this.errorMessage=''; }
    },
    nextStep(){
      // validate current step required fields
      const requiredChecks = {
        0: () => this.form.dob && this.form.idType,
        1: () => this.form.idNumber && this.form.idImage,
        2: () => this.form.userPhoto && this.form.houseNumber,
        3: () => this.form.line1 && this.form.city,
        4: () => this.form.state && this.form.zipCode,
        5: () => this.form.country
      };
      const ok = requiredChecks[this.currentStep] ? requiredChecks[this.currentStep]() : true;
      if(!ok) {
        this.errorMessage = 'Please complete all required fields on this step.';
        return;
      }
      this.errorMessage='';
      if(!this.isLastStep){
        this.currentStep++;
      }
    },
    onFileChange(e, field){
      const file = e.target.files && e.target.files[0];
      if(!file) {
        this.previews[field] = null;
        this.form[field] = null;
        return;
      }
      if(file.size > 5 * 1024 * 1024) {
        Toastify({ text: 'File too large (max 5MB).', duration: 3500, close:true, gravity:'top', position:'center' }).showToast();
        e.target.value = '';
        return;
      }
      if(file.type !== 'image/png') {
        Toastify({ text: 'Only PNG files are allowed.', duration: 3500, close:true, gravity:'top', position:'center' }).showToast();
        e.target.value = '';
        return;
      }
      this.form[field] = file;
      this.previews[field] = URL.createObjectURL(file);
    },
    showLoading(){ document.getElementById('loadingOverlay').style.display = 'flex'; },
    hideLoading(){ document.getElementById('loadingOverlay').style.display = 'none'; },

    async submit(){
      // final validation
      const required = ['dob','idType','idNumber','idImage','userPhoto','houseNumber','line1','city','state','zipCode','country'];
      for(const key of required){
        if(!this.form[key]) {
          this.errorMessage = 'Please complete all required fields.';
          // jump to the step that contains the missing field
          const stepMap = { dob:0, idType:0, idNumber:1, idImage:1, userPhoto:2, houseNumber:2, line1:3, city:3, state:4, zipCode:4, country:5 };
          this.currentStep = stepMap[key] ?? 0;
          return;
        }
      }
      this.errorMessage = '';
      this.submitting = true;
      this.showLoading();

      const data = new FormData();
      data.append('action','pulsepoint_customer_kyc');
      data.append('nonce', this.nonce);
      data.append('dob', this.form.dob);
      data.append('idType', this.form.idType);
      data.append('idNumber', this.form.idNumber);
      data.append('houseNumber', this.form.houseNumber);
      data.append('line1', this.form.line1);
      data.append('city', this.form.city);
      data.append('state', this.form.state);
      data.append('zipCode', this.form.zipCode);
      data.append('country', this.form.country);

      // append files
      if(this.form.idImage) data.append('idImage', this.form.idImage);
      if(this.form.userPhoto) data.append('userPhoto', this.form.userPhoto);

      try {
        const res = await fetch("<?= esc_js(admin_url('admin-ajax.php')) ?>", {
          method: 'POST',
          body: data,
          credentials: 'same-origin'
        });

        // attempt to parse json, fallback to text
        let json;
        try { json = await res.json(); } catch(e) {
          const t = await res.text();
          json = { success: false, message: t || 'Invalid server response' };
        }

        if(json.success) {
          Toastify({ text: json.message || 'KYC submitted successfully', duration: 3000, close:true, gravity:'top', position:'center', style:{background:'linear-gradient(to right, #00b09b, #96c93d)'} }).showToast();
          // show success card and redirect button (same pattern as original)
          document.querySelector('.rounded-card').innerHTML = `
            <div class="text-center py-10">
              <i data-lucide="check-circle" class="text-green-500 text-5xl mb-3"></i>
              <h2 class="font-bold text-lg mb-1">KYC Submitted</h2>
              <p class="muted text-sm mb-3">Your KYC information has been successfully submitted.</p>
              <p class="muted text-sm mb-2">Verification takes up to <strong>3 hours</strong>. You’ll be notified once approved.</p>
              <a href="/app/status-acct" class="generate-btn inline-block mt-3" style="display:inline-block;width:200px;margin:0 auto;">Check Status</a>
            </div>`;
          // re-init lucide icons
          lucide.createIcons();
        } else {
          const msg = json.message || json.error || 'Verification failed';
          Toastify({ text: msg, duration: 4000, close:true, gravity:'top', position:'center', style:{background:'#ff3860'} }).showToast();
          this.submitting = false;
          this.hideLoading();
        }
      } catch (err) {
        console.error(err);
        Toastify({ text: 'Network error. Try again.', duration: 3500, close:true, gravity:'top', position:'center', style:{background:'#ff3860'} }).showToast();
        this.submitting = false;
        this.hideLoading();
      } finally {
        this.submitting = false;
        this.hideLoading();
      }
    }
  },
  mounted(){
    lucide.createIcons();
  }
}).mount('#app');
</script>

<!-- init lucide in case new elements were injected -->
<script>lucide.createIcons();</script>
</body>
</html>