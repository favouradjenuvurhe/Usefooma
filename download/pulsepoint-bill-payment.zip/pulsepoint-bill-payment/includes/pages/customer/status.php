<?php
/**
 * KYC Status Page — Vue / Airtime-Style UI clone
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// Start session
if (!session_id()) session_start();

$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
if (!$user_id) {
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';
    exit;
}

// Fetch settings
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#0057ff';

// User info
$table_users = $base_prefix . 'users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));
$statuskyc = $user->statuskyc ?? 0;

// Map status for display
$status_map = [
    'approved' => ['icon'=>'check-circle','color'=>'green-500','text'=>'KYC Approved','badge'=>'Approved','message'=>'Your KYC has been verified successfully.'],
    'pending'  => ['icon'=>'hourglass-split','color'=>'yellow-500','text'=>'KYC Pending','badge'=>'Pending','message'=>'Your verification is still being processed. Please check back later.'],
    'failed'   => ['icon'=>'x-circle','color'=>'red-500','text'=>'KYC Failed','badge'=>'Failed','message'=>'Your KYC could not be verified. Please resubmit your documents.']
];

// Determine initial status
if($statuskyc == 1) {
    $current_status = 'approved';
} elseif($statuskyc == 0) {
    $current_status = 'pending';
} else {
    $current_status = 'failed';
}
$kyc_nonce = wp_create_nonce('pulsepoint_kyc_status');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>KYC Status - <?= esc_html($platform_name) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<style>
:root{--app-bg:#f7f8fb;--card-bg:#ffffff;--muted:#6b7280;--primary:<?= esc_attr($color_hex) ?>;}
html,body,#app{min-height:100%;background:var(--app-bg);}
body{font-family:Inter,sans-serif;margin:0;padding:18px;}
.rounded-card{border-radius:14px;background:var(--card-bg);}
.muted{color:var(--muted);}
.generate-btn{background:var(--primary);color:#fff;font-weight:600;border-radius:10px;padding:10px 14px;}
.status-badge{display:inline-block;padding:6px 14px;border-radius:9999px;font-weight:600;font-size:14px;}
.status-approved{background:#dcfce7;color:#166534;}
.status-pending{background:#fef9c3;color:#854d0e;}
.status-failed{background:#fee2e2;color:#991b1b;}
#loadingOverlay{position:fixed;inset:0;background: rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999;}
</style>
</head>
<body>
<div id="app" class="max-w-md mx-auto">

  <!-- Header -->
  <div class="flex items-center justify-between mb-4 mt-2">
    <div class="flex items-center gap-3">
      <button @click="goBack" class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="circle-chevron-left" class="w-6 h-6 text-gray-900"></i>
      </button>
      <h2 class="text-lg font-bold text-gray-900">KYC Status</h2>
    </div>
    <div class="flex items-center gap-3">
      <button class="w-10 h-10 rounded-full flex items-center justify-center shadow bg-white">
        <i data-lucide="info" class="w-5 h-5 text-gray-800"></i>
      </button>
    </div>
  </div>

  <!-- Status Card -->
  <div class="rounded-card p-4 border border-gray-200 shadow-sm text-center">
    <div v-if="loading" class="py-10 text-gray-500">
      <i class="bi bi-arrow-repeat animate-spin text-4xl" :style="{color: primaryColor}"></i>
      <p class="mt-2 text-sm">Checking your KYC status...</p>
    </div>

    <div v-else>
      <i :data-lucide="status.icon" :class="`text-${status.color} text-5xl mb-3`"></i>
      <h3 class="font-bold text-lg mb-1">{{ status.text }}</h3>
      <p class="muted text-sm mb-3">{{ status.message }}</p>
      <span :class="['status-badge', badgeClass]">{{ status.badge }}</span>

      <div class="mt-6 space-y-3">
        <button v-if="statusKey==='pending'" @click="refreshStatus" class="generate-btn w-full">Check Again</button>
        <a v-else-if="statusKey==='approved'" href="/app/dashboard" class="generate-btn w-full">Go Back to Dashboard</a>
        <a v-else href="/app/customer" class="generate-btn w-full bg-red-500">Resubmit</a>
      </div>
    </div>
  </div>

</div>

<!-- Loading overlay -->
<div id="loadingOverlay" style="display:none">
  <div class="text-center">
    <svg class="animate-spin w-12 h-12 mb-3" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <circle cx="12" cy="12" r="10" stroke-width="4" stroke="var(--primary)" stroke-opacity="0.25"></circle>
      <path d="M22 12a10 10 0 00-10-10" stroke-width="4" stroke="var(--primary)"></path>
    </svg>
    <div style="font-weight:700;color:var(--primary)">Loading...</div>
  </div>
</div>

<script>
const { createApp } = Vue;

createApp({
  data(){
    return {
      loading: true,
      statusKey: "<?= $current_status ?>",
      status: {},
      primaryColor: "<?= esc_attr($color_hex) ?>",
      status_map: <?= wp_json_encode($status_map) ?>,
      nonce: "<?= esc_js($kyc_nonce) ?>"
    };
  },
  computed:{
    badgeClass(){
      return {
        'status-approved': this.statusKey==='approved',
        'status-pending': this.statusKey==='pending',
        'status-failed': this.statusKey==='failed'
      };
    }
  },
  methods:{
    goBack(){ window.location.href='/app/dashboard'; },
    async fetchStatus(){
      this.loading=true;
      try{
        const res = await fetch("<?= esc_js(admin_url('admin-ajax.php')) ?>", {
          method:'POST',
          body: new URLSearchParams({ action:'pulsepoint_check_kyc_status', nonce:this.nonce }),
          credentials:'same-origin'
        });
        const data = await res.json();
        // Update status
        if(data.success){
          if(data.kyc_status.toLowerCase().includes('high')){
            this.statusKey='approved';
          } else if(data.kyc_status.toLowerCase().includes('pending') || data.kyc_status.toLowerCase().includes('unreview')){
            this.statusKey='pending';
          } else {
            this.statusKey='failed';
          }
        } else {
          this.statusKey='failed';
        }
      } catch(e){
        this.statusKey='failed';
        console.error(e);
      }
      this.status = this.status_map[this.statusKey];
      this.loading=false;
      lucide.createIcons();
    },
    refreshStatus(){ this.fetchStatus(); }
  },
  mounted(){ this.fetchStatus(); }
}).mount('#app');
</script>
<script>lucide.createIcons();</script>
</body>
</html>