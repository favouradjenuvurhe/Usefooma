<?php  
/**    
 * KYC Verification Page for Pulsepoint Plugin    
 * Auto Uploads Image & Triggers Strowallet API    
 * Author: Amaaavl (updated)  
 */    
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// Start session if not started  
if (!session_id()) session_start();  
  
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;  
if (!$user_id) {  
    echo '<div style="text-align:center;margin-top:50px;font-family:sans-serif;">You must be logged in to access this page.</div>';  
    exit;  
}  
  
// Fetch settings  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  
  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#0d6efd';  
  
// User info  
$table_users = $base_prefix . 'users';  
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));  
$statuskyc = $user->statuskyc ?? 0;  
  
// If KYC already done, redirect to account status page  
if ($statuskyc == 1) {  
    wp_redirect(site_url('/app/status-acct'));  
    exit;  
}  
  
// create a nonce for ajax submit  
$kyc_nonce = wp_create_nonce('pulsepoint_kyc');  
?>  

<!doctype html>
<html lang="en">  
<head>  
<meta charset="utf-8" />  
<meta name="viewport" content="width=device-width,initial-scale=1" />  
<title>KYC Verification | <?= esc_html($platform_name) ?></title>  
<script src="https://cdn.tailwindcss.com"></script>  
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">  
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">  
<style>  
  :root { --primary: <?= esc_attr($color_hex) ?>; }  
  body { font-family: "Inter", sans-serif; background: #f9f9f9; padding: 24px; min-height: 100vh; }  
  .card { background: #fff; border-radius: 22px; box-shadow: 0 3px 12px rgba(0,0,0,0.07); padding: 24px; }  
  label { font-weight: 600; font-size: 14px; color: #333; display: block; margin-bottom: 4px; }  
  input, select { border: 1px solid #ddd; border-radius: 8px; padding: 10px; width: 100%; font-size: 14px; }  
  .generate-btn { background: var(--primary); color: #fff; font-weight: 600; border-radius: 10px; padding: 12px; width: 100%; transition: .3s; }  
  .generate-btn:hover { opacity: .9; }  
  .header-bar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }  
  .header-bar i { font-size: 22px; color: #000; cursor: pointer; }  
  .header-avatar { width: 38px; height: 38px; border-radius: 50%; background: var(--primary); display: flex; align-items: center; justify-content: center; overflow: hidden; }  
  .header-avatar img { width: 100%; height: 100%; object-fit: cover; }  
  .form-step { display: none; animation: fadeIn .4s ease-in-out; }  
  .form-step.active { display: block; }  
  @keyframes fadeIn { from { opacity: 0; transform: translateY(10px);} to { opacity: 1; transform: translateY(0);} }  
  .file-preview { max-height: 120px; border-radius: 8px; display:block; margin-top:8px; object-fit:cover; }  
  .small-muted { font-size:13px;color:#6b7280;margin-top:6px; }  
  .error-text { color:#b91c1c; font-weight:600; margin-top:8px; }  
</style>  
</head>  
<body>  
<div class="max-w-2xl mx-auto space-y-6">  
  <!-- Header -->  
  <div class="header-bar">  
    <a href="/app/dashboard"><i class="bi bi-arrow-left-circle"></i></a>  
    <div class="header-avatar">  
      <img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt="User Avatar">  
    </div>  
  </div>  

  <!-- KYC Card -->  
  <div class="card" id="kycCard">  
    <div class="text-center mb-6">  
      <i class="bi bi-person-vcard text-[var(--primary)] text-4xl mb-2"></i>  
      <h2 class="font-bold text-lg mb-1">KYC Verification</h2>  
      <p class="text-gray-600 text-sm leading-6">Upload your government-issued ID and a selfie for verification.<br>Approval usually takes <strong>up to 3 hours</strong>.</p>  
    </div>  

    <!-- KYC Form -->  
    <form id="kycForm" enctype="multipart/form-data" class="space-y-4" novalidate>  
      <input type="hidden" name="action" value="pulsepoint_customer_kyc">  
      <input type="hidden" name="nonce" value="<?= esc_attr($kyc_nonce) ?>">  

      <div id="stepContainer">  
        <!-- STEP 1 -->  
        <div class="form-step active">  
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">  
            <div>  
              <label>Date of Birth</label>  
              <input type="date" name="dob" required>  
            </div>  
            <div>  
              <label>ID Type</label>  
              <select name="idType" required>  
                <option value="">Select</option>  
                <option value="NIN">NIN</option>               
                <option value="PASSPORT">International Passport</option>  
              </select>  
            </div>  
          </div>  
        </div>  

        <!-- STEP 2 -->  
        <div class="form-step">  
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">  
            <div>  
              <label>ID Number</label>  
              <input type="text" name="idNumber" required>  
            </div>  
            <div>  
              <label>ID Image (PNG only)</label>  
              <input type="file" name="idImage" accept="image/png" required>  
              <img id="idPreview" class="file-preview" style="display:none;" alt="ID preview">  
              <div id="idNote" class="small-muted">Supported: PNG only. Max 5MB.</div>  
            </div>  
          </div>  
        </div>  

        <!-- STEP 3 -->  
        <div class="form-step">  
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">  
            <div>  
              <label>Selfie Photo (PNG only)</label>  
              <input type="file" name="userPhoto" accept="image/png" required>  
              <img id="selfiePreview" class="file-preview" style="display:none;" alt="Selfie preview">  
              <div id="selfieNote" class="small-muted">Take a clear PNG selfie (face visible). Max 5MB.</div>  
            </div>  
            <div>  
              <label>House Number</label>  
              <input type="text" name="houseNumber" required>  
            </div>  
          </div>  
        </div>  

        <!-- STEP 4 -->  
        <div class="form-step">  
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">  
            <div>  
              <label>Street / Line 1</label>  
              <input type="text" name="line1" required>  
            </div>  
            <div>  
              <label>City</label>  
              <input type="text" name="city" required>  
            </div>  
          </div>  
        </div>  

        <!-- STEP 5 -->  
        <div class="form-step">  
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">  
            <div>  
              <label>State</label>  
              <input type="text" name="state" required>  
            </div>  
            <div>  
              <label>ZIP Code</label>  
              <input type="text" name="zipCode" required>  
            </div>  
          </div>  
        </div>  

        <!-- STEP 6 -->  
        <div class="form-step">  
          <div>  
            <label>Country</label>  
            <input type="text" name="country" value="Nigeria" required>  
          </div>  
        </div>  
      </div>  

      <!-- Navigation Buttons -->  
      <div class="flex justify-between mt-3 gap-3">  
        <button type="button" id="prevBtn" class="generate-btn bg-gray-300 text-black hidden" style="width: 48%;">Previous</button>  
        <button type="button" id="nextBtn" class="generate-btn" style="width: 48%;">Next</button>  
      </div>  

      <div id="formError" class="error-text" style="display:none;"></div>  
    </form>  

    <p class="text-center text-sm text-gray-500 mt-5">We take your privacy seriously. Your data is securely encrypted and processed through NDPR.</p>
  </div>  
</div>  

<script>  
(function(){  
  const steps = document.querySelectorAll('.form-step');  
  let currentStep = 0;  
  const nextBtn = document.getElementById('nextBtn');  
  const prevBtn = document.getElementById('prevBtn');  
  const form = document.getElementById('kycForm');  
  const card = document.getElementById('kycCard');  
  const formError = document.getElementById('formError');  
  
  function showStep(index) {  
    steps.forEach((step, i) => step.classList.toggle('active', i === index));  
    prevBtn.classList.toggle('hidden', index === 0);  
    nextBtn.textContent = (index === steps.length - 1) ? 'Submit Verification' : 'Next';  
    formError.style.display = 'none';  
  }  
  
  nextBtn.addEventListener('click', async () => {  
    const inputs = steps[currentStep].querySelectorAll('input, select, textarea');  
    for (let input of inputs) {  
      if (input.required && !input.value) {  
        formError.textContent = 'Please complete all required fields on this step.';  
        formError.style.display = 'block';  
        return;  
      }  
    }  
  
    if (currentStep < steps.length - 1) {  
      currentStep++;  
      showStep(currentStep);  
      return;  
    }  
  
    const data = new FormData(form);  
    card.innerHTML = `<div class='text-center py-10 text-gray-500'>  
      <i class="bi bi-arrow-repeat animate-spin text-4xl" style="color:var(--primary)"></i>  
      <p>Submitting your KYC information...</p>  
    </div>`;  
  
    try {  
      const res = await fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {  
        method: 'POST',  
        body: data,  
        credentials: 'same-origin',  
      });  
      const json = await res.json().catch(async () => {  
        const t = await res.text();  
        return { success: false, message: t || 'Invalid server response' };  
      });  
  
      let messageText = '';  
      if (typeof json.message === 'string') {  
        messageText = json.message;  
      } else if (typeof json.message === 'object') {  
        try { messageText = JSON.stringify(json.message); } catch(e) { messageText = 'Verification failed.'; }  
      } else {  
        messageText = json.message ?? (json.error ?? 'Unknown response from server.');  
      }  
  
      if (json.success) {  
        card.innerHTML = `<div class='text-center py-10'>  
          <i class='bi bi-check-circle-fill text-green-500 text-4xl mb-3'></i>  
          <h2 class='font-bold text-lg mb-1'>KYC Submitted</h2>  
          <p class='text-gray-600 text-sm mb-3'>Your KYC information has been successfully submitted.</p>  
          <p class='text-sm text-gray-500 mb-2'>Verification takes up to <strong>3 hours</strong>. You’ll be notified once approved.</p>  
          <a href='/app/status-acct' class='generate-btn inline-block text-center mt-3' style='display:inline-block;width:200px;margin:0 auto;'>Check Status</a>  
        </div>`;  
      } else {  
        card.innerHTML = `<div class='text-center py-10'>  
          <i class='bi bi-exclamation-circle text-[var(--primary)] text-4xl mb-3'></i>  
          <h2 class='font-bold text-lg mb-2'>Verification Failed</h2>  
          <p class='text-gray-600 text-sm mb-4'>${messageText}</p>  
          <button class='generate-btn' onclick='location.reload()'>Try Again</button>  
        </div>`;  
      }  
    } catch (err) {  
      console.error(err);  
      card.innerHTML = `<div class='text-center py-10'>  
        <i class='bi bi-exclamation-circle text-[var(--primary)] text-4xl mb-3'></i>  
        <h2 class='font-bold text-lg mb-2'>Network Error</h2>  
        <p class='text-gray-600 text-sm mb-4'>Unable to connect. Please check your internet and try again.</p>  
        <button class='generate-btn' onclick='location.reload()'>Try Again</button>  
      </div>`;  
    }  
  });  
  
  prevBtn.addEventListener('click', () => {  
    if (currentStep > 0) {  
      currentStep--;  
      showStep(currentStep);  
    }  
  });  
  
  function setupPreview(inputName, previewId) {  
    const input = document.querySelector(`input[name="${inputName}"]`);  
    const preview = document.getElementById(previewId);  
    if (!input) return;  
    input.addEventListener('change', () => {  
      const f = input.files[0];  
      if (!f) { preview.style.display = 'none'; return; }  
      if (f.size > 5 * 1024 * 1024) {  
        alert('File too large (max 5MB). Please choose a smaller PNG.');  
        input.value = '';  
        preview.style.display = 'none';  
        return;  
      }  
      if (f.type !== 'image/png') {  
        alert('Only PNG files are allowed.');  
        input.value = '';  
        preview.style.display = 'none';  
        return;  
      }  
      const url = URL.createObjectURL(f);  
      preview.src = url;  
      preview.style.display = 'block';  
    });  
  }  
  setupPreview('idImage', 'idPreview');  
  setupPreview('userPhoto', 'selfiePreview');  
  
  showStep(0);  
})();  
</script>  
</body>  
</html>