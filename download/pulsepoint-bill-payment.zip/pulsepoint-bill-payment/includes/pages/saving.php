<?php  
/**  
 * Pulsepoint Savings Dashboard  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/savings-dashboard.php  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) {  
    exit;  
}  
  
// Stop page if domain not verified  
if (defined('PULSEPOINT_CORE') && PULSEPOINT_CORE) {  
    echo '<div class="notice notice-error"><p><strong>Access Restricted:</strong> This feature is available only to verified domains.</p></div>';  
    return;  
}  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// Detect device  
function is_mobile_device() {  
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');  
    return preg_match('/(android|iphone|ipad|ipod|blackberry|opera mini|iemobile|mobile)/i', $user_agent);  
}  
$is_mobile = is_mobile_device();  
  
// Get platform settings  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#000';  
  
// Get user  
session_start();  
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;  
  
$table_users   = $base_prefix . 'users';  
$table_savings = $base_prefix . 'savings_pocket';  
$table_trnx    = $base_prefix . 'savings_transactions';  
  
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id));  
$firstname = $user ? esc_html($user->firstname) : 'User';  
  
// Fetch all user saving pockets  
$pockets = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_savings} WHERE user_id = %d ORDER BY created_at DESC", $user_id));  
  
// Calculate total savings  
$total_savings = 0;  
foreach ($pockets as $p) $total_savings += $p->current_amount;  
$total_savings_fmt = number_format($total_savings, 2);  
?>  
<!doctype html>
<html lang="en">        
<head>        
  <meta charset="utf-8" />        
  <meta name="viewport" content="width=device-width,initial-scale=1" />        
  <title>Savings | <?= esc_html($platform_name) ?></title>        
  <script src="https://cdn.tailwindcss.com"></script>        
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">        
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">        
  <style>        
    :root { --primary: <?= $color_hex ?>; }        
    body {        
      font-family: 'Inter', sans-serif;        
      background: #f9f9fb;        
      min-height: 100vh;        
      padding: 20px;        
    }        
    .header-bar {        
      display: flex;        
      align-items: center;        
      justify-content: space-between;        
      margin-bottom: 1.5rem;        
    }        
    .header-avatar {        
      width: 38px;        
      height: 38px;        
      border-radius: 50%;        
      background: var(--primary);        
      display: flex;        
      align-items: center;        
      justify-content: center;        
      overflow: hidden;        
    }        
    .header-avatar img { width: 100%; height: 100%; object-fit: cover; }        
  </style>        
</head>        
<body>    

<?php if ($is_mobile): ?>  
<!-- MOBILE SAVINGS DASHBOARD -->  
<div class="max-w-md mx-auto pb-24">        
    <div class="w-full max-w-md mx-auto space-y-6">        
        <div class="header-bar">        
            <a href="/app/dashboard"><i class="bi bi-arrow-left-circle"></i></a>        
            <div class="header-avatar"><img src="/wp-content/plugins/pulsepoint-bill-payment/assets/img/icon.png" alt=""></div>        
        </div>    
        <!-- Total Savings -->        
        <div class="p-6 rounded-2xl text-white" style="background: <?= $color_hex ?>;">        
            <div class="opacity-80 text-sm">Total Savings</div>        
            <div class="text-4xl font-bold mt-1">₦<?= $total_savings_fmt ?></div>        
            <div class="mt-4">        
                <a href="/app/create-savings" class="bg-white text-black px-4 py-2 rounded-lg font-semibold">+ New Plan</a>        
            </div>        
        </div>    

        <!-- Savings Pockets -->        
        <div class="mt-8">        
            <div class="font-semibold text-[<?= $color_hex ?>] mb-3">My Saving Pockets</div>        
            <?php if (empty($pockets)): ?>        
                <div class="bg-white rounded-xl p-5 text-center shadow-sm text-gray-400">        
                    No savings pocket yet.<br>        
                    <a href="/app/create-savings" class="text-[<?= $color_hex ?>] font-semibold">Create one now →</a>        
                </div>        
            <?php else: ?>        
                <div class="space-y-4">        
                    <?php foreach ($pockets as $p):        
                        $progress = ($p->current_amount / max(1, $p->target_amount)) * 100;        
                        $progress = number_format(min($progress, 100), 0);        

                        // Set display for 0% saved on cancelled
                        $progress_label = ($p->status == 'cancelled' && $progress == 0) ? 'Completed' : $progress.'% saved';
                        // Determine deposit availability
                        $deposit_allowed = ($p->status == 'cancelled') ? false : true;
                    ?>        
                    <div class="bg-white rounded-xl p-5 shadow-sm">        
                        <div class="flex justify-between items-center mb-1">        
                            <div class="font-semibold text-gray-800"><?= esc_html($p->title) ?></div>        
                            <div class="text-xs px-2 py-1 rounded-full
  <?= $p->status == 'active' ? 'bg-green-100 text-green-600' : ($p->status == 'completed' ? 'bg-green-100 text-green-600' : ($p->status == 'cancelled' ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-500')) ?>">    
  <?= ucfirst($p->status) ?>                                              
                            </div>        
                        </div>        
                        <div class="text-sm text-gray-600 mb-3">₦<?= number_format($p->current_amount,2) ?> / ₦<?= number_format($p->target_amount,2) ?></div>        
                        <div class="w-full bg-gray-200 rounded-full h-2">        
                            <div class="h-2 rounded-full" style="width: <?= $progress ?>%; background: <?= $color_hex ?>;"></div>        
                        </div>        
                        <div class="text-xs text-gray-500 mt-1"><?= $progress_label ?></div>        
                        <div class="flex justify-between items-center mt-4">        
                            <a href="/app/savings-details?pocket=<?= $p->id ?>" class="text-[<?= $color_hex ?>] text-sm font-semibold">View Details</a>        
                            <?php if ($deposit_allowed): ?>
                                <a href="/app/deposit?pocket=<?= $p->id ?>" class="bg-[<?= $color_hex ?>] text-white text-sm px-3 py-1.5 rounded-lg font-semibold">Deposit</a>      
                            <?php else: ?>
                                <span class="text-red-500 text-sm font-semibold">Deposit unavailable</span>
                            <?php endif; ?>
                        </div>        
                    </div>        
                    <?php endforeach; ?>        
                </div>        
            <?php endif; ?>        
        </div>        
    </div>      
</div>

<?php else: ?>  
<!-- DESKTOP VERSION -->  
<?php include __DIR__.'/sidebar.php'; ?>  
<div class="ml-[280px] max-w-7xl mx-auto pb-24 px-6">      
    <!-- Top Summary -->      
    <div class="grid md:grid-cols-3 gap-6 mb-10">      
        <div class="p-6 rounded-2xl text-white" style="background: <?= $color_hex ?>;">      
            <div class="opacity-80 text-sm">Total Savings</div>      
            <div class="text-2xl font-bold mt-1">₦<?= $total_savings_fmt ?></div>      
            <div class="mt-4">      
                <a href="/app/create-savings" class="bg-white text-black px-4 py-2 rounded-lg font-semibold">+ New Plan</a>      
            </div>      
        </div>    
        <div class="p-6 bg-white rounded-2xl shadow-sm flex flex-col justify-center">      
            <div class="text-gray-600 text-sm">Active Pockets</div>      
            <div class="text-3xl font-bold mt-1 text-[<?= $color_hex ?>]"><?= count($pockets) ?></div>      
        </div>    
        <div class="p-6 bg-white rounded-2xl shadow-sm flex flex-col justify-center">      
            <div class="text-gray-600 text-sm">Last Updated</div>      
            <div class="text-3xl font-bold mt-1"><?= date('d M Y') ?></div>      
        </div>      
    </div>      
    <!-- Savings Pockets -->      
    <div>      
        <div class="font-semibold text-[<?= $color_hex ?>] mb-3 text-lg">My Saving Pockets</div>      
        <?php if (empty($pockets)): ?>      
            <div class="bg-white rounded-xl p-10 text-center shadow-sm text-gray-400">      
                No savings pocket yet.<br>      
                <a href="/app/create-savings" class="text-[<?= $color_hex ?>] font-semibold">Create one now →</a>      
            </div>      
        <?php else: ?>      
            <div class="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">      
                <?php foreach ($pockets as $p):      
                    $progress = ($p->current_amount / max(1, $p->target_amount)) * 100;      
                    $progress = number_format(min($progress, 100), 0);      
                    $progress_label = ($p->status == 'cancelled' && $progress == 0) ? 'Completed' : $progress.'% saved';
                    $deposit_allowed = ($p->status == 'cancelled') ? false : true;
                ?>      
                <div class="bg-white rounded-xl p-5 shadow-sm hover:shadow-md transition">      
                    <div class="flex justify-between items-center mb-1">      
                        <div class="font-semibold text-gray-800"><?= esc_html($p->title) ?></div>      
                        <div class="text-xs px-2 py-1 rounded-full   
<?= $p->status == 'active' ? 'bg-green-100 text-green-600' : ($p->status == 'completed' ? 'bg-green-100 text-green-600' : ($p->status == 'cancelled' ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-500')) ?>">  
<?= ucfirst($p->status) ?>
</div>  
                    </div>      
                    <div class="text-sm text-gray-600 mb-3">₦<?= number_format($p->current_amount,2) ?> / ₦<?= number_format($p->target_amount,2) ?></div>      
                    <div class="w-full bg-gray-200 rounded-full h-2">      
                        <div class="h-2 rounded-full" style="width: <?= $progress ?>%; background: <?= $color_hex ?>;"></div>      
                    </div>      
                    <div class="text-xs text-gray-500 mt-1"><?= $progress_label ?></div>      
                    <div class="flex justify-between items-center mt-4">      
                        <a href="/app/savings-details?pocket=<?= $p->id ?>" class="text-[<?= $color_hex ?>] text-sm font-semibold">View Details</a>      
                        <?php if ($deposit_allowed): ?>
                            <a href="/app/deposit?pocket=<?= $p->id ?>" class="bg-[<?= $color_hex ?>] text-white text-sm px-3 py-1.5 rounded-lg font-semibold">Deposit</a>
                        <?php else: ?>
                            <span class="text-red-500 text-sm font-semibold">Deposit unavailable</span>
                        <?php endif; ?>
                    </div>      
                </div>      
                <?php endforeach; ?>      
            </div>      
        <?php endif; ?>      
    </div>      
<?php endif; ?>    
</body>        
</html>