<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
header('Content-Type: application/json');

/* ---------- POST ONLY ---------- */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'message'=>'POST only']);
    exit;
}

/* ---------- READ RAW ---------- */
$raw = file_get_contents('php://input');

/* ---------- LOG ---------- */
file_put_contents(
    __DIR__.'/strocard-webhook-log.txt',
    date('Y-m-d H:i:s')." | ".$raw.PHP_EOL,
    FILE_APPEND
);

$data = json_decode($raw, true);

if (!$data || empty($data['cardId'])) {
    echo json_encode(['success'=>false,'message'=>'Missing cardId']);
    exit;
}

/* ---------- SAFE EXTRACT ---------- */
$card_id   = sanitize_text_field($data['cardId']);
$status    = sanitize_text_field($data['status'] ?? '');
$reference = sanitize_text_field($data['reference'] ?? '');
$txn_id    = sanitize_text_field($data['id'] ?? uniqid());
$narrative = sanitize_text_field($data['narrative'] ?? '');
$currency  = sanitize_text_field($data['currency'] ?? 'USD');
$event     = sanitize_text_field($data['event'] ?? '');

/* ---------- AMOUNT NORMALIZATION ---------- */
$amount_raw = $data['amount'] ?? 0;
$amount = floatval($amount_raw);

// Convert cents if amount is large (likely in cents)
if ($amount > 1000) {
    $amount = round($amount / 100, 2);
}
$amount_cents = round($amount * 100);

/* ---------- TABLES ---------- */
$table_cards = $wpdb->prefix.'virtual_cards';
$table_trnx  = $wpdb->prefix.'virtualcard_transactions';

/* ---------- START DB TRANSACTION ---------- */
$wpdb->query('START TRANSACTION');

/* ---------- LOCK CARD ROW ---------- */
$card = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$table_cards} WHERE card_id=%s FOR UPDATE",
        $card_id
    )
);

if (!$card) {
    $wpdb->query('ROLLBACK');
    echo json_encode(['success'=>false,'message'=>'Card not found']);
    exit;
}

/* ---------- DUPLICATE CHECK ---------- */
$dup = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT id FROM {$table_trnx} WHERE transaction_id=%s",
        $txn_id
    )
);

if ($dup) {
    $wpdb->query('ROLLBACK');
    echo json_encode(['success'=>true,'message'=>'Duplicate ignored']);
    exit;
}

/* ---------- DETERMINE TRANSACTION TYPE ---------- */
$type = 'debit'; // default

switch ($event) {
    case 'virtualcard.created.success':
    case 'virtualcard.topup.success':
        $type = 'credit';
        break;

    case 'virtualcard.transaction.crossborder':
        $type = 'debit';
        break;

    case 'virtualcard.transaction.declined':
    case 'virtualcard.transaction.declined.terminated':
        $type = 'none'; // failed transactions do not affect balance
        break;

    default:
        // fallback for other unknown events
        if (strpos($reference, 'Fund') !== false) $type = 'credit';
        if (strpos($reference, 'Withdraw') !== false) $type = 'debit';
        break;
}

/* ---------- INSERT TRANSACTION ---------- */
$inserted = $wpdb->insert($table_trnx, [
    'transaction_id' => $txn_id,
    'card_id'        => $card_id,
    'amount'         => $amount,
    'cent_amount'    => $amount_cents,
    'type'           => $type,
    'narrative'      => $narrative,
    'status'         => $status,
    'currency'       => $currency,
    'reference'      => $reference,
    'event'          => $event,
    'created_at'     => current_time('mysql'),
    'updated_at'     => current_time('mysql')
]);

if (!$inserted) {
    $wpdb->query('ROLLBACK');
    echo json_encode(['success'=>false,'message'=>'Insert failed']);
    exit;
}

/* ---------- UPDATE BALANCE ---------- */
$new_balance = floatval($card->balance);

if ($status === 'success') {
    if ($type === 'credit') {
        $new_balance += $amount;
    } elseif ($type === 'debit') {
        $new_balance -= $amount;
        if ($new_balance < 0) $new_balance = 0;
    }

    // Only update balance if type affects it
    if ($type !== 'none') {
        $updated = $wpdb->update(
            $table_cards,
            ['balance' => $new_balance],
            ['card_id' => $card_id]
        );

        if ($updated === false) {
            $wpdb->query('ROLLBACK');
            echo json_encode(['success'=>false,'message'=>'Balance update failed']);
            exit;
        }
    }
}

/* ---------- COMMIT ---------- */
$wpdb->query('COMMIT');

/* ---------- RESPONSE ---------- */
echo json_encode([
    'success' => true,
    'message' => 'Processed successfully',
    'type'    => $type,
    'amount'  => $amount,
    'balance' => $new_balance
]);

exit;