<?php
/**
 * Africa's Talking Voice callback dispatcher.
 */
if (!defined('ABSPATH')) exit;

if (function_exists('usefooma_africastalking_webhook')) {
    usefooma_africastalking_webhook();
    exit;
}

status_header(500);
header('Content-Type: application/xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?><Response><Reject/></Response>';
exit;
