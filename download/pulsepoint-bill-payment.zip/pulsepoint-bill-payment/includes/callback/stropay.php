<?php  
/**  
 * Stropay Webhook Callback (Wallet Funding + Fee + Referral Bonus + Email Notifications)  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
  
// === BLOCK DIRECT ACCESS (Non-POST requests) ===  
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {  
    header('Content-Type: application/json');  
    http_response_code(403);  
    echo json_encode([  
        'success' => false,  
        'message' => 'Access forbidden. This endpoint only accepts POST requests.'  
    ], JSON_PRETTY_PRINT);  
    exit;  
}  
  
header('Content-Type: application/json');  
  
// === STEP 1: Read Payload ===  
$raw = file_get_contents('php://input');  
$data = json_decode($raw, true);  
  
// === STEP 2: Log webhook data ===  
$log_file = __DIR__ . '/stropay-webhook-log.txt';  
file_put_contents($log_file, date('Y-m-d H:i:s') . " | " . $raw . PHP_EOL, FILE_APPEND);  
  
// === STEP 3: Validate Payload ===  
if (!$data || !isset($data['sessionId']) || !isset($data['accountNumber']) || !isset($data['transactionAmount'])) {  
    error_log("Invalid Stropay payload: " . $raw);  
    echo json_encode(['success' => false, 'message' => 'Invalid Stropay payload structure'], JSON_PRETTY_PRINT);  
    exit;  
}  

// === STEP 3b: SECURITY PATCH — Verify transaction with Strowallet ===  
$base_prefix    = $wpdb->prefix . 'pulsepoint_';  
$table_settings = "{$base_prefix}settings";  

$public_key = $wpdb->get_var("SELECT opt_value FROM {$table_settings} WHERE opt_key = 'pay_token' LIMIT 1");  

if (empty($public_key)) {  
    error_log("Missing Strowallet public key");  
    echo json_encode(['success' => false, 'message' => 'Verification failed: missing API key'], JSON_PRETTY_PRINT);  
    exit;  
}  

$verify_url = "https://strowallet.com/api/verifysessionid/?public_key={$public_key}&amount={$data['transactionAmount']}&sessionID={$data['sessionId']}";  

$ch = curl_init();  
curl_setopt_array($ch, [  
    CURLOPT_URL => $verify_url,  
    CURLOPT_RETURNTRANSFER => true,  
    CURLOPT_HTTPHEADER => ['accept: application/json'],  
    CURLOPT_TIMEOUT => 15,  
]);  

$verify_response = curl_exec($ch);  
$verify_error = curl_error($ch);  
curl_close($ch);  

if ($verify_error) {  
    error_log("Verification cURL error: " . $verify_error);  
    echo json_encode(['success' => false, 'message' => 'Verification request failed'], JSON_PRETTY_PRINT);  
    exit;  
}  

$verify_data = json_decode($verify_response, true);  

if (!is_array($verify_data) || !isset($verify_data['status']) || $verify_data['status'] != 200) {  
    error_log("Strowallet verification failed: " . $verify_response);  
    echo json_encode(['success' => false, 'message' => 'Transaction verification failed'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 4: Extract Fields ===  
$reference          = sanitize_text_field($data['sessionId']);  
$accountNo          = sanitize_text_field($data['accountNumber']);  
$tranRemarks        = sanitize_text_field($data['tranRemarks'] ?? '');  
$transactionAmount  = floatval($data['transactionAmount']);  
$settledAmount      = floatval($data['settledAmount'] ?? 0);  
$feeAmount          = floatval($data['feeAmount'] ?? 0);  
$vatAmount          = floatval($data['vatAmount'] ?? 0);  
$currency           = sanitize_text_field($data['currency'] ?? 'NGN');  
$sourceAccountNo    = sanitize_text_field($data['sourceAccountNumber'] ?? '');  
$sourceAccountName  = sanitize_text_field($data['sourceAccountName'] ?? '');  
$status             = 'success';  
  
if ($transactionAmount <= 0 || empty($accountNo) || empty($reference)) {  
    echo json_encode(['success' => false, 'message' => 'Incomplete transaction data.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 5: Define Tables ===  
$table_users    = "{$base_prefix}users";  
$table_trnx     = "{$base_prefix}trnx";  
$table_accnt    = "{$base_prefix}account";  
$table_referrals = "{$base_prefix}referrals";  
  
// === STEP 6: Find User Account ===  
$account = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_accnt} WHERE number = %s LIMIT 1", $accountNo));  
if (!$account) {  
    echo json_encode(['success' => false, 'message' => 'Account not found: ' . $accountNo], JSON_PRETTY_PRINT);  
    exit;  
}  
$user_id = intval($account->user_id);  
  
// === STEP 7: Prevent Duplicate Webhooks ===  
$exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_trnx} WHERE reference = %s", $reference));  
if ($exists > 0) {  
    echo json_encode(['success' => true, 'message' => 'Duplicate webhook ignored.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 8: Get Funding Fee ===  
$funding_fee_val = $wpdb->get_var($wpdb->prepare(  
    "SELECT opt_value FROM {$table_settings} WHERE opt_key = %s LIMIT 1",  
    'pay_fee'  
));  
$funding_fee_val = floatval($funding_fee_val);  
  
// === STEP 9: Calculate Fee ===  
$fee = 0;  
if ($funding_fee_val > 0) {  
    $fee = ($funding_fee_val / 100) * $transactionAmount;  
}  
$credited_amount = max($transactionAmount - $fee, 0);  
  
// === STEP 10: Record Transaction ===  
$wpdb->insert($table_trnx, [  
    'user_id'          => $user_id,  
    'details'          => $tranRemarks,  
    'recipient'        => $accountNo,  
    'amount'           => $transactionAmount,  
    'reference'        => $reference,  
    'payment'          => 'wallet',  
    'category'         => 'funding',  
    'status'           => 'success',  
    'type'             => 'credit',  
    'gateway_response' => maybe_serialize($data),  
    'description'      => "Wallet credited ₦{$transactionAmount} from {$sourceAccountName} ({$sourceAccountNo}). fee: ₦{$fee}"  
]);  
  
// === STEP 11: Update Wallet ===  
$wpdb->query($wpdb->prepare(  
    "UPDATE {$table_users} SET wallet = wallet + %f WHERE id = %d",  
    $credited_amount, $user_id  
));  
  
// === STEP 11b: Handle Referral Bonus ===  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  
$referral_amount = floatval($settings['referral_amount'] ?? 200);  
  
$referrer_id = $wpdb->get_var($wpdb->prepare(  
    "SELECT referrer_id FROM {$table_referrals} WHERE referee_id = %d LIMIT 1",  
    $user_id  
));  
  
if ($referrer_id) {  
    $funding_count = $wpdb->get_var($wpdb->prepare(  
        "SELECT COUNT(*) FROM {$table_trnx} WHERE user_id = %d AND category = 'funding' AND status = 'success'",  
        $user_id  
    ));  
  
    if ($funding_count >= 3) {  
        $wpdb->query($wpdb->prepare(  
            "UPDATE {$table_referrals} SET completed = 1, updated_at = NOW() WHERE referee_id = %d",  
            $user_id  
        ));  
  
        $bonus_given = $wpdb->get_var($wpdb->prepare(  
            "SELECT bonus_given FROM {$table_referrals} WHERE referee_id = %d",  
            $user_id  
        ));  
  
        if (!$bonus_given) {  
            $wpdb->query($wpdb->prepare(  
                "UPDATE {$table_users} SET wallet = wallet + %f, referral_balance = referral_balance + %f WHERE id = %d",  
                $referral_amount, $referral_amount, $referrer_id  
            ));  
  
            $wpdb->query($wpdb->prepare(  
                "UPDATE {$table_referrals} SET bonus_given = 1 WHERE referee_id = %d",  
                $user_id  
            ));  
  
            $referrer = $wpdb->get_row($wpdb->prepare("SELECT firstname, lastname, email FROM {$table_users} WHERE id = %d", $referrer_id));  
            if ($referrer) {  
                $subject_referrer = "Referral Bonus Credited!";  
                $message_referrer = "  
                    Hi {$referrer->firstname},<br><br>  
                    You have earned ₦{$referral_amount} for your referral completing 3 funding transactions.<br><br>  
                    Keep inviting friends to earn more!<br><br>  
                    Regards,<br>{$settings['platform_name']} Team  
                ";  
                @wp_mail($referrer->email, $subject_referrer, $message_referrer, ['Content-Type: text/html; charset=UTF-8']);  
            }  
        }  
    }  
}  
  
// === STEP 12: Email Notifications ===  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$admin_email   = $settings['email_number'] ?? get_option('admin_email');  
  
$user = $wpdb->get_row($wpdb->prepare("SELECT firstname, lastname, email, phone FROM {$table_users} WHERE id = %d", $user_id));  
$user_ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';  
$date_time = date('Y-m-d H:i:s');  
  
$subject_admin = "New Wallet Funding on {$platform_name}";  
$message_admin = "  
Hello Admin,<br><br>  
A new wallet funding transaction has been received.<br><br>  
<strong>User:</strong> {$user->firstname} {$user->lastname} ({$user->email})<br>  
<strong>Phone:</strong> {$user->phone}<br>  
<strong>Account Number:</strong> {$accountNo}<br>  
<strong>Transaction Amount:</strong> ₦{$transactionAmount}<br>  
<strong>Fee:</strong> ₦{$fee}<br>  
<strong>Amount Credited:</strong> ₦{$credited_amount}<br>  
<strong>Reference:</strong> {$reference}<br>  
<strong>Status:</strong> {$status}<br>  
<strong>Date/Time:</strong> {$date_time}<br>  
<strong>IP:</strong> {$user_ip}<br><br>  
Regards,<br>  
{$platform_name} System  
";  
  
$subject_user = "Wallet Credited on {$platform_name}";  
$message_user = "  
Hi {$user->firstname},<br><br>  
Your wallet has been successfully credited.<br><br>  
<strong>Account Number:</strong> {$accountNo}<br>  
<strong>Transaction Amount:</strong> ₦{$transactionAmount}<br>  
<strong>Fee Deducted:</strong> ₦{$fee}<br>  
<strong>Amount Credited:</strong> ₦{$credited_amount}<br>  
<strong>Reference:</strong> {$reference}<br>  
<strong>Status:</strong> {$status}<br>  
<strong>Date/Time:</strong> {$date_time}<br><br>  
Thank you for using {$platform_name}.<br><br>  
Regards,<br>  
{$platform_name} Team  
";  
  
$headers = ['Content-Type: text/html; charset=UTF-8'];  
@wp_mail($admin_email, $subject_admin, $message_admin, $headers);  
@wp_mail($user->email, $subject_user, $message_user, $headers);  
  
// === STEP 13: Respond ===  
echo json_encode([  
    'success'   => true,  
    'message'   => "Wallet credited successfully (Stropay). Fee ₦{$fee} deducted.",  
    'credited'  => $credited_amount,  
    'fee'       => $fee,  
    'reference' => $reference,  
], JSON_PRETTY_PRINT);  
exit;  
?>