<?php
if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

global $wpdb;

header('Content-Type: application/json');

/* POST only */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    exit(json_encode(['success'=>false,'message'=>'POST only']));
}

/* Read payload */
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

/* Log incoming */
file_put_contents(
    __DIR__.'/cashwyre-crypto.log',
    date('Y-m-d H:i:s')." | ".$raw.PHP_EOL,
    FILE_APPEND
);

/* Validate payload */
if (!$data || !isset($data['hash'])) {
    http_response_code(400);
    exit(json_encode(['success'=>false,'message'=>'Invalid payload']));
}

/* Extract fields */
$tx_hash  = sanitize_text_field($data['hash']);
$amount   = floatval($data['amount']);
$address  = sanitize_text_field($data['address']);
$network  = strtoupper(sanitize_text_field($data['chain'] ?? 'TRON'));
$confirmations = intval($data['confirmations'] ?? 0);

/* Require at least 1 confirmation (optional) */
if ($confirmations < 0) {
    exit(json_encode(['success'=>true,'message'=>'Waiting confirmations']));
}

if (!$tx_hash || $amount <= 0 || !$address) {
    http_response_code(400);
    exit(json_encode(['success'=>false,'message'=>'Incomplete data']));
}

/* Tables */
$base = $wpdb->prefix . 'pulsepoint_';
$wallet_table = $base . 'crypto_wallet';
$trx_table    = $base . 'crypto_transactions';

/* Find wallet */
$wallet = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$wallet_table}
         WHERE address=%s AND status='active'
         LIMIT 1",
        $address
    )
);

if (!$wallet) {
    exit(json_encode(['success'=>false,'message'=>'Wallet not found']));
}

/* Duplicate check */
$exists = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT id FROM {$trx_table}
         WHERE tx_hash=%s LIMIT 1",
        $tx_hash
    )
);

if ($exists) {
    exit(json_encode(['success'=>true,'message'=>'Duplicate ignored']));
}

/* Fee calc */
$fee_amount = round(($amount * 0.1) / 100, 8);
$net_amount = round($amount - $fee_amount, 8);

/* Transaction */
$wpdb->query('START TRANSACTION');

/* Insert transaction */
$insert = $wpdb->insert(
    $trx_table,
    [
        'user_id'   => $wallet->user,
        'wallet_id' => $wallet->id,
        'tx_type'   => 'receive',
        'assetType' => $wallet->assetType,
        'network'   => $network,
        'amount'    => $net_amount,
        'fee'       => $fee_amount,
        'status'    => 'completed',
        'tx_hash'   => $tx_hash,
        'to_address'=> $address,
        'created_at'=> current_time('mysql')
    ],
    ['%d','%d','%s','%s','%s','%f','%f','%s','%s','%s','%s']
);

if (!$insert) {
    $wpdb->query('ROLLBACK');

    file_put_contents(
        __DIR__.'/cashwyre-crypto.log',
        date('Y-m-d H:i:s').
        " | SQL ERROR: ".$wpdb->last_error.PHP_EOL,
        FILE_APPEND
    );

    exit(json_encode(['success'=>false,'message'=>'DB insert failed']));
}

/* Update balance */
$updated = $wpdb->query(
    $wpdb->prepare(
        "UPDATE {$wallet_table}
         SET balance = balance + %f
         WHERE id=%d",
        $net_amount,
        $wallet->id
    )
);

if ($updated === false) {
    $wpdb->query('ROLLBACK');
    exit(json_encode(['success'=>false,'message'=>'Balance update failed']));
}

$wpdb->query('COMMIT');

/* Success */
exit(json_encode([
    'success'=>true,
    'credited'=>$net_amount,
    'tx_hash'=>$tx_hash
]));