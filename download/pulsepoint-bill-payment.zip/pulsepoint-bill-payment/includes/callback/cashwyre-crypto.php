<?php
/**
 * Cashwyre Crypto Deposit Webhook Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/cashwyre-crypto.php
 *
 * FIXES in this version:
 * 1. Amount is now converted from smallest-unit (what Cashwyre sends, e.g.
 *    "148500000" for 148.5 USDT) to the actual decimal amount before crediting.
 *    Previously this was credited as a raw float, which would have
 *    massively over-credited wallets.
 * 2. Confirmation check was dead code ($confirmations < 0 can never be true
 *    since it's cast with intval()). Now actually requires a minimum number
 *    of confirmations before crediting, and responds "pending" until then.
 * 3. Payload parsing is now tolerant of: raw JSON body, form-encoded
 *    "payload" field, and JSON nested under a "data" key — and logs
 *    json_last_error_msg() + Content-Type so a future "Invalid payload"
 *    can actually be diagnosed from the log file instead of guessing.
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

global $wpdb;

header('Content-Type: application/json');

/* Minimum confirmations required before we credit a deposit */
const CASHWYRE_MIN_CONFIRMATIONS = 1;

/* Decimal places per asset type — adjust to match what's actually stored
   in your crypto_wallet.assetType column */
function pulsepoint_asset_decimals($assetType, $network) {
    $assetType = strtoupper(trim($assetType));
    $network   = strtoupper(trim($network));

    $map = [
        'USDT' => 6,
        'USDC' => 6,
        'TRX'  => 6,
        'BTC'  => 8,
        'ETH'  => 18,
        'BNB'  => 18,
    ];

    return $map[$assetType] ?? 6; // default fallback
}

/* POST only */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    exit(json_encode(['success'=>false,'message'=>'POST only']));
}

/* Read payload */
$raw = file_get_contents('php://input');
$content_type = $_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? 'unknown');

/* Log incoming raw request (always, before any parsing/validation) */
file_put_contents(
    __DIR__.'/cashwyre-crypto.log',
    date('Y-m-d H:i:s')." | Content-Type: {$content_type} | RAW: ".$raw.PHP_EOL,
    FILE_APPEND
);

/* --- Robust payload parsing --- */
$data = json_decode($raw, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    // Not a raw JSON body — maybe it came in as a form field (e.g. payload=<json>)
    parse_str($raw, $form);
    if (!empty($form['payload'])) {
        $data = json_decode($form['payload'], true);
    } elseif (!empty($_POST['payload'])) {
        $data = json_decode($_POST['payload'], true);
    } elseif (!empty($_POST)) {
        $data = $_POST;
    }
}

// Some providers nest the actual transaction object under "data"
if (is_array($data) && !isset($data['hash']) && isset($data['data']) && is_array($data['data'])) {
    $data = $data['data'];
}

if (!is_array($data) || !isset($data['hash'])) {
    file_put_contents(
        __DIR__.'/cashwyre-crypto.log',
        date('Y-m-d H:i:s')." | PARSE FAILED | json_last_error: ".json_last_error_msg().PHP_EOL,
        FILE_APPEND
    );

    http_response_code(400);
    exit(json_encode(['success'=>false,'message'=>'Invalid payload']));
}

/* Extract fields */
$tx_hash       = sanitize_text_field($data['hash']);
$raw_amount    = $data['amount'] ?? 0;
$address       = sanitize_text_field($data['address'] ?? '');
$network       = strtoupper(sanitize_text_field($data['chain'] ?? 'TRON'));
$confirmations = intval($data['confirmations'] ?? 0);
$asset_type_in = strtoupper(sanitize_text_field($data['assetType'] ?? $data['token'] ?? ''));

if (!$tx_hash || !$address || floatval($raw_amount) <= 0) {
    http_response_code(400);
    exit(json_encode(['success'=>false,'message'=>'Incomplete data']));
}

/* Tables */
$base = $wpdb->prefix . 'pulsepoint_';
$wallet_table = $base . 'crypto_wallet';
$trx_table    = $base . 'crypto_transactions';

/* Find wallet */
$wallet = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$wallet_table}
         WHERE address=%s AND status='active'
         LIMIT 1",
        $address
    )
);

if (!$wallet) {
    exit(json_encode(['success'=>false,'message'=>'Wallet not found']));
}

/* Decimal-adjust the amount now that we know the wallet's asset type */
$decimals = pulsepoint_asset_decimals($asset_type_in ?: $wallet->assetType, $network);
$amount   = floatval($raw_amount) / pow(10, $decimals);

/* Duplicate check (by hash — independent of confirmation state) */
$exists = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT id FROM {$trx_table}
         WHERE tx_hash=%s LIMIT 1",
        $tx_hash
    )
);

if ($exists) {
    exit(json_encode(['success'=>true,'message'=>'Duplicate ignored']));
}

/* Require minimum confirmations before crediting */
if ($confirmations < CASHWYRE_MIN_CONFIRMATIONS) {
    exit(json_encode([
        'success' => true,
        'message' => 'Waiting confirmations',
        'confirmations' => $confirmations
    ]));
}

/* Fee calc */
$fee_amount = round(($amount * 0.1) / 100, 8);
$net_amount = round($amount - $fee_amount, 8);

/* Transaction */
$wpdb->query('START TRANSACTION');

/* Insert transaction */
$insert = $wpdb->insert(
    $trx_table,
    [
        'user_id'   => $wallet->user,
        'wallet_id' => $wallet->id,
        'tx_type'   => 'receive',
        'assetType' => $wallet->assetType,
        'network'   => $network,
        'amount'    => $net_amount,
        'fee'       => $fee_amount,
        'status'    => 'completed',
        'tx_hash'   => $tx_hash,
        'to_address'=> $address,
        'created_at'=> current_time('mysql')
    ],
    ['%d','%d','%s','%s','%s','%f','%f','%s','%s','%s','%s']
);

if (!$insert) {
    $wpdb->query('ROLLBACK');

    file_put_contents(
        __DIR__.'/cashwyre-crypto.log',
        date('Y-m-d H:i:s').
        " | SQL ERROR: ".$wpdb->last_error.PHP_EOL,
        FILE_APPEND
    );

    exit(json_encode(['success'=>false,'message'=>'DB insert failed']));
}

/* Update balance */
$updated = $wpdb->query(
    $wpdb->prepare(
        "UPDATE {$wallet_table}
         SET balance = balance + %f
         WHERE id=%d",
        $net_amount,
        $wallet->id
    )
);

if ($updated === false) {
    $wpdb->query('ROLLBACK');
    exit(json_encode(['success'=>false,'message'=>'Balance update failed']));
}

$wpdb->query('COMMIT');

/* Success */
exit(json_encode([
    'success'=>true,
    'credited'=>$net_amount,
    'tx_hash'=>$tx_hash
]));
