<?php
/**
 * XIXAPAY Webhook Callback
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/xixapay-webhook.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

/**
 * =====================================
 * BLOCK DIRECT ACCESS
 * =====================================
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header('Content-Type: application/json');

    http_response_code(403);

    echo json_encode([

        'success' => false,
        'message' => 'Access forbidden. This endpoint only accepts POST requests from XIXAPAY.'

    ], JSON_PRETTY_PRINT);

    exit;
}

header('Content-Type: application/json');

/**
 * =====================================
 * STEP 1: READ RAW PAYLOAD
 * =====================================
 */
$raw = file_get_contents('php://input');

/**
 * =====================================
 * STEP 2: GET XIXAPAY SIGNATURE
 * =====================================
 */
$signatureHeader = $_SERVER['HTTP_XIXAPAY'] ?? '';

/**
 * =====================================
 * STEP 3: SETTINGS TABLE
 * =====================================
 */
$base_prefix    = $wpdb->prefix . 'pulsepoint_';

$table_settings = "{$base_prefix}settings";
$table_accnt    = "{$base_prefix}account";
$table_users    = "{$base_prefix}users";
$table_trnx     = "{$base_prefix}trnx";
$table_referrals = "{$base_prefix}referrals";

/**
 * =====================================
 * STEP 4: GET SECRET KEY
 * =====================================
 */
$secretKey = trim($wpdb->get_var($wpdb->prepare(

    "SELECT opt_value 
     FROM {$table_settings} 
     WHERE opt_key=%s 
     LIMIT 1",

    'pay_secret'

)));

if (empty($secretKey)) {

    http_response_code(500);

    echo json_encode([

        'success' => false,
        'message' => 'XIXAPAY secret key not configured.'

    ], JSON_PRETTY_PRINT);

    exit;
}

/**
 * =====================================
 * STEP 5: VERIFY SIGNATURE
 * =====================================
 */
$calculatedSignature = hash_hmac(
    'sha256',
    $raw,
    $secretKey
);

if (!hash_equals($calculatedSignature, $signatureHeader)) {

    http_response_code(400);

    echo json_encode([

        'success' => false,
        'message' => 'Invalid signature.'

    ], JSON_PRETTY_PRINT);

    exit;
}

/**
 * =====================================
 * STEP 6: DECODE PAYLOAD
 * =====================================
 */
$data = json_decode($raw, true);

if (!$data || !is_array($data)) {

    http_response_code(400);

    echo json_encode([

        'success' => false,
        'message' => 'Invalid JSON payload.'

    ], JSON_PRETTY_PRINT);

    exit;
}

/**
 * =====================================
 * STEP 7: EXTRACT DATA
 * =====================================
 */
$notification_status = sanitize_text_field(
    $data['notification_status'] ?? ''
);

$transactionId = sanitize_text_field(
    $data['transaction_id'] ?? ''
);

$amountPaid = floatval(
    $data['amount_paid'] ?? 0
);

$settlement_amount = floatval(
    $data['settlement_amount'] ?? 0
);

$settlement_fee = floatval(
    $data['settlement_fee'] ?? 0
);

$status = sanitize_text_field(
    $data['transaction_status'] ?? ''
);

$receiverAcct = sanitize_text_field(
    $data['receiver']['account_number'] ?? ''
);

$receiverName = sanitize_text_field(
    $data['receiver']['name'] ?? ''
);

$senderName = sanitize_text_field(
    $data['sender']['name'] ?? ''
);

$senderAcct = sanitize_text_field(
    $data['sender']['account_number'] ?? ''
);

$customer_email = sanitize_email(
    $data['customer']['email'] ?? ''
);

$customer_name = sanitize_text_field(
    $data['customer']['name'] ?? ''
);

$customer_id = sanitize_text_field(
    $data['customer']['customer_id'] ?? ''
);

$description = sanitize_text_field(
    $data['description'] ?? 'Wallet funding'
);

$timestamp = sanitize_text_field(
    $data['timestamp'] ?? current_time('mysql')
);

/**
 * =====================================
 * STEP 8: VALIDATE REQUIRED DATA
 * =====================================
 */
if (
    empty($transactionId) ||
    empty($receiverAcct) ||
    $amountPaid <= 0
) {

    http_response_code(400);

    echo json_encode([

        'success' => false,
        'message' => 'Incomplete transaction data.'

    ], JSON_PRETTY_PRINT);

    exit;
}

/**
 * =====================================
 * STEP 9: LOG WEBHOOK
 * =====================================
 */
$log_file = __DIR__ . '/xixapay-webhook-log.txt';

file_put_contents(

    $log_file,

    date('Y-m-d H:i:s') .
    " | " .
    $raw .
    PHP_EOL,

    FILE_APPEND

);

/**
 * =====================================
 * STEP 10: FIND USER ACCOUNT
 * =====================================
 */
$account = $wpdb->get_row(

    $wpdb->prepare(

        "SELECT * 
         FROM {$table_accnt} 
         WHERE number=%s 
         LIMIT 1",

        $receiverAcct

    )

);

if (!$account) {

    echo json_encode([

        'success' => false,
        'message' => 'Account not found.'

    ], JSON_PRETTY_PRINT);

    exit;
}

$user_id = intval($account->user_id);

/**
 * =====================================
 * STEP 11: PREVENT DUPLICATE
 * =====================================
 */
$exists = $wpdb->get_var(

    $wpdb->prepare(

        "SELECT COUNT(*) 
         FROM {$table_trnx} 
         WHERE reference=%s",

        $transactionId

    )

);

if ($exists > 0) {

    echo json_encode([

        'success' => true,
        'message' => 'Duplicate webhook ignored.'

    ], JSON_PRETTY_PRINT);

    exit;
}

/**
 * =====================================
 * STEP 12: GET FUNDING FEE
 * =====================================
 */
$fundingFeeVal = floatval(

    $wpdb->get_var(

        $wpdb->prepare(

            "SELECT opt_value 
             FROM {$table_settings} 
             WHERE opt_key=%s 
             LIMIT 1",

            'pay_fee'

        )

    )

);

/**
 * =====================================
 * STEP 13: CALCULATE FEE
 * =====================================
 */
$fee = ($fundingFeeVal >= 30)

    ? $fundingFeeVal
    : ($fundingFeeVal / 100) * $amountPaid;

$credited_amount = max(
    $amountPaid - $fee,
    0
);

/**
 * =====================================
 * STEP 14: INSERT TRANSACTION
 * =====================================
 */
$wpdb->insert(

    $table_trnx,

    [

        'user_id'          => $user_id,
        'details'          => $description,
        'recipient'        => $receiverName,
        'amount'           => $amountPaid,
        'reference'        => $transactionId,
        'payment'          => 'wallet',
        'category'         => 'funding',
        'status'           => $status,
        'type'             => 'credit',
        'gateway_response' => maybe_serialize($data),
        'description'      => "Wallet funding ₦{$amountPaid} from {$senderName} ({$senderAcct}) via XIXAPAY. Fee: ₦{$fee}"

    ]

);

/**
 * =====================================
 * STEP 15: CREDIT USER WALLET
 * =====================================
 */
$wpdb->query(

    $wpdb->prepare(

        "UPDATE {$table_users} 
         SET wallet = wallet + %f 
         WHERE id = %d",

        $credited_amount,
        $user_id

    )

);

/**
 * =====================================
 * STEP 16: REFERRAL BONUS
 * =====================================
 */
$settings_rows = $wpdb->get_results(
    "SELECT opt_key, opt_value FROM {$table_settings}"
);

$settings = [];

foreach ($settings_rows as $row) {

    $settings[$row->opt_key] = maybe_unserialize(
        $row->opt_value
    );
}

$referral_amount = floatval(
    $settings['referral_amount'] ?? 200
);

$referrer_id = $wpdb->get_var(

    $wpdb->prepare(

        "SELECT referrer_id 
         FROM {$table_referrals} 
         WHERE referee_id=%d 
         LIMIT 1",

        $user_id

    )

);

if ($referrer_id) {

    $funding_count = $wpdb->get_var(

        $wpdb->prepare(

            "SELECT COUNT(*) 
             FROM {$table_trnx} 
             WHERE user_id=%d 
             AND category='funding' 
             AND status='success'",

            $user_id

        )

    );

    if ($funding_count >= 3) {

        $wpdb->query(

            $wpdb->prepare(

                "UPDATE {$table_referrals} 
                 SET completed=1,
                     updated_at=NOW() 
                 WHERE referee_id=%d",

                $user_id

            )

        );

        $bonus_given = $wpdb->get_var(

            $wpdb->prepare(

                "SELECT bonus_given 
                 FROM {$table_referrals} 
                 WHERE referee_id=%d",

                $user_id

            )

        );

        if (!$bonus_given) {

            $wpdb->query(

                $wpdb->prepare(

                    "UPDATE {$table_users} 
                     SET wallet=wallet+%f,
                         referral_balance=referral_balance+%f 
                     WHERE id=%d",

                    $referral_amount,
                    $referral_amount,
                    $referrer_id

                )

            );

            $wpdb->query(

                $wpdb->prepare(

                    "UPDATE {$table_referrals} 
                     SET bonus_given=1 
                     WHERE referee_id=%d",

                    $user_id

                )

            );
        }
    }
}

/**
 * =====================================
 * STEP 17: EMAILS
 * =====================================
 */
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';

$admin_email = $settings['email_number']
    ?? get_option('admin_email');

$user = $wpdb->get_row(

    $wpdb->prepare(

        "SELECT firstname, lastname, email, phone 
         FROM {$table_users} 
         WHERE id=%d",

        $user_id

    )

);

$user_ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';

$date_time = date('Y-m-d H:i:s');

$subject_admin = "New Wallet Funding on {$platform_name}";

$message_admin = "

Hello Admin,<br><br>

A new wallet funding transaction has been received.<br><br>

<strong>User:</strong>
{$user->firstname} {$user->lastname}
({$user->email})<br>

<strong>Phone:</strong>
{$user->phone}<br>

<strong>Account Number:</strong>
{$receiverAcct}<br>

<strong>Transaction Amount:</strong>
₦{$amountPaid}<br>

<strong>Fee:</strong>
₦{$fee}<br>

<strong>Amount Credited:</strong>
₦{$credited_amount}<br>

<strong>Reference:</strong>
{$transactionId}<br>

<strong>Status:</strong>
{$status}<br>

<strong>Date/Time:</strong>
{$date_time}<br>

<strong>IP:</strong>
{$user_ip}<br><br>

Regards,<br>
{$platform_name} System

";

$subject_user = "Wallet Credited on {$platform_name}";

$message_user = "

Hi {$user->firstname},<br><br>

Your wallet has been successfully credited.<br><br>

<strong>Account Number:</strong>
{$receiverAcct}<br>

<strong>Transaction Amount:</strong>
₦{$amountPaid}<br>

<strong>Fee Deducted:</strong>
₦{$fee}<br>

<strong>Amount Credited:</strong>
₦{$credited_amount}<br>

<strong>Reference:</strong>
{$transactionId}<br>

<strong>Status:</strong>
{$status}<br>

<strong>Date/Time:</strong>
{$date_time}<br><br>

Thank you for using {$platform_name}.<br><br>

Regards,<br>
{$platform_name} Team

";

$headers = [
    'Content-Type: text/html; charset=UTF-8'
];

@wp_mail(
    $admin_email,
    $subject_admin,
    $message_admin,
    $headers
);

@wp_mail(
    $user->email,
    $subject_user,
    $message_user,
    $headers
);

/**
 * =====================================
 * STEP 18: SUCCESS RESPONSE
 * =====================================
 */
echo json_encode([

    'success'   => true,
    'message'   => "Wallet credited successfully. Fee ₦{$fee} deducted.",
    'credited'  => $credited_amount,
    'fee'       => $fee,
    'reference' => $transactionId

], JSON_PRETTY_PRINT);

exit;

?>