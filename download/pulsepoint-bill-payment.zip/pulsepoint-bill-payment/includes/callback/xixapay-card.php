<?php
/**
 * XIXAPAY CARD WEBHOOK HANDLER
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/webhooks/xixapay-card.php
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

header('Content-Type: application/json');

/**
 * ======================================
 * 1. ONLY POST REQUESTS
 * ======================================
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);

    exit;
}

/**
 * ======================================
 * 2. READ RAW PAYLOAD
 * ======================================
 */
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data || !is_array($data)) {

    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON payload'
    ]);

    exit;
}

/**
 * ======================================
 * 3. SIGNATURE
 * ======================================
 */
$signatureHeader = $_SERVER['HTTP_XIXAPAY'] ?? '';

$base_prefix     = $wpdb->prefix . 'pulsepoint_';
$table_settings  = $base_prefix . 'settings';

$secretKey = trim($wpdb->get_var(
    "SELECT opt_value FROM {$table_settings} WHERE opt_key='stropay_skey' LIMIT 1"
));

if (!$secretKey) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Secret not configured']);
    exit;
}

$calculatedSignature = hash_hmac('sha256', $raw, $secretKey);

if (!hash_equals($calculatedSignature, $signatureHeader)) {

    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Invalid signature'
    ]);

    exit;
}

/**
 * ======================================
 * 4. TABLES
 * ======================================
 */
$table_cards = $base_prefix . 'virtual_cards';
$table_users  = $base_prefix . 'users';
$table_txn    = $base_prefix . 'virtualcard_transactions';

/**
 * ======================================
 * 5. EXTRACT DATA
 * ======================================
 */
$card_id        = sanitize_text_field($data['card_id'] ?? '');
$transaction_id = sanitize_text_field($data['transaction_id'] ?? '');
$status         = strtolower(sanitize_text_field($data['status'] ?? ''));
$amount         = floatval($data['amount'] ?? 0);
$currency       = sanitize_text_field($data['currency'] ?? 'USD');
$merchant       = sanitize_text_field($data['merchant_name'] ?? '');
$balance        = floatval($data['card_balance'] ?? 0);

/**
 * ======================================
 * 6. FIND CARD
 * ======================================
 */
$card = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_cards} WHERE card_id=%s LIMIT 1", $card_id)
);

if (!$card) {

    echo json_encode([
        'success' => false,
        'message' => 'Card not found'
    ]);

    exit;
}

$user = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d LIMIT 1", $card->user_id)
);

/**
 * ======================================
 * 7. EMAIL FUNCTION
 * ======================================
 */
function xixapay_send_mail($to, $subject, $message) {
    $headers = ['Content-Type: text/html; charset=UTF-8'];
    @wp_mail($to, $subject, $message, $headers);
}

/**
 * ======================================
 * 8. BAD STATUS HANDLER (AUTO DELETE)
 * ======================================
 */
$badStatuses = ['terminated','inactive','blocked','expired','deleted'];

if (in_array($status, $badStatuses)) {

    $wpdb->delete($table_cards, ['card_id' => $card_id], ['%s']);

    $wpdb->update(
        $table_users,
        ['cardid' => null],
        ['id' => $card->user_id],
        ['%s'],
        ['%d']
    );

    /**
     * EMAIL: TERMINATION ALERT
     */
    if ($user) {

        xixapay_send_mail(
            $user->email,
            "Card Removed / {$status}",
            "
                Hi {$user->firstname},<br><br>
                Your virtual card ({$card_id}) has been <b>{$status}</b> and removed from your account.<br><br>
                If you think this is a mistake, contact support.<br><br>
                Regards,<br>System Team
            "
        );
    }

    echo json_encode([
        'success' => true,
        'message' => 'Card removed due to status: ' . $status
    ]);

    exit;
}

/**
 * ======================================
 * 9. UPDATE CARD
 * ======================================
 */
$wpdb->update(
    $table_cards,
    [
        'balance'     => $balance,
        'card_status' => $status,
        'updated_at'  => current_time('mysql')
    ],
    ['card_id' => $card_id],
    ['%f','%s','%s'],
    ['%s']
);

/**
 * ======================================
 * 10. TRANSACTION INSERT
 * ======================================
 */
if (!empty($transaction_id)) {

    $exists = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM {$table_txn} WHERE transaction_id=%s LIMIT 1", $transaction_id)
    );

    if (!$exists) {

        $wpdb->insert(
            $table_txn,
            [
                'transaction_id' => $transaction_id,
                'card_id'        => $card_id,
                'amount'         => $amount,
                'type'           => $status,
                'method'         => 'card',
                'narrative'      => $merchant,
                'status'         => $status,
                'currency'       => $currency,
                'reference'      => $transaction_id,
                'created_at'     => current_time('mysql'),
                'updated_at'     => current_time('mysql')
            ],
            ['%s','%s','%f','%s','%s','%s','%s','%s','%s','%s','%s']
        );
    }
}

/**
 * ======================================
 * 11. EMAILS (ALL EVENTS)
 * ======================================
 */
if ($user) {

    // SUCCESS / DEBIT / REFUND EMAIL
    if ($status === 'debit') {

        xixapay_send_mail(
            $user->email,
            "Card Debit Alert",
            "
            Hi {$user->firstname},<br><br>
            Your card was charged:<br>
            <b>Amount:</b> {$amount} {$currency}<br>
            <b>Merchant:</b> {$merchant}<br>
            <b>Balance:</b> {$balance}<br><br>
            Regards,<br>System
            "
        );
    }

    if ($status === 'credit') {

        xixapay_send_mail(
            $user->email,
            "Card Credit Alert",
            "
            Hi {$user->firstname},<br><br>
            Your card was credited:<br>
            <b>Amount:</b> {$amount} {$currency}<br>
            <b>Balance:</b> {$balance}<br><br>
            Regards,<br>System
            "
        );
    }

    if ($status === 'refund') {

        xixapay_send_mail(
            $user->email,
            "Card Refund Alert",
            "
            Hi {$user->firstname},<br><br>
            A refund was processed:<br>
            <b>Amount:</b> {$amount}<br><br>
            Regards,<br>System
            "
        );
    }
}

/**
 * ======================================
 * 12. RESPONSE
 * ======================================
 */
echo json_encode([
    'success' => true,
    'message' => 'Webhook processed successfully',
    'data' => [
        'card_id'        => $card_id,
        'transaction_id' => $transaction_id,
        'status'         => $status,
        'balance'        => $balance
    ]
]);

exit;
?>