<?php    
/**    
 * PeplePay Telegram Bot Webhook (CLEAN FINAL VERSION - NO AUTH)    
 */    
    
// ================= CONFIG =================    
$BOT_TOKEN = "8509795491:AAHXORgqjdGXhBbsj5F-wAMEY6kxb5tfHOA";    
    
// ================= ERROR HANDLING =================    
error_reporting(E_ALL);    
ini_set('display_errors', 0);    
    
// ================= HEADERS =================    
header("Content-Type: application/json; charset=utf-8");    
    
// ================= READ UPDATE =================    
$raw = file_get_contents("php://input");    
file_put_contents("log.txt", date("Y-m-d H:i:s") . " RAW: " . $raw . "\n", FILE_APPEND);    
    
$update = json_decode($raw, true);    
    
if (!$update) {    
    echo json_encode(["ok" => true]);    
    exit;    
}    
    
// ================= MESSAGE =================    
$message = $update["message"]    
    ?? $update["edited_message"]    
    ?? $update["callback_query"]["message"]    
    ?? null;    
    
if (!$message) exit;    
    
$chat_id = $message["chat"]["id"] ?? null;    
$user_id = $message["from"]["id"] ?? null;    
$text    = trim($message["text"] ?? "");    
    
if (!$chat_id || !$user_id) exit;    
    
// ================= USER STORAGE =================    
if (!file_exists("users")) {    
    mkdir("users", 0777, true);    
}    
    
$user_file = "users/$user_id.json";    
    
if (file_exists($user_file)) {    
    $user = json_decode(file_get_contents($user_file), true);    
} else {    
    $user = [    
        "user_id" => $user_id,    
        "step" => "home",    
        "balance" => 0,    
        "network" => "",    
        "phone" => "",    
        "amount" => 0,    
        "created_at" => date("Y-m-d H:i:s")    
    ];    
}    
    
// ================= SAVE =================    
function saveUser($file, $data) {    
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));    
}    
    
// ================= SEND MESSAGE =================    
function sendMessage($chat_id, $text, $keyboard = null) {    
    
    $BOT_TOKEN = "8509795491:AAHXORgqjdGXhBbsj5F-wAMEY6kxb5tfHOA";    
    $url = "https://api.telegram.org/bot$BOT_TOKEN/sendMessage";    
    
    $data = [    
        "chat_id" => $chat_id,    
        "text" => $text,    
        "parse_mode" => "HTML"    
    ];    
    
    if ($keyboard) {    
        $data["reply_markup"] = json_encode($keyboard);    
    }    
    
    $ch = curl_init();    
    curl_setopt($ch, CURLOPT_URL, $url);    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    
    curl_setopt($ch, CURLOPT_POST, true);    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);    
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);    
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);    
    
    $res = curl_exec($ch);    
    
    if (curl_errno($ch)) {    
        file_put_contents("log.txt", "CURL ERROR: " . curl_error($ch) . "\n", FILE_APPEND);    
    }    
    
    file_put_contents("log.txt", "TG RESPONSE: " . $res . "\n", FILE_APPEND);    
    
    curl_close($ch);    
}    
    
// ================= MENU (OPAY STYLE) =================    
$menu = [    
    "keyboard" => [    
        ["Fund Wallet", "Buy Airtime"],    
        ["Buy Data", "Send Money"],    
        ["Customer Support"]    
    ],    
    "resize_keyboard" => true    
];    
    
// ================= START =================    
if ($text == "/start") {    
    
    $user["step"] = "home";    
    saveUser($user_file, $user);    
    
    sendMessage($chat_id,    
        "👋 Hey 👋 What's up?",    
        $menu    
    );    
    
    exit;    
}    
    
// ================= BALANCE =================    
if ($text == "📊 Balance") {    
    
    sendMessage($chat_id,    
        "💰 Your Balance: ₦" . number_format($user["balance"], 2)    
    );    
    
    exit;    
}    
    
// ================= FUND WALLET =================    
if ($text == "Fund Wallet") {    
    
    include "Bot/fund.php";    
    exit;    
}    
    
// ================= AIRTIME =================    
if ($user["step"] === "airtime_select_network") {

    $map = [
        "1" => "MTN",
        "2" => "Airtel",
        "3" => "Glo",
        "4" => "9mobile",
        "mtn" => "MTN",
        "airtel" => "Airtel",
        "glo" => "Glo",
        "9mobile" => "9mobile"
    ];

    $key = strtolower(trim($text));

    if (!isset($map[$key])) {
        sendMessage($chat_id,
            "❌ Invalid network.\n\nReply:\n1 - MTN\n2 - Airtel\n3 - Glo\n4 - 9mobile"
        );
        exit;
    }

    $user["network"] = $map[$key];
    $user["step"] = "airtime_enter_phone";

    saveUser($user_file, $user);

    sendMessage($chat_id, "📲 Enter phone number:");
    exit;
}
    
// ================= DATA =================    
if ($text == "Buy Data") {    
    
    include "Bot/data.php";    
    exit;    
}    
    
// ================= BANK TRANSFER =================    
if ($text == "Send Money") {    
    
    include "Bot/bank.php";    
    exit;    
}    
    
// ================= SUPPORT =================    
if ($text == "Customer Support") {    
    
    include "Bot/support.php";    
    exit;    
}    
    
// ================= DEFAULT =================    
sendMessage($chat_id, "⚠️ Use /start to begin.");    
    