<?php
/**
 * StroWallet Webhook Callback (USDT Funding → Dollar Wallet + Fee)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/callback/strowallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

// === 1. BLOCK NON-POST ACCESS ===
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access forbidden. POST only.'], JSON_PRETTY_PRINT);
    exit;
}

header('Content-Type: application/json');

// === 2. READ PAYLOAD ===
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

// === 3. LOG RAW DATA ===
$log_file = __DIR__ . '/strowallet-webhook-log.txt';
file_put_contents($log_file, date('Y-m-d H:i:s') . " | " . $raw . PHP_EOL, FILE_APPEND);

// === 4. VALIDATE PAYLOAD ===
if (!$data || !isset($data['address']) || !isset($data['amount']) || !isset($data['reference'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid StroWallet payload.'], JSON_PRETTY_PRINT);
    exit;
}

// === 5. EXTRACT VALUES ===
$reference   = sanitize_text_field($data['reference']);
$address     = sanitize_text_field($data['address']);
$amount      = floatval($data['amount']);
$type        = sanitize_text_field($data['type'] ?? '');
$chain       = sanitize_text_field($data['chain'] ?? '');
$hash        = sanitize_text_field($data['hash'] ?? '');
$description = sanitize_text_field($data['description'] ?? 'USDT received');
$status      = 'success';

if ($amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid amount.'], JSON_PRETTY_PRINT);
    exit;
}

// === 6. DEFINE TABLES ===
$base_prefix   = $wpdb->prefix . 'pulsepoint_';
$table_wallets = "{$base_prefix}wallets";
$table_users   = "{$base_prefix}users";
$table_trnx    = "{$base_prefix}trnx";
$table_settings = "{$base_prefix}settings";

// === 7. FIND WALLET OWNER ===
$wallet = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_wallets} WHERE address = %s LIMIT 1", $address));
if (!$wallet) {
    echo json_encode(['success' => false, 'message' => 'Wallet address not found.'], JSON_PRETTY_PRINT);
    exit;
}
$user_id = intval($wallet->user_id);

// === 8. PREVENT DUPLICATE REFERENCE ===
$exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_trnx} WHERE reference = %s", $reference));
if ($exists > 0) {
    echo json_encode(['success' => true, 'message' => 'Duplicate webhook ignored.'], JSON_PRETTY_PRINT);
    exit;
}

// === 9. USDT RATE (Default 1:1) ===
$usdt_rate = 1.00; // Can pull from settings later

// === 10. CONVERT TO DOLLAR ===
$dollar_amount = $amount * $usdt_rate;

// === 11. GET FUNDING FEE % ===
$funding_fee_val = $wpdb->get_var($wpdb->prepare(
    "SELECT opt_value FROM {$table_settings} WHERE opt_key = %s LIMIT 1",
    'cryto_fee'
));
$funding_fee_val = floatval($funding_fee_val); // e.g., 1 = 1%

// === 12. CALCULATE FEE ===
$fee = 0;
if ($funding_fee_val > 0) {
    $fee = ($funding_fee_val / 100) * $dollar_amount;
}
$credited_amount = max($dollar_amount - $fee, 0);

// === 13. INSERT TRANSACTION ===
$wpdb->insert($table_trnx, [
    'user_id'          => $user_id,
    'details'          => 'USDT Deposit (' . strtoupper($chain) . ')',
    'recipient'        => $address,
    'amount'           => $dollar_amount,
    'reference'        => $reference,
    'payment'          => 'crypto',
    'category'         => 'funding',
    'status'           => $status,
    'type'             => 'credit',
    'gateway_response' => maybe_serialize($data),
    'description'      => "USDT Deposit via — {$dollar_amount} USD credited. fee: {$fee}"
]);

// === 14. UPDATE USERS TABLE ===
$wpdb->query($wpdb->prepare(
    "UPDATE {$table_users} SET dollar = dollar + %f WHERE id = %d",
    $credited_amount, $user_id
));

$wpdb->query($wpdb->prepare(
    "UPDATE {$table_wallets} SET balance = balance + %f WHERE id = %d",
    $amount, $wallet->id
));

// === 15. EMAIL NOTIFICATIONS ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$admin_email   = $settings['email_number'] ?? get_option('admin_email');

$user = $wpdb->get_row($wpdb->prepare("SELECT firstname, lastname, email, phone FROM {$table_users} WHERE id = %d", $user_id));
$user_ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$date_time = date('Y-m-d H:i:s');

// --- Admin Notification ---
$subject_admin = "New USDT Deposit on {$platform_name}";
$message_admin = "
Hello Admin,<br><br>
A new USDT deposit has been received.<br><br>
<strong>User:</strong> {$user->firstname} {$user->lastname} ({$user->email})<br>
<strong>Phone:</strong> {$user->phone}<br>
<strong>Wallet Address:</strong> {$address}<br>
<strong>Amount (USDT):</strong> {$amount}<br>
<strong>Amount (USD):</strong> {$dollar_amount}<br>
<strong>Fee:</strong> {$fee}<br>
<strong>Amount Credited (USD after fee):</strong> {$credited_amount}<br>
<strong>Reference:</strong> {$reference}<br>
<strong>Status:</strong> {$status}<br>
<strong>Date/Time:</strong> {$date_time}<br>
<strong>IP:</strong> {$user_ip}<br><br>
Regards,<br>
{$platform_name} System
";

// --- User Notification ---
$subject_user = "USDT Deposit Credited on {$platform_name}";
$message_user = "
Hi {$user->firstname},<br><br>
Your USDT deposit has been successfully credited.<br><br>
<strong>Wallet Address:</strong> {$address}<br>
<strong>Amount (USDT):</strong> {$amount}<br>
<strong>Fee Deducted (USD):</strong> {$fee}<br>
<strong>Amount Credited (USD):</strong> {$credited_amount}<br>
<strong>Reference:</strong> {$reference}<br>
<strong>Status:</strong> {$status}<br>
<strong>Date/Time:</strong> {$date_time}<br><br>
Thank you for using {$platform_name}.<br><br>
Regards,<br>
{$platform_name} Team
";

$headers = ['Content-Type: text/html; charset=UTF-8'];
@wp_mail($admin_email, $subject_admin, $message_admin, $headers);
@wp_mail($user->email, $subject_user, $message_user, $headers);

// === 16. SEND SUCCESS RESPONSE ===
echo json_encode([
    'success'       => true,
    'message'       => "USDT deposit credited: \${$credited_amount} to user #{$user_id}. Fee: \${$fee}",
    'user_id'       => $user_id,
    'address'       => $address,
    'reference'     => $reference,
    'usd_value'     => $credited_amount,
    'fee_deducted'  => $fee
], JSON_PRETTY_PRINT);

exit;
?>