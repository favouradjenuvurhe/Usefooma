<?php
/** Legacy compatibility shim. Admin routes are now owned by UseFooma\Controllers\AdminController. */
if (!defined('ABSPATH')) exit;
if (class_exists('UseFooma\\Controllers\\AdminController')) {
    \UseFooma\Controllers\AdminController::register();
}
