<?php
/**
 * Pulsepoint Admin Menu (Dynamic + Fixed Menu Structure with Role-Based Access + Add-on Support)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/admin-menu.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Register the Pulsepoint Admin Menu
 */
add_action('admin_menu', 'pulsepoint_register_admin_menu');

function pulsepoint_register_admin_menu() {
    $plugin_path = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/includes/panel/';
    $icon_url    = plugins_url('../assets/conn/logo.png', __FILE__);

    add_action('admin_head', function() {
        echo '<style>
            #adminmenu .toplevel_page_pulsepoint-dashboard .wp-menu-image img {
                width: 65px !important;
                height: 65px !important;
                object-fit: contain;
                filter: brightness(1.15) saturate(1.3) drop-shadow(0 0 1px rgba(0,0,0,0.5));
                margin-top: 0 !important;
                opacity: 1 !important;
            }
            #adminmenu .toplevel_page_pulsepoint-dashboard .wp-menu-image {
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
            }
            #adminmenu .toplevel_page_pulsepoint-dashboard:hover .wp-menu-image img {
                filter: brightness(1.3) saturate(1.4) drop-shadow(0 0 2px rgba(0,0,0,0.6)) !important;
            }
        </style>';
    });

    // === Main Menu ===
    add_menu_page(
        'Pulsepoint Dashboard',
        'Usefooma',
        'manage_options',
        'pulsepoint-dashboard',
        'pulsepoint_load_admin_page',
        $icon_url,
        26
    );

    // === Fixed pages (Support removed) ===
    $pages = [
        'dashboard'      => 'Dashboard',
        'configuration'  => 'Configuration',
        'transactions'   => 'Transactions',
        'revenue'       => 'Revenue', // ✅ added
        'users'          => 'Users',
        'settings'       => 'Settings',
        'developer'      => 'Developer'
    ];

    // === Roles ===
    $current_user = wp_get_current_user();
    $roles = (array) $current_user->roles;
    $is_admin  = in_array('administrator', $roles);
    $is_editor = in_array('editor', $roles);

    // === Fixed menu pages ===
    foreach ($pages as $slug => $title) {
        if (!$is_admin) {
            if ($is_editor) {
                if (!in_array($slug, ['dashboard','transactions','users'])) continue;
            } else {
                continue;
            }
        }

        add_submenu_page(
            'pulsepoint-dashboard',
            $title,
            $title,
            'manage_options',
            'pulsepoint-' . $slug,
            'pulsepoint_load_admin_page'
        );
    }

    // === Auto-register dynamic panel pages (hidden loader) ===
    if (is_dir($plugin_path)) {
        foreach (scandir($plugin_path) as $file) {
            if (substr($file, -4) === '.php') {
                $slug = basename($file, '.php');
                if (array_key_exists($slug, $pages)) continue;

                add_submenu_page(
                    null,
                    ucwords(str_replace(['-', '_'], ' ', $slug)),
                    '',
                    'manage_options',
                    'pulsepoint-' . $slug,
                    'pulsepoint_load_admin_page'
                );
            }
        }
    }

    /**
     * ADD-ON DEVELOPER HOOK (UNCHANGED & WORKING)
     */
    do_action('pulsepoint_addon_menu', $is_admin, $is_editor);
}

/**
 * Universal Loader for Admin Pages
 */
function pulsepoint_load_admin_page() {
    $current_user = wp_get_current_user();
    $roles = (array) $current_user->roles;
    $is_admin  = in_array('administrator', $roles);
    $is_editor = in_array('editor', $roles);

    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : 'pulsepoint-dashboard';
    $slug = str_replace('pulsepoint-', '', $page);

    if (!$is_admin) {
        if ($is_editor) {
            if (!in_array($slug, ['dashboard','transactions','users'])) {
                echo '<div class="wrap"><h1>Access Denied</h1></div>';
                return;
            }
        } else {
            echo '<div class="wrap"><h1>Access Denied</h1></div>';
            return;
        }
    }

    $file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/includes/panel/' . $slug . '.php';

    if (file_exists($file)) {
        include $file;
    } else {
        echo '<div class="wrap"><h1>Page Not Found</h1></div>';
    }
}