<?php
/**
 * Pulsepoint Change Password API (Token Based)
 * Path: /api/change-password.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// ================================
// ALLOW ONLY POST
// ================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// ================================
// AUTHORIZATION HEADER
// ================================
$headers = getallheaders();

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

$auth_header = trim($headers['Authorization']);

if (!preg_match('/Token\s+(\S+)/', $auth_header, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// ================================
// VALIDATE USER
// ================================
$table = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare("SELECT id FROM {$table} WHERE token = %s LIMIT 1", $token)
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
    exit;
}

// ================================
// GET JSON INPUT
// ================================
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON body'
    ]);
    exit;
}

// ================================
// VALIDATE FIELDS
// ================================
$previous_password = sanitize_text_field($input['previous_password'] ?? '');
$new_password      = sanitize_text_field($input['new_password'] ?? '');
$confirm_password  = sanitize_text_field($input['confirm_password'] ?? '');

if (empty($previous_password) || empty($new_password) || empty($confirm_password)) {
    echo json_encode([
        'success' => false,
        'message' => 'All fields are required'
    ]);
    exit;
}

// ================================
// PASS TO WORDPRESS HANDLER
// ================================
$_SERVER['REQUEST_METHOD'] = 'POST';

$_POST['previous_password'] = $previous_password;
$_POST['new_password']      = $new_password;
$_POST['confirm_password']  = $confirm_password;

// Inject user ID into session manually (IMPORTANT FIX)
if (!session_id()) {
    session_start();
}

$_SESSION['pulsepoint_user']['id'] = $user->id;

// ================================
// LOAD HANDLER
// ================================
$handler = PULSEPOINT_DIR . 'core/change-password.php';

if (!file_exists($handler)) {
    echo json_encode([
        'success' => false,
        'message' => 'Change password handler not found'
    ]);
    exit;
}

require_once $handler;

// ================================
// CALL FUNCTION
// ================================
if (function_exists('pulsepoint_change_password')) {
    pulsepoint_change_password();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Function pulsepoint_change_password() not found'
    ]);
}

exit;