<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH.'wp-load.php';
require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';
global $wpdb; header('Content-Type: application/json; charset=utf-8');
$headers=function_exists('getallheaders')?getallheaders():[];$auth=$headers['Authorization']??($headers['authorization']??($_SERVER['HTTP_AUTHORIZATION']??''));if(!preg_match('/Token\s+(\S+)/i',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]);$users=$wpdb->prefix.'pulsepoint_users';$user=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$users} WHERE token=%s LIMIT 1",$token));if(!$user||(int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}
$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$tx} WHERE user_id=%d AND transaction_type='purchase' ORDER BY id DESC LIMIT 100",$user->id));
$data=[];foreach($rows as $r){$m=json_decode($r->note,true);if(!is_array($m))$m=[];$data[]=['id'=>(int)$r->id,'reference'=>$r->reference,'status'=>$r->status,'product_id'=>(int)($m['product_id']??0),'product_name'=>$m['product_name']??'Giftcard','amount'=>(float)$r->amount,'wallet_charge'=>(float)$r->selling_price,'currency'=>$m['recipient_currency']??'','sender_currency'=>$m['sender_currency']??'','redeem'=>$r->delivered_code,'pinCode'=>$r->delivered_pin,'redeemId'=>$m['redeem_id']??'','created_at'=>$r->created_at];}
echo wp_json_encode(['success'=>true,'data'=>$data]);exit;
