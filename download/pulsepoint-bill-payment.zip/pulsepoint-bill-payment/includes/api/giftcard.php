<?php
/**
 * Pulsepoint Giftcard API Endpoint
 * Path: /api/giftcard.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// ================================
// ALLOW ONLY POST
// ================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// ================================
// AUTHORIZATION HEADER
// ================================
$headers = getallheaders();

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

$auth_header = trim($headers['Authorization']);

if (!preg_match('/Token\s+(\S+)/', $auth_header, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// ================================
// VALIDATE USER TOKEN
// ================================
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$table_users} WHERE token = %s",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
    exit;
}

// ================================
// CREATE SESSION
// ================================
if (!session_id()) {
    session_start();
}

$_SESSION['pulsepoint_user']['id'] = $user->id;

// ================================
// VALIDATE INPUTS
// ================================
$giftcard_id = intval($_POST['giftcard_id'] ?? 0);
$amount      = floatval($_POST['amount'] ?? 0);
$type        = sanitize_text_field($_POST['type'] ?? 'digital');
$digital_code = sanitize_text_field($_POST['digital_code'] ?? '');
$note        = sanitize_textarea_field($_POST['note'] ?? '');

if ($giftcard_id <= 0 || $amount <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'giftcard_id and amount are required'
    ]);
    exit;
}

// ================================
// LOAD GIFTCARD HANDLER
// ================================
$handler = PULSEPOINT_DIR . 'core/giftcard/pulsepoint.php';

if (!file_exists($handler)) {
    echo json_encode([
        'success' => false,
        'message' => 'Giftcard handler not found'
    ]);
    exit;
}

require_once $handler;

// ================================
// PASS DATA TO EXISTING HANDLER
// ================================
$_POST['giftcard_id'] = $giftcard_id;
$_POST['amount']      = $amount;
$_POST['type']        = $type;
$_POST['digital_code'] = $digital_code;
$_POST['note']        = $note;

// Physical image upload
if (isset($_FILES['physical_image'])) {
    $_FILES['physical_image'] = $_FILES['physical_image'];
}

// ================================
// CALL EXISTING FUNCTION
// ================================
if (function_exists('pulsepoint_sell_giftcard')) {

    pulsepoint_sell_giftcard();

} else {

    echo json_encode([
        'success' => false,
        'message' => 'Function pulsepoint_sell_giftcard() not found'
    ]);

}

exit;