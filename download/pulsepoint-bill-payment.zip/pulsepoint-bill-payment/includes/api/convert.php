<?php
/**
 * Pulsepoint Airtime-to-Cash Trade Submission API Endpoint
 * Path: /api/convert.php
 * Author: Amaaavl
 *
 * Unlike cable/education/betting, this submission includes a file (proof
 * of the airtime transfer screenshot), so the request is multipart/form-data
 * instead of JSON — $_POST and $_FILES already arrive in the shape
 * pulsepoint_airtime_to_cash_trade() expects, so this adapter only needs
 * to resolve the token into a simulated session before handing off.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

if (empty($_POST['network']) || empty($_POST['sender_number']) || empty($_POST['amount'])) {
    echo json_encode(['success' => false, 'message' => 'network, sender_number & amount required']);
    exit;
}

$handler = PULSEPOINT_DIR . 'core/airtime/a2c/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Airtime-to-cash handler not found']);
    exit;
}
require_once $handler;

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

if (function_exists('pulsepoint_airtime_to_cash_trade')) {
    pulsepoint_airtime_to_cash_trade(); // outputs JSON, reads $_POST / $_FILES directly
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_airtime_to_cash_trade() not found']);
}
