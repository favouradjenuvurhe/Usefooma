<?php
/**
 * Customer Offline Data configuration API.
 * GET  /api/offline-data?network=MTN
 * POST /api/offline-data
 */
if (!defined('ABSPATH')) exit;

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    if (function_exists('pulsepoint_start_session')) pulsepoint_start_session();
    elseif (function_exists('session_start')) session_start();
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['pulsepoint_user']['id'])) {
    status_header(401);
    echo wp_json_encode(['success'=>false,'message'=>'Please log in.']);
    exit;
}

$user_id = (int) $_SESSION['pulsepoint_user']['id'];
global $wpdb;
$users = $wpdb->prefix . 'pulsepoint_users';
$data = $wpdb->prefix . 'pulsepoint_data';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE id=%d AND status=1 LIMIT 1", $user_id));
if (!$user) {
    status_header(401);
    echo wp_json_encode(['success'=>false,'message'=>'Customer account not found.']);
    exit;
}

if (empty($_SESSION['usefooma_offline_data_nonce'])) {
    $_SESSION['usefooma_offline_data_nonce'] = bin2hex(random_bytes(24));
}

$settings = [];
$settings_table = $wpdb->prefix . 'pulsepoint_settings';
foreach ((array) $wpdb->get_results("SELECT opt_key,opt_value FROM {$settings_table}") as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$enabled = ($settings['africas_talking_enabled'] ?? '0') === '1';
$daily_limit = (float) ($settings['africas_talking_daily_limit'] ?? 0);
$fee_enabled = ($settings['offline_data_fee_enabled'] ?? '0') === '1';
$fee_type = ($settings['offline_data_fee_type'] ?? 'flat') === 'percent' ? 'percent' : 'flat';
$offline_fee = max(0, (float) ($settings['offline_data_fee'] ?? 0));

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $network = strtoupper(sanitize_text_field(wp_unslash($_GET['network'] ?? '')));
    $plans = [];
    if ($network !== '') {
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id,network,type,details,amount FROM {$data} WHERE status='active' AND network=%s ORDER BY type,amount ASC",
            $network
        ));
        foreach ((array) $rows as $plan) {
            $plans[] = [
                'id'=>(int)$plan->id,
                'network'=>(string)$plan->network,
                'type'=>(string)$plan->type,
                'details'=>(string)$plan->details,
                'amount'=>(float)$plan->amount,
            ];
        }
    }
    echo wp_json_encode([
        'success'=>true,
        'enabled'=>$enabled,
        'daily_limit'=>$daily_limit,
        'service_charge'=>[
            'enabled'=>$fee_enabled,
            'type'=>$fee_type,
            'value'=>$offline_fee,
        ],
        'offline_data_number'=>(string)($settings['africas_talking_number'] ?? ''),
        'provider'=>'africas_talking',
        'nonce'=>$_SESSION['usefooma_offline_data_nonce'],
        'config'=>[
            'enabled'=>(int)$user->offline_data_enabled === 1,
            'phone'=>(string)($user->offline_data_phone ?? ''),
            'network'=>strtoupper((string)($user->offline_data_network ?? '')),
            'plan_id'=>(int)($user->offline_data_plan_id ?? 0),
        ],
        'plans'=>$plans,
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    status_header(405);
    echo wp_json_encode(['success'=>false,'message'=>'Invalid request method.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;

$nonce = sanitize_text_field((string)($input['nonce'] ?? ''));
if (empty($_SESSION['usefooma_offline_data_nonce']) || !hash_equals($_SESSION['usefooma_offline_data_nonce'], $nonce)) {
    status_header(403);
    echo wp_json_encode(['success'=>false,'message'=>'Security check failed. Refresh and try again.']);
    exit;
}

$enabled_request = !empty($input['enabled']);
$phone = preg_replace('/\D+/', '', sanitize_text_field((string)($input['phone'] ?? '')));
if (str_starts_with($phone, '234') && strlen($phone) === 13) $phone = '0' . substr($phone,3);
if (strlen($phone) === 10) $phone = '0' . $phone;
$network = strtoupper(sanitize_text_field((string)($input['network'] ?? '')));
$plan_id = (int)($input['plan_id'] ?? 0);

// Configuration and activation are separate states. Turning the service OFF
// must not erase the customer's saved receiving number/network/plan; otherwise
// the UI loses its selections and the next plan-sheet/toggle action has no
// network or plan in state. Validate any supplied configuration even while
// disabled, then persist it for the next activation.
if ($phone !== '' && !preg_match('/^0\d{10}$/', $phone)) {
    echo wp_json_encode(['success'=>false,'message'=>'Enter a valid Nigerian receiving phone number.']);
    exit;
}

if ($network !== '') {
    $allowed = ['MTN','GLO','AIRTEL','9MOBILE','ETISALAT'];
    if (!in_array($network, $allowed, true)) {
        echo wp_json_encode(['success'=>false,'message'=>'Select a valid network.']);
        exit;
    }
}

if ($plan_id > 0) {
    if ($network === '') {
        echo wp_json_encode(['success'=>false,'message'=>'Select a network before choosing a data bundle.']);
        exit;
    }
    $plan = $wpdb->get_row($wpdb->prepare(
        "SELECT id,network FROM {$data} WHERE id=%d AND network=%s AND status='active' LIMIT 1",
        $plan_id, $network
    ));
    if (!$plan) {
        echo wp_json_encode(['success'=>false,'message'=>'Select an active data bundle.']);
        exit;
    }
}

if ($enabled_request && ($phone === '' || $network === '' || $plan_id <= 0)) {
    echo wp_json_encode(['success'=>false,'message'=>'Complete your receiving number, network and data plan first.']);
    exit;
}

$updated = $wpdb->update($users, [
    'offline_data_enabled'=>$enabled_request ? 1 : 0,
    'offline_data_phone'=>$phone !== '' ? $phone : null,
    'offline_data_network'=>$network !== '' ? $network : null,
    'offline_data_plan_id'=>$plan_id > 0 ? $plan_id : null,
    'offline_data_updated_at'=>current_time('mysql'),
], ['id'=>$user_id]);

if ($updated === false) {
    echo wp_json_encode(['success'=>false,'message'=>'Unable to save Offline Data settings.']);
    exit;
}

echo wp_json_encode([
    'success'=>true,
    'message'=>$enabled_request ? 'Offline Data activated.' : 'Offline Data disabled.',
    'config'=>[
        'enabled'=>$enabled_request,
        'phone'=>$phone,
        'network'=>$network,
        'plan_id'=>$plan_id,
    ],
]);
exit;
