<?php
/**
 * Pulsepoint Data Plan API Endpoint
 * Path: /api/dataplan.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// ================================
// AUTHORIZATION
// ================================
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

$auth = trim($headers['Authorization']);
if (!preg_match('/Token\s+(\S+)/', $auth, $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

// ================================
// VALIDATE USER TOKEN
// ================================
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row(
    $wpdb->prepare("SELECT id, status FROM {$table_users} WHERE token = %s", $token)
);

if (!$user || (int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or inactive token'
    ]);
    exit;
}

// ================================
// INPUT FILTERS (OPTIONAL)
// ================================
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$network  = sanitize_text_field($input['network'] ?? '');
$type     = sanitize_text_field($input['type'] ?? '');

// ================================
// FETCH DATA PLANS
// ================================
$table_data = $wpdb->prefix . 'pulsepoint_data';

$where  = [];
$params = [];

if (!empty($network)) {
    $where[]  = "network = %s";
    $params[] = $network;
}

if (!empty($type)) {
    $where[]  = "type = %s";
    $params[] = $type;
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$query = "SELECT * FROM {$table_data} {$where_sql} ORDER BY network, amount ASC";

$plans = $params
    ? $wpdb->get_results($wpdb->prepare($query, ...$params))
    : $wpdb->get_results($query);

if (!$plans) {
    echo json_encode([
        'success' => false,
        'message' => 'No data plans found'
    ]);
    exit;
}

// ================================
// GROUP PLANS BY NETWORK & TYPE
// ================================
$result = [];

foreach ($plans as $plan) {
    $net  = $plan->network ?? 'Unknown';
    $typ  = $plan->type ?? 'Default';

    $result[$net][$typ][] = [
        'id'        => (int)$plan->id,
        'plan'      => $plan->plan,
        'details'   => $plan->details,
        'amount'    => (float)$plan->amount,
        'cashback'  => (float)$plan->cashback,
        'apiamount' => (float)$plan->apiamount,
        'provider'  => $plan->provider
    ];
}

// ================================
// RESPONSE
// ================================
echo json_encode([
    'success' => true,
    'message' => 'Data plans fetched successfully',
    'data'    => $result
]);
exit;