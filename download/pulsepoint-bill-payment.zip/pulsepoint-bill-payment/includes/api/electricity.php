<?php
/**
 * Pulsepoint Electricity API Endpoint
 * Path: /api/electricity.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

/** ----------------------------------
 *  AUTHORIZATION (TOKEN)
 * ---------------------------------- */
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token)
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

/** ----------------------------------
 *  READ JSON BODY
 * ---------------------------------- */
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

/** ----------------------------------
 *  SANITIZE INPUTS
 * ---------------------------------- */
$disco        = sanitize_text_field($input['disco'] ?? '');
$meter_type   = sanitize_text_field($input['meter_type'] ?? '');
$meter_number = sanitize_text_field($input['meter_number'] ?? '');
$amount       = floatval($input['amount'] ?? 0);
$bypass       = isset($input['bypass']) ? (bool)$input['bypass'] : false;
$reference    = sanitize_text_field($input['reference'] ?? '');

if (
    empty($disco) ||
    empty($meter_type) ||
    empty($meter_number) ||
    $amount <= 0
) {
    echo json_encode([
        'success' => false,
        'message' => 'disco, meter_type, meter_number & amount are required'
    ]);
    exit;
}

/** ----------------------------------
 *  LOAD ELECTRICITY HANDLER
 * ---------------------------------- */
$handler = PULSEPOINT_DIR . 'core/electricity/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Electricity handler not found']);
    exit;
}
require_once $handler;

/** ----------------------------------
 *  SIMULATE USER SESSION
 * ---------------------------------- */
if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

/** ----------------------------------
 *  MAP API → HANDLER INPUT
 * ---------------------------------- */
$_POST['disco']        = $disco;
$_POST['meter_type']   = $meter_type;
$_POST['meter_number'] = $meter_number;
$_POST['amount']       = $amount;
$_POST['bypass']       = $bypass;
$_POST['request_id']   = $reference;

/** ----------------------------------
 *  EXECUTE ELECTRICITY PURCHASE
 * ---------------------------------- */
if (function_exists('pulsepoint_electricity_purchase')) {
    pulsepoint_electricity_purchase(); // outputs JSON directly
} else {
    echo json_encode([
        'success' => false,
        'message' => 'pulsepoint_electricity_purchase() not found'
    ]);
}
exit;