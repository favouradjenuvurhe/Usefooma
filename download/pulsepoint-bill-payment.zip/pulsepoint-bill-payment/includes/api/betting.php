<?php
/**
 * Pulsepoint Betting Purchase API Endpoint
 * Path: /api/betting.php
 * Author: Amaaavl
 *
 * Thin token-auth adapter, same pattern as /api/cable.php and
 * /api/education.php — hands off to pulsepoint_betting_purchase().
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

$biller_id   = intval($input['biller'] ?? 0);
$customer_id = sanitize_text_field($input['customer_id'] ?? '');
$amount      = floatval($input['amount'] ?? 0);
$reference   = sanitize_text_field($input['reference'] ?? '');

if (!$biller_id || !$customer_id || $amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'biller, customer_id & amount required']);
    exit;
}

$handler = PULSEPOINT_DIR . 'core/betting/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Betting handler not found']);
    exit;
}
require_once $handler;

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

$_POST['biller']      = $biller_id;
$_POST['customer_id'] = $customer_id;
$_POST['amount']      = $amount;
$_POST['reference']   = $reference;

if (function_exists('pulsepoint_betting_purchase')) {
    pulsepoint_betting_purchase(); // outputs JSON
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_betting_purchase() not found']);
}
