<?php
/**
 * Pulsepoint API Support Channel Details
 * Path: /api/channel.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json; charset=utf-8');

// Allow only GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Support contact details
$phone_number = '09064873505';
$email        = 'favour-amaaavl@outlook.com';

// Build WhatsApp link — needs international format (Nigeria: 0 -> 234), no symbols
$whatsapp_number = '234' . ltrim($phone_number, '0');
$whatsapp_url    = 'https://wa.me/' . $whatsapp_number;

echo json_encode([
    'success' => true,
    'message' => 'Support channel details fetched successfully',
    'channel' => [
        'email'        => $email,
        'phone_number' => $phone_number,
        'whatsapp_url' => $whatsapp_url
    ]
]);
exit;
