<?php
/**
 * Pulsepoint API Support Channel Details
 * Path: /api/channel.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json; charset=utf-8');

global $wpdb;

// Allow only GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// =========================
// TABLE DEFINITIONS
// =========================
$base_prefix    = $wpdb->prefix . 'pulsepoint_';
$settings_table = $base_prefix . 'settings';

// =========================
// FETCH LIVE SUPPORT DETAILS
// =========================
$phone_number = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
        'phone_number'
    )
);

$email = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
        'email_number'
    )
);

if (empty($phone_number) || empty($email)) {
    echo json_encode([
        'success' => false,
        'message' => 'Support channel details are not configured'
    ]);
    exit;
}

$phone_number = trim($phone_number);
$email        = trim($email);

// Build WhatsApp link — needs international format (Nigeria: 0 -> 234), no symbols
$whatsapp_number = '234' . ltrim($phone_number, '0');
$whatsapp_url    = 'https://wa.me/' . $whatsapp_number;

echo json_encode([
    'success' => true,
    'message' => 'Support channel details fetched successfully',
    'channel' => [
        'email'        => $email,
        'phone_number' => $phone_number,
        'whatsapp_url' => $whatsapp_url
    ]
]);
exit;
