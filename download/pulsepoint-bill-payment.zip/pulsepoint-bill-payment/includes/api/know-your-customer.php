<?php
/**
 * Pulsepoint Know Your Customer (KYC) API Endpoint
 * Path: /api/know-your-customer.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// -------------------------
// Allow only GET or POST
// -------------------------
if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'POST'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// -------------------------
// Authorization
// -------------------------
$headers = function_exists('getallheaders') ? getallheaders() : [];

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

$auth = trim($headers['Authorization']);

if (!preg_match('/Token\s+(\S+)/', $auth, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// -------------------------
// Validate Token
// -------------------------
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$table_users} WHERE token=%s",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
    exit;
}

// -------------------------
// Load Settings
// -------------------------
$table_settings = $wpdb->prefix . 'pulsepoint_settings';

$settings_rows = $wpdb->get_results("
    SELECT opt_key,opt_value
    FROM {$table_settings}
");

$settings = [];

foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$provider = strtolower($settings['virtualcard_type'] ?? 'strowallet');

// -------------------------
// GET USER KYC DETAILS
// -------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    echo json_encode([
        'success' => true,
        'message' => 'KYC details fetched successfully',
        'data' => [
            'customerId' => $user->customerId,
            'statusKyc'  => (int) $user->statuskyc,
            'provider'   => $provider
        ]
    ]);

    exit;
}

// -------------------------
// Load KYC Handler
// -------------------------
$handler = PULSEPOINT_DIR . 'core/customer/pulsepoint.php';

if (!file_exists($handler)) {
    echo json_encode([
        'success' => false,
        'message' => 'Customer KYC handler not found'
    ]);
    exit;
}

require_once $handler;

// -------------------------
// Login Session
// -------------------------
if (!session_id()) {
    session_start();
}

$_SESSION['pulsepoint_user']['id'] = $user->id;

// -------------------------
// Pass Request
// -------------------------
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';

if (strpos($contentType, 'application/json') !== false) {

    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid JSON body'
        ]);
        exit;
    }

    foreach ($input as $key => $value) {
        $_POST[$key] = $value;
    }

} else {

    foreach ($_POST as $key => $value) {
        $_POST[$key] = $value;
    }

    foreach ($_FILES as $key => $value) {
        $_FILES[$key] = $value;
    }

}

// -------------------------
// Execute KYC
// -------------------------
if (function_exists('pulsepoint_customer_kyc')) {

    pulsepoint_customer_kyc();

} else {

    echo json_encode([
        'success' => false,
        'message' => 'Function pulsepoint_customer_kyc() not found'
    ]);

}

exit;