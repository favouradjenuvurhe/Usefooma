<?php
/**
 * Pulsepoint Cable API Endpoint
 * Path: /api/cable.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

/** ---------------------------
 *  AUTHORIZATION
 * --------------------------- */
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token)
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

/** ---------------------------
 *  INPUT VALIDATION
 * --------------------------- */
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

$plan_id   = intval($input['plan'] ?? 0);
$smartcard = sanitize_text_field($input['smartcard'] ?? '');
$details   = sanitize_text_field($input['details'] ?? '');
$amount    = floatval($input['amount'] ?? 0);
$reference = sanitize_text_field($input['reference'] ?? '');

if (!$plan_id || !$smartcard || $amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'plan, smartcard & amount required']);
    exit;
}

/** ---------------------------
 *  LOAD CABLE HANDLER
 * --------------------------- */
$handler = PULSEPOINT_DIR . 'core/cable/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Cable handler not found']);
    exit;
}
require_once $handler;

/** ---------------------------
 *  SIMULATE LOGIN SESSION
 * --------------------------- */
if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

/** ---------------------------
 *  MAP API INPUT → HANDLER INPUT
 * --------------------------- */
$_POST['plan']      = $plan_id;
$_POST['smartcard'] = $smartcard;
$_POST['details']   = $details;
$_POST['amount']    = $amount;
$_POST['reference'] = $reference;

/** ---------------------------
 *  EXECUTE PURCHASE
 * --------------------------- */
if (function_exists('pulsepoint_cable_purchase')) {
    pulsepoint_cable_purchase(); // outputs JSON
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_cable_purchase() not found']);
}
exit;