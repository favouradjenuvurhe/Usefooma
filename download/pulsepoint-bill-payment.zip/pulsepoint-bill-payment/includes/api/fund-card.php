<?php
/**
 * Pulsepoint Virtual Card Funding API
 * Path: /api/fund-card.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$base_prefix    = $wpdb->prefix . 'pulsepoint_';
$users_table    = $base_prefix . 'users';
$settings_table = $base_prefix . 'settings';

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
*/

$headers = function_exists('getallheaders') ? getallheaders() : [];

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header.'
    ]);
    exit;
}

$authorization = trim($headers['Authorization']);

if (!preg_match('/Token\s+(\S+)/', $authorization, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format.'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$users_table} WHERE token=%s LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token.'
    ]);
    exit;
}

if ((int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Account inactive.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| GET - Funding Configuration
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $provider = $wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='virtualcard_type'
        LIMIT 1"
    );

    $flat_fee = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='card_funding_flat_fee'
        LIMIT 1"
    );

    if (!$flat_fee) {
        $flat_fee = 1.90;
    }

    $percent_fee = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='card_funding_percent_fee'
        LIMIT 1"
    );

    if (!$percent_fee) {
        $percent_fee = 1.90;
    }

    $rate = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='rate_usd'
        LIMIT 1"
    );

    echo json_encode([

        'success' => true,

        'message' => 'Virtual card funding configuration fetched successfully.',

        'data' => [

            'provider' => $provider,
            'flat_fee' => $flat_fee,
            'percent_fee' => $percent_fee,
            'rate_usd' => $rate,
            'wallet_balance' => (float)$user->wallet,
            'currency' => 'NGN',
            'card_id' => $user->cardid

        ]

    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| POST ONLY
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);

    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $input = $_POST;
}

/*
|--------------------------------------------------------------------------
| Resolve card_id from the user's account (no longer accepted as input)
|--------------------------------------------------------------------------
*/

$card_id = sanitize_text_field($user->cardid ?? '');
$amount  = floatval($input['amount'] ?? 0);

if (empty($card_id)) {

    echo json_encode([
        'success' => false,
        'message' => 'No virtual card is linked to this account.'
    ]);

    exit;
}

if ($amount <= 0) {

    echo json_encode([
        'success' => false,
        'message' => 'Invalid amount.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Fund Virtual Card
|--------------------------------------------------------------------------
*/

// Start session
if (!session_id()) {
    session_start();
}

// Simulate logged-in user for the main funding handler
$_SESSION['pulsepoint_user']['id'] = (int) $user->id;

// Pass request values to the existing handler
$_POST['card_id'] = $card_id;
$_POST['amount']  = $amount;

// Main funding handler
$handler = PULSEPOINT_DIR . 'core/virtualcard/fund.php';

if (!file_exists($handler)) {

    echo json_encode([
        'success' => false,
        'message' => 'Virtual card funding handler not found.'
    ]);

    exit;
}

require_once $handler;

// Ensure the function exists
if (!function_exists('pulsepoint_fund_card')) {

    echo json_encode([
        'success' => false,
        'message' => 'Function pulsepoint_fund_card() not found.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Execute
|--------------------------------------------------------------------------
|
| The handler will:
| - Validate card ID and amount
| - Get the active provider
| - Calculate funding fees
| - Convert USD to NGN
| - Deduct the user's wallet balance
| - Call the provider funding API
| - Save the funding transaction
| - Return the JSON response via wp_send_json()
|
*/

pulsepoint_fund_card();

exit;
