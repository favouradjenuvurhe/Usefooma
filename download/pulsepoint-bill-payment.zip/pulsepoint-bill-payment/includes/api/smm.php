<?php
/**
 * Pulsepoint SMM (Boost) Purchase API Endpoint
 * Path: /api/smm.php
 * Author: Amaaavl
 *
 * Thin token-auth adapter, same pattern as /api/betting.php etc — hands
 * off to pulsepoint_smm_purchase().
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

$service_id = intval($input['service_id'] ?? 0);
$link       = sanitize_text_field($input['link'] ?? '');
$quantity   = intval($input['quantity'] ?? 0);
$reference  = sanitize_text_field($input['reference'] ?? '');

if (!$service_id || !$link || $quantity <= 0) {
    echo json_encode(['success' => false, 'message' => 'service_id, link & quantity required']);
    exit;
}

$handler = PULSEPOINT_DIR . 'core/smm/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'SMM handler not found']);
    exit;
}
require_once $handler;

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

$_POST['service_id'] = $service_id;
$_POST['link']       = $link;
$_POST['quantity']   = $quantity;
$_POST['reference']  = $reference;

if (function_exists('pulsepoint_smm_purchase')) {
    pulsepoint_smm_purchase(); // outputs JSON
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_smm_purchase() not found']);
}
