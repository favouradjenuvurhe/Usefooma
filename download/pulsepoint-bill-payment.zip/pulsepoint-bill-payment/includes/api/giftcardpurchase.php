<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']); exit; }
$headers=function_exists('getallheaders')?getallheaders():[]; $auth=$headers['Authorization']??($headers['authorization']??($_SERVER['HTTP_AUTHORIZATION']??''));
if(!preg_match('/Token\s+(\S+)/i',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]); $users=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT id,wallet,passcode,status,email,firstname,lastname FROM {$users} WHERE token=%s LIMIT 1",$token));
if(!$user||(int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}

$pin=sanitize_text_field($_POST['passcode']??'');
if(!preg_match('/^\d{4}$/',$pin)||empty($user->passcode)||!hash_equals((string)$user->passcode,$pin)){echo wp_json_encode(['success'=>false,'message'=>'Incorrect transaction PIN']);exit;}

$mode=get_option('pulsepoint_giftcard_purchase_mode','manual');
if($mode!=='api'){
    // Keep the existing manual inventory flow intact.
    $stock_id=absint($_POST['stock_id']??0); if(!$stock_id){echo wp_json_encode(['success'=>false,'message'=>'Stock item is required']);exit;}
    $stock=$wpdb->prefix.'pulsepoint_giftcard_stock';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';
    $wpdb->query('START TRANSACTION');
    try{
        $item=$wpdb->get_row($wpdb->prepare("SELECT s.*,g.category,g.sub_category FROM {$stock} s INNER JOIN {$settings} g ON g.id=s.giftcard_id WHERE s.id=%d AND s.status='available' AND g.status='active' FOR UPDATE",$stock_id));
        if(!$item)throw new Exception('This giftcard is no longer available.');
        if(!empty($item->expires_at)&&strtotime($item->expires_at)!==false&&strtotime($item->expires_at)<current_time('timestamp')){$wpdb->update($stock,['status'=>'expired'],['id'=>$stock_id]);throw new Exception('This giftcard has expired.');}
        $price=(float)$item->sale_price;$balance=(float)$user->wallet;if($balance<$price)throw new Exception('Insufficient wallet balance.');
        $ref='PGB'.strtoupper(wp_generate_password(12,false,false));$new=$balance-$price;
        $ok=$wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=%f WHERE id=%d AND wallet >= %f",$new,$user->id,$price));if($ok!==1)throw new Exception('Unable to debit wallet.');
        $wpdb->update($stock,['status'=>'sold','sold_to'=>$user->id,'sold_at'=>current_time('mysql')],['id'=>$stock_id],['%s','%d','%s'],['%d']);
        $ok=$wpdb->insert($tx,['listing_id'=>null,'user_id'=>$user->id,'amount'=>$item->face_value,'selling_price'=>$price,'fee'=>0,'status'=>'completed','payment_method'=>'wallet','reference'=>$ref,'note'=>'Giftcard purchase: '.$item->category.' '.$item->sub_category,'transaction_type'=>'purchase','inventory_id'=>$stock_id,'delivered_code'=>$item->digital_code,'delivered_pin'=>$item->digital_pin],['%d','%d','%f','%f','%f','%s','%s','%s','%s','%d','%s','%s']);
        if(!$ok)throw new Exception('Failed to record purchase.');
        $wpdb->query('COMMIT');
        echo wp_json_encode(['success'=>true,'message'=>'Giftcard purchased successfully.','data'=>['reference'=>$ref,'category'=>$item->category,'sub_category'=>$item->sub_category,'face_value'=>(float)$item->face_value,'sale_price'=>$price,'code'=>$item->digital_code,'pin'=>$item->digital_pin,'new_balance'=>$new,'status'=>'completed']]);exit;
    }catch(Throwable $e){$wpdb->query('ROLLBACK');echo wp_json_encode(['success'=>false,'message'=>$e->getMessage()]);exit;}
}

$product_id=absint($_POST['product_id']??0);
$amount=(float)($_POST['amount']??$_POST['local_amount']??0);
$recipient=sanitize_email($_POST['recipient_email']??($_POST['email']??''));
if(!$recipient)$recipient=sanitize_email($user->email??'');
$sender=sanitize_text_field($_POST['sender']??trim(($user->firstname??'').' '.($user->lastname??'')));
if(!$product_id||$amount<=0){echo wp_json_encode(['success'=>false,'message'=>'product_id and amount are required']);exit;}
if(!$recipient){echo wp_json_encode(['success'=>false,'message'=>'A valid recipient email is required']);exit;}
if($sender==='')$sender='UseFooma Customer';

// Always validate the product and price against the live provider catalog before debiting.
$product=usefooma_topupmate_find_product($product_id);
if(!$product){echo wp_json_encode(['success'=>false,'message'=>'Giftcard product is no longer available.']);exit;}
$normalized=usefooma_topupmate_normalize_product($product);
$fixed=$normalized['fixed_denominations'];
$valid=false;
foreach($fixed as $d){if(abs((float)$d-$amount)<0.00001){$valid=true;break;}}
if(!$valid && strtoupper($normalized['denomination_type'])!=='FIXED'){
    $min=$normalized['min_amount'];$max=$normalized['max_amount'];
    $valid=($min===null||$amount>=(float)$min)&&($max===null||$amount<=(float)$max);
}
if(!$valid){echo wp_json_encode(['success'=>false,'message'=>'Invalid giftcard denomination for this product.']);exit;}

$sender_amount=usefooma_topupmate_sender_amount($product,$amount);
$charge=usefooma_topupmate_wallet_charge($product,$amount);
if($sender_amount<=0||$charge<=0){echo wp_json_encode(['success'=>false,'message'=>'Unable to calculate giftcard wallet charge. Check the NGN/USD rate in Giftcard settings.']);exit;}
$balance=(float)$user->wallet;
if($balance<$charge){echo wp_json_encode(['success'=>false,'message'=>'Insufficient wallet balance.','required'=>$charge,'wallet'=>$balance]);exit;}

$ref='GC_'.strtoupper(wp_generate_password(16,false,false));
$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';
$note_meta=[
    'source'=>'topupmate','product_id'=>$product_id,'product_name'=>$normalized['name'],'brand'=>$normalized['brand'],
    'country_iso'=>$normalized['country_iso'],'recipient_currency'=>$normalized['currency'],'sender_currency'=>$normalized['sender_currency'],
    'recipient_amount'=>$amount,'sender_amount'=>$sender_amount,'wallet_charge'=>$charge,'recipient_email'=>$recipient,
    'sender'=>$sender,'provider_ref'=>$ref,'status'=>'pending'
];

// Debit first with a guarded SQL condition, then call the provider outside the DB transaction.
$debited=$wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet-%f WHERE id=%d AND wallet >= %f",$charge,$user->id,$charge));
if($debited!==1){echo wp_json_encode(['success'=>false,'message'=>'Wallet balance changed. Please try again.']);exit;}
$new_balance=round($balance-$charge,2);
$inserted=$wpdb->insert($tx,[
    'listing_id'=>null,'user_id'=>$user->id,'amount'=>$amount,'selling_price'=>$charge,'fee'=>0,
    'status'=>'pending','payment_method'=>'wallet','reference'=>$ref,'note'=>wp_json_encode($note_meta),
    'transaction_type'=>'purchase'
],['%d','%d','%f','%f','%f','%s','%s','%s','%s','%s']);
$txid=(int)$wpdb->insert_id;
if(!$inserted||!$txid){
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Failed to create giftcard transaction. Your wallet was not charged.']);exit;
}

// Also create the platform-wide transaction record so the purchase appears in
// normal transaction history and profitability analytics.
$trnx=$wpdb->prefix.'pulsepoint_trnx';
$provider_cost=round($sender_amount*max(0,(float)get_option('pulsepoint_giftcard_api_fx_rate',1)),2);
$profit=round($charge-$provider_cost,2);
$main_insert=$wpdb->insert($trnx,[
    'user_id'=>$user->id,
    'details'=>wp_json_encode(['product_id'=>$product_id,'product_name'=>$normalized['name'],'brand'=>$normalized['brand'],'country_iso'=>$normalized['country_iso'],'recipient_amount'=>$amount,'sender_amount'=>$sender_amount,'provider_cost'=>$provider_cost]),
    'value'=>(string)$amount,'recipient'=>$recipient,'amount'=>$charge,'profit_amount'=>$profit,'reference'=>$ref,'payment'=>'wallet','category'=>'others','status'=>'pending','type'=>'debit','session'=>session_id(),'description'=>'Giftcard purchase - '.$normalized['name']
],['%d','%s','%s','%s','%f','%f','%s','%s','%s','%s','%s','%s']);
$main_trnx_id=(int)$wpdb->insert_id;
if(!$main_insert||!$main_trnx_id){
    $wpdb->update($tx,['status'=>'failed','note'=>wp_json_encode(array_merge($note_meta,['status'=>'failed','message'=>'Platform transaction record could not be created.']))],['id'=>$txid]);
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Failed to initialize the wallet transaction. Your wallet was not charged.']);exit;
}
$note_meta['main_trnx_id']=$main_trnx_id;
$wpdb->update($tx,['note'=>wp_json_encode($note_meta)],['id'=>$txid],['%s'],['%d']);

$provider=usefooma_topupmate_purchase($product_id,$amount,$recipient,$sender,$ref);
if(!$provider['ok']){
    $note_meta['status']='failed';$note_meta['provider_message']=$provider['message'];$note_meta['provider_http_code']=$provider['code'];
    $wpdb->update($tx,['status'=>'failed','note'=>wp_json_encode($note_meta)],['id'=>$txid],['%s','%s'],['%d']);
    if($main_trnx_id)$wpdb->update($trnx,['status'=>'failed','gateway_response'=>$provider['message']],['id'=>$main_trnx_id],['%s','%s'],['%d']);
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Giftcard provider rejected the purchase. Your wallet has been refunded.','provider_message'=>$provider['message']]);exit;
}

$redeem=usefooma_topupmate_extract_redeem($provider['data']);
$provider_status=$redeem['status']!==''?$redeem['status']:'successful';
if(in_array($provider_status,['failed','failure','declined','rejected','cancelled','canceled'],true)){
    $note_meta['status']='failed';$note_meta['provider_response']=$redeem['raw'];
    $wpdb->update($tx,['status'=>'failed','note'=>wp_json_encode($note_meta)],['id'=>$txid],['%s','%s'],['%d']);
    if($main_trnx_id)$wpdb->update($trnx,['status'=>'failed','gateway_response'=>wp_json_encode($redeem['raw'])],['id'=>$main_trnx_id],['%s','%s'],['%d']);
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Topupmate did not complete the giftcard order. Your wallet has been refunded.','provider_status'=>$provider_status]);exit;
}
$completed=($redeem['redeem']!==''||$redeem['card_number']!==''||$redeem['pin_code']!=='');
$note_meta['status']=$completed?'successful':$provider_status;
$note_meta['redeem_id']=$redeem['redeem_id'];$note_meta['provider_response']=$redeem['raw'];
$note_meta['redeem_instructions']=$redeem['redeem_details'];
$updates=['status'=>$completed?'completed':'pending','note'=>wp_json_encode($note_meta)];
if($redeem['redeem']!=='')$updates['delivered_code']=sanitize_textarea_field($redeem['redeem']);
if($redeem['pin_code']!=='')$updates['delivered_pin']=sanitize_text_field($redeem['pin_code']);
$wpdb->update($tx,$updates,['id'=>$txid],['%s','%s'],['%d']);
if($main_trnx_id){
    $wpdb->update($trnx,['status'=>$completed?'success':'pending','gateway_response'=>wp_json_encode($redeem['raw'])],['id'=>$main_trnx_id],['%s','%s'],['%d']);
}

$data=[
    'reference'=>$ref,'transaction_id'=>$txid,'product_id'=>$product_id,'product_name'=>$normalized['name'],'brand'=>$normalized['brand'],
    'country_iso'=>$normalized['country_iso'],'amount'=>$amount,'recipient_amount'=>$amount,'sender_amount'=>$sender_amount,
    'currency'=>$normalized['currency'],'sender_currency'=>$normalized['sender_currency'],'wallet_charge'=>$charge,'new_balance'=>$new_balance,
    'status'=>$completed?'completed':'pending','redeemId'=>$redeem['redeem_id'],'redeem'=>$redeem['redeem'],'redeem_details'=>$redeem['redeem_details'],
    'cardNumber'=>$redeem['card_number'],'pinCode'=>$redeem['pin_code']
];
echo wp_json_encode(['success'=>true,'message'=>$completed?'Giftcard purchased successfully.':'Giftcard order submitted. Your code will appear when Topupmate releases it.','data'=>$data]);exit;
