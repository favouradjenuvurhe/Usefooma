<?php
/**
 * UseFooma API Fetch User Details
 * Supports JSON/form POST and Authorization: Token <token>.
 */
if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}
global $wpdb;
header('Content-Type: application/json; charset=utf-8');

if (!in_array(strtoupper($_SERVER['REQUEST_METHOD'] ?? ''), ['GET', 'POST'], true)) {
    echo wp_json_encode(['success' => false, 'message' => 'Invalid request method']); exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = $_POST;
if (!is_array($input)) $input = [];
if (empty($input['token']) && isset($_GET['token'])) $input['token'] = $_GET['token'];
$headers = function_exists('getallheaders') ? getallheaders() : [];
$auth = $headers['Authorization'] ?? ($headers['authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? ''));
$token = sanitize_text_field($input['token'] ?? '');
if ($token === '' && preg_match('/^Token\s+(.+)$/i', trim((string) $auth), $m)) $token = sanitize_text_field($m[1]);
if ($token === '') { echo wp_json_encode(['success'=>false,'message'=>'Token is required']); exit; }

$table = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id, firstname, lastname, phone, email, wallet, promo_bonus_pending, dollar, referral_balance, token, account_type, status FROM `{$table}` WHERE token=%s LIMIT 1",
    $token
));
if (!$user) { echo wp_json_encode(['success'=>false,'message'=>'Invalid or expired token']); exit; }
if ((int)$user->status !== 1) { echo wp_json_encode(['success'=>false,'message'=>'Account inactive']); exit; }

$wallet_balance = (float) $user->wallet;
$promo_bonus_pending = (float) ($user->promo_bonus_pending ?? 0);
$total_wallet = round($wallet_balance + $promo_bonus_pending, 2);

// wallet is intentionally numeric so Android/Web clients can render it reliably.
echo wp_json_encode([
    'success' => true,
    'message' => 'User fetched successfully',
    'user' => [
        'id' => (int) $user->id,
        'firstname' => (string) $user->firstname,
        'lastname' => (string) $user->lastname,
        'email' => (string) $user->email,
        'phone' => (string) $user->phone,
        'wallet' => $total_wallet,
        'wallet_balance' => round($wallet_balance, 2),
        'promo_bonus_pending' => round($promo_bonus_pending, 2),
        'wallet_formatted' => '₦' . number_format($total_wallet, 2, '.', ','),
        'dollar' => '$' . number_format((float)$user->dollar, 2, '.', ','),
        'referral_balance' => '₦' . number_format((float)$user->referral_balance, 2, '.', ','),
        'token' => (string) $user->token,
        'account_type' => (string) $user->account_type,
        'status' => (int) $user->status,
    ]
]);
exit;
