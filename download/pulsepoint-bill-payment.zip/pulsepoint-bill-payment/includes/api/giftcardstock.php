<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']); exit; }
$headers=function_exists('getallheaders')?getallheaders():[]; $auth=$headers['Authorization']??($headers['authorization']??($_SERVER['HTTP_AUTHORIZATION']??''));
if(!preg_match('/Token\s+(\S+)/i',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]); $users=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$users} WHERE token=%s LIMIT 1",$token));
if(!$user || (int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}

$mode=get_option('pulsepoint_giftcard_purchase_mode','manual');
if($mode==='api'){
    $country=strtoupper(sanitize_text_field($_POST['country']??''));
    $search=sanitize_text_field($_POST['search']??'');
    $product_id=absint($_POST['product_id']??0);
    $query=[];
    if($country!=='')$query['countryCode']=$country;
    if($search!=='')$query['productName']=$search;
    if($product_id)$query['productId']=$product_id;
    $res=usefooma_topupmate_catalog($query);
    if(!$res['ok']){echo wp_json_encode(['success'=>false,'message'=>$res['message'],'provider_http_code'=>$res['code']]);exit;}
    echo wp_json_encode(['success'=>true,'mode'=>'api','provider'=>'topupmate','data'=>$res['data']]);exit;
}

$stock=$wpdb->prefix.'pulsepoint_giftcard_stock';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';
$rows=$wpdb->get_results("SELECT s.id,s.giftcard_id,s.face_value,s.sale_price,s.type,s.status,s.expires_at,g.category,g.sub_category,g.image_url,g.rate FROM {$stock} s INNER JOIN {$settings} g ON g.id=s.giftcard_id WHERE s.status='available' AND g.status='active' ORDER BY g.category,g.sub_category,s.face_value,s.id DESC");
$data=[];foreach($rows as $r){$data[]=['id'=>(int)$r->id,'giftcard_id'=>(int)$r->giftcard_id,'category'=>$r->category,'sub_category'=>$r->sub_category,'face_value'=>(float)$r->face_value,'sale_price'=>(float)$r->sale_price,'type'=>$r->type,'image_url'=>$r->image_url,'rate'=>(float)$r->rate,'expires_at'=>$r->expires_at];}
echo wp_json_encode(['success'=>true,'mode'=>'manual','data'=>$data]);exit;
