<?php
/**
 * Pulsepoint Giftcard Transaction History API
 * Path: /api/giftcardhistory.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// =====================================
// ALLOW ONLY POST
// =====================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// =====================================
// AUTHORIZATION
// =====================================
$headers = getallheaders();

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

$auth = trim($headers['Authorization']);

if (!preg_match('/Token\s+(\S+)/', $auth, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// =====================================
// VALIDATE USER
// =====================================
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status FROM {$table_users} WHERE token = %s",
        $token
    )
);

if (!$user || (int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or inactive token'
    ]);
    exit;
}

// =====================================
// OPTIONAL FILTERS
// =====================================
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $input = $_POST;
}

$status = sanitize_text_field($input['status'] ?? '');
$limit  = intval($input['limit'] ?? 50);

// =====================================
// TABLES
// =====================================
$table_transactions = $wpdb->prefix . 'pulsepoint_giftcard_transactions';
$table_listings     = $wpdb->prefix . 'pulsepoint_giftcard_listings';
$table_settings     = $wpdb->prefix . 'pulsepoint_giftcard_settings';

// =====================================
// QUERY
// =====================================
$where = ["t.user_id = %d"];
$params = [$user->id];

if (!empty($status)) {
    $where[] = "t.status = %s";
    $params[] = $status;
}

$where_sql = implode(' AND ', $where);

$query = "
SELECT
    t.*,
    g.category,
    g.sub_category,
    l.type
FROM {$table_transactions} t
LEFT JOIN {$table_listings} l
    ON t.listing_id = l.id
LEFT JOIN {$table_settings} g
    ON l.giftcard_id = g.id
WHERE {$where_sql}
ORDER BY t.id DESC
LIMIT {$limit}
";

$transactions = $wpdb->get_results(
    $wpdb->prepare($query, ...$params)
);

if (!$transactions) {
    echo json_encode([
        'success' => false,
        'message' => 'No giftcard transactions found'
    ]);
    exit;
}

// =====================================
// RESPONSE DATA
// =====================================
$data = [];

foreach ($transactions as $tx) {

    $data[] = [
        'id'             => (int)$tx->id,
        'listing_id'     => (int)$tx->listing_id,
        'reference'      => $tx->reference,
        'category'       => $tx->category,
        'sub_category'   => $tx->sub_category,
        'type'           => $tx->type,
        'amount'         => (float)$tx->amount,
        'selling_price'  => (float)$tx->selling_price,
        'fee'            => (float)$tx->fee,
        'payment_method' => $tx->payment_method,
        'status'         => $tx->status,
        'note'           => $tx->note,
        'created_at'     => $tx->created_at
    ];
}

// =====================================
// RESPONSE
// =====================================
echo json_encode([
    'success' => true,
    'message' => 'Giftcard transactions fetched successfully',
    'data'    => $data
]);

exit;