<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']);exit;}
$headers=function_exists('getallheaders')?getallheaders():[];$auth=$headers['Authorization']??($headers['authorization']??'');
if(!preg_match('/Token\s+(\S+)/',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]);$users=$wpdb->prefix.'pulsepoint_users';$user=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$users} WHERE token=%s",$token));
if(!$user||(int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}
$body=json_decode(file_get_contents('php://input'),true); if(!is_array($body)) $body=[];
$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';$list=$wpdb->prefix.'pulsepoint_giftcard_listings';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';$limit=min(100,max(1,absint($body['limit']??($_POST['limit']??50))));
$rows=$wpdb->get_results($wpdb->prepare("SELECT t.*,g.category,g.sub_category,l.type AS listing_type FROM {$tx} t LEFT JOIN {$list} l ON t.listing_id=l.id LEFT JOIN {$settings} g ON (g.id=l.giftcard_id OR (t.inventory_id IS NOT NULL AND g.id=(SELECT giftcard_id FROM {$wpdb->prefix}pulsepoint_giftcard_stock s WHERE s.id=t.inventory_id LIMIT 1))) WHERE t.user_id=%d ORDER BY t.id DESC LIMIT %d",$user->id,$limit));
$data=[];foreach($rows as $r){$meta=json_decode($r->note,true);if(!is_array($meta))$meta=[];$is_api=in_array(($meta['source']??''),['kripicard','topupmate'],true);$data[]=['id'=>(int)$r->id,'reference'=>$r->reference,'category'=>$is_api?($meta['brand']??$meta['product_name']??$meta['service_name']??'Giftcard'):($r->category??'Giftcard'),'sub_category'=>$is_api?($meta['product_name']??$meta['country_iso']??''):($r->sub_category??''),'type'=>$r->transaction_type??'sale','amount'=>(float)$r->amount,'selling_price'=>(float)$r->selling_price,'fee'=>(float)$r->fee,'payment_method'=>$r->payment_method,'status'=>$r->status,'note'=>$r->note,'code'=>($r->transaction_type==='purchase'?$r->delivered_code:null),'pin'=>($r->transaction_type==='purchase'?$r->delivered_pin:null),'giftcard_request_id'=>$meta['giftcard_request_id']??null,'order_ref'=>$meta['order_ref']??($meta['provider_ref']??null),'provider_status'=>$meta['status']??null,'redeem_id'=>$meta['redeem_id']??null,'redeem_instructions'=>$meta['redeem_instructions']??'','card_number'=>$r->delivered_code,'pin_code'=>$r->delivered_pin,'created_at'=>$r->created_at];}
echo wp_json_encode(['success'=>true,'data'=>$data]);exit;
