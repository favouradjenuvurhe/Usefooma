<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH.'wp-load.php';
require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';
global $wpdb; header('Content-Type: application/json; charset=utf-8');
$headers=function_exists('getallheaders')?getallheaders():[];$auth=$headers['Authorization']??($headers['authorization']??($_SERVER['HTTP_AUTHORIZATION']??''));if(!preg_match('/Token\s+(\S+)/i',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]);$users=$wpdb->prefix.'pulsepoint_users';$user=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$users} WHERE token=%s LIMIT 1",$token));if(!$user||(int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}
$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';$txid=absint($_POST['transaction_id']??0);$ref=sanitize_text_field($_POST['reference']??'');
$where=$txid?"id=%d":"reference=%s";$arg=$txid?:$ref;if(!$arg){echo wp_json_encode(['success'=>false,'message'=>'Transaction reference is required.']);exit;}
$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$tx} WHERE user_id=%d AND transaction_type='purchase' AND {$where} LIMIT 1",$user->id,$arg));if(!$row){echo wp_json_encode(['success'=>false,'message'=>'Giftcard order not found']);exit;}
$meta=json_decode($row->note,true);if(!is_array($meta))$meta=[];
if(($meta['source']??'')!=='topupmate'){echo wp_json_encode(['success'=>true,'data'=>['reference'=>$row->reference,'transaction_id'=>(int)$row->id,'status'=>$row->status,'code'=>$row->delivered_code,'pin'=>$row->delivered_pin]]);exit;}
$res=usefooma_topupmate_redeem($row->reference);if(!$res['ok']){echo wp_json_encode(['success'=>false,'message'=>$res['message'],'provider_http_code'=>$res['code']]);exit;}
$d=usefooma_topupmate_extract_redeem($res['data']);$has=($d['redeem']!==''||$d['card_number']!==''||$d['pin_code']!=='');
$updates=['note'=>wp_json_encode(array_merge($meta,['status'=>$d['status']?:$meta['status']??$row->status,'redeem_id'=>$d['redeem_id'],'redeem_instructions'=>$d['redeem_details'],'redeem_response'=>$d['raw']]))];
if($has)$updates['status']='completed';if($d['redeem']!=='')$updates['delivered_code']=sanitize_textarea_field($d['redeem']);if($d['pin_code']!=='')$updates['delivered_pin']=sanitize_text_field($d['pin_code']);$wpdb->update($tx,$updates,['id'=>$row->id]);
echo wp_json_encode(['success'=>true,'data'=>['reference'=>$row->reference,'transaction_id'=>(int)$row->id,'status'=>$has?'completed':$row->status,'code'=>$d['redeem']?:$row->delivered_code,'pin'=>$d['pin_code']?:$row->delivered_pin,'redeem'=>$d['redeem'],'redeem_details'=>$d['redeem_details'],'cardNumber'=>$d['card_number'],'pinCode'=>$d['pin_code'],'redeemId'=>$d['redeem_id']]]);exit;
