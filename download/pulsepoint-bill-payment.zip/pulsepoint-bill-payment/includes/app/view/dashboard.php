<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/../index.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- =====================================================
         Theme engine (light / dark / system)
         Runs first, before anything paints, so there is never a
         flash of the wrong theme. It reads the saved choice from
         localStorage ("pp-theme": "light" | "dark" | "system"),
         falls back to the device/OS preference when the choice is
         "system" (or nothing has been chosen yet), and stamps the
         result on <html data-theme="..."> which the CSS below and
         every page/component in this app reacts to.
         Exposes window.PPTheme = { get, resolved, set } so any
         page (e.g. pages/profile.html) can build a theme switcher
         without needing to know any of these details.
         ===================================================== -->
    <meta name="color-scheme" content="light dark">
    <script>
    (function () {

        var STORAGE_KEY = 'pp-theme';
        var mql = window.matchMedia('(prefers-color-scheme: dark)');

        function systemTheme() {
            return mql.matches ? 'dark' : 'light';
        }

        function getMode() {
            try {
                return localStorage.getItem(STORAGE_KEY) || 'system';
            } catch (e) {
                return 'system';
            }
        }

        function resolveTheme(mode) {
            mode = mode || getMode();
            return mode === 'system' ? systemTheme() : mode;
        }

        function applyTheme(mode) {

            mode = mode || getMode();

            var resolved = resolveTheme(mode);

            document.documentElement.setAttribute('data-theme', resolved);
            document.documentElement.setAttribute('data-theme-mode', mode);

            var meta = document.querySelector('meta[name="theme-color"]');

            if (meta) {

                if (!meta.dataset.ppLightColor) {
                    meta.dataset.ppLightColor = meta.getAttribute('content') || '#ffffff';
                }

                meta.setAttribute('content', resolved === 'dark' ? '#0B1220' : meta.dataset.ppLightColor);

            }

            document.dispatchEvent(new CustomEvent('pp-theme-change', {
                detail: { mode: mode, resolved: resolved }
            }));

        }

        function setMode(mode) {

            try {

                if (mode === 'system') {
                    localStorage.removeItem(STORAGE_KEY);
                } else {
                    localStorage.setItem(STORAGE_KEY, mode);
                }

            } catch (e) {}

            applyTheme(mode);

        }

        // Apply immediately (before first paint) to avoid any flash.
        applyTheme(getMode());

        // If the user hasn't overridden it, follow OS-level changes live.
        if (mql.addEventListener) {
            mql.addEventListener('change', function () {
                if (getMode() === 'system') applyTheme('system');
            });
        } else if (mql.addListener) {
            mql.addListener(function () {
                if (getMode() === 'system') applyTheme('system');
            });
        }

        window.PPTheme = {
            get: getMode,
            resolved: function () { return resolveTheme(getMode()); },
            set: setMode
        };

    })();
    </script>

    <!-- SEO -->   
    <meta name="theme-color" content="<?php echo esc_attr($color_hex); ?>">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/favicon.png">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <script>
tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: "<?php echo esc_js($color_hex); ?>",
                secondary: "#111827",
                success: "#16A34A",
                warning: "#F59E0B",
                danger: "#DC2626",
                surface: "#F8FAFC"
            }
        }
    }
};
</script>

    <!-- Hugeicons -->
    <script src="https://cdn.jsdelivr.net/npm/@hugeicons/core@latest/dist/hugeicons.min.js"></script>

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <!-- Alpine JS -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- Swiper -->
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- AOS -->
    <link rel="stylesheet"
        href="https://unpkg.com/aos@2.3.4/dist/aos.css">

    <!--
        ===== Dynamic plugin URLs (WordPress) =====
        This file (dashboard.php) lives directly inside includes/app/view/,
        right next to both the "pages" folder and the "component" folder,
        so plugin_dir_url(__FILE__) already points to includes/app/view/
        — no folder-hopping needed.

        PAGES_URL     -> includes/app/view/pages/     (small dashboard pieces:
                          header, wallet, quick-actions, banner, services, kyc,
                          referral, recent-transactions, statistics,
                          notifications, fab, bottom-nav, scripts, and the
                          bottom-nav TAB pages: card/history/profit/wallet)

        COMPONENT_URL -> includes/app/view/component/  (full-screen slide-in
                          pages: airtime.html, data.html, bills.html, etc.
                          — these open via openFullPage())

        NOTE: dashboard.php no longer fetches the Pulsepoint user record
        itself. Each page/component (wallet.html, kyc.html, etc.) is now
        responsible for calling rest_url('usefooma/v1/api/user') on its own with the
        session token it needs — dashboard.php just loads the markup/script
        shell for each piece.
    -->
    <script>
    const PLUGIN_VIEW_BASE = "<?php echo esc_url( plugin_dir_url( __FILE__ ) ); ?>";
    const PAGES_URL     = PLUGIN_VIEW_BASE + "pages/";

    // Only the URL is exposed here — no token, no session data.
    // Each page/component fetches its own user data using its own
    // session cookie via credentials: 'same-origin'.
    
    window.pulsepointConfig = {
        // Add-on availability is determined locally from active WordPress
        // plugins. It is deliberately independent from license validity.
        activeAddons: <?php
            echo wp_json_encode(function_exists('pulsepoint_active_addons')
                ? pulsepoint_active_addons()
                : []);
        ?>,
        kycEnabled: <?php
            global $wpdb;
            $kyc_enabled_value = $wpdb->get_var($wpdb->prepare(
                "SELECT opt_value FROM {$wpdb->prefix}pulsepoint_settings WHERE opt_key = %s",
                'kyc_enabled'
            ));
            echo (maybe_unserialize($kyc_enabled_value) === '0') ? 'false' : 'true';
        ?>,
        apiUserUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/user') ); ?>",
        assetImgUrl: "<?php echo esc_js( trailingslashit(PULSEPOINT_URL . 'assets/img') ); ?>",
        sessionUser: <?php
            global $wpdb;
            $pp_session_user = null;
            $pp_session_id = (int)($_SESSION['pulsepoint_user']['id'] ?? 0);
            if ($pp_session_id > 0) {
                $pp_session_user = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, firstname, lastname, phone, email, wallet, promo_bonus_pending, dollar, referral_balance, token, account_type, status FROM {$wpdb->prefix}pulsepoint_users WHERE id = %d LIMIT 1",
                    $pp_session_id
                ), ARRAY_A);
            }
            echo wp_json_encode($pp_session_user ?: ($_SESSION['pulsepoint_user'] ?? []));
        ?>,
        wooCommerceActive: <?php echo class_exists('WooCommerce') ? 'true' : 'false'; ?>,
        wooFundingEnabled: <?php
            global $wpdb;
            $woo_funding_flag = $wpdb->get_var($wpdb->prepare(
                "SELECT opt_value FROM {$wpdb->prefix}pulsepoint_settings WHERE opt_key = %s",
                'woo_funding_enabled'
            ));
            echo (maybe_unserialize($woo_funding_flag) === '1') ? 'true' : 'false';
        ?>,
        apiWooFundUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/woo-fund') ); ?>",
        apiBeneficiariesUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/beneficiaries') ); ?>",
        apiSmmListUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/smmlist') ); ?>",
        apiSmmUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/smm') ); ?>",
        apiEsimUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/esim') ); ?>",
        apiStorefrontUrl: "<?php echo esc_js( admin_url('admin-ajax.php') ); ?>",
        apiStorefrontNonce: "<?php echo esc_js( wp_create_nonce('pulsepoint_storefront') ); ?>",
        apiAccountUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/virtual-account') ); ?>",
        apiWalletsUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/wallets') ); ?>",
        apiTrnxUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/trnx') ); ?>",
        apiAirtimeUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/airtime') ); ?>",
        apiDataplanUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/dataplan') ); ?>",
        apiDataBundleUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/data') ); ?>",
        apiOfflineDataUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/offline-data') ); ?>",
        apiBillUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/planbill') ); ?>",
        apiBoltUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/electricity') ); ?>",
        apiCablelisrUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/plancable') ); ?>",
        apiCableUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/cable') ); ?>",
        apiExamsListUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/planedu') ); ?>",
        apiExamsUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/education') ); ?>",
        apiBettingListUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/planbetting') ); ?>",
        apiBettingUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/betting') ); ?>",
        apiConvertRatesUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/convertrates') ); ?>",
        apiConvertUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/convert') ); ?>",
        apiGiftcardlistUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/listcard') ); ?>",
        apiGiftcardUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/giftcard') ); ?>",
        apiGiftcardhistoryUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/giftcardhistory') ); ?>",
        apiGiftcardRatesUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/giftcardrates') ); ?>",
        apiGiftcardStockUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/giftcardstock') ); ?>",
        apiGiftcardPurchaseUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/giftcardpurchase') ); ?>",
        apiGiftcardStatusUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/giftcardstatus') ); ?>",
        giftcardPurchaseMode: "<?php echo esc_js( get_option('pulsepoint_giftcard_purchase_mode','api') ); ?>",
        email: "<?php echo esc_js( wp_get_current_user()->user_email ); ?>",
        apiCardTransactionsUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/trnx-card') ); ?>",
        apiCardUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/cards') ); ?>",
        apiFundCardUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/fund-card') ); ?>",
        apiCreateCardUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/create-card') ); ?>",
        apiReferralUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/referrals') ); ?>",
        apiPasswordPinUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/passwordpin') ); ?>",
        apiPersonalInfoUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/personal-info') ); ?>",
        apiNotificationsUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/notifications') ); ?>",
        apiNotificationReadUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/notification-read') ); ?>",
        apiNotificationReadAllUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/notification-read-all') ); ?>",
        apiAnnouncementsUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/announcements') ); ?>",
        api2faStatusUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/2fa-status') ); ?>",
        api2faSetupUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/2fa-setup') ); ?>",
        api2faVerifyUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/2fa-verify') ); ?>",
        api2faDisableUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/2fa-disable') ); ?>",
        apiKycUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/know-your-customer') ); ?>",
        apiChannelUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/channel') ); ?>",
        apiLeaderboardUrl: "<?php echo esc_js( rest_url('usefooma/v1/api/leaderboard') ); ?>",
        offlineDataNumber: <?php
            global $wpdb;
            $vb_number = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$wpdb->prefix}pulsepoint_settings WHERE opt_key=%s LIMIT 1", 'africas_talking_number'));
            echo wp_json_encode((string)maybe_unserialize($vb_number));
        ?>,
        offlineDataDailyLimit: <?php
            global $wpdb;
            $vb_limit = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$wpdb->prefix}pulsepoint_settings WHERE opt_key=%s LIMIT 1", 'africas_talking_daily_limit'));
            echo (float)maybe_unserialize($vb_limit);
        ?>,
        passcode: "<?php echo esc_js( $_SESSION['pulsepoint_user']['passcode'] ?? '' ); ?>",
        token: "<?php echo esc_js( $_SESSION['pulsepoint_user']['token'] ?? '' ); ?>"
    };
    </script>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Inter',sans-serif;
        }

        html{
            scroll-behavior:smooth;
        }

        body{
            background:#F8FAFC;
        }

        ::-webkit-scrollbar{
            display:none;
        }

        html, body{
            height:100%;
            overscroll-behavior:none;
            -webkit-text-size-adjust:100%;
        }

        /* Slide-in panel for full-screen pages (airtime, data, bills, etc.) */
        #fullpage-panel{
            transform: translate3d(100%,0,0);
            -webkit-transform: translate3d(100%,0,0);
            transition: transform 0.25s ease-out;
            will-change: transform;
            backface-visibility: hidden;
            -webkit-backface-visibility: hidden;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior: contain;
        }

        #fullpage-panel.open{
            transform: translate3d(0,0,0);
            -webkit-transform: translate3d(0,0,0);
        }

        /* 404 animation */
        @keyframes notFoundFade {
            0% {
                opacity: 0;
                transform: translateY(16px) scale(0.96);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes notFoundBounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }

        .nf-wrap{
            animation: notFoundFade 0.4s ease-out both;
        }

        .nf-number{
            animation: notFoundBounce 2s ease-in-out infinite;
        }

        /* ===== Page loading overlay (gray scrim + pulsing dot) =====
           Only shown when there is nothing cached to display yet.
           Background/silent refreshes never trigger this. */
        #page-loading-overlay{
            position:fixed;
            inset:0;
            z-index:9999;
            background:rgba(17,24,39,0.45);
            display:flex;
            align-items:center;
            justify-content:center;
            opacity:0;
            pointer-events:none;
            transition:opacity 0.15s ease;
        }

        #page-loading-overlay.show{
            opacity:1;
            pointer-events:all;
        }

        .loading-dot{
            width:14px;
            height:14px;
            border-radius:9999px;
            background: <?php echo esc_js($color_hex); ?>;
            animation:loadingDotPulse 0.9s ease-in-out infinite;
        }

        @keyframes loadingDotPulse{
            0%, 100% {
                transform:scale(0.55);
                opacity:0.55;
            }
            50% {
                transform:scale(1.25);
                opacity:1;
            }
        }

        /* ===== Anti-clone / anti-copy hardening =====
           NOTE: none of this is real security — it only deters casual
           "view source / right-click save / drag image / select text"
           copying from ordinary visitors. Anyone who opens devtools
           network tab or disables JS can still get the markup and assets.
           Use it as a light deterrent, not as content protection. */
        html, body, #app{
            -webkit-user-select:none;
            -moz-user-select:none;
            -ms-user-select:none;
            user-select:none;
            -webkit-touch-callout:none; /* iOS long-press menu */
        }

        /* Still allow selection inside real inputs/textareas so forms work */
        input, textarea, [contenteditable="true"]{
            -webkit-user-select:text;
            -moz-user-select:text;
            -ms-user-select:text;
            user-select:text;
        }

        img{
            -webkit-user-drag:none;
            user-drag:none;
            pointer-events:none; /* blocks right-click "save image as" via drag/context on the image itself */
        }

        /* Buttons/icons that sit on top of images still need clicks */
        img.pp-allow-click{
            pointer-events:auto;
        }

        /* =====================================================
           Dark / Light theme
           Controlled by <html data-theme="light|dark">, set by the
           theme engine script above. Every class below already
           exists in the markup (bg-white, text-gray-500, etc.) —
           nothing here changes the HTML, it only remaps what those
           classes render as once data-theme="dark" is set, and
           reverts automatically when it's "light".
           ===================================================== */
        :root{
            --pp-bg:#F8FAFC;
            --pp-surface:#FFFFFF;
            --pp-surface-muted:#F9FAFB;
            --pp-surface-hover:#F3F4F6;
            --pp-border-100:#F3F4F6;
            --pp-border-200:#E5E7EB;
            --pp-border-300:#D1D5DB;
            --pp-text-900:#111827;
            --pp-text-800:#1F2937;
            --pp-text-700:#374151;
            --pp-text-600:#4B5563;
            --pp-text-500:#6B7280;
            --pp-text-400:#9CA3AF;
            --pp-text-300:#D1D5DB;
            --pp-skeleton:#E5E7EB;
        }

        html[data-theme="dark"]{
            --pp-bg:#0B1220;
            --pp-surface:#131C2E;
            --pp-surface-muted:#182236;
            --pp-surface-hover:#1D2A40;
            --pp-border-100:#1F2A3D;
            --pp-border-200:#263450;
            --pp-border-300:#324162;
            --pp-text-900:#F1F5F9;
            --pp-text-800:#E2E8F0;
            --pp-text-700:#CBD5E1;
            --pp-text-600:#AAB8CC;
            --pp-text-500:#8A9AB4;
            --pp-text-400:#6B7B98;
            --pp-text-300:#4B5C7A;
            --pp-skeleton:#22304A;
        }

        html[data-theme="dark"] body{
            background:var(--pp-bg);
        }

        html[data-theme="dark"] #page-loading-overlay{
            background:rgba(0,0,0,0.6);
        }

        html[data-theme="dark"] #app,
        html[data-theme="dark"] #fullpage-panel{
            background-color:var(--pp-bg) !important;
        }

        /* The sticky top header is a full-bleed bar, not a card — it
           should blend flush with the page background rather than
           pick up the lighter "surface" tone .bg-white gets below.
           (Higher specificity than the generic .bg-white rule, so
           this wins here and leaves every other bg-white
           card/button/panel using the surface tone.)

           Covers:
           - #header — the global chrome shell in this file
           - every <header> tag — pages/header.html, and the
             per-tab headers in profile.html, card.html, history.html,
             wallet-menu.html (these load into #page-tab, not #header,
             so they need the tag selector, not just the ID one)
           - the KYC and Sell Gift Card slide-in panels, which paint
             their entire header + body bg-white directly (most other
             component/*.html panels leave this transparent and just
             inherit #fullpage-panel's background, so they never had
             this problem) */
        html[data-theme="dark"] #header.bg-white,
        html[data-theme="dark"] #header .bg-white,
        html[data-theme="dark"] header.bg-white,
        html[data-theme="dark"] .border-b.border-gray-100.flex-shrink-0.bg-white,
        html[data-theme="dark"] #kycContent,
        html[data-theme="dark"] #giftcardContent{
            background-color:var(--pp-bg) !important;
        }

        /* Surfaces */
        html[data-theme="dark"] .bg-white{ background-color:var(--pp-surface) !important; }
        html[data-theme="dark"] .bg-surface{ background-color:var(--pp-bg) !important; }
        html[data-theme="dark"] .bg-gray-50{ background-color:var(--pp-surface-muted) !important; }
        html[data-theme="dark"] .bg-gray-100{ background-color:var(--pp-surface-hover) !important; }
        html[data-theme="dark"] .bg-gray-200{ background-color:var(--pp-skeleton) !important; }
        html[data-theme="dark"] .hover\:bg-gray-50:hover{ background-color:var(--pp-surface-hover) !important; }
        html[data-theme="dark"] .hover\:bg-gray-100:hover{ background-color:var(--pp-border-200) !important; }
        html[data-theme="dark"] .active\:bg-gray-100:active{ background-color:var(--pp-border-200) !important; }

        /* Borders / dividers */
        html[data-theme="dark"] .border-gray-100{ border-color:var(--pp-border-100) !important; }
        html[data-theme="dark"] .border-gray-200{ border-color:var(--pp-border-200) !important; }
        html[data-theme="dark"] .border-gray-300{ border-color:var(--pp-border-300) !important; }
        html[data-theme="dark"] .border-white{ border-color:var(--pp-surface) !important; }
        html[data-theme="dark"] .divide-gray-100 > :not([hidden]) ~ :not([hidden]){ border-color:var(--pp-border-100) !important; }

        /* Text */
        html[data-theme="dark"] .text-gray-900{ color:var(--pp-text-900) !important; }
        html[data-theme="dark"] .text-gray-800{ color:var(--pp-text-800) !important; }
        html[data-theme="dark"] .text-gray-700{ color:var(--pp-text-700) !important; }
        html[data-theme="dark"] .text-gray-600{ color:var(--pp-text-600) !important; }
        html[data-theme="dark"] .text-gray-500{ color:var(--pp-text-500) !important; }
        html[data-theme="dark"] .text-gray-400{ color:var(--pp-text-400) !important; }
        html[data-theme="dark"] .text-gray-300{ color:var(--pp-text-300) !important; }
        html[data-theme="dark"] .placeholder-gray-400::placeholder{ color:var(--pp-text-400) !important; }
        html[data-theme="dark"] .placeholder-gray-500::placeholder{ color:var(--pp-text-500) !important; }

        /* Skeleton loading bars (span/div with bg-gray-200 + animate-pulse) */
        html[data-theme="dark"] .bg-gray-200.animate-pulse{ background-color:var(--pp-skeleton) !important; }

        /* ===== Status / accent color families =====
           Same idea as the neutrals above: every one of these classes
           already exists in the markup (badges, pills, tier labels,
           error/success/warning states). In dark mode the "-50" style
           tint backgrounds become a translucent version of the same
           hue (instead of a near-white wash) and the text brightens a
           step so it still reads clearly on a dark card. */
        html[data-theme="dark"] .bg-red-50{ background-color:rgba(248,113,113,0.16) !important; }
        html[data-theme="dark"] .text-red-500{ color:#F87171 !important; }
        html[data-theme="dark"] .text-red-700{ color:#FCA5A5 !important; }
        html[data-theme="dark"] .border-red-300{ border-color:rgba(248,113,113,0.4) !important; }

        html[data-theme="dark"] .bg-green-50{ background-color:rgba(74,222,128,0.16) !important; }
        html[data-theme="dark"] .text-green-600{ color:#4ADE80 !important; }
        html[data-theme="dark"] .text-green-700{ color:#86EFAC !important; }
        html[data-theme="dark"] .border-green-300{ border-color:rgba(74,222,128,0.4) !important; }

        html[data-theme="dark"] .bg-yellow-50{ background-color:rgba(250,204,21,0.16) !important; }
        html[data-theme="dark"] .text-yellow-600{ color:#FACC15 !important; }
        html[data-theme="dark"] .text-yellow-700{ color:#FDE047 !important; }
        html[data-theme="dark"] .text-yellow-300{ color:#FEF08A !important; }
        html[data-theme="dark"] .border-yellow-300{ border-color:rgba(250,204,21,0.4) !important; }

        html[data-theme="dark"] .bg-blue-50{ background-color:rgba(96,165,250,0.16) !important; }
        html[data-theme="dark"] .text-blue-600{ color:#60A5FA !important; }

        html[data-theme="dark"] .bg-amber-50{ background-color:rgba(251,191,36,0.16) !important; }
        html[data-theme="dark"] .text-amber-500{ color:#FBBF24 !important; }
        html[data-theme="dark"] .text-amber-600{ color:#FCD34D !important; }

        html[data-theme="dark"] .bg-orange-50{ background-color:rgba(251,146,60,0.16) !important; }
        html[data-theme="dark"] .text-orange-600{ color:#FB923C !important; }

        html[data-theme="dark"] .bg-indigo-50{ background-color:rgba(129,140,248,0.16) !important; }
        html[data-theme="dark"] .text-indigo-600{ color:#818CF8 !important; }

        html[data-theme="dark"] .bg-purple-50{ background-color:rgba(192,132,252,0.16) !important; }
        html[data-theme="dark"] .text-purple-600{ color:#C084FC !important; }

        html[data-theme="dark"] .bg-pink-50{ background-color:rgba(244,114,182,0.16) !important; }
        html[data-theme="dark"] .text-pink-600{ color:#F472B6 !important; }

        html[data-theme="dark"] .bg-rose-50{ background-color:rgba(251,113,133,0.16) !important; }
        html[data-theme="dark"] .text-rose-600{ color:#FB7185 !important; }

        html[data-theme="dark"] .bg-cyan-50{ background-color:rgba(34,211,238,0.16) !important; }
        html[data-theme="dark"] .text-cyan-600{ color:#22D3EE !important; }

        /* Shadows read as too heavy on dark surfaces — soften them */
        html[data-theme="dark"] .shadow,
        html[data-theme="dark"] .shadow-sm,
        html[data-theme="dark"] .shadow-lg{
            box-shadow:0 4px 18px rgba(0,0,0,0.45) !important;
        }

        /* Smooth, non-jarring transition whenever the theme is switched */
        body, .bg-white, .bg-gray-50, .bg-gray-100, .bg-gray-200,
        .text-gray-900, .text-gray-800, .text-gray-700, .text-gray-600,
        .text-gray-500, .text-gray-400, .text-gray-300,
        .border-gray-100, .border-gray-200, .border-gray-300{
            transition:background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
        }

    </style>

</head>

<body class="bg-surface text-gray-900 antialiased" oncontextmenu="return false;" oncopy="return false;" oncut="return false;" ondragstart="return false;">

    <!-- ================= APP ================= -->

    <div id="app"
        class="relative min-h-screen max-w-md mx-auto bg-white overflow-hidden">

        <!-- Header (sticky) — hidden while a bottom-nav tab (card/history/
             profit/wallet) is open, shown again on the home tab -->
        <div id="header" class="sticky top-0 z-30 bg-white"></div>

        <!-- Main -->
        <main class="pb-24 space-y-6">

            <!-- Home tab: dashboard sections -->
            <div id="page-home">

                <div id="wallet"></div>

                <div id="quick-actions"></div>

                <div id="banner"></div>

                <div id="services"></div>

                <?php if (true): ?><div id="kyc"></div><?php endif; ?>

                <div id="referral"></div>

                <div id="recent-transactions"></div>

                <div id="statistics"></div>

                <div id="notifications"></div>

            </div>

            <!-- Other bottom-nav tabs: card, history, profit, wallet -->
            <div id="page-tab" class="hidden"></div>

        </main>

        <!-- Floating Action Button -->
        <div id="fab"></div>

        <!-- Bottom Navigation -->
        <div id="bottom-nav"></div>

        <!-- Full-screen slide-in panel (airtime, data, bills, etc.) -->
        <div id="fullpage-panel"
            class="fixed inset-0 z-50 bg-white overflow-y-auto">
        </div>

        <!-- ===================================================================
             ANNOUNCEMENT — auto-popup bottom sheet for admin news/updates.
             Opens itself on load when there's a new one; no trigger button.
        =================================================================== -->
        <div id="announcementSheetOverlay"
            class="fixed inset-0 z-[75] bg-black/40 opacity-0 pointer-events-none transition-opacity duration-200"
            onclick="closeAnnouncementSheet()">
        </div>

        <div id="announcementSheet"
            class="fixed left-0 right-0 bottom-0 z-[76] bg-white rounded-t-3xl translate-y-full transition-transform duration-250 ease-out max-w-md mx-auto overscroll-contain overflow-y-auto max-h-[70vh]"
            style="padding-bottom: calc(env(safe-area-inset-bottom) + 20px);">

            <div class="flex justify-center pt-3 pb-1">
                <span class="w-10 h-1.5 rounded-full bg-gray-200"></span>
            </div>

            <div class="px-6 pt-4 pb-2 flex flex-col items-center text-center">
                <span id="announcementIconWrap" class="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <iconify-icon id="announcementIcon" icon="hugeicons:megaphone-01" width="26" class="text-primary"></iconify-icon>
                </span>
                <h4 id="announcementTitle" class="font-bold text-base text-gray-900 mb-2"></h4>
                <p id="announcementMessage" class="text-sm text-gray-500 leading-relaxed"></p>
            </div>

            <div class="px-6 pt-6 pb-2">
                <button type="button" onclick="closeAnnouncementSheet()" class="w-full h-12 rounded-full bg-primary text-white text-sm font-semibold">
                    Got it
                </button>
            </div>

        </div>

        <!-- Page loading overlay -->
        <div id="page-loading-overlay">
            <div class="loading-dot"></div>
        </div>

    </div>

    <!-- Scripts -->
    <div id="scripts"></div>

    <!-- Vendor JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

    <script>
        AOS.init({
            once: true,
            duration: 500
        });

        // ===== iOS-safe body scroll lock =====
        let lockedScrollY = 0;

        function lockBodyScroll() {

            lockedScrollY = window.scrollY;

            document.body.style.position = 'fixed';
            document.body.style.top = `-${lockedScrollY}px`;
            document.body.style.left = '0';
            document.body.style.right = '0';
            document.body.style.width = '100%';

        }

        function unlockBodyScroll() {

            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.left = '';
            document.body.style.right = '';
            document.body.style.width = '';

            window.scrollTo(0, lockedScrollY);

        }

        // ===================================================================
        // ANNOUNCEMENT — auto-popup bottom sheet. Checks once per dashboard
        // load for the latest active admin announcement; if it's one the
        // user hasn't already seen (tracked in localStorage), it pops open
        // by itself — no button to click.
        // ===================================================================
        var ANNOUNCEMENT_TYPE_ICON = {
            info: 'hugeicons:megaphone-01',
            success: 'hugeicons:checkmark-circle-02',
            warning: 'hugeicons:alert-02',
            error: 'hugeicons:alert-diamond',
            promotion: 'hugeicons:gift'
        };

        function openAnnouncementSheet(announcement) {

            document.getElementById('announcementTitle').textContent = announcement.title;
            document.getElementById('announcementMessage').textContent = announcement.message;
            document.getElementById('announcementIcon').setAttribute('icon', ANNOUNCEMENT_TYPE_ICON[announcement.type] || 'hugeicons:megaphone-01');

            try {
                localStorage.setItem('pulsepoint_last_announcement_id', String(announcement.id));
            } catch (e) {}

            var overlay = document.getElementById('announcementSheetOverlay');
            var sheet = document.getElementById('announcementSheet');

            lockBodyScroll();

            overlay.classList.remove('pointer-events-none');
            overlay.classList.remove('opacity-0');

            void sheet.offsetHeight;
            sheet.classList.remove('translate-y-full');
        }

        function closeAnnouncementSheet() {

            var overlay = document.getElementById('announcementSheetOverlay');
            var sheet = document.getElementById('announcementSheet');

            sheet.classList.add('translate-y-full');
            overlay.classList.add('opacity-0');
            unlockBodyScroll();

            setTimeout(function () {
                overlay.classList.add('pointer-events-none');
            }, 250);
        }

        function checkForNewAnnouncement() {

            var cfg = window.pulsepointConfig || {};

            if (!cfg.apiAnnouncementsUrl || !cfg.token) return;

            fetch(cfg.apiAnnouncementsUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: cfg.token })
            })
            .then(function (res) { return res.json(); })
            .then(function (res) {

                if (!res.success || !res.announcement) return;

                var lastSeenId = null;
                try { lastSeenId = localStorage.getItem('pulsepoint_last_announcement_id'); } catch (e) {}

                if (String(res.announcement.id) === String(lastSeenId)) return;

                openAnnouncementSheet(res.announcement);
            })
            .catch(function (error) {
                console.error('Announcement check failed', error);
            });
        }

        setTimeout(checkForNewAnnouncement, 800);

        // ===== Loading overlay helpers =====
        let loadingRequests = 0;

        function showLoading() {

            loadingRequests++;

            document.getElementById('page-loading-overlay').classList.add('show');

        }

        function hideLoading() {

            loadingRequests = Math.max(0, loadingRequests - 1);

            if (loadingRequests === 0) {
                document.getElementById('page-loading-overlay').classList.remove('show');
            }

        }

        // ===== Re-execute <script> tags found inside injected HTML =====
        function runScripts(container) {

            const scripts = container.querySelectorAll('script');

            scripts.forEach((oldScript) => {

                const newScript = document.createElement('script');

                Array.from(oldScript.attributes).forEach((attr) => {
                    newScript.setAttribute(attr.name, attr.value);
                });

                if (oldScript.src) {
                    newScript.src = oldScript.src;
                } else {
                    newScript.textContent = oldScript.textContent;
                }

                oldScript.replaceWith(newScript);

            });

        }

        // ===== Shared error UI =====
        function notFoundMarkup(closeAction){

            const closeBtn = closeAction
                ? `
                    <button
                        type="button"
                        onclick="${closeAction}"
                        class="absolute top-4 right-4 h-9 w-9 rounded-full bg-gray-100 flex items-center justify-center">
                        <iconify-icon icon="hugeicons:cancel-01" width="18" height="18"></iconify-icon>
                    </button>
                `
                : '';

            return `
                <div class="nf-wrap relative min-h-[70vh] flex flex-col items-center justify-center px-6 text-center">
                    ${closeBtn}
                    <span class="nf-number text-[64px] font-extrabold text-primary leading-none">404</span>
                    <p class="mt-4 text-sm text-gray-500 leading-relaxed max-w-[260px]">
                      Hi, I'm Usefooma — looks like I wandered off. page isn't ready yet.
                    </p>
                </div>
            `;
        }

        // =========================================================
        // ===== Stale-while-revalidate caching for component HTML =====
        // Each piece (wallet.html, header.html, a bottom-nav tab, etc.)
        // is cached in localStorage. On load we render the cached
        // markup instantly (if present) with no loading overlay, then
        // fetch a fresh copy in the background and swap it in only if
        // it actually changed. The overlay only shows the very first
        // time a piece is loaded with nothing cached yet.
        // =========================================================

        const CACHE_PREFIX = 'pp_cache_';

        function getCachedHTML(file) {

            try {

                const raw = localStorage.getItem(CACHE_PREFIX + file);

                return raw ? JSON.parse(raw) : null;

            } catch (error) {

                return null;

            }

        }

        function setCachedHTML(file, html) {

            try {

                localStorage.setItem(
                    CACHE_PREFIX + file,
                    JSON.stringify({ html, ts: Date.now() })
                );

            } catch (error) {

                // Storage full / unavailable (e.g. private browsing) —
                // caching is best-effort, safe to ignore.

            }

        }

        // ===== Load a component (id) from pages/{file} into the DOM =====
        // opts.silent = true -> background refresh: no overlay, no forced
        // re-render unless the fetched HTML actually differs from cache.
        async function loadComponent(id, file, opts = {}) {

            const silent = !!opts.silent;

            const el = document.getElementById(id);

            if (!el) return;

            const cached = getCachedHTML(file);
            const hasCache = !!cached;

            if (hasCache && !silent) {
                el.innerHTML = cached.html;
                runScripts(el);
            }

            if (!hasCache && !silent) {
                showLoading();
            }

            try {

                const response = await fetch(PAGES_URL + file, { cache: 'no-store' });

                if (!response.ok) {
                    throw new Error(`Unable to load ${file}`);
                }

                const html = await response.text();

                if (!cached || html !== cached.html) {
                    el.innerHTML = html;
                    runScripts(el);
                }

                setCachedHTML(file, html);

            } catch (error) {

                console.error(error);

                if (!hasCache) {
                    el.innerHTML = notFoundMarkup(null);
                }

                // If we already had cache, keep showing it silently and
                // just retry on the next background refresh cycle.

            } finally {

                if (!hasCache && !silent) hideLoading();

            }
        }

        // ===== Full-screen slide pages (no bottom nav) =====
        // Call this with the path relative to includes/app/view/, e.g.:
        //   onclick="openFullPage('component/airtime.html')"
        //   onclick="openFullPage('component/convert.html')"
        async function openFullPage(file) {

            const panel = document.getElementById('fullpage-panel');

            const cached = getCachedHTML(file);
            const hasCache = !!cached;

            if (hasCache) {
                panel.innerHTML = cached.html;
                runScripts(panel);
            } else {
                showLoading();
            }

            try {

                const response = await fetch(PLUGIN_VIEW_BASE + file, { cache: 'no-store' });

                if (!response.ok) {
                    throw new Error(`Unable to load ${file}`);
                }

                const html = await response.text();

                if (!cached || html !== cached.html) {
                    panel.innerHTML = html;
                    runScripts(panel);
                }

                setCachedHTML(file, html);

            } catch (error) {

                console.error(error);

                if (!hasCache) {
                    panel.innerHTML = notFoundMarkup("closeFullPage()");
                }

            } finally {

                if (!hasCache) hideLoading();

            }

            panel.classList.add('open');
            lockBodyScroll();

        }

        function closeFullPage() {

            const panel = document.getElementById('fullpage-panel');

            panel.classList.remove('open');
            unlockBodyScroll();

            setTimeout(() => {
                panel.innerHTML = '';
            }, 250);

        }

        // ===== Bottom-nav tab pages (card, history, profit, wallet) =====
        // If these actually live in the "component" folder instead of "pages"
        // on your server, change PAGES_URL below to COMPONENT_URL.
        //
        // The header is intentionally hidden while a tab is open — only
        // the tab content + bottom nav are shown. Home is the only view
        // that shows the header. showHome() brings it back.
        let currentTabFile = null;

        async function loadTab(file, opts = {}) {

            const silent = !!opts.silent;

            currentTabFile = file;

            const home = document.getElementById('page-home');
            const tab = document.getElementById('page-tab');
            const header = document.getElementById('header');

            const cached = getCachedHTML(file);
            const hasCache = !!cached;

            if (hasCache && !silent) {
                tab.innerHTML = cached.html;
                runScripts(tab);
            }

            if (!hasCache && !silent) {
                showLoading();
            }

            try {

                const response = await fetch(PAGES_URL + file, { cache: 'no-store' });

                if (!response.ok) {
                    throw new Error(`Unable to load ${file}`);
                }

                const html = await response.text();

                if (!cached || html !== cached.html) {
                    tab.innerHTML = html;
                    runScripts(tab);
                }

                setCachedHTML(file, html);

            } catch (error) {

                console.error(error);

                if (!hasCache) {
                    tab.innerHTML = notFoundMarkup("showHome()");
                }

            } finally {

                if (!hasCache && !silent) hideLoading();

            }

            // Header stays hidden for every bottom-nav tab — only the
            // tab content and bottom nav remain visible.
            header.classList.add('hidden');

            home.classList.add('hidden');
            tab.classList.remove('hidden');

        }

        function showHome() {

            currentTabFile = null;

            document.getElementById('header').classList.remove('hidden');
            document.getElementById('page-tab').classList.add('hidden');
            document.getElementById('page-tab').innerHTML = '';
            document.getElementById('page-home').classList.remove('hidden');

        }

        // ===== Bottom nav active state =====
        function setActiveNav(clicked) {

            const buttons = document.querySelectorAll('#bottomNavGrid .nav-btn');

            buttons.forEach(function (btn) {

                const iconWrap = btn.querySelector('.nav-icon-wrap');
                const icon = btn.querySelector('.nav-icon');
                const label = btn.querySelector('.nav-label');

                iconWrap.classList.remove('bg-white/15');
                icon.classList.remove('text-white');
                icon.classList.add('text-white/70');
                label.classList.remove('text-white', 'font-semibold');
                label.classList.add('text-white/70', 'font-medium');

            });

            const iconWrap = clicked.querySelector('.nav-icon-wrap');
            const icon = clicked.querySelector('.nav-icon');
            const label = clicked.querySelector('.nav-label');

            iconWrap.classList.add('bg-white/15');
            icon.classList.remove('text-white/70');
            icon.classList.add('text-white');
            label.classList.remove('text-white/70', 'font-medium');
            label.classList.add('text-white', 'font-semibold');

        }

        // =========================================================
        // ===== Silent background auto-refresh =====
        // Every AUTO_REFRESH_INTERVAL ms, silently re-fetch whatever is
        // currently visible (always the header/bottom-nav/fab chrome,
        // plus either the home sections or the open tab) and swap in
        // fresh markup only if it changed. Never shows the loading
        // overlay and never fires while a full-screen panel is open on
        // top, since that panel owns the view at that point.
        // =========================================================

        const AUTO_REFRESH_INTERVAL = 30000; // 30s

        const CHROME_COMPONENTS = [
            ["header", "header.html"],
            ["bottom-nav", "bottom-nav.html"],
            ["fab", "fab.html"],
        ];

        const HOME_COMPONENTS = [
            ["wallet", "wallet.html"],
            ["quick-actions", "quick-actions.html"],
            ["banner", "banner.html"],
            ["services", "services.html"],
            ...(window.pulsepointConfig.kycEnabled ? [["kyc", "kyc.html"]] : []),
            ["referral", "referral.html"],
            ["recent-transactions", "recent-transactions.html"],
            ["statistics", "statistics.html"],
            ["notifications", "notifications.html"],
        ];

        function refreshVisible() {

            const panel = document.getElementById('fullpage-panel');

            if (panel.classList.contains('open')) return;

            CHROME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file, { silent: true }));

            const home = document.getElementById('page-home');

            if (!home.classList.contains('hidden')) {
                HOME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file, { silent: true }));
            } else if (currentTabFile) {
                loadTab(currentTabFile, { silent: true });
            }

        }

        let autoRefreshTimer = null;

        function startAutoRefresh() {

            stopAutoRefresh();
            autoRefreshTimer = setInterval(refreshVisible, AUTO_REFRESH_INTERVAL);

        }

        function stopAutoRefresh() {

            if (autoRefreshTimer) {
                clearInterval(autoRefreshTimer);
                autoRefreshTimer = null;
            }

        }

        // Pause background refresh while the tab/app isn't visible (saves
        // battery + data), and refresh immediately when the user returns.
        document.addEventListener('visibilitychange', () => {

            if (document.hidden) {
                stopAutoRefresh();
            } else {
                refreshVisible();
                startAutoRefresh();
            }

        });

        // =========================================================
        // NOTE: The old fetchPulsepointUser()/loadWalletBalance()/
        // ensureVirtualAccount() helpers and the window.pulsepointUser
        // token bootstrap have been removed from dashboard.php.
        // Each page/component (wallet.html, kyc.html, etc.) now calls
        // rest_url('usefooma/v1/api/user') on its own, with its own token handling,
        // so dashboard.php no longer needs to know about that endpoint
        // at all — it's just loading markup shells.
        // =========================================================

        document.addEventListener("DOMContentLoaded", () => {

            CHROME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file));
            HOME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file));

            // scripts.html is a one-time include, not refreshed in the
            // background — re-running it on every cycle would re-declare
            // globals / re-attach listeners each time.
            loadComponent("scripts", "scripts.html");

            startAutoRefresh();

        });

        // ===== Anti-clone / anti-copy JS deterrents =====
        // Again: these only stop casual copying, not a determined user
        // with devtools. Right-click, copy/cut, and image dragging are
        // already blocked via the body attributes + CSS above; this adds
        // a keyboard-shortcut layer (view-source, save-page, print,
        // devtools) and a text-selection guard as backup.
        document.addEventListener('selectstart', (e) => {
            const tag = e.target.tagName;
            if (tag !== 'INPUT' && tag !== 'TEXTAREA') e.preventDefault();
        });

        document.addEventListener('keydown', (e) => {

            const key = e.key.toUpperCase();
            const blockedCombo =
                (e.ctrlKey || e.metaKey) && ['U', 'S', 'P', 'C'].includes(key) ||
                (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(key)) ||
                key === 'F12';

            if (blockedCombo) {
                e.preventDefault();
            }

        });
    </script>

    <!--
        Controller scripts have been removed from here on purpose.
        Each component page (e.g. pages/airtime.html, pages/data.html,
        pages/convert.html) now owns its own <script> block inline in its
        own file. runScripts() above automatically executes that script
        the moment the markup is injected into the DOM.
    -->

</body>

</html>