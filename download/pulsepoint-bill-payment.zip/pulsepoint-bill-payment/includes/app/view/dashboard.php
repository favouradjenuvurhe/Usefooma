<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/../index.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <!-- SEO -->   
    <meta name="theme-color" content="<?php echo esc_attr($color_hex); ?>">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/favicon.png">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <script>
tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: "<?php echo esc_js($color_hex); ?>",
                secondary: "#111827",
                success: "#16A34A",
                warning: "#F59E0B",
                danger: "#DC2626",
                surface: "#F8FAFC"
            }
        }
    }
};
</script>

    <!-- Hugeicons -->
    <script src="https://cdn.jsdelivr.net/npm/@hugeicons/core@latest/dist/hugeicons.min.js"></script>

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <!-- Alpine JS -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- Swiper -->
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <!-- AOS -->
    <link rel="stylesheet"
        href="https://unpkg.com/aos@2.3.4/dist/aos.css">

    <!--
        ===== Dynamic plugin URLs (WordPress) =====
        This file (dashboard.php) lives directly inside includes/app/view/,
        right next to both the "pages" folder and the "component" folder,
        so plugin_dir_url(__FILE__) already points to includes/app/view/
        — no folder-hopping needed.

        PAGES_URL     -> includes/app/view/pages/     (small dashboard pieces:
                          header, wallet, quick-actions, banner, services, kyc,
                          referral, recent-transactions, statistics,
                          notifications, fab, bottom-nav, scripts, and the
                          bottom-nav TAB pages: card/history/profit/wallet)

        COMPONENT_URL -> includes/app/view/component/  (full-screen slide-in
                          pages: airtime.html, data.html, bills.html, etc.
                          — these open via openFullPage())

        NOTE: dashboard.php no longer fetches the Pulsepoint user record
        itself. Each page/component (wallet.html, kyc.html, etc.) is now
        responsible for calling site_url('/api/user') on its own with the
        session token it needs — dashboard.php just loads the markup/script
        shell for each piece.
    -->
    <script>
    const PLUGIN_VIEW_BASE = "<?php echo esc_url( plugin_dir_url( __FILE__ ) ); ?>";
    const PAGES_URL     = PLUGIN_VIEW_BASE + "pages/";

    // Only the URL is exposed here — no token, no session data.
    // Each page/component fetches its own user data using its own
    // session cookie via credentials: 'same-origin'.
    
    window.pulsepointConfig = {
        MainApiUrl: "https://usefooma.site/api/v3/<?php echo esc_js(parse_url(home_url(), PHP_URL_HOST)); ?>.json",
        apiUserUrl: "<?php echo esc_js( site_url('/api/user') ); ?>",
        apiAccountUrl: "<?php echo esc_js( site_url('/api/virtual-account') ); ?>",
        apiWalletsUrl: "<?php echo esc_js( site_url('/api/wallets') ); ?>",
        apiTrnxUrl: "<?php echo esc_js( site_url('/api/trnx') ); ?>",
        apiAirtimeUrl: "<?php echo esc_js( site_url('/api/airtime') ); ?>",
        apiDataplanUrl: "<?php echo esc_js( site_url('/api/dataplan') ); ?>",
        apiDataBundleUrl: "<?php echo esc_js( site_url('/api/data') ); ?>",
        apiBillUrl: "<?php echo esc_js( site_url('/api/planbill') ); ?>",
        apiBoltUrl: "<?php echo esc_js( site_url('/api/electricity') ); ?>",
        apiCablelisrUrl: "<?php echo esc_js( site_url('/api/plancable') ); ?>",
        apiCableUrl: "<?php echo esc_js( site_url('/api/cable') ); ?>",
        apiGiftcardlistUrl: "<?php echo esc_js( site_url('/api/listcard') ); ?>",
        apiGiftcardUrl: "<?php echo esc_js( site_url('/api/giftcard') ); ?>",
        apiCardTransactionsUrl: "<?php echo esc_js( site_url('/api/trnx-card') ); ?>",
        apiCardUrl: "<?php echo esc_js( site_url('/api/cards') ); ?>",
        apiFundCardUrl: "<?php echo esc_js( site_url('/api/fund-card') ); ?>",
        apiCreateCardUrl: "<?php echo esc_js( site_url('/api/create-card') ); ?>",
        apiReferralUrl: "<?php echo esc_js( site_url('/api/referrals') ); ?>",
        apiPasswordPinUrl: "<?php echo esc_js( site_url('/api/passwordpin') ); ?>",
        passcode: "<?php echo esc_js( $_SESSION['pulsepoint_user']['passcode'] ?? '' ); ?>",
        token: "<?php echo esc_js( $_SESSION['pulsepoint_user']['token'] ?? '' ); ?>"
    };
    </script>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Inter',sans-serif;
        }

        html{
            scroll-behavior:smooth;
        }

        body{
            background:#F8FAFC;
        }

        ::-webkit-scrollbar{
            display:none;
        }

        html, body{
            height:100%;
            overscroll-behavior:none;
            -webkit-text-size-adjust:100%;
        }

        /* Slide-in panel for full-screen pages (airtime, data, bills, etc.) */
        #fullpage-panel{
            transform: translate3d(100%,0,0);
            -webkit-transform: translate3d(100%,0,0);
            transition: transform 0.25s ease-out;
            will-change: transform;
            backface-visibility: hidden;
            -webkit-backface-visibility: hidden;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior: contain;
        }

        #fullpage-panel.open{
            transform: translate3d(0,0,0);
            -webkit-transform: translate3d(0,0,0);
        }

        /* 404 animation */
        @keyframes notFoundFade {
            0% {
                opacity: 0;
                transform: translateY(16px) scale(0.96);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes notFoundBounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }

        .nf-wrap{
            animation: notFoundFade 0.4s ease-out both;
        }

        .nf-number{
            animation: notFoundBounce 2s ease-in-out infinite;
        }

        /* ===== Page loading overlay (gray scrim + pulsing dot) =====
           Only shown when there is nothing cached to display yet.
           Background/silent refreshes never trigger this. */
        #page-loading-overlay{
            position:fixed;
            inset:0;
            z-index:9999;
            background:rgba(17,24,39,0.45);
            display:flex;
            align-items:center;
            justify-content:center;
            opacity:0;
            pointer-events:none;
            transition:opacity 0.15s ease;
        }

        #page-loading-overlay.show{
            opacity:1;
            pointer-events:all;
        }

        .loading-dot{
            width:14px;
            height:14px;
            border-radius:9999px;
            background: <?php echo esc_js($color_hex); ?>;
            animation:loadingDotPulse 0.9s ease-in-out infinite;
        }

        @keyframes loadingDotPulse{
            0%, 100% {
                transform:scale(0.55);
                opacity:0.55;
            }
            50% {
                transform:scale(1.25);
                opacity:1;
            }
        }

        /* ===== Anti-clone / anti-copy hardening =====
           NOTE: none of this is real security — it only deters casual
           "view source / right-click save / drag image / select text"
           copying from ordinary visitors. Anyone who opens devtools
           network tab or disables JS can still get the markup and assets.
           Use it as a light deterrent, not as content protection. */
        html, body, #app{
            -webkit-user-select:none;
            -moz-user-select:none;
            -ms-user-select:none;
            user-select:none;
            -webkit-touch-callout:none; /* iOS long-press menu */
        }

        /* Still allow selection inside real inputs/textareas so forms work */
        input, textarea, [contenteditable="true"]{
            -webkit-user-select:text;
            -moz-user-select:text;
            -ms-user-select:text;
            user-select:text;
        }

        img{
            -webkit-user-drag:none;
            user-drag:none;
            pointer-events:none; /* blocks right-click "save image as" via drag/context on the image itself */
        }

        /* Buttons/icons that sit on top of images still need clicks */
        img.pp-allow-click{
            pointer-events:auto;
        }

    </style>

</head>

<body class="bg-surface text-gray-900 antialiased" oncontextmenu="return false;" oncopy="return false;" oncut="return false;" ondragstart="return false;">

    <!-- ================= APP ================= -->

    <div id="app"
        class="relative min-h-screen max-w-md mx-auto bg-white overflow-hidden">

        <!-- Header (sticky) — hidden while a bottom-nav tab (card/history/
             profit/wallet) is open, shown again on the home tab -->
        <div id="header" class="sticky top-0 z-30 bg-white"></div>

        <!-- Main -->
        <main class="pb-24 space-y-6">

            <!-- Home tab: dashboard sections -->
            <div id="page-home">

                <div id="wallet"></div>

                <div id="quick-actions"></div>

                <div id="banner"></div>

                <div id="services"></div>

                <div id="kyc"></div>

                <div id="referral"></div>

                <div id="recent-transactions"></div>

                <div id="statistics"></div>

                <div id="notifications"></div>

            </div>

            <!-- Other bottom-nav tabs: card, history, profit, wallet -->
            <div id="page-tab" class="hidden"></div>

        </main>

        <!-- Floating Action Button -->
        <div id="fab"></div>

        <!-- Bottom Navigation -->
        <div id="bottom-nav"></div>

        <!-- Full-screen slide-in panel (airtime, data, bills, etc.) -->
        <div id="fullpage-panel"
            class="fixed inset-0 z-50 bg-white overflow-y-auto">
        </div>

        <!-- Page loading overlay -->
        <div id="page-loading-overlay">
            <div class="loading-dot"></div>
        </div>

    </div>

    <!-- Scripts -->
    <div id="scripts"></div>

    <!-- Vendor JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

    <script>
        AOS.init({
            once: true,
            duration: 500
        });

        // ===== iOS-safe body scroll lock =====
        let lockedScrollY = 0;

        function lockBodyScroll() {

            lockedScrollY = window.scrollY;

            document.body.style.position = 'fixed';
            document.body.style.top = `-${lockedScrollY}px`;
            document.body.style.left = '0';
            document.body.style.right = '0';
            document.body.style.width = '100%';

        }

        function unlockBodyScroll() {

            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.left = '';
            document.body.style.right = '';
            document.body.style.width = '';

            window.scrollTo(0, lockedScrollY);

        }

        // ===== Loading overlay helpers =====
        let loadingRequests = 0;

        function showLoading() {

            loadingRequests++;

            document.getElementById('page-loading-overlay').classList.add('show');

        }

        function hideLoading() {

            loadingRequests = Math.max(0, loadingRequests - 1);

            if (loadingRequests === 0) {
                document.getElementById('page-loading-overlay').classList.remove('show');
            }

        }

        // ===== Re-execute <script> tags found inside injected HTML =====
        function runScripts(container) {

            const scripts = container.querySelectorAll('script');

            scripts.forEach((oldScript) => {

                const newScript = document.createElement('script');

                Array.from(oldScript.attributes).forEach((attr) => {
                    newScript.setAttribute(attr.name, attr.value);
                });

                if (oldScript.src) {
                    newScript.src = oldScript.src;
                } else {
                    newScript.textContent = oldScript.textContent;
                }

                oldScript.replaceWith(newScript);

            });

        }

        // ===== Shared error UI =====
        function notFoundMarkup(closeAction){

            const closeBtn = closeAction
                ? `
                    <button
                        type="button"
                        onclick="${closeAction}"
                        class="absolute top-4 right-4 h-9 w-9 rounded-full bg-gray-100 flex items-center justify-center">
                        <iconify-icon icon="hugeicons:cancel-01" width="18" height="18"></iconify-icon>
                    </button>
                `
                : '';

            return `
                <div class="nf-wrap relative min-h-[70vh] flex flex-col items-center justify-center px-6 text-center">
                    ${closeBtn}
                    <span class="nf-number text-[64px] font-extrabold text-primary leading-none">404</span>
                    <p class="mt-4 text-sm text-gray-500 leading-relaxed max-w-[260px]">
                      Hi, I'm Usefooma — looks like I wandered off. page isn't ready yet.
                    </p>
                </div>
            `;
        }

        // =========================================================
        // ===== Stale-while-revalidate caching for component HTML =====
        // Each piece (wallet.html, header.html, a bottom-nav tab, etc.)
        // is cached in localStorage. On load we render the cached
        // markup instantly (if present) with no loading overlay, then
        // fetch a fresh copy in the background and swap it in only if
        // it actually changed. The overlay only shows the very first
        // time a piece is loaded with nothing cached yet.
        // =========================================================

        const CACHE_PREFIX = 'pp_cache_';

        function getCachedHTML(file) {

            try {

                const raw = localStorage.getItem(CACHE_PREFIX + file);

                return raw ? JSON.parse(raw) : null;

            } catch (error) {

                return null;

            }

        }

        function setCachedHTML(file, html) {

            try {

                localStorage.setItem(
                    CACHE_PREFIX + file,
                    JSON.stringify({ html, ts: Date.now() })
                );

            } catch (error) {

                // Storage full / unavailable (e.g. private browsing) —
                // caching is best-effort, safe to ignore.

            }

        }

        // ===== Load a component (id) from pages/{file} into the DOM =====
        // opts.silent = true -> background refresh: no overlay, no forced
        // re-render unless the fetched HTML actually differs from cache.
        async function loadComponent(id, file, opts = {}) {

            const silent = !!opts.silent;

            const el = document.getElementById(id);

            if (!el) return;

            const cached = getCachedHTML(file);
            const hasCache = !!cached;

            if (hasCache && !silent) {
                el.innerHTML = cached.html;
                runScripts(el);
            }

            if (!hasCache && !silent) {
                showLoading();
            }

            try {

                const response = await fetch(PAGES_URL + file, { cache: 'no-store' });

                if (!response.ok) {
                    throw new Error(`Unable to load ${file}`);
                }

                const html = await response.text();

                if (!cached || html !== cached.html) {
                    el.innerHTML = html;
                    runScripts(el);
                }

                setCachedHTML(file, html);

            } catch (error) {

                console.error(error);

                if (!hasCache) {
                    el.innerHTML = notFoundMarkup(null);
                }

                // If we already had cache, keep showing it silently and
                // just retry on the next background refresh cycle.

            } finally {

                if (!hasCache && !silent) hideLoading();

            }
        }

        // ===== Full-screen slide pages (no bottom nav) =====
        // Call this with the path relative to includes/app/view/, e.g.:
        //   onclick="openFullPage('component/airtime.html')"
        //   onclick="openFullPage('component/convert.html')"
        async function openFullPage(file) {

            const panel = document.getElementById('fullpage-panel');

            const cached = getCachedHTML(file);
            const hasCache = !!cached;

            if (hasCache) {
                panel.innerHTML = cached.html;
                runScripts(panel);
            } else {
                showLoading();
            }

            try {

                const response = await fetch(PLUGIN_VIEW_BASE + file, { cache: 'no-store' });

                if (!response.ok) {
                    throw new Error(`Unable to load ${file}`);
                }

                const html = await response.text();

                if (!cached || html !== cached.html) {
                    panel.innerHTML = html;
                    runScripts(panel);
                }

                setCachedHTML(file, html);

            } catch (error) {

                console.error(error);

                if (!hasCache) {
                    panel.innerHTML = notFoundMarkup("closeFullPage()");
                }

            } finally {

                if (!hasCache) hideLoading();

            }

            panel.classList.add('open');
            lockBodyScroll();

        }

        function closeFullPage() {

            const panel = document.getElementById('fullpage-panel');

            panel.classList.remove('open');
            unlockBodyScroll();

            setTimeout(() => {
                panel.innerHTML = '';
            }, 250);

        }

        // ===== Bottom-nav tab pages (card, history, profit, wallet) =====
        // If these actually live in the "component" folder instead of "pages"
        // on your server, change PAGES_URL below to COMPONENT_URL.
        //
        // The header is intentionally hidden while a tab is open — only
        // the tab content + bottom nav are shown. Home is the only view
        // that shows the header. showHome() brings it back.
        let currentTabFile = null;

        async function loadTab(file, opts = {}) {

            const silent = !!opts.silent;

            currentTabFile = file;

            const home = document.getElementById('page-home');
            const tab = document.getElementById('page-tab');
            const header = document.getElementById('header');

            const cached = getCachedHTML(file);
            const hasCache = !!cached;

            if (hasCache && !silent) {
                tab.innerHTML = cached.html;
                runScripts(tab);
            }

            if (!hasCache && !silent) {
                showLoading();
            }

            try {

                const response = await fetch(PAGES_URL + file, { cache: 'no-store' });

                if (!response.ok) {
                    throw new Error(`Unable to load ${file}`);
                }

                const html = await response.text();

                if (!cached || html !== cached.html) {
                    tab.innerHTML = html;
                    runScripts(tab);
                }

                setCachedHTML(file, html);

            } catch (error) {

                console.error(error);

                if (!hasCache) {
                    tab.innerHTML = notFoundMarkup("showHome()");
                }

            } finally {

                if (!hasCache && !silent) hideLoading();

            }

            // Header stays hidden for every bottom-nav tab — only the
            // tab content and bottom nav remain visible.
            header.classList.add('hidden');

            home.classList.add('hidden');
            tab.classList.remove('hidden');

        }

        function showHome() {

            currentTabFile = null;

            document.getElementById('header').classList.remove('hidden');
            document.getElementById('page-tab').classList.add('hidden');
            document.getElementById('page-tab').innerHTML = '';
            document.getElementById('page-home').classList.remove('hidden');

        }

        // ===== Bottom nav active state =====
        function setActiveNav(clicked) {

            const buttons = document.querySelectorAll('#bottomNavGrid .nav-btn');

            buttons.forEach(function (btn) {

                const iconWrap = btn.querySelector('.nav-icon-wrap');
                const icon = btn.querySelector('.nav-icon');
                const label = btn.querySelector('.nav-label');

                iconWrap.classList.remove('bg-white/15');
                icon.classList.remove('text-white');
                icon.classList.add('text-white/70');
                label.classList.remove('text-white', 'font-semibold');
                label.classList.add('text-white/70', 'font-medium');

            });

            const iconWrap = clicked.querySelector('.nav-icon-wrap');
            const icon = clicked.querySelector('.nav-icon');
            const label = clicked.querySelector('.nav-label');

            iconWrap.classList.add('bg-white/15');
            icon.classList.remove('text-white/70');
            icon.classList.add('text-white');
            label.classList.remove('text-white/70', 'font-medium');
            label.classList.add('text-white', 'font-semibold');

        }

        // =========================================================
        // ===== Silent background auto-refresh =====
        // Every AUTO_REFRESH_INTERVAL ms, silently re-fetch whatever is
        // currently visible (always the header/bottom-nav/fab chrome,
        // plus either the home sections or the open tab) and swap in
        // fresh markup only if it changed. Never shows the loading
        // overlay and never fires while a full-screen panel is open on
        // top, since that panel owns the view at that point.
        // =========================================================

        const AUTO_REFRESH_INTERVAL = 30000; // 30s

        const CHROME_COMPONENTS = [
            ["header", "header.html"],
            ["bottom-nav", "bottom-nav.html"],
            ["fab", "fab.html"],
        ];

        const HOME_COMPONENTS = [
            ["wallet", "wallet.html"],
            ["quick-actions", "quick-actions.html"],
            ["banner", "banner.html"],
            ["services", "services.html"],
            ["kyc", "kyc.html"],
            ["referral", "referral.html"],
            ["recent-transactions", "recent-transactions.html"],
            ["statistics", "statistics.html"],
            ["notifications", "notifications.html"],
        ];

        function refreshVisible() {

            const panel = document.getElementById('fullpage-panel');

            if (panel.classList.contains('open')) return;

            CHROME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file, { silent: true }));

            const home = document.getElementById('page-home');

            if (!home.classList.contains('hidden')) {
                HOME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file, { silent: true }));
            } else if (currentTabFile) {
                loadTab(currentTabFile, { silent: true });
            }

        }

        let autoRefreshTimer = null;

        function startAutoRefresh() {

            stopAutoRefresh();
            autoRefreshTimer = setInterval(refreshVisible, AUTO_REFRESH_INTERVAL);

        }

        function stopAutoRefresh() {

            if (autoRefreshTimer) {
                clearInterval(autoRefreshTimer);
                autoRefreshTimer = null;
            }

        }

        // Pause background refresh while the tab/app isn't visible (saves
        // battery + data), and refresh immediately when the user returns.
        document.addEventListener('visibilitychange', () => {

            if (document.hidden) {
                stopAutoRefresh();
            } else {
                refreshVisible();
                startAutoRefresh();
            }

        });

        // =========================================================
        // NOTE: The old fetchPulsepointUser()/loadWalletBalance()/
        // ensureVirtualAccount() helpers and the window.pulsepointUser
        // token bootstrap have been removed from dashboard.php.
        // Each page/component (wallet.html, kyc.html, etc.) now calls
        // site_url('/api/user') on its own, with its own token handling,
        // so dashboard.php no longer needs to know about that endpoint
        // at all — it's just loading markup shells.
        // =========================================================

        document.addEventListener("DOMContentLoaded", () => {

            CHROME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file));
            HOME_COMPONENTS.forEach(([id, file]) => loadComponent(id, file));

            // scripts.html is a one-time include, not refreshed in the
            // background — re-running it on every cycle would re-declare
            // globals / re-attach listeners each time.
            loadComponent("scripts", "scripts.html");

            startAutoRefresh();

        });

        // ===== Anti-clone / anti-copy JS deterrents =====
        // Again: these only stop casual copying, not a determined user
        // with devtools. Right-click, copy/cut, and image dragging are
        // already blocked via the body attributes + CSS above; this adds
        // a keyboard-shortcut layer (view-source, save-page, print,
        // devtools) and a text-selection guard as backup.
        document.addEventListener('selectstart', (e) => {
            const tag = e.target.tagName;
            if (tag !== 'INPUT' && tag !== 'TEXTAREA') e.preventDefault();
        });

        document.addEventListener('keydown', (e) => {

            const key = e.key.toUpperCase();
            const blockedCombo =
                (e.ctrlKey || e.metaKey) && ['U', 'S', 'P', 'C'].includes(key) ||
                (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(key)) ||
                key === 'F12';

            if (blockedCombo) {
                e.preventDefault();
            }

        });
    </script>

    <!--
        Controller scripts have been removed from here on purpose.
        Each component page (e.g. pages/airtime.html, pages/data.html,
        pages/convert.html) now owns its own <script> block inline in its
        own file. runScripts() above automatically executes that script
        the moment the markup is injected into the DOM.
    -->

</body>

</html>