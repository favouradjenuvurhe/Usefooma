<?php
/**
 * Pulsepoint Signup View
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/../index.php';

// Fixed prefixes per the current router: /auth/{route} and /dashboard
$pp_login_url     = home_url('/auth/login');
$pp_dashboard_url = home_url('/dashboard');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($page_title); ?></title>

    <!-- SEO -->
    <meta name="description" content="Create your account">
    <meta name="theme-color" content="<?php echo esc_attr($color_hex); ?>">

    <!-- Favicon -->
    <link rel="icon" href="<?php echo esc_url($page_favicon); ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: "<?php echo esc_js($color_hex); ?>",
                        secondary: "#111827",
                        success: "#16A34A",
                        warning: "#F59E0B",
                        danger: "#DC2626",
                        surface: "#F8FAFC"
                    }
                }
            }
        };
    </script>

    <!-- Hugeicons -->
    <script src="https://cdn.jsdelivr.net/npm/@hugeicons/core@latest/dist/hugeicons.min.js"></script>

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <!-- Alpine JS -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            background: #F8FAFC;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        html, body {
            height: 100%;
            overscroll-behavior: none;
            -webkit-text-size-adjust: 100%;
        }

        .btn-primary {
            background: #f85902;
            color: #fff;
        }

        .fa-spin {
            animation: faSpin 0.8s linear infinite;
        }

        @keyframes faSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

    </style>

</head>

<body class="bg-surface" x-data="signupForm()">

    <!-- Toast container -->
    <div id="toast-container"
         class="fixed top-4 inset-x-0 z-50 flex flex-col items-center gap-2 px-4 pointer-events-none"></div>

    <div class="min-h-screen flex flex-col">

        <!-- Header block -->
        <div class="bg-gray-100 px-6 pt-10 pb-8">

            <button type="button"
                    onclick="window.history.back()"
                    class="h-9 w-9 rounded-lg border border-gray-300 flex items-center justify-center text-gray-700 mb-5">
                <iconify-icon icon="hugeicons:arrow-left-01" width="14" height="14"></iconify-icon>
            </button>

            <h1 class="text-xl font-bold text-gray-900">Create account</h1>
            <p class="text-sm text-gray-400 mt-1">Sign up to get started</p>

        </div>

        <!-- Body -->
        <div class="flex-1 flex flex-col px-6 pt-6 pb-8">

            <form @submit.prevent="register" class="flex-1 flex flex-col">

                <div class="space-y-3">

                    <!-- First name + Last name, same row -->
                    <div class="flex items-center gap-3">

                        <div class="flex-1 flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                            <iconify-icon icon="hugeicons:user" width="16" height="16" class="text-gray-400"></iconify-icon>
                            <input type="text"
                                   x-model="form.firstname"
                                   required
                                   autocomplete="given-name"
                                   aria-label="First name"
                                   class="flex-1 w-full min-w-0 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                                   placeholder="First name">
                        </div>

                        <div class="flex-1 flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                            <iconify-icon icon="hugeicons:user" width="16" height="16" class="text-gray-400"></iconify-icon>
                            <input type="text"
                                   x-model="form.lastname"
                                   required
                                   autocomplete="family-name"
                                   aria-label="Last name"
                                   class="flex-1 w-full min-w-0 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                                   placeholder="Last name">
                        </div>

                    </div>

                    <!-- Email -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:mail-01" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input type="email"
                               x-model="form.email"
                               required
                               autocomplete="email"
                               aria-label="Email"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                               placeholder="Email">
                    </div>

                    <!-- Phone -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:smart-phone-01" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input type="tel"
                               x-model="form.phone"
                               required
                               inputmode="numeric"
                               autocomplete="tel"
                               aria-label="Phone number"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                               placeholder="Phone number">
                    </div>

                    <!-- Password -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:square-lock-02" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input :type="showPassword ? 'text' : 'password'"
                               x-model="form.password"
                               required
                               minlength="6"
                               autocomplete="new-password"
                               aria-label="Password"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                               placeholder="Password">
                        <button type="button" @click="showPassword = !showPassword" class="text-gray-400">
                            <iconify-icon :icon="showPassword ? 'hugeicons:view' : 'hugeicons:view-off-slash'" width="16" height="16"></iconify-icon>
                        </button>
                    </div>

                    <!-- Transaction PIN -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:security-lock" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input :type="showPin ? 'text' : 'password'"
                               x-model="form.pin"
                               required
                               maxlength="4"
                               inputmode="numeric"
                               pattern="[0-9]*"
                               autocomplete="off"
                               aria-label="Transaction PIN"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400 tracking-widest"
                               placeholder="4-digit transaction PIN">
                        <button type="button" @click="showPin = !showPin" class="text-gray-400">
                            <iconify-icon :icon="showPin ? 'hugeicons:view' : 'hugeicons:view-off-slash'" width="16" height="16"></iconify-icon>
                        </button>
                    </div>

                    <!-- Referral code -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:gift" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input type="text"
                               x-model="form.refer"
                               autocomplete="off"
                               aria-label="Referral code"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                               placeholder="Referral code (optional)">
                    </div>

                    <!-- Create account -->
<button
    type="submit"
    :disabled="loading"
    class="w-full bg-primary text-white rounded-full py-3.5 text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed mt-4">
    
    <iconify-icon
        icon="hugeicons:reload"
        width="14"
        height="14"
        class="fa-spin"
        x-show="loading">
    </iconify-icon>

    <span x-text="loading ? 'Please wait...' : 'Create account'"></span>
</button>

                    <!-- Sign in -->
                    <p class="text-center text-xs text-gray-600 mt-5">
                        Already have an account?
                        <a href="<?php echo esc_url($pp_login_url); ?>" class="text-primary font-bold">Sign in</a>
                    </p>

                </div>

            </form>

        </div>

    </div>

    <script>
        // ---- Toast system ----
        function showToast(message, type = 'success') {
            const colors = {
                success: { bg: 'bg-green-50', border: 'border-green-300', text: 'text-green-700', icon: 'hugeicons:checkmark-circle-02' },
                error:   { bg: 'bg-red-50',   border: 'border-red-300',   text: 'text-red-700',   icon: 'hugeicons:cancel-circle' },
                warning: { bg: 'bg-yellow-50',border: 'border-yellow-300',text: 'text-yellow-700', icon: 'hugeicons:alert-02' }
            };

            const style = colors[type] || colors.success;
            const container = document.getElementById('toast-container');

            if (!container) return;

            const toast = document.createElement('div');
            toast.className = `pointer-events-auto flex items-center gap-2 ${style.bg} ${style.border} ${style.text} border rounded-xl px-4 py-3 shadow-lg text-sm font-medium max-w-sm w-full transition-all duration-300 ease-out opacity-0 -translate-y-4`;
            toast.innerHTML = `
                <iconify-icon icon="${style.icon}" width="18" class="shrink-0"></iconify-icon>
                <span class="flex-1">${message}</span>
            `;

            container.appendChild(toast);

            requestAnimationFrame(() => {
                toast.classList.remove('opacity-0', '-translate-y-4');
            });

            setTimeout(() => {
                toast.classList.add('opacity-0', '-translate-y-4');
                setTimeout(() => toast.remove(), 300);
            }, 3500);
        }

        // ---- Signup form ----
        function signupForm() {
            return {
                loading: false,
                showPassword: false,
                showPin: false,
                form: {
                    firstname: '',
                    lastname: '',
                    email: '',
                    phone: '',
                    password: '',
                    pin: '',
                    refer: '',
                },

                async register() {
                    const f = this.form;

                    if (!f.firstname.trim() || !f.lastname.trim() || !f.phone.trim() || !f.password) {
                        showToast('First name, last name, phone and password are required', 'error');
                        return;
                    }

                    if (f.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.trim())) {
                        showToast('Enter a valid email address', 'warning');
                        return;
                    }

                    if (f.password.length < 6) {
                        showToast('Password must be at least 6 characters', 'warning');
                        return;
                    }

                    if (!/^\d{4}$/.test(f.pin)) {
                        showToast('Enter a 4-digit transaction PIN', 'warning');
                        return;
                    }

                    this.loading = true;

                    const fd = new FormData();
                    fd.append('action', 'pulsepoint_user_register');
                    fd.append('firstname', f.firstname.trim());
                    fd.append('lastname', f.lastname.trim());
                    fd.append('phone', f.phone.trim());
                    fd.append('email', f.email.trim());
                    fd.append('password', f.password);
                    fd.append('passcode', f.pin);
                    fd.append('refer', f.refer.trim());

                    try {
                        const res = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                            method: 'POST',
                            body: fd,
                            credentials: 'same-origin',
                        });

                        const data = await res.json();
                        this.loading = false;

                        if (data.success) {
                            showToast(data.message || 'Account created', 'success');

                            if (data.user) {
                                localStorage.setItem('auth-token', data.user.token);
                                localStorage.setItem('transaction-pin', data.user.passcode);
                                localStorage.setItem('pulsepoint-user', JSON.stringify(data.user));
                            }

                            const redirectTo = data.redirect || '<?php echo esc_url($pp_dashboard_url); ?>';

                            setTimeout(() => {
                                window.location.href = redirectTo;
                            }, 600);
                        } else {
                            showToast(data.message || 'Registration failed', 'error');
                        }
                    } catch (err) {
                        this.loading = false;
                        showToast('Network error, please try again', 'error');
                    }
                },
            };
        }
    </script>

</body>
</html>
