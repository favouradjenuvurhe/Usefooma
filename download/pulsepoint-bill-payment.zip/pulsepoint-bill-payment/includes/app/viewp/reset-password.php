<?php
/**
 * Pulsepoint Reset Password View
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/../index.php';

// Fixed prefixes per the current router: /auth/{route} and /dashboard
$pp_login_url     = home_url('/auth/login');
$pp_recovery_url  = home_url('/auth/recovery');
$pp_dashboard_url = home_url('/dashboard');

// Token comes in via ?token=... on /auth/reset-password
$pp_token = isset($_GET['token']) ? sanitize_text_field(wp_unslash($_GET['token'])) : '';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($page_title); ?></title>

    <!-- SEO -->
    <meta name="description" content="Reset your account password">
    <meta name="theme-color" content="<?php echo esc_attr($color_hex); ?>">

    <!-- Favicon -->
    <link rel="icon" href="<?php echo esc_url($page_favicon); ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: "<?php echo esc_js($color_hex); ?>",
                        secondary: "#111827",
                        success: "#16A34A",
                        warning: "#F59E0B",
                        danger: "#DC2626",
                        surface: "#F8FAFC"
                    }
                }
            }
        };
    </script>

    <!-- Hugeicons -->
    <script src="https://cdn.jsdelivr.net/npm/@hugeicons/core@latest/dist/hugeicons.min.js"></script>

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <!-- Alpine JS -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            background: #F8FAFC;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        html, body {
            height: 100%;
            overscroll-behavior: none;
            -webkit-text-size-adjust: 100%;
        }

        .btn-primary {
            background: #f85902;
            color: #fff;
        }

        .fa-spin {
            animation: faSpin 0.8s linear infinite;
        }

        @keyframes faSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

    </style>

</head>

<body class="bg-surface" x-data="resetPasswordForm()">

    <!-- Toast container -->
    <div id="toast-container"
         class="fixed top-4 inset-x-0 z-50 flex flex-col items-center gap-2 px-4 pointer-events-none"></div>

    <div class="min-h-screen flex flex-col">

        <!-- Header block -->
        <div class="bg-gray-100 px-6 pt-10 pb-8">

            <button type="button"
                    onclick="window.history.back()"
                    class="h-9 w-9 rounded-lg border border-gray-300 flex items-center justify-center text-gray-700 mb-5">
                <iconify-icon icon="hugeicons:arrow-left-01" width="14" height="14"></iconify-icon>
            </button>

            <h1 class="text-xl font-bold text-gray-900">Reset password</h1>
            <p class="text-sm text-gray-400 mt-1">Create a new password for your account</p>

        </div>

        <!-- Body -->
        <div class="flex-1 flex flex-col px-6 pt-6 pb-8">

            <template x-if="!token">
                <div class="flex-1 flex flex-col items-center justify-center text-center gap-3 px-4">
                    <iconify-icon icon="hugeicons:alert-02" width="28" height="28" class="text-danger"></iconify-icon>
                    <p class="text-sm text-gray-600">This reset link is invalid or missing a token.</p>
                    <a href="<?php echo esc_url($pp_recovery_url); ?>" class="text-primary font-bold text-sm">Request a new link</a>
                </div>
            </template>

            <form x-show="token" @submit.prevent="submit" class="flex-1 flex flex-col">

                <div class="space-y-3">

                    <!-- New password -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:square-lock-02" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input :type="showPassword ? 'text' : 'password'"
                               x-model="password"
                               required
                               autocomplete="new-password"
                               aria-label="New password"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                               placeholder="New password">
                        <button type="button" @click="showPassword = !showPassword" class="text-gray-400">
                            <iconify-icon :icon="showPassword ? 'hugeicons:view' : 'hugeicons:view-off-slash'" width="16" height="16"></iconify-icon>
                        </button>
                    </div>

                    <!-- Confirm password -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:square-lock-02" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input :type="showConfirmPassword ? 'text' : 'password'"
                               x-model="confirm_password"
                               required
                               autocomplete="new-password"
                               aria-label="Confirm new password"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400"
                               placeholder="Confirm password">
                        <button type="button" @click="showConfirmPassword = !showConfirmPassword" class="text-gray-400">
                            <iconify-icon :icon="showConfirmPassword ? 'hugeicons:view' : 'hugeicons:view-off-slash'" width="16" height="16"></iconify-icon>
                        </button>
                    </div>

                    <!-- Continue -->
                    <button
                        type="submit"
                        :disabled="loading"
                        class="w-full bg-primary text-white rounded-full py-3.5 text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed mt-4">
                        <iconify-icon icon="hugeicons:reload" width="14" height="14" class="fa-spin" x-show="loading"></iconify-icon>
                        <span x-text="loading ? 'Please wait...' : 'Reset password'"></span>
                    </button>

                    <!-- Back to login -->
                    <p class="text-center text-xs text-gray-600 mt-5">
                        Remembered your password?
                        <a href="<?php echo esc_url($pp_login_url); ?>" @click.prevent="goLogin" class="text-primary font-bold">Sign in</a>
                    </p>

                </div>

            </form>

        </div>

    </div>

    <script>
        // ---- Toast system ----
        function showToast(message, type = 'success') {
            const colors = {
                success: { bg: 'bg-green-50', border: 'border-green-300', text: 'text-green-700', icon: 'hugeicons:checkmark-circle-02' },
                error:   { bg: 'bg-red-50',   border: 'border-red-300',   text: 'text-red-700',   icon: 'hugeicons:cancel-circle' },
                warning: { bg: 'bg-yellow-50',border: 'border-yellow-300',text: 'text-yellow-700', icon: 'hugeicons:alert-02' }
            };

            const style = colors[type] || colors.success;
            const container = document.getElementById('toast-container');

            if (!container) return;

            const toast = document.createElement('div');
            toast.className = `pointer-events-auto flex items-center gap-2 ${style.bg} ${style.border} ${style.text} border rounded-xl px-4 py-3 shadow-lg text-sm font-medium max-w-sm w-full transition-all duration-300 ease-out opacity-0 -translate-y-4`;
            toast.innerHTML = `
                <iconify-icon icon="${style.icon}" width="18" class="shrink-0"></iconify-icon>
                <span class="flex-1">${message}</span>
            `;

            container.appendChild(toast);

            requestAnimationFrame(() => {
                toast.classList.remove('opacity-0', '-translate-y-4');
            });

            setTimeout(() => {
                toast.classList.add('opacity-0', '-translate-y-4');
                setTimeout(() => toast.remove(), 300);
            }, 3500);
        }

        // ---- Reset password form ----
        function resetPasswordForm() {
            return {
                loading: false,
                showPassword: false,
                showConfirmPassword: false,
                password: '',
                confirm_password: '',
                token: '<?php echo esc_js($pp_token); ?>',

                submit() {
                    if (!this.password || !this.confirm_password) {
                        showToast('All fields are required', 'error');
                        return;
                    }

                    if (this.password !== this.confirm_password) {
                        showToast('Passwords do not match', 'error');
                        return;
                    }

                    this.loading = true;

                    const formData = new FormData();
                    formData.append('action', 'pulsepoint_reset_password');
                    formData.append('token', this.token);
                    formData.append('password', this.password);

                    fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(res => res.json())
                    .then(res => {
                        this.loading = false;
                        if (res.success) {
                            showToast(res.message);
                            setTimeout(() => window.location.href = '<?php echo esc_url($pp_login_url); ?>', 1200);
                        } else {
                            showToast(res.message, 'error');
                        }
                    })
                    .catch(() => {
                        this.loading = false;
                        showToast('Network error, please try again', 'error');
                    });
                },

                goLogin() {
                    window.location.href = '<?php echo esc_url($pp_login_url); ?>';
                }
            };
        }
    </script>

</body>
</html>
