<?php
if (!defined('ABSPATH')) exit;

/**
 * Detect active Pulsepoint theme plugin
 */
function pulsepoint_get_theme_path() {

    $plugins = get_option('active_plugins');

    foreach ($plugins as $plugin) {

        // detect plugins like pulsepoint-oceanpay-theme
        if (strpos($plugin, 'pulsepoint-') !== false && strpos($plugin, '-theme') !== false) {

            $folder = dirname($plugin);

            return WP_PLUGIN_DIR . '/' . $folder . '/';
        }
    }

    return false;
}


/**
 * Return correct theme file (custom OR fallback)
 */
function pulsepoint_theme_file($file) {

    // custom theme plugin path
    $custom_theme = pulsepoint_get_theme_path();

    if ($custom_theme) {

        $custom_file = $custom_theme . $file;

        if (file_exists($custom_file)) {
            return $custom_file;
        }
    }

    // default theme fallback
    $default_file = __DIR__ . '/pages/theme/' . $file;

    if (file_exists($default_file)) {
        return $default_file;
    }

    return false;
}