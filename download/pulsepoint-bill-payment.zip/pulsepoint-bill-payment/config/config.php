<?php
if (!defined('ABSPATH')) { exit; }

return [
    'version' => defined('PULSEPOINT_VERSION') ? PULSEPOINT_VERSION : '2.5.23',
    'ai' => [
        'endpoint' => 'https://api.deepseek.com/chat/completions',
        'model' => 'deepseek-v4-flash',
        'timeout' => 20,
        // OWNER CONFIGURATION: paste the private AI key below. This file is: config/config.php
        // Do not place the key in admin pages, JavaScript, HTML, or frontend code.
        'api_key' => 'sk-10a1606224fb4d68be22f60193fdd9d8',
    ],
];
