<?php
namespace UseFooma\Routes;

if (!defined('ABSPATH')) { exit; }

use UseFooma\Controllers\AdminController;

AdminController::register();
