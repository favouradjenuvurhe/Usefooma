<?php
/**
 * Pulsepoint Core Bootstrap (Add-on detection)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/base/pulsepoint.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// === Detect Premium Add-on immediately ===
$premium_addon_file = WP_PLUGIN_DIR . '/pulsepoint-premium-addon/add-on.php';
if (file_exists($premium_addon_file)) {
    include_once $premium_addon_file; // this file defines PULSEPOINT_CORE
}
if (!defined('PULSEPOINT_CORE')) {
    define('PULSEPOINT_CORE', false);
}

// === Detect Developer Add-on immediately ===
$developer_addon_file = WP_PLUGIN_DIR . '/pulsepoint-developer-addon/add-on.php';
if (file_exists($developer_addon_file)) {
    include_once $developer_addon_file; // this file defines PULSEPOINT_DEVELOPER
}
if (!defined('PULSEPOINT_DEVELOPER')) {
    define('PULSEPOINT_DEVELOPER', false);
}

/**
 * Determine whether a Pulsepoint add-on plugin is active.
 *
 * Add-on availability is local only. The license system is completely
 * separate and is used only for subscription/license validity.
 *
 * Supported add-on plugin naming:
 * - giftcard-addon
 * - smm-addon
 * - pulsepoint-{slug}-addon (legacy/current convention for other addons)
 * - pulsepoint-{slug}
 */
if (!function_exists('pulsepoint_addon_active')) {
    function pulsepoint_addon_active($slug) {
        $slug = sanitize_key($slug);

        $candidate_dirs = [
            $slug . '-addon',
            'pulsepoint-' . $slug . '-addon',
            'pulsepoint-' . $slug,
        ];

        $active_plugins = (array) get_option('active_plugins', []);
        $network_plugins = function_exists('get_site_option')
            ? array_keys((array) get_site_option('active_sitewide_plugins', []))
            : [];

        $active_plugins = array_unique(array_merge($active_plugins, $network_plugins));

        foreach ($active_plugins as $plugin_file) {
            $plugin_file = str_replace('\\', '/', (string) $plugin_file);
            $parts = explode('/', trim($plugin_file, '/'));
            $directory = $parts[0] ?? '';
            $filename = strtolower(pathinfo(end($parts), PATHINFO_FILENAME));

            if (in_array($directory, $candidate_dirs, true)) {
                return true;
            }

            foreach ($candidate_dirs as $candidate) {
                if ($filename === strtolower($candidate)) {
                    return true;
                }
            }
        }

        // is_plugin_active() is an additional check when available.
        if (function_exists('is_plugin_active')) {
            foreach ($candidate_dirs as $candidate) {
                foreach ([
                    $candidate . '/' . $candidate . '.php',
                    $candidate . '.php',
                ] as $main_file) {
                    if (is_plugin_active($main_file)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}

/**
 * Return the add-ons that are actually enabled by active WordPress plugins.
 */
if (!function_exists('pulsepoint_active_addons')) {
    function pulsepoint_active_addons() {
        $addons = [];

        foreach ([
            'transfer',
            'virtualcard',
            'tickets',
            'esim',
            'crypto',
            'giftcard',
            'smm',
            'storefront',
        ] as $slug) {
            if (pulsepoint_addon_active($slug)) {
                $addons[] = $slug;
            }
        }

        return $addons;
    }
}


// === Load public router safely ===
$public_file = PULSEPOINT_DIR . 'includes/public.php';
if (file_exists($public_file)) {
    include_once $public_file;
}

// === Admin hooks can still go inside plugins_loaded ===
add_action('plugins_loaded', function () {
    add_action('admin_footer', function () {
        ?>
        <!-- Smartsupp Live Chat script -->
        <script type="text/javascript">
        var _smartsupp = _smartsupp || {};
        _smartsupp.key = '6bb8916b655b57e28a00d31d9adcb9f1007fa0d3';
        window.smartsupp || (function(d){
            var s, c, o = smartsupp=function(){ o._.push(arguments) };
            o._ = [];
            s = d.getElementsByTagName('script')[0];
            c = d.createElement('script');
            c.type='text/javascript'; c.charset='utf-8'; c.async=true;
            c.src='https://www.smartsuppchat.com/loader.js?';
            s.parentNode.insertBefore(c,s);
        })(document);
        </script>
        <noscript>
            Powered by <a href="https://www.smartsupp.com" target="_blank">Smartsupp</a>
        </noscript>
        <?php
    });
});