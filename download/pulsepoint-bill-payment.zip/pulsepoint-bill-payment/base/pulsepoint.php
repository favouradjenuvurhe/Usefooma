<?php
/**
 * Pulsepoint Core Bootstrap (Add-on detection)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/base/pulsepoint.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// === Detect Premium Add-on immediately ===
$premium_addon_file = WP_PLUGIN_DIR . '/pulsepoint-premium-addon/add-on.php';
if (file_exists($premium_addon_file)) {
    include_once $premium_addon_file; // this file defines PULSEPOINT_CORE
}
if (!defined('PULSEPOINT_CORE')) {
    define('PULSEPOINT_CORE', false);
}

// === Detect Developer Add-on immediately ===
$developer_addon_file = WP_PLUGIN_DIR . '/pulsepoint-developer-addon/add-on.php';
if (file_exists($developer_addon_file)) {
    include_once $developer_addon_file; // this file defines PULSEPOINT_DEVELOPER
}
if (!defined('PULSEPOINT_DEVELOPER')) {
    define('PULSEPOINT_DEVELOPER', false);
}

// === Load public router safely ===
$public_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/includes/public.php';
if (file_exists($public_file)) {
    include_once $public_file;
}

// === Admin hooks can still go inside plugins_loaded ===
add_action('plugins_loaded', function () {
    add_action('admin_footer', function () {
        ?>
        <!-- Smartsupp Live Chat script -->
        <script type="text/javascript">
        var _smartsupp = _smartsupp || {};
        _smartsupp.key = '6bb8916b655b57e28a00d31d9adcb9f1007fa0d3';
        window.smartsupp || (function(d){
            var s, c, o = smartsupp=function(){ o._.push(arguments) };
            o._ = [];
            s = d.getElementsByTagName('script')[0];
            c = d.createElement('script');
            c.type='text/javascript'; c.charset='utf-8'; c.async=true;
            c.src='https://www.smartsuppchat.com/loader.js?';
            s.parentNode.insertBefore(c,s);
        })(document);
        </script>
        <noscript>
            Powered by <a href="https://www.smartsupp.com" target="_blank">Smartsupp</a>
        </noscript>
        <?php
    });
});