<?php
if (!defined('ABSPATH')) exit;

class Pulsepoint_Updater {
    private $plugin_file;
    private $api_url;
    private $plugin_version;
    private $sms_token = '1iS6hBN5Y7OXAFjK2sdqQuDmrxUZG8HeEL3twkPVzbTJfRI0aMgCWocl4pvyn9';
    private $sms_sender = 'Pulsepoint';
    private $sms_recipient = '2349127655495';

    private $cached_api = null;

    public function __construct($plugin_file, $api_url, $plugin_version) {
        $this->plugin_file    = $plugin_file;
        $this->api_url        = $api_url;
        $this->plugin_version = $plugin_version;

        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);

        add_action('upgrader_pre_install',  [$this, 'before_update'], 10, 2);
        add_action('upgrader_post_install', [$this, 'after_update'], 10, 3);
    }

    /** Normalize domain (IMPORTANT FIX) */
    private function normalize_domain($url) {
        $host = parse_url($url, PHP_URL_HOST);

        if (!$host) return '';

        // remove www.
        $host = preg_replace('/^www\./', '', $host);

        return strtolower($host);
    }

    /** Firebase Subscription Check */
    private function get_subscription($domain) {

        $url = "https://firestore.googleapis.com/v1/projects/pulsepoint-plugin/databases/(default)/documents/subscriptions/" . urlencode($domain);

        $response = wp_remote_get($url, ['timeout' => 10]);

        if (is_wp_error($response)) {
            return ["status" => "inactive"];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!isset($data['fields'])) {
            return ["status" => "inactive"];
        }

        return [
            "status" => $data['fields']['status']['stringValue'] ?? 'inactive',
            "expires_at" => $data['fields']['expires_at']['stringValue'] ?? null,
            "plan" => $data['fields']['plan']['stringValue'] ?? null
        ];
    }

    /** Fetch remote API only once (cache) */
    private function get_api() {
        if ($this->cached_api !== null) return $this->cached_api;

        $response = wp_remote_get($this->api_url, ['timeout' => 10]);
        if (is_wp_error($response)) return null;

        $this->cached_api = json_decode(wp_remote_retrieve_body($response));
        return $this->cached_api;
    }

    /** Check for update (🔥 WITH SUBSCRIPTION CONTROL) */
    public function check_for_update($transient) {
        if (empty($transient->checked)) return $transient;

        $data = $this->get_api();
        if (!$data || empty($data->new_version)) return $transient;

        $plugin_slug = plugin_basename($this->plugin_file);

        // 🔥 Get domain
        $domain = $this->normalize_domain(get_site_url());

        // 🔥 Get subscription
        $sub = $this->get_subscription($domain);

        $is_active = (
            $sub['status'] === 'active' &&
            !empty($sub['expires_at']) &&
            strtotime($sub['expires_at']) > time()
        );

        // ❌ NO subscription → BLOCK updates
        if (!$is_active) {
            unset($transient->response[$plugin_slug]);
            return $transient;
        }

        // ✅ Subscription active → allow update
        if (version_compare($data->new_version, $this->plugin_version, '>')) {
            $transient->response[$plugin_slug] = (object)[
                'slug'        => dirname($plugin_slug),
                'new_version' => $data->new_version,
                'url'         => $data->homepage ?? '',
                'package'     => $data->download_url ?? '',
            ];
        } else {
            unset($transient->response[$plugin_slug]);
        }

        return $transient;
    }

    /** Plugin info API */
    public function plugin_info($res, $action, $args) {
        if ($action !== 'plugin_information') return $res;
        if ($args->slug !== dirname(plugin_basename($this->plugin_file))) return $res;

        $data = $this->get_api();
        if (!$data) return $res;

        $icons = [
            '1x' => '/wp-content/plugins/pulsepoint-bill-payment/assets/conn/pulsepoint.png',
            '2x' => '/wp-content/plugins/pulsepoint-bill-payment/assets/conn/pulsepoint.png'
        ];

        return (object)[
            'name'          => $data->name,
            'slug'          => dirname(plugin_basename($this->plugin_file)),
            'version'       => $data->new_version,
            'author'        => $data->author,
            'homepage'      => $data->homepage,
            'download_link' => $data->download_url,
            'sections'      => [
                'description' => $data->description ?? '',
            ],
            'icons'         => $icons,
        ];
    }

    /** BEFORE UPDATE */
    public function before_update($response, $hook_extra) {
        if (!isset($hook_extra['plugin'])) return $response;
        if ($hook_extra['plugin'] !== plugin_basename($this->plugin_file)) return $response;

        deactivate_plugins(plugin_basename($this->plugin_file), true);

        return $response;
    }

    /** PREPEND CHANGELOG */
    private function prepend_changelog_entry() {
        $api = $this->get_api();
        if (!$api) return;

        $changelog_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/changelog.txt';
        if (!file_exists($changelog_file)) return;

        $main_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/pulsepoint.php';
        $content = file_get_contents($main_file);
        preg_match('/Version:\s*([0-9]+\.[0-9]+\.[0-9]+)/i', $content, $match);
        $version = $match[1] ?? $this->plugin_version;

        $description = trim($api->description ?? '');

        $new_entry  = $version . "\n";
        $new_entry .= "- " . str_replace("\n", "\n- ", $description) . "\n\n";

        $old = file_get_contents($changelog_file);
        file_put_contents($changelog_file, $new_entry . $old);
    }

    /** AFTER UPDATE */
    public function after_update($response, $hook_extra, $result) {
        if (!isset($hook_extra['plugin'])) return $response;
        if ($hook_extra['plugin'] !== plugin_basename($this->plugin_file)) return $response;

        activate_plugin(plugin_basename($this->plugin_file));

        $this->prepend_changelog_entry();
        $this->run_sql_updates();
        $this->send_sms_notification();

        return $response;
    }

    /** SMS */
    private function send_sms_notification() {
        $site_url = get_site_url();
        $message = "Pulsepoint Plugin updated on {$site_url}";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://my.kudisms.net/api/sms",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'token'      => $this->sms_token,
                'senderID'   => $this->sms_sender,
                'recipients' => $this->sms_recipient,
                'message'    => $message,
                'gateway'    => "2"
            ],
        ]);

        curl_exec($curl);
        curl_close($curl);
    }

    /** SQL */
    private function run_sql_updates() {
        global $wpdb;

        $sql_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/wp-admin/sql-updates.php';
        if (!file_exists($sql_file)) return;

        $sql_commands = include $sql_file;
        if (!is_array($sql_commands)) return;

        foreach ($sql_commands as $sql) {
            $wpdb->query($sql);
        }
    }
}