<?php
if (!defined('ABSPATH')) exit;
require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';

/**
 * Poll pending Topupmate giftcard orders and attach released redemption
 * codes/PINs to the original UseFooma transaction. The provider reference
 * is passed to the redeem endpoint so a code can never be assigned to the
 * wrong customer/order.
 */
add_action('pulsepoint_cron_giftcard_redeem_sync', function () {
    if (usefooma_topupmate_api_key() === '') return;
    global $wpdb;
    $tx = $wpdb->prefix . 'pulsepoint_giftcard_transactions';
    $rows = $wpdb->get_results("SELECT * FROM {$tx} WHERE transaction_type='purchase' AND status='pending' ORDER BY id ASC LIMIT 25");
    if (!$rows) return;

    foreach ($rows as $row) {
        $meta = json_decode($row->note, true);
        if (!is_array($meta) || ($meta['source'] ?? '') !== 'topupmate') continue;
        $res = usefooma_topupmate_redeem((string) $row->reference);
        if (!$res['ok']) continue;
        $d = usefooma_topupmate_extract_redeem($res['data']);
        $has_code = ($d['redeem'] !== '' || $d['card_number'] !== '' || $d['pin_code'] !== '');
        $meta['status'] = $d['status'] ?: ($meta['status'] ?? 'pending');
        $meta['redeem_id'] = $d['redeem_id'];
        $meta['redeem_instructions'] = $d['redeem_details'];
        $meta['redeem_response'] = $d['raw'];
        $updates = ['note' => wp_json_encode($meta)];
        if ($has_code) $updates['status'] = 'completed';
        if ($d['redeem'] !== '') $updates['delivered_code'] = sanitize_textarea_field($d['redeem']);
        if ($d['pin_code'] !== '') $updates['delivered_pin'] = sanitize_text_field($d['pin_code']);
        $wpdb->update($tx, $updates, ['id' => $row->id]);
        if ($has_code && !empty($meta['main_trnx_id'])) {
            $main = $wpdb->prefix . 'pulsepoint_trnx';
            $wpdb->update($main, ['status' => 'success', 'gateway_response' => wp_json_encode($d['raw'])], ['id' => (int) $meta['main_trnx_id']], ['%s', '%s'], ['%d']);
        }
    }
});
