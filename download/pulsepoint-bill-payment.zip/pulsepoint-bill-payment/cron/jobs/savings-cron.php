<?php

if (!defined('ABSPATH')) exit;

add_action('pulsepoint_cron_savings', function () {

    global $wpdb;

    $pockets = $wpdb->get_results("
        SELECT * FROM {$wpdb->prefix}pulsepoint_savings_pocket
        WHERE auto_save = 1 AND status = 'active'
    ");

    foreach ($pockets as $pocket) {

        // Example logic: deduct from wallet & add to savings
        // You will implement wallet debit logic here

        $wpdb->query($wpdb->prepare("
            UPDATE {$wpdb->prefix}pulsepoint_savings_pocket
            SET current_amount = current_amount + %f
            WHERE id = %d
        ", $pocket->amount_per_cycle, $pocket->id));
    }

});