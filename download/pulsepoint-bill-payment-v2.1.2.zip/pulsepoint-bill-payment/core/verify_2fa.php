<?php
/**
 * Verify PulsePoint 2FA
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__DIR__) . 'libs/PHPGangsta/GoogleAuthenticator.php';

add_action('wp_ajax_pulsepoint_verify_2fa', 'pulsepoint_verify_2fa');

function pulsepoint_verify_2fa() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Login required.'
        ]);
    }

    $code = isset($_POST['code'])
        ? sanitize_text_field($_POST['code'])
        : '';

    if (empty($code)) {
        wp_send_json([
            'success' => false,
            'message' => 'Authentication code required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user || empty($user->twofa_secret)) {

        wp_send_json([
            'success' => false,
            'message' => '2FA not configured.'
        ]);
    }

    $ga = new PHPGangsta_GoogleAuthenticator();

    $checkResult = $ga->verifyCode(
        $user->twofa_secret,
        $code,
        2
    );

    if (!$checkResult) {

        wp_send_json([
            'success' => false,
            'message' => 'Invalid authentication code.'
        ]);
    }

    // Enable 2FA after successful verification
    $wpdb->update(
        $table,
        [
            'twofa_enabled' => 1
        ],
        [
            'id' => $user_id
        ]
    );

    wp_send_json([
        'success' => true,
        'message' => '2FA enabled successfully.'
    ]);
}

/**
 * Disable 2FA — requires the current TOTP code as confirmation, same as
 * enabling does, so a stolen session alone can't turn off 2FA protection.
 */
add_action('wp_ajax_pulsepoint_disable_2fa', 'pulsepoint_disable_2fa');

function pulsepoint_disable_2fa() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Login required.'
        ]);
    }

    $code = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';

    if (empty($code)) {
        wp_send_json([
            'success' => false,
            'message' => 'Authentication code required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", $user_id)
    );

    if (!$user || empty($user->twofa_secret) || (int) $user->twofa_enabled !== 1) {
        wp_send_json([
            'success' => false,
            'message' => '2FA is not currently enabled.'
        ]);
    }

    $ga = new PHPGangsta_GoogleAuthenticator();
    $valid = $ga->verifyCode($user->twofa_secret, $code, 2);

    if (!$valid) {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid authentication code.'
        ]);
    }

    $wpdb->update(
        $table,
        [
            'twofa_enabled' => 0,
            'twofa_secret'  => null,
        ],
        ['id' => $user_id]
    );

    wp_send_json([
        'success' => true,
        'message' => '2FA disabled successfully.'
    ]);
}