<?php
/**
 * Pulsepoint API — WooCommerce One-Time Payment Wallet Funding
 * Path: /api/woo-fund.php
 * Author: Amaaavl
 *
 * Thin token-auth adapter, same pattern as /api/betting.php etc — hands
 * off to the existing pulsepoint_woocommerce_fund_wallet() in
 * core/woo-commerce/pulsepoint.php, which creates a WooCommerce order
 * and returns its checkout URL.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!class_exists('WooCommerce')) {
    echo json_encode(['success' => false, 'message' => 'WooCommerce is not available']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token  = sanitize_text_field($input['token'] ?? '');
$amount = isset($input['amount']) ? (float) $input['amount'] : 0;

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;
$_POST['amount'] = $amount;

if (function_exists('pulsepoint_woocommerce_fund_wallet')) {
    pulsepoint_woocommerce_fund_wallet(); // outputs JSON
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_woocommerce_fund_wallet() not found']);
}
