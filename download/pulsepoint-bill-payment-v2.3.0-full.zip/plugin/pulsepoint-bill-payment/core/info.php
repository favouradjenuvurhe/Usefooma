<?php
/**
 * User Info Fetch Endpoint for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/info.php
 *
 * Returns the currently authenticated user's profile details via AJAX.
 * Auth is session-based, matching the session set by login.php
 * ($_SESSION['pulsepoint_user'] + 'pulsepoint_user_session' cookie).
 *
 * SECURITY NOTES:
 * 1. This endpoint NEVER returns: password (hash), twofa_secret,
 *    security_code, security_question1-3, reset_token, token, passcode.
 *    Those are either secrets or session/reset artifacts and have no
 *    business being sent to the client on a "get my info" call.
 * 2. Auth is re-validated against the DB on every call (not just trusted
 *    from $_SESSION), so a suspended/deleted account is locked out
 *    immediately instead of waiting for next login.
 * 3. Only registered for wp_ajax_pulsepoint_user_info (logged-in / valid
 *    session only) — NOT wp_ajax_nopriv — since there is no legitimate
 *    reason for an anonymous request to hit this action.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file access
}

add_action('wp_ajax_pulsepoint_user_info', 'pulsepoint_user_info');
add_action('wp_ajax_nopriv_pulsepoint_user_info', 'pulsepoint_user_info_unauthenticated');

/**
 * Consistent "not logged in" response for the nopriv hook.
 */
function pulsepoint_user_info_unauthenticated() {
    header('Content-Type: application/json; charset=utf-8');
    wp_send_json(['success' => false, 'message' => 'Not authenticated.'], 401);
}

/**
 * Shape the DB row down to fields that are safe to expose to the client.
 * Centralized here so every response (this file + login.php, if you want
 * to line them up later) uses the same allow-list.
 */
function pulsepoint_public_user_shape(object $user): array {
    return [
        'id'               => (int) $user->id,
        'firstname'        => $user->firstname,
        'lastname'         => $user->lastname,
        'email'            => $user->email,
        'phone'            => $user->phone,
        'wallet'           => (float) $user->wallet,
        'dollar'           => (float) $user->dollar,
        'referral_balance' => (float) $user->referral_balance,
        'account_type'     => $user->account_type,
        'gender'           => $user->gender,
        'dob'              => $user->dob,
        'address'          => $user->address,
        'account_limit'    => (float) $user->account_limit,
        'auto_login'       => (int) $user->auto_login,
        'alert'            => (int) $user->alert,
        'status'           => (int) $user->status,
        'status_email'     => (int) $user->status_email,
        'statuskyc'        => (int) $user->statuskyc,
        'twofa_enabled'    => (int) $user->twofa_enabled,
        'created_at'       => $user->created_at,
    ];
}

function pulsepoint_user_info() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'GET') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'Not authenticated.'], 401);
    }

    $session_user_id = (int) $_SESSION['pulsepoint_user']['id'];
    $table = $wpdb->prefix . 'pulsepoint_users';

    // Re-fetch fresh from the DB rather than trusting the session blob —
    // status/suspension/close_account can change between requests.
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $session_user_id)
    );

    if (!$user) {
        // Account no longer exists — kill the stale session.
        unset($_SESSION['pulsepoint_user']);
        wp_send_json(['success' => false, 'message' => 'Account not found.'], 401);
    }

    if ((int) $user->close_account === 1) {
        unset($_SESSION['pulsepoint_user']);
        wp_send_json(['success' => false, 'message' => 'Your account is pending deletion and cannot login.'], 403);
    }

    if ((int) $user->status === 0) {
        unset($_SESSION['pulsepoint_user']);
        wp_send_json(['success' => false, 'message' => 'Your account has been suspended.'], 403);
    }

    wp_send_json([
        'success' => true,
        'user'    => pulsepoint_public_user_shape($user),
    ]);
}
