<?php
/**
 * Pulsepoint WooCommerce Wallet Funding Integration
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/woo-commerce/pulsepoint.php
 *
 * Lets a Pulsepoint user fund their wallet through ANY installed WooCommerce
 * payment gateway (Paystack, Flutterwave, Stripe, Monnify, etc.) without the
 * plugin needing a dedicated integration for each one.
 *
 * Flow:
 *  1. Frontend calls action=pulsepoint_woocommerce_fund_wallet with an amount.
 *  2. We make sure a hidden "Wallet Funding" product exists.
 *  3. We create a WooCommerce order for that amount, tag it with the
 *     Pulsepoint user id + a pending trnx row, and return the checkout URL.
 *  4. User pays on the normal WooCommerce checkout page.
 *  5. When the order status flips to processing/completed we credit the
 *     wallet exactly once (guarded by order meta) and mark the trnx success.
 *  6. If the order is cancelled/failed/refunded, the trnx is marked failed.
 */

if (!defined('ABSPATH')) exit;

/* ------------------------------------------------------------------------
 * 1. Bail out cleanly if WooCommerce isn't active
 * ---------------------------------------------------------------------- */
add_action('admin_notices', 'pulsepoint_woo_missing_notice');
function pulsepoint_woo_missing_notice() {
    if (!pulsepoint_woo_is_active()) {
        echo '<div class="notice notice-error"><p><strong>Pulsepoint:</strong> WooCommerce is not active. The WooCommerce wallet funding module is disabled.</p></div>';
    }
}

function pulsepoint_woo_is_active() {
    return class_exists('WooCommerce') && function_exists('wc_get_order') && function_exists('wc_create_order');
}

/* ------------------------------------------------------------------------
 * 2. Hidden "Wallet Funding" virtual product
 * ---------------------------------------------------------------------- */

/**
 * Returns the product ID of the hidden wallet-funding product, creating it
 * the first time it's needed. The ID is cached in pulsepoint_settings so we
 * only ever create one product.
 */
function pulsepoint_woo_get_wallet_product_id() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $settings_table = $base_prefix . 'settings';

    $existing_id = $wpdb->get_var($wpdb->prepare(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s",
        'woocommerce_wallet_product_id'
    ));

    if ($existing_id) {
        $existing_id = (int) maybe_unserialize($existing_id);
        if ($existing_id && get_post($existing_id)) {
            return $existing_id;
        }
    }

    // Create the product for the first time.
    $product = new WC_Product_Simple();
    $product->set_name('Wallet Funding');
    $product->set_status('private');       // never listed in the shop
    $product->set_catalog_visibility('hidden');
    $product->set_virtual(true);
    $product->set_sold_individually(true);
    $product->set_regular_price('0');
    $product->set_price('0');
    $product_id = $product->save();

    pulsepoint_woo_save_setting('woocommerce_wallet_product_id', $product_id);

    return $product_id;
}

function pulsepoint_woo_save_setting($key, $value) {
    global $wpdb;
    $settings_table = $wpdb->prefix . 'pulsepoint_settings';

    $wpdb->query($wpdb->prepare(
        "INSERT INTO {$settings_table} (opt_key, opt_value, type, grouping, autoload)
         VALUES (%s, %s, 'string', 'woocommerce', 0)
         ON DUPLICATE KEY UPDATE opt_value = VALUES(opt_value), updated_at = CURRENT_TIMESTAMP",
        $key,
        maybe_serialize($value)
    ));
}

/* ------------------------------------------------------------------------
 * 3. AJAX: initiate a wallet funding order
 * ---------------------------------------------------------------------- */
add_action('wp_ajax_nopriv_pulsepoint_woocommerce_fund_wallet', 'pulsepoint_woocommerce_fund_wallet');
add_action('wp_ajax_pulsepoint_woocommerce_fund_wallet', 'pulsepoint_woocommerce_fund_wallet');

function pulsepoint_woocommerce_fund_wallet() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    if (!pulsepoint_woo_is_active()) {
        wp_send_json(['success' => false, 'message' => 'WooCommerce is not available.']);
    }

    $user_id     = (int) $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';

    // Fetch user record
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id = %d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Validate amount
    $amount = isset($_POST['amount']) ? (float) $_POST['amount'] : 0;
    if ($amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Invalid funding amount.']);
    }

    $min_amount = 100.00;
    if ($amount < $min_amount) {
        wp_send_json(['success' => false, 'message' => "Minimum funding amount is ₦" . number_format($min_amount, 2)]);
    }

    try {
        $product_id = pulsepoint_woo_get_wallet_product_id();
        $product    = wc_get_product($product_id);

        if (!$product) {
            throw new Exception('Wallet funding product could not be created.');
        }

        // Reference used across trnx + order meta so we can reconcile.
        $reference = 'WFUND-' . $user_id . '-' . time() . '-' . wp_generate_password(6, false);

        $order = wc_create_order();

        // Set the product price for this specific order (custom amount).
        $order->add_product($product, 1, [
            'subtotal' => $amount,
            'total'    => $amount,
        ]);

        $order->set_billing_first_name($user->firstname ?? 'Pulsepoint');
        $order->set_billing_last_name($user->lastname ?? 'User');
        $order->set_billing_email($user->email ?? '');
        if (!empty($user->phone)) {
            $order->set_billing_phone($user->phone);
        }

        // WooCommerce customer_id expects a WP user id, which Pulsepoint
        // users don't necessarily have — so we tag the order with our own
        // reference instead of relying on set_customer_id().
        $order->update_meta_data('_pulsepoint_user_id', $user_id);
        $order->update_meta_data('_pulsepoint_wallet_reference', $reference);
        $order->update_meta_data('_pulsepoint_wallet_funded', 'no');

        $order->calculate_totals();
        $order->set_status('pending');
        $order->save();

        // Log a pending transaction so it shows in the user's history immediately.
        $wpdb->insert($table_trnx, [
            'user_id'     => $user_id,
            'details'     => 'Wallet funding via WooCommerce checkout',
            'value'       => $amount,
            'amount'      => $amount,
            'reference'   => $reference,
            'payment'     => 'wallet',
            'category'    => 'funding',
            'status'      => 'pending',
            'type'        => 'credit',
            'session'     => (string) $order->get_id(),
            'description' => 'Order #' . $order->get_id() . ' created for wallet funding.',
        ], ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);

        wp_send_json([
            'success'      => true,
            'message'      => 'Order created, redirecting to checkout.',
            'order_id'     => $order->get_id(),
            'reference'    => $reference,
            'checkout_url' => $order->get_checkout_payment_url(),
        ]);

    } catch (Exception $e) {
        wp_send_json(['success' => false, 'message' => 'Could not create funding order: ' . $e->getMessage()]);
    }
}

/* ------------------------------------------------------------------------
 * 4. Credit the wallet once payment succeeds
 * ---------------------------------------------------------------------- */
add_action('woocommerce_order_status_completed', 'pulsepoint_woo_maybe_credit_wallet');
add_action('woocommerce_order_status_processing', 'pulsepoint_woo_maybe_credit_wallet');

function pulsepoint_woo_maybe_credit_wallet($order_id) {
    global $wpdb;

    $order = wc_get_order($order_id);
    if (!$order) return;

    // Only touch orders that came from our wallet funding flow.
    $user_id = (int) $order->get_meta('_pulsepoint_user_id');
    if (!$user_id) return;

    // Guard against double-crediting (e.g. processing -> completed both firing).
    if ($order->get_meta('_pulsepoint_wallet_funded') === 'yes') return;

    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';

    $reference = $order->get_meta('_pulsepoint_wallet_reference');
    $amount    = (float) $order->get_total();

    if ($amount <= 0) return;

    // Credit the wallet atomically.
    $wpdb->query($wpdb->prepare(
        "UPDATE `{$table_users}` SET wallet = wallet + %f WHERE id = %d",
        $amount,
        $user_id
    ));

    // Update the pending trnx row to success (fall back to inserting one if missing).
    $updated = $wpdb->update(
        $table_trnx,
        [
            'status'      => 'success',
            'description' => 'Order #' . $order->get_id() . ' paid via ' . $order->get_payment_method_title() . '. Wallet credited.',
        ],
        [
            'reference' => $reference,
            'user_id'   => $user_id,
        ],
        ['%s', '%s'],
        ['%s', '%d']
    );

    if (!$updated) {
        $wpdb->insert($table_trnx, [
            'user_id'     => $user_id,
            'details'     => 'Wallet funding via WooCommerce checkout',
            'value'       => $amount,
            'amount'      => $amount,
            'reference'   => $reference ?: ('WFUND-' . $order->get_id()),
            'payment'     => 'wallet',
            'category'    => 'funding',
            'status'      => 'success',
            'type'        => 'credit',
            'session'     => (string) $order->get_id(),
            'description' => 'Order #' . $order->get_id() . ' paid via ' . $order->get_payment_method_title() . '. Wallet credited.',
        ], ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);
    }

    $order->update_meta_data('_pulsepoint_wallet_funded', 'yes');
    $order->save();

    // Optional: notify the user their wallet was funded, if you have a mailer/helper for this.
    do_action('pulsepoint_wallet_credited', $user_id, $amount, $order_id);
}

/* ------------------------------------------------------------------------
 * 5. Mark the transaction failed if the order doesn't complete
 * ---------------------------------------------------------------------- */
add_action('woocommerce_order_status_cancelled', 'pulsepoint_woo_mark_funding_failed');
add_action('woocommerce_order_status_failed', 'pulsepoint_woo_mark_funding_failed');
add_action('woocommerce_order_status_refunded', 'pulsepoint_woo_mark_funding_failed');

function pulsepoint_woo_mark_funding_failed($order_id) {
    global $wpdb;

    $order = wc_get_order($order_id);
    if (!$order) return;

    $user_id = (int) $order->get_meta('_pulsepoint_user_id');
    if (!$user_id) return;

    // If the wallet was already credited, don't touch anything here —
    // a refund after a successful credit should be handled separately.
    if ($order->get_meta('_pulsepoint_wallet_funded') === 'yes') return;

    $table_trnx = $wpdb->prefix . 'pulsepoint_trnx';
    $reference  = $order->get_meta('_pulsepoint_wallet_reference');

    $wpdb->update(
        $table_trnx,
        [
            'status'      => 'failed',
            'description' => 'Order #' . $order->get_id() . ' was ' . $order->get_status() . '. Wallet not credited.',
        ],
        [
            'reference' => $reference,
            'user_id'   => $user_id,
        ],
        ['%s', '%s'],
        ['%s', '%d']
    );
}
