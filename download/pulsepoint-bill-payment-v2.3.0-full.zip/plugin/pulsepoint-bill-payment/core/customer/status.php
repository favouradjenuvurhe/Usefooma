<?php
/**
 * KYC Status Checker for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/status.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// === AJAX Hooks ===
add_action('wp_ajax_pulsepoint_check_kyc_status', 'pulsepoint_check_kyc_status');
add_action('wp_ajax_nopriv_pulsepoint_check_kyc_status', 'pulsepoint_check_kyc_status');

function pulsepoint_check_kyc_status() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    // === Start session ===
    if (!session_id()) session_start();

    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_users = $base_prefix . 'users';
    $table_settings = $base_prefix . 'settings';

    // === Fetch user data ===
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d LIMIT 1", $user_id));
    if (!$user) {
        wp_send_json(['success' => false, 'message' => 'User not found.']);
    }

    if (empty($user->customerId) || empty($user->email)) {
        wp_send_json(['success' => false, 'message' => 'Missing customerId or email. Please complete KYC first.']);
    }

    // === Get public key ===
    $public_key = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$table_settings} WHERE opt_key = %s LIMIT 1", 'stropay_pkey'));
    if (empty($public_key)) {
        wp_send_json(['success' => false, 'message' => 'Strowallet public key not configured.']);
    }

    // === API Request ===
    $api_url = 'https://strowallet.com/api/bitvcard/getcardholder/';
    $params = [
        'public_key' => $public_key,
        'customerId' => $user->customerId,
        'customerEmail' => $user->email,
    ];

    $url_with_query = $api_url . '?' . http_build_query($params);

    $response = wp_remote_get($url_with_query, [
        'headers' => ['accept' => 'application/json'],
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet API.']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (empty($body) || !isset($body['success'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid API response.']);
    }

    if ($body['success'] !== true) {
        wp_send_json(['success' => false, 'message' => 'KYC status fetch failed.']);
    }

    $data = $body['data'] ?? [];
    $kyc_status = strtolower(trim($data['status'] ?? ''));

    // === Check KYC Status ===
    if (in_array($kyc_status, ['low kyc', 'lowkyc'])) {
        // KYC failed
        $wpdb->update($table_users, ['statuskyc' => 0], ['id' => $user_id], ['%d'], ['%d']);
        wp_send_json([
            'success' => true,
            'message' => 'KYC failed. Please resubmit your documents for review.',
            'kyc_status' => ucfirst($kyc_status),
            'data' => $data
        ]);
    } elseif (in_array($kyc_status, ['high kyc', 'highkyc'])) {
        // KYC approved
        $updated = $wpdb->update(
            $table_users,
            ['statuskyc' => 1],
            ['id' => $user_id],
            ['%d'],
            ['%d']
        );

        wp_send_json([
            'success' => true,
            'message' => ($updated !== false) ? 'KYC approved successfully.' : 'KYC approved but database update failed.',
            'kyc_status' => ucfirst($kyc_status),
            'data' => $data
        ]);
    } else {
        // Pending or unreviewed
        wp_send_json([
            'success' => true,
            'message' => 'KYC is pending approval. Please wait while we review your submission.',
            'kyc_status' => ucfirst($kyc_status ?: 'Unreview KYC'),
            'data' => $data
        ]);
    }
}
?>