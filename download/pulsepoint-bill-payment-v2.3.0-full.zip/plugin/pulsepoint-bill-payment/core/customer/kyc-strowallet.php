<?php
/**
 * Customer KYC Verification for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/customer.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

function pulsepoint_kyc_strowallet() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    // 🪵 Simple logger
    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';
    function pulsepoint_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }

    pulsepoint_log("==== KYC Request Started ====", $log_file);

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        pulsepoint_log("Invalid request method", $log_file);
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        pulsepoint_log("Session expired or user not found", $log_file);
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table = $base_prefix . 'users';

    pulsepoint_log("User ID: $user_id | Table: $table", $log_file);

    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", $user_id));
    if (!$user) {
        pulsepoint_log("User not found in DB.", $log_file);
        wp_send_json(['success' => false, 'message' => 'User not found.']);
    }

    // Sanitize text fields
    $dob         = sanitize_text_field($_POST['dob'] ?? '');
    $idType      = sanitize_text_field($_POST['idType'] ?? '');
    $idNumber    = sanitize_text_field($_POST['idNumber'] ?? '');
    $houseNumber = sanitize_text_field($_POST['houseNumber'] ?? '');
    $line1       = sanitize_text_field($_POST['line1'] ?? '');
    $state       = sanitize_text_field($_POST['state'] ?? '');
    $zipCode     = sanitize_text_field($_POST['zipCode'] ?? '');
    $city        = sanitize_text_field($_POST['city'] ?? '');
    $country     = sanitize_text_field($_POST['country'] ?? '');

    // ✅ Correct image upload directory (no /core/ in URL)
    $upload_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/assets/img/';
    $upload_url = plugins_url('pulsepoint-bill-payment/assets/img/', WP_PLUGIN_DIR . '/pulsepoint-bill-payment/');

    if (!file_exists($upload_dir)) {
        wp_mkdir_p($upload_dir);
    }

    $idImageUrl = '';
    $userPhotoUrl = '';

    // ✅ Upload ID Image (only PNG allowed)
    if (!empty($_FILES['idImage']['name'])) {
        $id_ext = strtolower(pathinfo($_FILES['idImage']['name'], PATHINFO_EXTENSION));
        if ($id_ext !== 'png') {
            wp_send_json(['success' => false, 'message' => 'Only PNG format allowed for ID Image.']);
        }

        $id_filename = 'id_' . $user_id . '_' . time() . '.png';
        $id_target = $upload_dir . $id_filename;

        if (move_uploaded_file($_FILES['idImage']['tmp_name'], $id_target)) {
            $idImageUrl = $upload_url . $id_filename;
        }
    }

    // ✅ Upload User Selfie (only PNG allowed)
    if (!empty($_FILES['userPhoto']['name'])) {
        $selfie_ext = strtolower(pathinfo($_FILES['userPhoto']['name'], PATHINFO_EXTENSION));
        if ($selfie_ext !== 'png') {
            wp_send_json(['success' => false, 'message' => 'Only PNG format allowed for Selfie Photo.']);
        }

        $selfie_filename = 'selfie_' . $user_id . '_' . time() . '.png';
        $selfie_target = $upload_dir . $selfie_filename;

        if (move_uploaded_file($_FILES['userPhoto']['tmp_name'], $selfie_target)) {
            $userPhotoUrl = $upload_url . $selfie_filename;
        }
    }

    if (empty($dob) || empty($idType) || empty($idNumber) || empty($idImageUrl) || empty($userPhotoUrl)) {
        pulsepoint_log("Missing fields in POST data.", $log_file);
        wp_send_json(['success' => false, 'message' => 'All KYC fields and PNG images are required.']);
    }

    // Get API key
    $settings_table = $base_prefix . 'settings';
    $public_key = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1", 'stropay_pkey'));
    if (empty($public_key)) {
        pulsepoint_log("Missing API key (stropay_pkey).", $log_file);
        wp_send_json(['success' => false, 'message' => 'Strowallet public key not configured.']);
    }

    // ✅ Detect if customerId exists for this user
    $existing_customerId = sanitize_text_field($user->customerId ?? '');

    if (!empty($existing_customerId)) {
        // ✅ Update Existing Customer via PUT
        $update_url = 'https://strowallet.com/api/bitvcard/updateCardCustomer/';
        $update_params = [
            'public_key'   => $public_key,
            'customerId'   => $existing_customerId,
            'firstName'    => $user->firstname,
            'lastName'     => $user->lastname,
            'idImage'      => $idImageUrl,
            'userPhoto'    => $userPhotoUrl,
            'phoneNumber'  => $user->phone,
            'country'      => $country,
            'city'         => $city,
            'state'        => $state,
            'zipCode'      => $zipCode,
            'line1'        => $line1,
            'houseNumber'  => $houseNumber
        ];

        $url_with_query = $update_url . '?' . http_build_query($update_params);
        pulsepoint_log("PUT API URL: $url_with_query", $log_file);

        $response = wp_remote_request($url_with_query, [
            'method'  => 'PUT',
            'headers' => ['accept' => 'application/json'],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            pulsepoint_log("Error contacting UPDATE API: " . $response->get_error_message(), $log_file);
            wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet update API.']);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        pulsepoint_log("PUT Response: " . json_encode($body), $log_file);

        if (!empty($body['success']) && $body['success'] === true) {
            pulsepoint_log("Customer updated successfully -> {$existing_customerId}", $log_file);
            wp_send_json([
                'success' => true,
                'message' => 'Existing customer updated successfully.',
                'customerId' => $existing_customerId,
                'api_response' => $body['response'] ?? []
            ]);
        } else {
            pulsepoint_log("Update failed: " . json_encode($body), $log_file);
            wp_send_json([
                'success' => false,
                'message' => $body['message'] ?? 'Customer update failed.'
            ]);
        }
    }

    // ✅ Create New Customer if no existing customerId
    $api_url = 'https://strowallet.com/api/bitvcard/create-user/';
    $params = [
        'public_key'     => $public_key,
        'houseNumber'    => $houseNumber,
        'firstName'      => $user->firstname,
        'lastName'       => $user->lastname,
        'idNumber'       => $idNumber,
        'customerEmail'  => $user->email,
        'phoneNumber'    => $user->phone,
        'dateOfBirth'    => $dob,
        'idImage'        => $idImageUrl,
        'userPhoto'      => $userPhotoUrl,
        'line1'          => $line1,
        'state'          => $state,
        'zipCode'        => $zipCode,
        'city'           => $city,
        'country'        => $country,
        'idType'         => $idType
    ];

    $url_with_query = $api_url . '?' . http_build_query($params);
    pulsepoint_log("API URL: $url_with_query", $log_file);

    $response = wp_remote_post($url_with_query, [
        'headers' => ['accept' => 'application/json'],
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        pulsepoint_log("Error contacting API: " . $response->get_error_message(), $log_file);
        wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet API.']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    pulsepoint_log("API Response: " . json_encode($body), $log_file);

    if (empty($body) || !isset($body['success'])) {
        pulsepoint_log("Invalid API response format.", $log_file);
        wp_send_json(['success' => false, 'message' => 'Invalid API response.']);
    }

    if ($body['success'] !== true) {
        pulsepoint_log("KYC failed: " . ($body['message'] ?? 'No message'), $log_file);
        wp_send_json(['success' => false, 'message' => $body['message'] ?? 'KYC failed.']);
    }

    // ✅ Extract and save customerId
    $resp = $body['response'] ?? [];
    $customerId = sanitize_text_field($resp['customerId'] ?? '');

    if (empty($customerId)) {
        pulsepoint_log("customerId not returned in response.", $log_file);
        wp_send_json(['success' => false, 'message' => 'No customerId returned from API.']);
    }

    $updated = $wpdb->update(
        $table,
        ['customerId' => $customerId],
        ['id' => $user_id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        pulsepoint_log("DB update failed: " . $wpdb->last_error, $log_file);
        wp_send_json([
            'success' => false,
            'message' => 'Failed to save customerId to database.',
            'wpdb_error' => $wpdb->last_error
        ]);
    }

    pulsepoint_log("customerId saved successfully for user #$user_id -> $customerId", $log_file);
    pulsepoint_log("==== KYC Request Completed ====", $log_file);

    wp_send_json([
        'success' => true,
        'message' => 'KYC verification successful and customerId saved.',
        'customerId' => $customerId,
        'api_response' => $resp
    ]);
}