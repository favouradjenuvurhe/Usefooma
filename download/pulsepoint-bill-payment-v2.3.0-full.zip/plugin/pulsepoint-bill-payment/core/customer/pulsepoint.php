<?php
if(!defined('ABSPATH')) exit;
add_action('wp_ajax_pulsepoint_customer_kyc','pulsepoint_customer_kyc');
add_action('wp_ajax_nopriv_pulsepoint_customer_kyc','pulsepoint_customer_kyc');
function pulsepoint_customer_kyc(){
global $wpdb;
$base_prefix=$wpdb->prefix.'pulsepoint_';
$rows=$wpdb->get_results("SELECT opt_key,opt_value FROM {$base_prefix}settings");
$settings=[];foreach($rows as $r){$settings[$r->opt_key]=maybe_unserialize($r->opt_value);}
require_once __DIR__.'/kyc-strowallet.php';
require_once __DIR__.'/kyc-xixapay.php';
$p=strtolower($settings['virtualcard_type']??'strowallet');
if($p==='xixapay'){pulsepoint_kyc_xixapay();}else{pulsepoint_kyc_strowallet();}
wp_die();
}
