<?php
/**
 * NCWallet Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/ncwallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via NCWallet
 *
 * TOKEN FORMAT:
 *   PIN:API_KEY
 *   Example: 0987:nc_afr_apikeyxxxxxxxx
 *
 * @param string $network
 * @param float  $amount
 * @param string $phone
 * @param string $token
 * @param string $reference
 * @return array
 */
function send_airtime($network, $amount, $phone, $token, $reference = '')
{
    // ✅ NCWallet endpoint
    $url = "https://ncwallet.africa/api/v1/airtime";

    // ✅ Split token => PIN : API KEY
    $parts = explode(':', $token, 2);
    $pin   = trim($parts[0] ?? '');
    $apiKey = trim($parts[1] ?? '');

    if (empty($pin) || empty($apiKey)) {
        return [
            'success' => false,
            'message' => 'Invalid NCWallet token format. Expected PIN:API_KEY.',
            'details' => ['provider' => 'NCWallet']
        ];
    }

    // ✅ Normalize network to NCWallet codes
    $network_map = [
        'MTN'     => 1,
        'GLO'     => 3,
        'AIRTEL'  => 2,
        '9MOBILE' => 4
    ];

    $network_upper = strtoupper(trim($network));
    $network_code  = $network_map[$network_upper] ?? null;

    if (!$network_code) {
        return [
            'success' => false,
            'message' => 'Invalid network selected.',
            'details' => [
                'network'  => $network_upper,
                'provider' => 'NCWallet'
            ]
        ];
    }

    // ✅ Request payload (EXACT NCWallet spec)
    $payload = [
        "network"       => $network_code,
        "phone_number"  => $phone,
        "airtime_type"  => "VTU",
        "country_code" => "NG",
        "amount"        => (string)$amount,
        "bypass"        => true
    ];

    // ✅ Initialize cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            "Accept: application/json",
            "Content-Type: application/json",
            "trnx_pin: {$pin}",
            "Authorization: {$apiKey}"
        ],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // ❌ cURL error
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    // ✅ Decode API response
    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid or empty API response from NCWallet.',
            'details' => $response_raw
        ];
    }

    /**
     * NCWallet may return "error" even when delivered
     * We normalize but DO NOT fake success
     */
    $status  = strtolower($api_response['status'] ?? '');
    $success = ($status === 'success');

    // ✅ Normalized response (RAW API KEPT)
    return [
        'success' => $success,
        'message' => $api_response['message'] ?? 'Airtime request processed.',
        'details' => [
            'transaction_id' => $api_response['ref_id'] ?? ($reference ?: 'NCA_' . time()),
            'network'        => $api_response['data']['network'] ?? $network_upper,
            'phone'          => $api_response['data']['phone_number'] ?? $phone,
            'amount'         => $api_response['data']['amount'] ?? $amount,
            'amount_paid'    => $api_response['data']['amount_paid'] ?? null,
            'old_balance'    => $api_response['data']['oldbal'] ?? null,
            'new_balance'    => $api_response['data']['newbal'] ?? null,
            'provider'       => 'NCWallet',
            'api_response'   => $api_response
        ]
    ];
}