<?php
/**
 * WhoGoPay Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/whogopay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via WhoGoPay
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   API token
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    $url = "https://whogopay.com.ng/api/v1/airtime-vending";
    $network_upper = strtoupper($network);

    // Prepare payload
    $payload = [
        "phone_number" => $phone,
        "network"      => $network_upper,
        "amount"       => (float)$amount
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$token}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid or empty API response
    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;
    $message = $success
        ? ($api_response['message'] ?? "Airtime purchase successful")
        : ($api_response['message'] ?? 'Airtime purchase failed');

    // Extract meta data if available
    $meta = isset($api_response['meta']) ? json_decode($api_response['meta'], true) : [];

    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $meta['TransRef'] ?? ($reference ?: 'WGP_' . time()),
            'network'        => $network_upper,
            'phone'          => $phone,
            'amount'         => $amount,
            'provider'       => 'WhoGoPay',
            'api_response'   => $api_response
        ]
    ];
}