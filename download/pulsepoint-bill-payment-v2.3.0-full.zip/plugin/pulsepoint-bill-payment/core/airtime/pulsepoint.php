<?php
/**
 * Pulsepoint Airtime Purchase Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/pulsepoint.php
 * Author: Amaaavl
 *
 * UPDATE:
 * 1. Wallet + Referral Balance can now BOTH fund an airtime purchase.
 *    Wallet is drawn from first, then referral_balance covers the rest.
 *    e.g. wallet=200, referral_balance=150 -> user can spend up to 350.
 * 2. Email notifications sent for success / failed / pending, rendered
 *    from templates/airtime.html.
 * 3. Extra security layer:
 *    - Network whitelist (no longer accepts an arbitrary string).
 *    - Phone number format validation.
 *    - Per-transaction hard amount cap (configurable via settings,
 *      falls back to a sane default) in addition to the daily limit.
 *    - Final debit is re-locked and re-verified at debit time (not just
 *      at the pre-check) to close the race window between the initial
 *      balance check and the actual deduction — combined balance is
 *      re-read under FOR UPDATE right before money moves.
 *    - Refunds on failed purchases restore money to the exact buckets
 *      (wallet vs referral_balance) it was taken from.
 */

if (!defined('ABSPATH')) exit;

// Hook for AJAX requests
add_action('wp_ajax_nopriv_pulsepoint_airtime_purchase', 'pulsepoint_airtime_purchase');
add_action('wp_ajax_pulsepoint_airtime_purchase', 'pulsepoint_airtime_purchase');

const PULSEPOINT_AIRTIME_ALLOWED_NETWORKS = ['MTN', 'GLO', 'AIRTEL', '9MOBILE', 'ETISALAT'];
const PULSEPOINT_AIRTIME_DEFAULT_MAX_AMOUNT = 50000.00; // hard per-transaction cap fallback

/**
 * Render the airtime email template with escaped values.
 * Falls back to a minimal safe message if the template file is missing.
 */
if (!function_exists('pulsepoint_render_airtime_email')) {
    function pulsepoint_render_airtime_email(array $vars): string {
        $template_path = dirname(__DIR__, 2) . '/templates/airtime.html';

        if (!file_exists($template_path)) {
            return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
        }

        $html = file_get_contents($template_path);

        $defaults = [
            'platform_name' => 'Pulsepoint',
            'color_hex'     => '#6C63FF',
            'status_label'  => '',
            'status_color'  => '#6C63FF',
            'firstname'     => '',
            'network'       => '',
            'phone'         => '',
            'amount'        => '',
            'reference'     => '',
            'date'          => date('Y-m-d H:i:s'),
            'message'       => '',
            'year'          => date('Y'),
            'support_email' => get_option('admin_email'),
        ];

        $vars = array_merge($defaults, $vars);

        foreach ($vars as $key => $value) {
            $safe = $key === 'message'
                ? $value
                : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
            $html = str_replace('{{' . $key . '}}', $safe, $html);
        }

        return $html;
    }
}

/**
 * Send the status email for an airtime transaction (success/failed/pending).
 */
if (!function_exists('pulsepoint_send_airtime_email')) {
    function pulsepoint_send_airtime_email(
        object $user,
        string $status,
        string $network,
        string $phone,
        float $amount,
        string $reference,
        array $branding
    ): void {
        if (empty($user->email)) {
            return;
        }

        $status_map = [
            'success' => ['label' => 'Successful', 'color' => '#16a34a', 'subject' => 'Airtime Purchase Successful'],
            'failed'  => ['label' => 'Failed',     'color' => '#dc2626', 'subject' => 'Airtime Purchase Failed'],
            'pending' => ['label' => 'Pending',    'color' => '#d97706', 'subject' => 'Airtime Purchase Pending'],
        ];

        $meta = $status_map[$status] ?? $status_map['pending'];

        $message = match ($status) {
            'success' => "Your airtime purchase was completed successfully.",
            'failed'  => "Your airtime purchase could not be completed. If any amount was deducted, it has been refunded to your balance.",
            default   => "Your airtime purchase is currently being processed. You'll be notified once it's confirmed.",
        };

        @wp_mail(
            $user->email,
            $meta['subject'],
            pulsepoint_render_airtime_email([
                'platform_name' => $branding['platform_name'],
                'color_hex'     => $branding['color_hex'],
                'status_label'  => $meta['label'],
                'status_color'  => $meta['color'],
                'firstname'     => $user->firstname,
                'network'       => $network,
                'phone'         => $phone,
                'amount'        => number_format($amount, 2),
                'reference'     => $reference,
                'date'          => current_time('mysql'),
                'message'       => $message,
            ]),
            ['Content-Type: text/html; charset=UTF-8']
        );
    }
}

function pulsepoint_airtime_purchase() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = (int) $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    /* =====================================================
       SECURITY LOGGING FUNCTION (NO NEW TABLE)
    ====================================================== */
    $log_security = function ($event, $meta = []) use ($wpdb, $base_prefix) {
        $wpdb->insert(
            "{$base_prefix}logs",
            [
                'event'      => $event,
                'meta'       => json_encode($meta),
                'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );
    };

    // Rate limiter
    $now = time();
    if (isset($_SESSION['last_airtime_request'][$user_id]) && ($now - $_SESSION['last_airtime_request'][$user_id]) < 15) {
        $log_security('rate_limited', ['user' => $user_id]);
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);
    }
    $_SESSION['last_airtime_request'][$user_id] = $now;

    // Fetch user (LOCKED)
    $wpdb->query('START TRANSACTION');

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM `{$table_users}` WHERE id=%d FOR UPDATE",
            $user_id
        )
    );

    if (!$user || $user->status != 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';
    $airtime_api      = $settings['airtime_api'] ?? 'adex';
    $airtime_token    = $settings['airtime_token'] ?? '';
    $max_amount       = isset($settings['airtime_max_amount']) && $settings['airtime_max_amount'] > 0
        ? (float) $settings['airtime_max_amount']
        : PULSEPOINT_AIRTIME_DEFAULT_MAX_AMOUNT;

    $branding = [
        'platform_name' => $settings['platform_name'] ?? 'Pulsepoint',
        'color_hex'     => $settings['color_hex'] ?? '#6C63FF',
    ];

    // KYC SETTING
    $require_kyc = isset($settings['airtime_kyc']) && $settings['airtime_kyc'] == 1;

    // KYC CHECK (LIKE BANK)
    if ($require_kyc && $user->statuskyc != 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }

    if ($maintenance_mode == '1') {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    // Sanitize inputs
    $network   = isset($_POST['network']) ? strtoupper(trim(sanitize_text_field($_POST['network']))) : '';
    $phone     = isset($_POST['phone']) ? preg_replace('/[^0-9+]/', '', sanitize_text_field($_POST['phone'])) : '';
    $amount    = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
    $reference = isset($_POST['reference']) ? sanitize_text_field($_POST['reference']) : '';

    /* =====================================================
       INPUT VALIDATION (SECURITY LAYER)
    ====================================================== */
    if (!in_array($network, PULSEPOINT_AIRTIME_ALLOWED_NETWORKS, true)) {
        $log_security('invalid_network_rejected', ['user' => $user_id, 'network' => $network]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Unsupported network selected.']);
    }

    // Nigerian mobile number: 11 digits starting with 0, or +234 followed by 10 digits
    $phone_digits = preg_replace('/\D/', '', $phone);
    $valid_phone = (bool) preg_match('/^0\d{10}$/', $phone_digits)
        || (bool) preg_match('/^234\d{10}$/', $phone_digits);

    if (empty($phone) || !$valid_phone) {
        $log_security('invalid_phone_rejected', ['user' => $user_id, 'phone' => $phone]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Please enter a valid phone number.']);
    }

    if ($amount <= 0 || !is_finite($amount)) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Network, Phone, and Amount are required.']);
    }

    /* =====================================================
       STRICT AMOUNT RULES
    ====================================================== */

    // Minimum airtime purchase
    if ($amount < 100) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Minimum airtime purchase is ₦100.']);
    }

    // Hard per-transaction cap
    if ($amount > $max_amount) {
        $log_security('amount_cap_exceeded', ['user' => $user_id, 'amount' => $amount, 'cap' => $max_amount]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Maximum airtime purchase per transaction is ₦' . number_format($max_amount, 2)]);
    }

    /* =====================================================
       COMBINED BALANCE CHECK (WALLET + REFERRAL BALANCE)
       Wallet is drawn from first, referral_balance covers the rest.
    ====================================================== */
    $wallet_balance   = (float) $user->wallet;
    $referral_balance = (float) $user->referral_balance;
    $combined_balance = $wallet_balance + $referral_balance;

    if ($api_mode === 'live' && $combined_balance < $amount) {
        $needed = $amount - $combined_balance;

        $log_security('balance_insufficient', [
            'user'       => $user_id,
            'amount'     => $amount,
            'wallet'     => $wallet_balance,
            'referral'   => $referral_balance,
        ]);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'You need ₦' . number_format($needed, 2) . ' more to proceed.'
        ]);
    }

    if (empty($reference)) {
        $reference = 'PSNG' . bin2hex(random_bytes(6));
    }

    /* =====================================================
       IDEMPOTENCY + UNIQUE REFERENCE ENFORCEMENT
    ====================================================== */
    $exists = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM {$table_trnx} WHERE reference=%s LIMIT 1",
            $reference
        )
    );

    if ($exists) {
        $log_security('duplicate_reference_blocked', [
            'user' => $user_id,
            'reference' => $reference
        ]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Duplicate transaction blocked']);
    }

    // Description created ONCE
    $description = "Airtime {$network} - Direct";

    // DAILY LIMIT (ONLY SUCCESS)
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');
    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx}
         WHERE user_id=%d
         AND date BETWEEN %s AND %s
         AND type='debit'
         AND category='airtime'
         AND status='success'
         FOR UPDATE",
        $user_id, $today_start, $today_end
    )) ?: 0;

    $account_limit = $user->account_limit ?: 5000;

    if (($spent_today + $amount) > $account_limit) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$account_limit} per day"]);
    }

    /* =====================================================
       INSERT PENDING (SAFE)
    ====================================================== */
    $wpdb->insert($table_trnx, [
        'user_id'     => $user_id,
        'details'     => json_encode(['network' => $network, 'phone' => $phone]),
        'recipient'   => $phone,
        'amount'      => $amount,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'airtime',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description
    ], ['%d', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);

    $trnx_id = $wpdb->insert_id;

    if (!$trnx_id) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Transaction initialization failed']);
    }

    $wpdb->query('COMMIT');

    // Notify: pending (purchase is now in flight)
    pulsepoint_send_airtime_email($user, 'pending', $network, $phone, $amount, $reference, $branding);

    /* =====================================================
       API CALL (OUTSIDE TRANSACTION)
    ====================================================== */

    $api_file = __DIR__ . '/' . strtolower($airtime_api) . '.php';
    if (!file_exists($api_file)) wp_send_json(['success' => false, 'message' => "Airtime API handler not found"]);
    require_once $api_file;
    if (!function_exists('send_airtime')) wp_send_json(['success' => false, 'message' => "Function not implemented"]);

    $wallet_debited   = false;
    $wallet_used      = 0.0;
    $referral_used    = 0.0;

    $api_response = send_airtime($network, $amount, $phone, $airtime_token, $reference, $trnx_id);

    $status = ($api_response['success'] ?? false) ? 'success' : 'failed';

    // Final debit (LOCKED, RE-VERIFIED AGAINST LIVE BALANCE)
    if ($status === 'success' && $api_mode === 'live') {
        $wpdb->query('START TRANSACTION');

        // Re-fetch under lock — balances may have moved since the pre-check
        $locked_user = $wpdb->get_row(
            $wpdb->prepare("SELECT wallet, referral_balance FROM `{$table_users}` WHERE id=%d FOR UPDATE", $user_id)
        );

        $live_wallet   = (float) $locked_user->wallet;
        $live_referral = (float) $locked_user->referral_balance;

        if (($live_wallet + $live_referral) < $amount) {
            $wpdb->query('ROLLBACK');
            $log_security('wallet_race_blocked', ['user' => $user_id, 'amount' => $amount]);
            wp_send_json(['success' => false, 'message' => 'Balance integrity violation blocked']);
        }

        // Wallet first, referral_balance covers the remainder
        $wallet_used   = min($live_wallet, $amount);
        $referral_used = round($amount - $wallet_used, 2);

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_users}
                 SET wallet = wallet - %f, referral_balance = referral_balance - %f
                 WHERE id=%d AND wallet >= %f AND referral_balance >= %f",
                $wallet_used, $referral_used, $user_id, $wallet_used, $referral_used
            )
        );

        if ($wpdb->rows_affected !== 1) {
            $wpdb->query('ROLLBACK');
            $log_security('wallet_race_blocked', ['user' => $user_id]);
            wp_send_json(['success' => false, 'message' => 'Balance integrity violation blocked']);
        }

        $wallet_debited = true;

        // Record the funding split for accurate refunds later
        $wpdb->update(
            $table_trnx,
            ['details' => json_encode([
                'network'       => $network,
                'phone'         => $phone,
                'wallet_used'   => $wallet_used,
                'referral_used' => $referral_used,
            ])],
            ['id' => $trnx_id],
            ['%s'],
            ['%d']
        );

        $wpdb->query('COMMIT');
    }

    /* =====================================================
       AUTO-REFUND ON FAILED API (FAIL-SAFE, SPLIT-AWARE)
    ====================================================== */
    if ($status === 'failed' && $api_mode === 'live' && $wallet_debited === true) {

        $wpdb->query('START TRANSACTION');

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_users} SET wallet = wallet + %f, referral_balance = referral_balance + %f WHERE id=%d",
                $wallet_used, $referral_used, $user_id
            )
        );

        $wpdb->update(
            $table_trnx,
            [
                'status'     => 'failed',
                'updated_at' => current_time('mysql')
            ],
            ['id' => $trnx_id],
            ['%s', '%s'],
            ['%d']
        );

        $wpdb->query('COMMIT');

        $log_security('auto_refund_executed', [
            'user'          => $user_id,
            'amount'        => $amount,
            'wallet_used'   => $wallet_used,
            'referral_used' => $referral_used,
            'reference'     => $reference,
            'trnx_id'       => $trnx_id
        ]);
    }

    $wpdb->update($table_trnx, [
        'status'           => $status,
        'gateway_response' => json_encode($api_response['details'] ?? []),
        'updated_at'       => current_time('mysql')
    ], ['id' => $trnx_id], ['%s', '%s', '%s'], ['%d']);

    // Notify: final outcome
    pulsepoint_send_airtime_email($user, $status, $network, $phone, $amount, $reference, $branding);

    if ($status === 'success' && function_exists('pulsepoint_save_beneficiary')) {
        pulsepoint_save_beneficiary($user_id, 'airtime', $phone, $phone, $network, ['network' => $network]);
    }

    wp_send_json([
        'success'     => $status === 'success',
        'message'     => $api_response['message'] ?? 'Airtime purchase failed.',
        'reference'   => $reference,
        'details'     => $api_response['details'] ?? [],
        'description' => $description
    ]);
}
