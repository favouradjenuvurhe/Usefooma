<?php
/**
 * Msorg Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/msorg.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via Msorg 
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Token in format "domain.com:token"
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    // Split token into domain and token part
    if (strpos($token, ':') === false) {
        return [
            'success' => false,
            'message' => 'Invalid token format (expected "domain.com:token")',
            'details' => []
        ];
    }

    list($domain, $api_token) = explode(':', $token, 2);
    $url = "https://{$domain}/api/airtime/";

    // Map networks to their IDs
    $network_map = [
        'MTN'     => 1,
        'AIRTEL'  => 2,
        'GLO'     => 3,
        '9MOBILE' => 4
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_id = $network_map[$network_upper];
    $request_id = $reference ?: 'MSORG_' . time();

    // Prepare JSON payload
    $payload = [
        "network"       => $network_id,
        "amount"        => (float) $amount,
        "mobile_number" => $phone,
        "Ported_number" => true,
        "airtime_type"  => "VTU"
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Token {$api_token}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle connection errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid JSON or empty response
    if (!$api_response || !isset($api_response['Status'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $status_lower = strtolower($api_response['Status']);
    $success = $status_lower === 'successful';

    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['Status'] ?? 'Airtime purchase failed');

    // Return standardized response
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['ident'] ?? $request_id,
            'network'        => $api_response['plan_network'] ?? $network_upper,
            'phone'          => $api_response['mobile_number'] ?? $phone,
            'amount'         => $api_response['amount'] ?? $amount,
            'paid_amount'    => $api_response['paid_amount'] ?? null,
            'old_balance'    => $api_response['balance_before'] ?? null,
            'new_balance'    => $api_response['balance_after'] ?? null,
            'status'         => $api_response['Status'] ?? null,
            'provider'       => 'Msorg',
            'api_response'   => $api_response
        ]
    ];
}