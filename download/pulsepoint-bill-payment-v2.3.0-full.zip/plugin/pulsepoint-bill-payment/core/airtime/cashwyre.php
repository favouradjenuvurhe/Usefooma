<?php
/**
 * Cashwyre Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/cashwyre.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via Cashwyre
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Combined token in format businessCode:secretKey
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    // Validate token format
    if (!strpos($token, ':')) {
        return [
            'success' => false,
            'message' => 'Invalid token format. Must be businessCode:secretKey',
            'details' => null
        ];
    }

    list($businessCode, $secretKey) = explode(':', $token, 2);
    $businessCode = trim($businessCode);
    $secretKey    = trim($secretKey);

    if (!$businessCode || !$secretKey) {
        return [
            'success' => false,
            'message' => 'Both businessCode and secretKey must be provided in token',
            'details' => null
        ];
    }

    $baseUrl = "https://businessapi.cashwyre.com/api/v1.0/Airtime/buyAirtime";
    $network_lower = strtolower($network);

    // Use reference if provided, otherwise generate one
    $requestReference = $reference ?: 'CW_' . time();

    // Prepare payload
    $payload = [
        "appId"        => $businessCode,
        "requestId"    => $requestReference,
        "businessCode" => $businessCode,
        "network"      => $network_lower,
        "phoneNumber"  => $phone,
        "reference"    => $requestReference,
        "amount"       => (float)$amount
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $baseUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$secretKey}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid or empty API response
    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;
    $message = $success
        ? ($api_response['message'] ?? "Airtime purchase successful")
        : ($api_response['message'] ?? 'Airtime purchase failed');

    $data = $api_response['data'] ?? [];

    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $data['reference'] ?? $requestReference,
            'network'        => $network_lower,
            'phone'          => $phone,
            'amount'         => $amount,
            'provider'       => 'Cashwyre',
            'api_response'   => $api_response
        ]
    ];
}