<?php
/**
 * Strowallet Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/strowallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via Strowallet
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Strowallet Public Key
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    $url = "https://strowallet.com/api/buyairtime/request/";

    // Map networks to Strowallet service names
    $network_map = [
        'MTN'     => 'mtn',
        'AIRTEL'  => 'airtel',
        'GLO'     => 'glo',
        '9MOBILE' => 'etisalat'
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $service_name = $network_map[$network_upper];
    $request_id   = $reference ?: 'STROWALLET_' . time();

    // Prepare JSON payload (Strowallet format)
    $payload = [
        "public_key"   => $token,
        "amount"       => (string) $amount,
        "phone"        => $phone,
        "service_name" => $service_name
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Accept: application/json",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle connection errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid JSON or empty response
    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;

    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['message'] ?? 'Airtime purchase failed');

    // Return standardized response (EXACT MSORG FORMAT)
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['reference'] ?? $request_id,
            'network'        => $network_upper,
            'phone'          => $phone,
            'amount'         => $amount,
            'paid_amount'    => $api_response['amount'] ?? null,
            'old_balance'    => $api_response['balance_before'] ?? null,
            'new_balance'    => $api_response['balance_after'] ?? null,
            'status'         => $api_response['success'] ?? null,
            'provider'       => 'Strowallet',
            'api_response'   => $api_response
        ]
    ];
}