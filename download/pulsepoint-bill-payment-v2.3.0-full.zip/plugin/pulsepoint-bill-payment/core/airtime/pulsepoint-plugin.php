<?php
/**
 * Pulsepoint Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/pulsepoint-api.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via Pulsepoint API
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Token in format "domain.com:token"
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime_pulsepoint($network, $amount, $phone, $token, $reference = '') {

    // Split token into domain and token part
    if (strpos($token, ':') === false) {
        return [
            'success' => false,
            'message' => 'Invalid token format (expected "domain.com:token")',
            'details' => []
        ];
    }

    list($domain, $api_token) = explode(':', $token, 2);
    $url = "https://{$domain}/api/airtime";

    // Map networks to their IDs (if your API uses numbers, else send names)
    $network_map = [
        'MTN'     => 'MTN',
        'AIRTEL'  => 'AIRTEL',
        'GLO'     => 'GLO',
        '9MOBILE' => '9MOBILE'
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $request_id = $reference ?: 'PULSEPOINT_' . time();

    // Prepare JSON payload
    $payload = [
        "network"       => $network_map[$network_upper],
        "amount"        => (float) $amount,
        "mobile_number" => $phone,
        "Ported_number" => false, // default false, can be parameterized if needed
        "airtime_type"  => "VTU"
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Token {$api_token}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle connection errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid JSON or empty response
    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;
    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['message'] ?? 'Airtime purchase failed');

    // Return standardized response
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['data']['reference'] ?? $request_id,
            'network'        => $network_upper,
            'phone'          => $phone,
            'amount'         => $amount,
            'paid_amount'    => $api_response['data']['paid_amount'] ?? null,
            'old_balance'    => $api_response['data']['balance_before'] ?? null,
            'new_balance'    => $api_response['data']['balance_after'] ?? null,
            'status'         => $success ? 'Successful' : 'Failed',
            'provider'       => 'Pulsepoint',
            'api_response'   => $api_response
        ]
    ];
}