<?php
/**
 * SMEPlug Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/smeplug.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via SMEPlug
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Token in format "domain.com:private_key"
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    // Split token into domain and key
    if (strpos($token, ':') === false) {
        return [
            'success' => false,
            'message' => 'Invalid token format)',
            'details' => []
        ];
    }

    list($domain, $api_key) = explode(':', $token, 2);
    $url = "https://{$domain}/api/v1/airtime/purchase";

    // Map networks to SMEPlug network IDs
    $network_map = [
        'MTN'     => 1,
        'AIRTEL'  => 2,
        'GLO'     => 4,
        '9MOBILE' => 3
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_id = $network_map[$network_upper];
    $request_id = $reference ?: 'SMEPLUG_' . time();

    // Prepare payload
    $payload = [
        "network_id" => $network_id,
        "phone"      => $phone,
        "amount"     => (float) $amount
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$api_key}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid or empty API response
    if (!$api_response || !isset($api_response['status'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['status'] === true;
    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['message'] ?? 'Airtime purchase failed');

    // Standardized return format
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['data']['reference'] ?? $request_id,
            'network'        => $network_upper,
            'phone'          => $phone,
            'amount'         => $amount,
            'provider'       => 'SMEPlug',
            'api_response'   => $api_response
        ]
    ];
}