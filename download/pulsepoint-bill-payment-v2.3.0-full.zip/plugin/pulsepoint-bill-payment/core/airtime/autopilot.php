<?php
/**
 * Autopilot Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/autopilot.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via Autopilot API
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Token in format "domain.com:api_key"
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    // Validate token format
    if (strpos($token, ':') === false) {
        return [
            'success' => false,
            'message' => 'Invalid token format',
            'details' => []
        ];
    }

    list($domain, $api_key) = explode(':', $token, 2);
    $url = "https://{$domain}/api/live/v1/airtime";

    // Map network names to IDs
    $network_map = [
        'MTN'     => "1",
        'AIRTEL'  => "2",
        'GLO'     => "3",
        '9MOBILE' => "4"
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_id = $network_map[$network_upper];
    $request_id = $reference ?: 'AUTOPILOT_' . time();

    // Prepare JSON payload
    $payload = [
        "networkId"   => $network_id,
        "airtimeType" => "VTU",
        "amount"      => (string)$amount,
        "phone"       => $phone,
        "reference"   => $request_id
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$api_key}",
        "Content-Type: application/json",
        "Accept: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid JSON or no response
    if (!$api_response || !isset($api_response['status'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['status'] === true;
    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['message'] ?? 'Airtime purchase failed');

    // Standardized response
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['data']['reference'] ?? $request_id,
            'network'        => $api_response['data']['networkDiscovered'] ?? $network_upper,
            'phone'          => $phone,
            'amount'         => $amount,
            'provider'       => 'Autopilot',
            'status_code'    => $api_response['code'] ?? null,
            'timestamp'      => $api_response['time'] ?? null,
            'api_response'   => $api_response
        ]
    ];
}