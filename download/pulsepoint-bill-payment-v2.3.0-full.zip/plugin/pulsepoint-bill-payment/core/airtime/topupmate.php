<?php
/**
 * TopupMate Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/topupmate.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via TopupMate API
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float  $amount  Amount to recharge
 * @param string $phone   Recipient phone number
 * @param string $token   Token in format "domain.com:token"
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    // Split token into domain and token part
    if (strpos($token, ':') === false) {
        return [
            'success' => false,
            'message' => 'Invalid token format")',
            'details' => []
        ];
    }

    list($domain, $api_token) = explode(':', $token, 2);
    $url = "http://{$domain}/api/airtime/";

    // Map network names to IDs
    $network_map = [
        'MTN'     => 1,
        'AIRTEL'  => 4,
        'GLO'     => 2,
        '9MOBILE' => 3
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_id = $network_map[$network_upper];
    $request_id = $reference ?: 'TOPUPMATE_' . time();

    // Prepare JSON payload
    $payload = [
        "network"        => (string)$network_id,
        "phone"          => $phone,
        "ref"            => $request_id,
        "airtime_type"   => "VTU",
        "ported_number"  => false,
        "amount"         => (string)$amount
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Token {$api_token}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid or empty response
    if (!$api_response || !isset($api_response['status'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $status_lower = strtolower($api_response['status']);
    $success = $status_lower === 'success';

    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['status'] ?? 'Airtime purchase failed');

    // Standardized return structure
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $request_id,
            'network'        => $api_response['network'] ?? $network_upper,
            'phone'          => $phone,
            'amount'         => $api_response['amount'] ?? $amount,
            'old_balance'    => $api_response['oldbal'] ?? null,
            'new_balance'    => $api_response['newbal'] ?? null,
            'service'        => $api_response['service'] ?? 'Airtime',
            'provider'       => 'TopupMate',
            'api_response'   => $api_response
        ]
    ];
}