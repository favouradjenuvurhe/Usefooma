<?php
/**
 * Pulsepoint Airtime-to-Cash — Active Network Rates List
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/a2c/rates.php
 * Author: Amaaavl
 *
 * Public GET list of active networks the airtime-to-cash trade page needs
 * to populate its network selector and show min/max + rate up front.
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_get_a2c_rates', 'pulsepoint_get_a2c_rates');
add_action('wp_ajax_nopriv_pulsepoint_get_a2c_rates', 'pulsepoint_get_a2c_rates');

function pulsepoint_get_a2c_rates() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_rates = "{$base_prefix}airtime_to_cash";

    $rows = $wpdb->get_results(
        "SELECT id, network, rate, min_amount, max_amount, instruction
         FROM {$table_rates}
         WHERE status = 'active'
         ORDER BY network ASC"
    );

    if (!$rows) {
        wp_send_json([]);
    }

    $networks = [];

    foreach ($rows as $r) {
        $networks[] = [
            'id'          => (int) $r->id,
            'network'     => $r->network,
            'rate'        => number_format((float) $r->rate, 2, '.', ''),
            'min_amount'  => number_format((float) $r->min_amount, 2, '.', ''),
            'max_amount'  => number_format((float) $r->max_amount, 2, '.', ''),
            'instruction' => $r->instruction,
        ];
    }

    wp_send_json($networks);
}
