<?php
/**
 * Pulsepoint Airtime-to-Cash Trade Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime-to-cash/pulsepoint.php
 * Author: Amaaavl
 *
 * WHAT THIS IS:
 * Unlike airtime purchase (user pays wallet -> gets airtime instantly via API),
 * this is a MANUAL trade: user sends airtime to a receiver number, uploads proof,
 * and a `pending` trade record is created. NOTHING is debited or credited at
 * submission time — an admin reviews the proof and, on approval, credits the
 * user's wallet with `payable`. This file only handles submission. The
 * admin-side approve/reject handler (which does the actual wallet credit)
 * is intentionally out of scope here — flag if you want that written too.
 *
 * TABLES USED (as supplied):
 * {$prefix}airtime_to_cash              - admin-configured network rates/limits
 * {$prefix}airtime_to_cash_transactions - user trade submissions
 */

if (!defined('ABSPATH')) exit;

// Hook for AJAX requests
add_action('wp_ajax_nopriv_pulsepoint_airtime_to_cash_trade', 'pulsepoint_airtime_to_cash_trade');
add_action('wp_ajax_pulsepoint_airtime_to_cash_trade', 'pulsepoint_airtime_to_cash_trade');

const PULSEPOINT_A2C_DEFAULT_MAX_AMOUNT = 50000.00; // hard per-transaction cap fallback
const PULSEPOINT_A2C_ALLOWED_PROOF_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
const PULSEPOINT_A2C_MAX_PROOF_BYTES = 5 * 1024 * 1024; // 5MB

/**
 * Render the airtime-to-cash email template with escaped values.
 * Falls back to a minimal safe message if the template file is missing.
 */
if (!function_exists('pulsepoint_render_a2c_email')) {
    function pulsepoint_render_a2c_email(array $vars): string {
        $template_path = dirname(__DIR__, 2) . '/templates/airtime_to_cash.html';

        if (!file_exists($template_path)) {
            return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
        }

        $html = file_get_contents($template_path);

        $defaults = [
            'platform_name' => 'Pulsepoint',
            'color_hex'     => '#6C63FF',
            'status_label'  => '',
            'status_color'  => '#6C63FF',
            'firstname'     => '',
            'network'       => '',
            'sender_number' => '',
            'amount'        => '',
            'payable'       => '',
            'reference'     => '',
            'date'          => date('Y-m-d H:i:s'),
            'message'       => '',
            'year'          => date('Y'),
            'support_email' => get_option('admin_email'),
        ];

        $vars = array_merge($defaults, $vars);

        foreach ($vars as $key => $value) {
            $safe = $key === 'message'
                ? $value
                : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
            $html = str_replace('{{' . $key . '}}', $safe, $html);
        }

        return $html;
    }
}

/**
 * Send the status email for an airtime-to-cash trade (submitted/approved/declined).
 */
if (!function_exists('pulsepoint_send_a2c_email')) {
    function pulsepoint_send_a2c_email(
        object $user,
        string $status,
        string $network,
        string $sender_number,
        float $amount,
        float $payable,
        string $reference,
        array $branding
    ): void {
        if (empty($user->email)) {
            return;
        }

        $status_map = [
            'submitted' => ['label' => 'Submitted', 'color' => '#d97706', 'subject' => 'Airtime-to-Cash Trade Submitted'],
            'approved'  => ['label' => 'Approved',  'color' => '#16a34a', 'subject' => 'Airtime-to-Cash Trade Approved'],
            'declined'  => ['label' => 'Declined',  'color' => '#dc2626', 'subject' => 'Airtime-to-Cash Trade Declined'],
        ];

        $meta = $status_map[$status] ?? $status_map['submitted'];

        $message = match ($status) {
            'approved' => "Your airtime-to-cash trade has been approved and the payable amount has been credited to your wallet.",
            'declined' => "Your airtime-to-cash trade could not be approved. Please check the remark on your transaction history.",
            default    => "We've received your airtime-to-cash trade and it's awaiting review. You'll be notified once it's confirmed.",
        };

        @wp_mail(
            $user->email,
            $meta['subject'],
            pulsepoint_render_a2c_email([
                'platform_name' => $branding['platform_name'],
                'color_hex'     => $branding['color_hex'],
                'status_label'  => $meta['label'],
                'status_color'  => $meta['color'],
                'firstname'     => $user->firstname,
                'network'       => $network,
                'sender_number' => $sender_number,
                'amount'        => number_format($amount, 2),
                'payable'       => number_format($payable, 2),
                'reference'     => $reference,
                'date'          => current_time('mysql'),
                'message'       => $message,
            ]),
            ['Content-Type: text/html; charset=UTF-8']
        );
    }
}

function pulsepoint_airtime_to_cash_trade() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id      = (int) $_SESSION['pulsepoint_user']['id'];
    $table_users  = $wpdb->prefix . 'pulsepoint_users';
    $base_prefix  = $wpdb->prefix . 'pulsepoint_';
    $table_rates  = "{$base_prefix}airtime_to_cash";
    $table_trnx   = "{$base_prefix}airtime_to_cash_transactions";

    /* =====================================================
       SECURITY LOGGING FUNCTION (NO NEW TABLE)
    ====================================================== */
    $log_security = function ($event, $meta = []) use ($wpdb, $base_prefix) {
        $wpdb->insert(
            "{$base_prefix}logs",
            [
                'event'      => $event,
                'meta'       => json_encode($meta),
                'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );
    };

    // Rate limiter
    $now = time();
    if (isset($_SESSION['last_a2c_request'][$user_id]) && ($now - $_SESSION['last_a2c_request'][$user_id]) < 15) {
        $log_security('a2c_rate_limited', ['user' => $user_id]);
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);
    }
    $_SESSION['last_a2c_request'][$user_id] = $now;

    // Fetch user
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id=%d", $user_id)
    );

    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $require_kyc      = isset($settings['a2c_kyc']) && $settings['a2c_kyc'] == 1;
    $daily_limit      = isset($settings['a2c_daily_limit']) && $settings['a2c_daily_limit'] > 0
        ? (float) $settings['a2c_daily_limit']
        : null; // null = no daily cap enforced

    $branding = [
        'platform_name' => $settings['platform_name'] ?? 'Pulsepoint',
        'color_hex'     => $settings['color_hex'] ?? '#6C63FF',
    ];

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    // KYC CHECK
    if ($require_kyc && $user->statuskyc != 1) {
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }

    // Sanitize inputs
    $network       = isset($_POST['network']) ? strtoupper(trim(sanitize_text_field($_POST['network']))) : '';
    $sender_number = isset($_POST['sender_number']) ? preg_replace('/[^0-9+]/', '', sanitize_text_field($_POST['sender_number'])) : '';
    $amount        = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
    $reference     = isset($_POST['reference']) ? sanitize_text_field($_POST['reference']) : '';

    /* =====================================================
       INPUT VALIDATION
    ====================================================== */
    if ($amount <= 0 || !is_finite($amount)) {
        wp_send_json(['success' => false, 'message' => 'Network, sender number, and amount are required.']);
    }

    // Nigerian mobile number: 11 digits starting with 0, or +234 followed by 10 digits
    $phone_digits = preg_replace('/\D/', '', $sender_number);
    $valid_phone = (bool) preg_match('/^0\d{10}$/', $phone_digits)
        || (bool) preg_match('/^234\d{10}$/', $phone_digits);

    if (empty($sender_number) || !$valid_phone) {
        $log_security('a2c_invalid_phone_rejected', ['user' => $user_id, 'sender_number' => $sender_number]);
        wp_send_json(['success' => false, 'message' => 'Please enter a valid sender phone number.']);
    }

    /* =====================================================
       NETWORK / RATE CONFIG LOOKUP (ADMIN-CONTROLLED, NOT HARDCODED)
    ====================================================== */
    $rate_row = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM `{$table_rates}` WHERE network=%s AND status='active' LIMIT 1",
            $network
        )
    );

    if (!$rate_row) {
        $log_security('a2c_invalid_network_rejected', ['user' => $user_id, 'network' => $network]);
        wp_send_json(['success' => false, 'message' => 'This network is not available for airtime-to-cash trade right now.']);
    }

    $rate       = (float) $rate_row->rate; // treated as a percentage payout, e.g. 85.00 = 85%
    $min_amount = (float) $rate_row->min_amount;
    $max_amount = (float) $rate_row->max_amount ?: PULSEPOINT_A2C_DEFAULT_MAX_AMOUNT;

    if ($amount < $min_amount) {
        wp_send_json(['success' => false, 'message' => 'Minimum trade amount for ' . $network . ' is ₦' . number_format($min_amount, 2)]);
    }

    if ($amount > $max_amount) {
        $log_security('a2c_amount_cap_exceeded', ['user' => $user_id, 'amount' => $amount, 'cap' => $max_amount]);
        wp_send_json(['success' => false, 'message' => 'Maximum trade amount for ' . $network . ' is ₦' . number_format($max_amount, 2)]);
    }

    // Optional daily cumulative cap (based on submitted trades, not just approved ones)
    if ($daily_limit !== null) {
        $today_start = date('Y-m-d 00:00:00');
        $today_end   = date('Y-m-d 23:59:59');
        $spent_today = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(amount) FROM {$table_trnx}
             WHERE user_id=%d
             AND created BETWEEN %s AND %s
             AND status IN ('pending','approved')",
            $user_id, $today_start, $today_end
        )) ?: 0;

        if (($spent_today + $amount) > $daily_limit) {
            wp_send_json(['success' => false, 'message' => "Daily Max ₦" . number_format($daily_limit, 2) . " per day"]);
        }
    }

    $payable = round($amount * ($rate / 100), 2);

    /* =====================================================
       PROOF UPLOAD (REQUIRED FOR MANUAL REVIEW)
    ====================================================== */
    if (empty($_FILES['proof']) || $_FILES['proof']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json(['success' => false, 'message' => 'Proof of airtime transfer is required.']);
    }

    $file = $_FILES['proof'];

    if ($file['size'] > PULSEPOINT_A2C_MAX_PROOF_BYTES) {
        wp_send_json(['success' => false, 'message' => 'Proof file is too large (max 5MB).']);
    }

    $file_type = mime_content_type($file['tmp_name']);
    if (!in_array($file_type, PULSEPOINT_A2C_ALLOWED_PROOF_TYPES, true)) {
        $log_security('a2c_invalid_proof_type', ['user' => $user_id, 'type' => $file_type]);
        wp_send_json(['success' => false, 'message' => 'Proof must be a JPG, PNG, WEBP, or PDF.']);
    }

    if (!function_exists('wp_handle_upload')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    $upload_overrides = ['test_form' => false, 'mimes' => [
        'jpg|jpeg' => 'image/jpeg',
        'png'      => 'image/png',
        'webp'     => 'image/webp',
        'pdf'      => 'application/pdf',
    ]];

    $moved = wp_handle_upload($file, $upload_overrides);

    if (!$moved || isset($moved['error'])) {
        $log_security('a2c_proof_upload_failed', ['user' => $user_id, 'error' => $moved['error'] ?? 'unknown']);
        wp_send_json(['success' => false, 'message' => 'Could not upload proof, please try again.']);
    }

    $proof_url = $moved['url'];

    if (empty($reference)) {
        $reference = 'A2C' . bin2hex(random_bytes(6));
    }

    /* =====================================================
       IDEMPOTENCY + UNIQUE REFERENCE ENFORCEMENT
    ====================================================== */
    $exists = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM {$table_trnx} WHERE reference=%s LIMIT 1", $reference)
    );

    if ($exists) {
        $log_security('a2c_duplicate_reference_blocked', ['user' => $user_id, 'reference' => $reference]);
        wp_send_json(['success' => false, 'message' => 'Duplicate transaction blocked']);
    }

    /* =====================================================
       INSERT PENDING TRADE (NO WALLET MOVEMENT HERE)
    ====================================================== */
    $inserted = $wpdb->insert($table_trnx, [
        'reference'       => $reference,
        'user_id'         => $user_id,
        'network'         => $network,
        'sender_number'   => $sender_number,
        'receiver_number' => $rate_row->receiver_number,
        'amount'          => $amount,
        'rate'            => $rate,
        'payable'         => $payable,
        'proof'           => $proof_url,
        'status'          => 'pending',
    ], ['%s', '%d', '%s', '%s', '%s', '%f', '%f', '%f', '%s', '%s']);

    if (!$inserted) {
        $log_security('a2c_insert_failed', ['user' => $user_id, 'reference' => $reference]);
        wp_send_json(['success' => false, 'message' => 'Could not submit trade, please try again.']);
    }

    $trnx_id = $wpdb->insert_id;

    $log_security('a2c_trade_submitted', [
        'user'      => $user_id,
        'reference' => $reference,
        'trnx_id'   => $trnx_id,
        'network'   => $network,
        'amount'    => $amount,
        'payable'   => $payable,
    ]);

    // Notify: submitted (awaiting admin review)
    pulsepoint_send_a2c_email($user, 'submitted', $network, $sender_number, $amount, $payable, $reference, $branding);

    wp_send_json([
        'success'     => true,
        'message'     => 'Trade submitted successfully and is awaiting review.',
        'reference'   => $reference,
        'payable'     => $payable,
        'receiver'    => [
            'number' => $rate_row->receiver_number,
            'name'   => $rate_row->receiver_name,
        ],
        'instruction' => $rate_row->instruction,
    ]);
}
