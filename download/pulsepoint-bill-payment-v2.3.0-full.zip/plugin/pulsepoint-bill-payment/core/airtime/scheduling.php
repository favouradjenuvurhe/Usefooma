<?php
/**
 * Pulsepoint Scheduling Input (Airtime)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/scheduling.php
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_airtime_schedule', 'pulsepoint_airtime_schedule');
add_action('wp_ajax_pulsepoint_airtime_schedule', 'pulsepoint_airtime_schedule');

function pulsepoint_airtime_schedule() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $base_prefix  = $wpdb->prefix . 'pulsepoint_';
    $table_users  = $base_prefix . 'users';
    $table_jobs   = $base_prefix . 'airtime_jobs';

    // =========================================
    // GET INPUT (API STYLE)
    // =========================================
    $input = json_decode(file_get_contents("php://input"), true);

    $token      = $input['token'] ?? '';
    $network    = strtoupper(trim($input['network'] ?? ''));
    $amount     = floatval($input['amount'] ?? 0);
    $phone      = sanitize_text_field($input['mobile_number'] ?? '');
    $ported     = !empty($input['Ported_number']) ? 1 : 0;
    $type       = $input['airtime_type'] ?? 'VTU';

    // NEW: scheduling fields
    $schedule_type   = $input['schedule_type'] ?? 'one_time'; // one_time | recurring
    $run_at          = $input['run_at'] ?? current_time('mysql');
    $interval_minutes = isset($input['interval_minutes']) ? intval($input['interval_minutes']) : null;

    // =========================================
    // VALIDATE TOKEN
    // =========================================
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table_users} WHERE token=%s LIMIT 1",
            $token
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid token'
        ]);
    }

    // =========================================
    // VALIDATION RULES
    // =========================================
    if (!$network || !$phone || $amount < 50) {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid input (minimum ₦50)'
        ]);
    }

    if (!in_array($schedule_type, ['one_time','recurring'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid schedule type'
        ]);
    }

    if ($schedule_type === 'recurring' && empty($interval_minutes)) {
        wp_send_json([
            'success' => false,
            'message' => 'Recurring jobs require interval_minutes'
        ]);
    }

    // =========================================
    // CALCULATE NEXT RUN
    // =========================================
    $next_run = $run_at;

    // =========================================
    // INSERT SCHEDULE JOB
    // =========================================
    $insert = $wpdb->insert($table_jobs, [
        'token'       => $token,
        'network'          => $network,
        'amount'           => $amount,
        'mobile_number'    => $phone,
        'ported_number'    => $ported,
        'airtime_type'     => $type,

        'schedule_type'    => $schedule_type,
        'run_at'           => $run_at,
        'interval_minutes' => $interval_minutes,
        'next_run'         => $next_run,

        'is_active'        => 1
    ], [
        '%s','%s','%f','%s','%d','%s',
        '%s','%s','%d','%s','%d'
    ]);

    if (!$insert) {
        wp_send_json([
            'success' => false,
            'message' => 'Failed to create schedule'
        ]);
    }

    // =========================================
    // RESPONSE
    // =========================================
    wp_send_json([
        'success'  => true,
        'message'  => 'Airtime schedule created successfully',
        'job_id'   => $wpdb->insert_id,
        'next_run' => $next_run
    ]);
}