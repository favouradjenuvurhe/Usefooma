<?php
/**
 * Adex Airtime API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/airtime/adex.php
 */

if (!defined('ABSPATH')) exit;

/**
 * Send airtime via Adex
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param float $amount Amount to recharge
 * @param string $phone Recipient phone number
 * @param string $token Token in format "domain.com:token"
 * @param string $reference Optional transaction reference
 * @return array Standardized response
 */
function send_airtime($network, $amount, $phone, $token, $reference = '') {

    // Split token into domain and token
    if (strpos($token, ':') === false) {
        return [
            'success' => false,
            'message' => 'Invalid token format',
            'details' => []
        ];
    }

    list($domain, $api_token) = explode(':', $token, 2);
    $url = "https://{$domain}/api/topup";

    // Map network names to IDs
    $network_map = [
        'MTN'     => 1,
        'AIRTEL'  => 2,
        'GLO'     => 3,
        '9MOBILE' => 4
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_id = $network_map[$network_upper];
    $request_id = $reference ?: 'Airtime_' . time();

    // Prepare cURL payload
    $payload = [
        'network'    => $network_id,
        'phone'      => $phone,
        'plan_type'  => 'VTU',
        'bypass'     => false,
        'amount'     => $amount,
        'request-id' => $request_id
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Token {$api_token}",
        'Content-Type: application/json'
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    if (!$api_response || !isset($api_response['status'])) {
        return [
            'success' => false,
            'message' => "Invalid API response",
            'details' => $response_raw
        ];
    }

    $success = strtolower($api_response['status']) === 'success';
    $message = $success
        ? "Airtime purchase successful"
        : ($api_response['message'] ?? 'Airtime purchase failed');

    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $request_id,
            'network'        => $network_upper,
            'phone'          => $phone,
            'amount'         => $amount,
            'discount'       => $api_response['discount'] ?? null,
            'old_balance'    => $api_response['oldbal'] ?? null,
            'new_balance'    => $api_response['newbal'] ?? null,
            'plan_type'      => $api_response['plan_type'] ?? 'VTU',
            'system'         => $api_response['system'] ?? 'API',
            'wallet_vending' => $api_response['wallet_vending'] ?? 'wallet',
            'api_response'   => $api_response,
            'provider'       => 'Adex'
        ]
    ];
}