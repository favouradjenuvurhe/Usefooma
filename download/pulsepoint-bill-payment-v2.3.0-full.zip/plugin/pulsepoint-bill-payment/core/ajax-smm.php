<?php
if (!defined('ABSPATH')) exit;

// Fetch active SMM services (optionally filtered by category)
add_action('wp_ajax_pulsepoint_get_smm', 'pulsepoint_get_smm');
add_action('wp_ajax_nopriv_pulsepoint_get_smm', 'pulsepoint_get_smm');

function pulsepoint_get_smm() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table = "{$base_prefix}smm_services";

    $category = isset($_REQUEST['category']) ? sanitize_text_field($_REQUEST['category']) : '';

    if ($category) {
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, category, name, rate, min, max, refill, cancel FROM {$table} WHERE status='active' AND category = %s ORDER BY name ASC",
            $category
        ));
    } else {
        $rows = $wpdb->get_results(
            "SELECT id, category, name, rate, min, max, refill, cancel FROM {$table} WHERE status='active' ORDER BY category ASC, name ASC"
        );
    }

    if (!$rows) {
        wp_send_json([]);
    }

    $settings_rows = $wpdb->get_results("SELECT opt_value FROM {$base_prefix}settings WHERE opt_key = 'smm_markup'");
    $markup = $settings_rows ? (float) maybe_unserialize($settings_rows[0]->opt_value) : 0;

    $provider_raw = $wpdb->get_var("SELECT opt_value FROM {$base_prefix}settings WHERE opt_key = 'smm_api_provider'");
    $provider = strtolower(trim((string) maybe_unserialize($provider_raw ?: 'owlet')));

    $services = [];

    foreach ($rows as $r) {
        $base_cost = ($provider === 'ncwallet')
            ? (float) $r->rate
            : ((float) $r->rate / 1000);
        $unit_price = $base_cost + ($base_cost * ($markup / 100));

        $services[] = [
            'id'          => (int) $r->id,
            'category'    => $r->category,
            'name'        => $r->name,
            'unit_price'  => round($unit_price, 4), // price per 1 quantity, after markup
            'min'         => (int) $r->min,
            'max'         => (int) $r->max,
            'refill'      => (bool) $r->refill,
            'cancel'      => (bool) $r->cancel,
        ];
    }

    wp_send_json($services);
}

// Fetch distinct categories only (for the category picker)
add_action('wp_ajax_pulsepoint_get_smm_categories', 'pulsepoint_get_smm_categories');
add_action('wp_ajax_nopriv_pulsepoint_get_smm_categories', 'pulsepoint_get_smm_categories');

function pulsepoint_get_smm_categories() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table = "{$base_prefix}smm_services";

    $categories = $wpdb->get_col("SELECT DISTINCT category FROM {$table} WHERE status='active' ORDER BY category ASC");

    wp_send_json($categories ?: []);
}
