<?php

if (!defined('ABSPATH')) exit;

function send_recharge($data) {

    $network  = strtoupper($data['network'] ?? 'MTN');
    $amount   = $data['amount'] ?? 100;
    $name     = $data['name'] ?? 'Pulsepoint';
    $reference= $data['reference'] ?? uniqid();

    return [
        'success'   => true,
        'network'   => $network,
        'amount'    => $amount,
        'name'      => $name,
        'reference' => $reference,

        // 16-digit recharge PIN
        'code' => mt_rand(1000,9999)
                . mt_rand(1000,9999)
                . mt_rand(1000,9999)
                . mt_rand(1000,9999),

        // serial number
        'serial' => strtoupper(
            substr(md5(uniqid(mt_rand(), true)), 0, 12)
        ),

        'status' => 'success'
    ];
}