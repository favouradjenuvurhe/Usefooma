<?php
/**
 * NCWallet Betting Provider
 * File: core/betting/ncwallet.php
 * Author: Amaaavl
 *
 * POST https://ncwallet.africa/api/v1/betting
 * Headers: Accept, Content-Type, trnx_pin, Authorization
 * Body: { betsite_id, betting_number, amount, bypass }
 *
 * Same pin:token settings convention as core/education/ncwallet.php —
 * the `betting_token` setting is stored as "pin:token".
 */

if (!defined('ABSPATH')) exit;

function send_betting($provider, $service_id, $customer_id, $amount, $reference, $trnx_id) {

    global $wpdb;
    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $table_settings = "{$base_prefix}settings";

    // ✅ Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}", OBJECT_K);

    $betting_api   = $settings_rows['betting_api']->opt_value ?? 'https://ncwallet.africa/api/v1/betting';
    $betting_token = $settings_rows['betting_token']->opt_value ?? '';

    if (!$betting_token) {
        return [
            'success' => false,
            'message' => 'NCWallet Betting API not configured'
        ];
    }

    // ✅ SPLIT pin:token
    $parts    = explode(':', $betting_token);
    $trnx_pin = trim($parts[0] ?? '');
    $token    = trim($parts[1] ?? '');

    if (!$token) {
        return [
            'success' => false,
            'message' => 'Invalid NCWallet token format. Expected pin:token'
        ];
    }

    // ✅ Build payload
    $payload = [
        'betsite_id'     => (string) $service_id,
        'betting_number' => (string) $customer_id,
        'amount'         => (string) $amount,
        'bypass'         => false,
    ];

    // ✅ CURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $betting_api);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        "trnx_pin: {$trnx_pin}",
        "Authorization: {$token}"
    ];

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return [
            'success' => false,
            'message' => 'Curl Error: ' . $error
        ];
    }

    curl_close($ch);

    // ✅ Decode response
    $res = json_decode($response, true);

    if (!$res) {
        return [
            'success' => false,
            'message' => 'Invalid API response'
        ];
    }

    $status = strtolower($res['status'] ?? '');

    if ($status !== 'success') {
        return [
            'success' => false,
            'message' => $res['message'] ?? 'Betting funding failed',
        ];
    }

    // FINAL RESPONSE (STANDARD FORMAT)
    return [
        'success' => true,
        'message' => $res['message'] ?? 'Betting wallet funded successfully',
        'data'    => $res['data'] ?? [],
    ];
}
