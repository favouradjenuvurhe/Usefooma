<?php
/**
 * Pulsepoint Betting Wallet Funding Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/betting/pulsepoint.php
 * Author: Amaaavl
 *
 * Same shape as core/education/pulsepoint.php and core/cable/pulsepoint.php:
 * user picks a biller (betting platform) from the `betting` table, enters
 * their platform customer ID and an amount, and it's funded from wallet.
 * A provider file (core/betting/{provider}.php exposing send_betting())
 * is dynamically loaded per biller, same convention as airtime/data/education.
 */

if (!defined('ABSPATH')) exit;

// AJAX Hooks
add_action('wp_ajax_nopriv_pulsepoint_betting_purchase', 'pulsepoint_betting_purchase');
add_action('wp_ajax_pulsepoint_betting_purchase', 'pulsepoint_betting_purchase');

function pulsepoint_betting_purchase() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in']);
    }

    $user_id     = $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_bet   = "{$base_prefix}betting";

    /** RATE LIMIT **/
    $now = time();
    if (isset($_SESSION['last_bet_request'][$user_id]) && ($now - $_SESSION['last_bet_request'][$user_id]) < 15) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds']);
    }
    $_SESSION['last_bet_request'][$user_id] = $now;

    /** FETCH USER **/
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id)
    );

    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active']);
    }

    /** LOAD SETTINGS **/
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");

    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    /** SANITIZE INPUT **/
    $biller_id    = intval($_POST['biller'] ?? 0);
    $customer_id  = sanitize_text_field($_POST['customer_id'] ?? '');
    $amount       = floatval($_POST['amount'] ?? 0);
    $reference    = sanitize_text_field($_POST['reference'] ?? '');

    if (!$biller_id || empty($customer_id) || $amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Biller, customer ID, and amount are required']);
    }

    /** GET BETTING BILLER **/
    $biller = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_bet} WHERE id=%d", $biller_id)
    );

    if (!$biller) {
        wp_send_json(['success' => false, 'message' => 'Invalid betting platform']);
    }

    $provider    = strtolower(trim($biller->provider));
    $service_id  = trim($biller->serviceid);
    $biller_name = trim($biller->biller);

    $fee   = (float) ($api_mode === 'api' ? $biller->fee_api : $biller->fee);
    $total = $amount + $fee;

    /** REFERENCE **/
    if (empty($reference)) {
        $reference = 'PSNG' . mt_rand(10000, 99999) . 'B';
    }

    $description = strtoupper($biller_name) . " - Wallet Funding ({$customer_id})";

    /** DAILY LIMIT **/
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');

    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx}
        WHERE user_id=%d
        AND date BETWEEN %s AND %s
        AND type='debit'",
        $user_id, $today_start, $today_end
    ));

    $spent_today = $spent_today ?: 0;
    $limit = $user->account_limit ?: 5000;

    if (($spent_today + $total) > $limit) {
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$limit} reached"]);
    }

    /** WALLET CHECK **/
    if ($api_mode === 'live' && $user->wallet < $total) {
        wp_send_json(['success' => false, 'message' => 'Insufficient balance']);
    }

    /** API MODE **/
    if ($api_mode === 'off') {
        wp_send_json(['success' => false, 'message' => 'Service not available']);
    }

    if ($api_mode === 'sandbox') {
        wp_send_json(['success' => true, 'message' => 'Betting Funding Success (Sandbox Mode)']);
    }

    /** LOAD PROVIDER FILE **/
    $safe_provider = preg_replace('/[^a-z0-9]/i', '', $provider);
    $api_file = __DIR__ . "/{$safe_provider}.php";

    if (!file_exists($api_file)) {
        wp_send_json(['success' => false, 'message' => 'Provider file missing. Ask admin to add core/betting/' . $safe_provider . '.php']);
    }

    require_once $api_file;

    if (!function_exists('send_betting')) {
        wp_send_json(['success' => false, 'message' => 'send_betting() missing']);
    }

    /** INSERT PENDING **/
    $wpdb->insert($table_trnx, [
        'user_id'     => $user_id,
        'details'     => json_encode([
            'provider'    => $provider,
            'biller'      => $service_id,
            'customer_id' => $customer_id,
        ]),
        'recipient'   => $customer_id,
        'amount'      => $total,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'others',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description,
    ]);

    $trnx_id = $wpdb->insert_id;

    /** CALL PROVIDER **/
    try {

        $api_response = send_betting(
            $provider,
            $service_id,
            $customer_id,
            $amount,
            $reference,
            $trnx_id
        );

    } catch (Exception $e) {
        wp_send_json(['success' => false, 'message' => 'Provider Error']);
    }

    $status = (!empty($api_response['success'])) ? 'success' : 'failed';

    /** UPDATE TRANSACTION **/
    $wpdb->update($table_trnx, [
        'status'           => $status,
        'gateway_response' => json_encode($api_response),
        'updated_at'       => current_time('mysql'),
    ], ['id' => $trnx_id]);

    /** DEDUCT WALLET **/
    $new_wallet = $user->wallet;

    if ($status === 'success' && $api_mode === 'live') {

        $new_wallet -= $total;

        $wpdb->update(
            $table_users,
            ['wallet' => $new_wallet],
            ['id' => $user_id]
        );

        if ((float) $biller->cashback > 0) {
            pulsepoint_credit_cashback(
                $user_id,
                (float) $biller->cashback,
                'others',
                $reference,
                'Cashback — ' . $biller_name
            );
        }

        if (function_exists('pulsepoint_save_beneficiary')) {
            pulsepoint_save_beneficiary($user_id, 'betting', $customer_id, $customer_id, $biller_name, ['biller_id' => $biller->id]);
        }
    }

    /** EMAIL NOTIFICATION **/
    if ($status === 'success' && function_exists('pulsepoint_send_transaction_email')) {
        pulsepoint_send_transaction_email(
            $user->email,
            'Betting Wallet Funded',
            [
                'status_label' => 'SUCCESS',
                'status_color' => '#22c55e',
                'heading'      => 'Betting Wallet Funding',
                'firstname'    => $user->firstname,
                'message'      => 'Your betting wallet has been funded successfully.',
                'details'      => [
                    'Platform'    => $biller_name,
                    'Customer ID' => $customer_id,
                    'Amount'      => '₦' . number_format($amount, 2),
                    'Fee'         => '₦' . number_format($fee, 2),
                    'Reference'   => $reference,
                ],
            ]
        );
    }

    wp_send_json([
        'success'    => $status === 'success',
        'message'    => $api_response['message'] ?? 'Betting Funding Completed',
        'reference'  => $reference,
        'new_wallet' => $new_wallet,
    ]);
}
