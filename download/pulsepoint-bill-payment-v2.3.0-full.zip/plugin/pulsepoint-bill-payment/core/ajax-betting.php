<?php
if (!defined('ABSPATH')) exit;

// Fetch betting billers
add_action('wp_ajax_pulsepoint_get_betting', 'pulsepoint_get_betting');
add_action('wp_ajax_nopriv_pulsepoint_get_betting', 'pulsepoint_get_betting');

function pulsepoint_get_betting() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    $rows = $wpdb->get_results(
        "SELECT id, serviceid, biller, cashback, fee, fee_api, provider FROM {$base_prefix}betting ORDER BY biller ASC"
    );

    if (!$rows) {
        wp_send_json([]);
    }

    $billers = [];

    foreach ($rows as $r) {
        $billers[] = [
            'id'        => (int) $r->id,
            'serviceid' => $r->serviceid,
            'biller'    => $r->biller,
            'cashback'  => number_format((float) $r->cashback, 2, '.', ''),
            'fee'       => number_format((float) $r->fee, 2, '.', ''),
        ];
    }

    wp_send_json($billers);
}
