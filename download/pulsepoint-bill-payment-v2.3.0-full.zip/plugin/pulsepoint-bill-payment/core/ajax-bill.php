<?php
if (!defined('ABSPATH')) exit;

// ✅ Fetch bill plans
add_action('wp_ajax_pulsepoint_get_bill_plans', 'pulsepoint_get_bill_plans');
add_action('wp_ajax_nopriv_pulsepoint_get_bill_plans', 'pulsepoint_get_bill_plans');

function pulsepoint_get_bill_plans() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $provider = sanitize_text_field($_GET['provider'] ?? '');

    // ✅ Fetch user account type
    $user_id = get_current_user_id();
    $account_type = 'Customer'; // default
    if ($user_id) {
        $account_type = $wpdb->get_var($wpdb->prepare(
            "SELECT account_type FROM {$base_prefix}users WHERE id = %d",
            $user_id
        )) ?: 'Customer';
    }

    // ✅ Fetch discount settings
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);
    $agent_discount = isset($settings['agent_discount']->opt_value) ? floatval($settings['agent_discount']->opt_value) : 0;
    $api_discount   = isset($settings['api_discount']->opt_value) ? floatval($settings['api_discount']->opt_value) : 0;

    // ✅ Fetch bill plans
    $sql = "SELECT id, plan, details, fee, fee_api, provider FROM {$base_prefix}bill";
    if ($provider) {
        $sql .= $wpdb->prepare(" WHERE provider = %s", $provider);
    }
    $rows = $wpdb->get_results($sql);

    if (!$rows) {
        wp_send_json([]);
    }

    $plans = [];
    foreach ($rows as $r) {
        $base_fee = ($account_type === 'API') ? floatval($r->fee_api) : floatval($r->fee);

        if ($account_type === 'Agent') {
            $discount = ($agent_discount / 100) * $base_fee;
            $final_fee = $base_fee - $discount;
        } elseif ($account_type === 'API') {
            $discount = ($api_discount / 100) * $base_fee;
            $final_fee = $base_fee - $discount;
        } else {
            $final_fee = $base_fee;
        }

        $plans[] = [
            'id'           => $r->id,
            'plan'         => $r->plan,
            'details'      => $r->details,
            'fee'          => number_format($final_fee, 2, '.', ''),
            'fee_api'      => $r->fee_api,
            'provider'     => $r->provider,
            'account_type' => $account_type,
        ];
    }

    wp_send_json($plans);
}