<?php
/**
 * PulsePoint 2FA Setup
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/setup_2fa.php
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__DIR__) . 'libs/PHPGangsta/GoogleAuthenticator.php';

add_action('wp_ajax_pulsepoint_setup_2fa', 'pulsepoint_setup_2fa');

function pulsepoint_setup_2fa() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    // Check login
    if (!isset($_SESSION['pulsepoint_user'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Login required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $method  = in_array($_POST['method'] ?? 'app', ['app', 'email'], true) ? $_POST['method'] : 'app';

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    // ===================================================================
    // EMAIL METHOD — generate + send a 6-digit code, valid 10 minutes
    // ===================================================================
    if ($method === 'email') {

        if (empty($user->email)) {
            wp_send_json(['success' => false, 'message' => 'No email address on file.']);
        }

        $code = (string) random_int(100000, 999999);

        $wpdb->update(
            $table,
            [
                'twofa_email_code'         => $code,
                'twofa_email_code_expires' => date('Y-m-d H:i:s', time() + 600),
            ],
            ['id' => $user_id]
        );

        if (function_exists('pulsepoint_send_transaction_email')) {
            pulsepoint_send_transaction_email(
                $user->email,
                'Your Two-Factor Authentication Code',
                [
                    'status_label' => 'SECURITY CODE',
                    'status_color' => '#356cf9',
                    'heading'      => 'Enable Email 2FA',
                    'firstname'    => $user->firstname,
                    'message'      => 'Use the code below to confirm enabling two-factor authentication via email.',
                    'details'      => ['Verification Code' => $code],
                ]
            );
        }

        wp_send_json([
            'success' => true,
            'message' => 'A verification code has been sent to your email.',
            'method'  => 'email',
        ]);
    }

    // ===================================================================
    // APP METHOD — existing Google Authenticator QR flow
    // ===================================================================
    $ga = new PHPGangsta_GoogleAuthenticator();

    // Generate secret if empty
    if (empty($user->twofa_secret)) {

        $secret = $ga->createSecret();

        $wpdb->update(
            $table,
            [
                'twofa_secret' => $secret
            ],
            [
                'id' => $user_id
            ]
        );

    } else {

        $secret = $user->twofa_secret;
    }

    // QR Code
    $company_name = 'Pulsepoint SaaS Limited';

    $qrCodeUrl = $ga->getQRCodeGoogleUrl(
        $company_name . ':' . $user->email,
        $secret,
        $company_name
    );

    wp_send_json([
        'success' => true,
        'message' => '2FA setup generated.',
        'method' => 'app',
        'secret' => $secret,
        'qr_code' => $qrCodeUrl
    ]);
}