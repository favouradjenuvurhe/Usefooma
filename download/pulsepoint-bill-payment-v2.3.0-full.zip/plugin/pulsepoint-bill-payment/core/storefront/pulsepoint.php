<?php
/**
 * Pulsepoint Storefront core.
 * Storefront is available only when pulsepoint-storefront-addon is active.
 * WooCommerce powers products, carts, checkout and orders.
 */
if (!defined('ABSPATH')) exit;

function pulsepoint_storefront_woo_active() {
    return class_exists('WooCommerce') && function_exists('wc_get_product') && function_exists('wc_get_orders');
}

function pulsepoint_storefront_table() { global $wpdb; return $wpdb->prefix . 'pulsepoint_stores'; }
function pulsepoint_storefront_current_user_id() {
    if (session_status() === PHP_SESSION_NONE && !headers_sent()) @session_start();
    return (int)($_SESSION['pulsepoint_user']['id'] ?? 0);
}

function pulsepoint_storefront_install_table() {
    global $wpdb;
    $table = pulsepoint_storefront_table();
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE {$table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        slug VARCHAR(120) NOT NULL,
        name VARCHAR(190) NOT NULL,
        description TEXT NULL,
        logo_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        owner_email VARCHAR(190) NULL,
        owner_phone VARCHAR(50) NULL,
        owner_address TEXT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        review_note TEXT NULL,
        reviewed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
        reviewed_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY slug (slug),
        KEY user_id (user_id),
        KEY status (status)
    ) {$charset};");
}
add_action('init', 'pulsepoint_storefront_install_table', 3);

function pulsepoint_storefront_get_store_by_slug($slug) {
    global $wpdb; $table = pulsepoint_storefront_table();
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE slug=%s LIMIT 1", sanitize_title($slug)));
}
function pulsepoint_storefront_get_store_by_user($user_id) {
    global $wpdb; $table = pulsepoint_storefront_table();
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d LIMIT 1", (int)$user_id));
}
function pulsepoint_storefront_get_user($user_id) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}pulsepoint_users WHERE id=%d LIMIT 1", (int)$user_id));
}
function pulsepoint_storefront_public_url($slug) { return home_url('/p/'.rawurlencode(sanitize_title($slug))); }
function pulsepoint_storefront_product_store_id($product_id) { return (int)get_post_meta((int)$product_id, '_pulsepoint_store_id', true); }
function pulsepoint_storefront_product_belongs($product_id, $store_id) { return pulsepoint_storefront_product_store_id($product_id) === (int)$store_id; }

function pulsepoint_storefront_setting($key, $default = '') {
    return get_option('pulsepoint_storefront_'.$key, $default);
}
function pulsepoint_storefront_fee_percent() { return max(0, (float)pulsepoint_storefront_setting('fee_percent', 0)); }
function pulsepoint_storefront_fee_flat() { return max(0, (float)pulsepoint_storefront_setting('fee_flat', 0)); }
function pulsepoint_storefront_price_decimals() { return function_exists('wc_get_price_decimals') ? wc_get_price_decimals() : 2; }
function pulsepoint_storefront_customer_price($base_price) {
    $base = max(0, (float)$base_price);
    $fee = ($base * pulsepoint_storefront_fee_percent() / 100) + pulsepoint_storefront_fee_flat();
    return round($base + $fee, pulsepoint_storefront_price_decimals());
}
function pulsepoint_storefront_fee_for_unit($base_price) {
    return round(pulsepoint_storefront_customer_price($base_price) - (float)$base_price, pulsepoint_storefront_price_decimals());
}

/* Add the platform store fee to storefront items at cart/checkout level. */
add_action('woocommerce_before_calculate_totals', function($cart) {
    if (!$cart || !is_object($cart)) return;
    foreach ($cart->get_cart() as $cart_item_key => $item) {
        if (empty($item['data']) || !is_object($item['data'])) continue;
        $product_id = (int)$item['data']->get_id();
        if (!pulsepoint_storefront_product_store_id($product_id)) continue;
        if (!isset($item['_pulsepoint_store_base_price'])) {
            $item['_pulsepoint_store_base_price'] = (float)$item['data']->get_price();
            $cart->cart_contents[$cart_item_key]['_pulsepoint_store_base_price'] = $item['_pulsepoint_store_base_price'];
        }
        $base = (float)$cart->cart_contents[$cart_item_key]['_pulsepoint_store_base_price'];
        $item['data']->set_price(pulsepoint_storefront_customer_price($base));
    }
}, 20);

add_filter('woocommerce_get_item_data', function($data, $cart_item) {
    if (!empty($cart_item['_pulsepoint_store_base_price']) && !empty($cart_item['data'])) {
        $base = (float)$cart_item['_pulsepoint_store_base_price'];
        $fee = pulsepoint_storefront_fee_for_unit($base);
        if ($fee > 0) $data[] = ['name'=>'Store fee', 'value'=>wc_price($fee) . ' per item'];
    }
    return $data;
}, 10, 2);

add_action('woocommerce_checkout_create_order_line_item', function($item, $cart_item_key, $values) {
    $product_id = $item->get_product_id();
    $store_id = pulsepoint_storefront_product_store_id($product_id);
    if (!$store_id) return;
    $base = isset($values['_pulsepoint_store_base_price']) ? (float)$values['_pulsepoint_store_base_price'] : (float)$item->get_product()->get_price();
    $fee = pulsepoint_storefront_fee_for_unit($base);
    $item->add_meta_data('_pulsepoint_store_id', $store_id, true);
    $item->add_meta_data('_pulsepoint_store_base_unit', $base, true);
    $item->add_meta_data('_pulsepoint_store_fee_unit', $fee, true);
    $item->add_meta_data('_pulsepoint_store_product_type', get_post_meta($product_id, '_pulsepoint_store_product_type', true), true);
}, 10, 3);

/* Vendor order email + payout helpers. */
function pulsepoint_storefront_order_store_items($order, $store_id) {
    $items = [];
    if (!$order) return $items;
    foreach ($order->get_items() as $item_id => $item) {
        $pid = (int)$item->get_product_id();
        $sid = (int)$item->get_meta('_pulsepoint_store_id', true);
        if (!$sid) $sid = pulsepoint_storefront_product_store_id($pid);
        if ($sid !== (int)$store_id) continue;
        $qty = max(1, (int)$item->get_quantity());
        $base_unit = (float)$item->get_meta('_pulsepoint_store_base_unit', true);
        if ($base_unit <= 0 && $item->get_product()) $base_unit = (float)$item->get_product()->get_regular_price();
        $items[] = [
            'item_id'=>$item_id,
            'product_id'=>$pid,
            'name'=>$item->get_name(),
            'qty'=>$qty,
            'base_unit'=>$base_unit,
            'seller_total'=>round($base_unit*$qty, pulsepoint_storefront_price_decimals()),
            'customer_line_total'=>(float)$item->get_total(),
            'type'=>(string)$item->get_meta('_pulsepoint_store_product_type', true),
        ];
    }
    return $items;
}

function pulsepoint_storefront_send_vendor_order_email($store, $order, $items, $status_label = 'New order') {
    if (!$store || !$order || !$items) return;
    $owner = pulsepoint_storefront_get_user($store->user_id);
    $email = sanitize_email($store->owner_email ?: ($owner->email ?? ''));
    if (!is_email($email)) return;
    $customer_name = trim($order->get_formatted_billing_full_name() ?: $order->get_formatted_shipping_full_name()) ?: 'Customer';
    $phone = $order->get_billing_phone();
    $customer_email = $order->get_billing_email();
    $address = trim($order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address());
    $rows = '';
    foreach ($items as $it) {
        $rows .= '<tr><td style="padding:8px;border-bottom:1px solid #eee">'.esc_html($it['name']).'</td><td style="padding:8px;border-bottom:1px solid #eee">'.(int)$it['qty'].'</td><td style="padding:8px;border-bottom:1px solid #eee">'.wp_kses_post(wc_price($it['seller_total'])).'</td></tr>';
    }
    $subject = '['.get_bloginfo('name').'] '.$status_label.' for '.$store->name.' — Order #'.$order->get_id();
    $body = '<div style="font-family:Arial,sans-serif;line-height:1.6"><h2>'.esc_html($status_label).'</h2><p>Your store <strong>'.esc_html($store->name).'</strong> has an order #'.(int)$order->get_id().'.</p><h3>Customer details</h3><p><strong>Name:</strong> '.esc_html($customer_name).'<br><strong>Email:</strong> '.esc_html($customer_email).'<br><strong>Phone:</strong> '.esc_html($phone ?: 'Not provided').'<br><strong>Address:</strong><br>'.nl2br(esc_html($address ?: 'Not provided')).'</p><h3>Store items</h3><table style="border-collapse:collapse;width:100%"><tr><th style="text-align:left;padding:8px">Product</th><th style="text-align:left;padding:8px">Qty</th><th style="text-align:left;padding:8px">Your amount</th></tr>'.$rows.'</table><p><strong>Store amount:</strong> '.wp_kses_post(wc_price(array_sum(array_column($items,'seller_total')))).'</p><p><strong>Order status:</strong> '.esc_html($order->get_status()).'</p></div>';
    @wp_mail($email, $subject, $body, ['Content-Type: text/html; charset=UTF-8']);
}

function pulsepoint_storefront_maybe_notify_order($order_id, $status_label = 'New order') {
    if (!function_exists('wc_get_order')) return;
    $order = wc_get_order($order_id); if (!$order) return;
    $stores = [];
    foreach ($order->get_items() as $item) {
        $sid = (int)$item->get_meta('_pulsepoint_store_id', true);
        if ($sid) $stores[$sid] = true;
    }
    foreach (array_keys($stores) as $sid) {
        $meta = '_pulsepoint_store_notified_'.$sid.'_'.sanitize_key($status_label);
        if ($order->get_meta($meta) === 'yes') continue;
        $store = pulsepoint_storefront_get_store_by_id($sid);
        if (!$store) continue;
        $items = pulsepoint_storefront_order_store_items($order, $sid);
        if ($items) {
            pulsepoint_storefront_send_vendor_order_email($store, $order, $items, $status_label);
            $order->update_meta_data($meta, 'yes');
        }
    }
    $order->save();
}

function pulsepoint_storefront_get_store_by_id($id) {
    global $wpdb; $table = pulsepoint_storefront_table();
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d LIMIT 1", (int)$id));
}

function pulsepoint_storefront_payout_order($order_id) {
    global $wpdb;
    if (!function_exists('wc_get_order')) return;
    $order = wc_get_order($order_id); if (!$order) return;
    $store_ids = [];
    foreach ($order->get_items() as $item) {
        $sid = (int)$item->get_meta('_pulsepoint_store_id', true);
        if (!$sid) $sid = pulsepoint_storefront_product_store_id($item->get_product_id());
        if ($sid) $store_ids[$sid] = true;
    }
    foreach (array_keys($store_ids) as $sid) {
        $meta = '_pulsepoint_store_payout_'.$sid;
        if ($order->get_meta($meta) === 'yes') continue;
        $store = pulsepoint_storefront_get_store_by_id($sid); if (!$store || $store->status !== 'active') continue;
        $items = pulsepoint_storefront_order_store_items($order, $sid);
        $amount = round(array_sum(array_column($items,'seller_total')), pulsepoint_storefront_price_decimals());
        if ($amount <= 0) { $order->update_meta_data($meta,'yes'); continue; }
        $users = $wpdb->prefix.'pulsepoint_users';
        $trnx = $wpdb->prefix.'pulsepoint_trnx';
        $reference = 'STORE-ORDER-'.$order_id.'-'.$sid;
        $already = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$trnx} WHERE reference=%s LIMIT 1", $reference));
        if ($already) { $order->update_meta_data($meta,'yes'); continue; }
        $user_exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$users} WHERE id=%d LIMIT 1", (int)$store->user_id));
        if (!$user_exists) continue;
        $updated = $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet = wallet + %f WHERE id=%d", $amount, (int)$store->user_id));
        if ($updated === false) continue;
        $wpdb->insert($trnx, [
            'user_id'=>(int)$store->user_id,
            'details'=>'Storefront order payout',
            'value'=>$amount,
            'amount'=>$amount,
            'profit_amount'=>0,
            'reference'=>$reference,
            'payment'=>'wallet',
            'category'=>'others',
            'status'=>'success',
            'type'=>'credit',
            'session'=>(string)$order_id,
            'description'=>'Store payout for WooCommerce order #'.$order_id.'. Platform store fee was retained from the customer price.',
        ], ['%d','%s','%s','%f','%f','%s','%s','%s','%s','%s','%s']);
        $order->update_meta_data($meta,'yes');
        pulsepoint_storefront_send_vendor_order_email($store, $order, $items, 'Order completed — payment credited');
        do_action('pulsepoint_storefront_payout_completed', (int)$store->user_id, $amount, $order_id, $sid);
    }
    $order->save();
}
add_action('woocommerce_order_status_processing', function($order_id){ pulsepoint_storefront_maybe_notify_order($order_id, 'New order'); }, 20);
add_action('woocommerce_payment_complete', function($order_id){ pulsepoint_storefront_maybe_notify_order($order_id, 'Payment received'); }, 20);
add_action('woocommerce_order_status_completed', function($order_id){ pulsepoint_storefront_maybe_notify_order($order_id, 'Order completed'); pulsepoint_storefront_payout_order($order_id); }, 20);

add_filter('pulsepoint_addon_routes', function($routes){
    if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('storefront')) $routes[]='storefront';
    return array_values(array_unique((array)$routes));
});

add_action('admin_notices', function(){
    if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('storefront') && !pulsepoint_storefront_woo_active()) {
        echo '<div class="notice notice-warning"><p><strong>Pulsepoint Storefront:</strong> Please activate WooCommerce to enable products, carts and orders.</p></div>';
    }
});
