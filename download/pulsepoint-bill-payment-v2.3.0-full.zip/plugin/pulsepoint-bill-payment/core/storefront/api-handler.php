<?php
/** Pulsepoint Storefront AJAX/API handler. */
if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_storefront_api_handler')) {
function pulsepoint_storefront_api_handler() {
    if (!function_exists('pulsepoint_addon_active') || !pulsepoint_addon_active('storefront')) {
        wp_send_json(['success'=>false,'message'=>'Storefront add-on is not active.'], 403);
    }
    if (session_status() === PHP_SESSION_NONE && !headers_sent()) @session_start();
    $user_id = function_exists('pulsepoint_storefront_current_user_id') ? pulsepoint_storefront_current_user_id() : (int)($_SESSION['pulsepoint_user']['id'] ?? 0);
    if (!$user_id) wp_send_json(['success'=>false,'message'=>'Please log in to manage your storefront.'], 401);
    if (isset($_POST['_ajax_nonce']) && !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_ajax_nonce'])), 'pulsepoint_storefront')) {
        wp_send_json(['success'=>false,'message'=>'Security check failed. Refresh the page and try again.'], 403);
    }
    global $wpdb;
    $stores = pulsepoint_storefront_table();
    $action = sanitize_key($_POST['sf_action'] ?? $_POST['action'] ?? $_GET['sf_action'] ?? $_GET['action'] ?? 'me');
    $json = static function($ok,$message='',$data=[],$status=200){ wp_send_json(array_merge(['success'=>$ok,'message'=>$message],$data),$status); };
    $owner = static function() use($user_id){ return [$user_id, pulsepoint_storefront_get_store_by_user($user_id)]; };
    $require_woo = static function() use($json){ if (!function_exists('pulsepoint_storefront_woo_active') || !pulsepoint_storefront_woo_active()) $json(false,'WooCommerce must be activated before managing products, carts and orders.',[],400); };

    if ($action === 'me') {
        [, $store] = $owner(); $products=[]; $woo_active=pulsepoint_storefront_woo_active();
        if ($store && $woo_active) {
            $ids=get_posts(['post_type'=>'product','post_status'=>['publish','draft','private','pending'],'posts_per_page'=>-1,'fields'=>'ids','meta_key'=>'_pulsepoint_store_id','meta_value'=>(int)$store->id]);
            foreach((array)$ids as $id){
                $p=wc_get_product($id); if(!$p)continue;
                $base=(float)$p->get_regular_price(); if($base<=0)$base=(float)$p->get_price();
                $gallery=(array)get_post_meta($id,'_pulsepoint_store_image_ids',true); $images=[];
                foreach($gallery as $aid){$u=wp_get_attachment_image_url((int)$aid,'medium');if($u)$images[]=$u;}
                if(!$images && $p->get_image_id()){$u=wp_get_attachment_image_url($p->get_image_id(),'medium');if($u)$images[]=$u;}
                $products[]=['id'=>$id,'name'=>$p->get_name(),'description'=>wp_strip_all_tags($p->get_description()),'price'=>$base,'display_price'=>pulsepoint_storefront_customer_price($base),'fee'=>pulsepoint_storefront_fee_for_unit($base),'stock'=>$p->get_stock_quantity(),'status'=>$p->get_status(),'image'=>$images[0]??'','images'=>$images,'type'=>get_post_meta($id,'_pulsepoint_store_product_type',true)?:'physical','download_url'=>get_post_meta($id,'_pulsepoint_store_download_url',true)];
            }
        }
        $status=$store->status??'';
        $json(true,'OK',['store'=>$store,'products'=>$products,'public_url'=>($store&&$status==='active')?pulsepoint_storefront_public_url($store->slug):'','woo_active'=>$woo_active,'fee_percent'=>pulsepoint_storefront_fee_percent(),'fee_flat'=>pulsepoint_storefront_fee_flat()]);
    }

    if ($action === 'save_store') {
        $name=sanitize_text_field(wp_unslash($_POST['name']??'')); $slug=sanitize_title(wp_unslash($_POST['slug']??$name)); $desc=sanitize_textarea_field(wp_unslash($_POST['description']??''));
        $email=sanitize_email(wp_unslash($_POST['owner_email']??'')); $phone=sanitize_text_field(wp_unslash($_POST['owner_phone']??'')); $address=sanitize_textarea_field(wp_unslash($_POST['owner_address']??''));
        if($name==='')$json(false,'Store name is required.',[],400); if($slug==='')$json(false,'A valid store URL is required.',[],400);
        [, $store]=$owner(); $existing=pulsepoint_storefront_get_store_by_slug($slug); if($existing&&(!$store||(int)$existing->id!==(int)$store->id))$json(false,'That store URL is already taken. Try another name.',[],409);
        $logo_id=$store?(int)$store->logo_id:0;
        if(!empty($_FILES['logo']['name'])){
            require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/image.php';
            $attachment=media_handle_upload('logo',0); if(is_wp_error($attachment))$json(false,'Store logo upload failed: '.$attachment->get_error_message(),[],400); $logo_id=(int)$attachment;
        }
        $now=current_time('mysql');
        if($store){
            $ok=$wpdb->update($stores,['name'=>$name,'slug'=>$slug,'description'=>$desc,'logo_id'=>$logo_id,'owner_email'=>$email,'owner_phone'=>$phone,'owner_address'=>$address,'updated_at'=>$now],['id'=>$store->id],['%s','%s','%s','%d','%s','%s','%s','%s'],['%d']);
            if($ok===false)$json(false,'Unable to update your store. Database error: '.$wpdb->last_error,[],500);
            $message='Store details updated successfully.';
        }else{
            $ok=$wpdb->insert($stores,['user_id'=>$user_id,'name'=>$name,'slug'=>$slug,'description'=>$desc,'logo_id'=>$logo_id,'owner_email'=>$email,'owner_phone'=>$phone,'owner_address'=>$address,'status'=>'pending','review_note'=>'','created_at'=>$now,'updated_at'=>$now],['%d','%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s']);
            if($ok===false)$json(false,'Unable to submit your store request. Database error: '.$wpdb->last_error,[],500);
            $saved=pulsepoint_storefront_get_store_by_user($user_id);
            $admin_email=get_option('admin_email');
            if(is_email($admin_email)){
                $subject='['.get_bloginfo('name').'] New Storefront review request — '.$name;
                $body='<div style="font-family:Arial,sans-serif"><h2>New Storefront Review Request</h2><p>A user has submitted a store for approval.</p><p><strong>Store:</strong> '.esc_html($name).'<br><strong>Slug:</strong> '.esc_html($slug).'<br><strong>Email:</strong> '.esc_html($email?:'Not provided').'<br><strong>Phone:</strong> '.esc_html($phone?:'Not provided').'<br><strong>Address:</strong> '.nl2br(esc_html($address?:'Not provided')).'</p><p>Review it in WordPress Admin → Pulsepoint → Configuration → Storefront.</p></div>';
                @wp_mail($admin_email,$subject,$body,['Content-Type: text/html; charset=UTF-8']);
            }
            $message='Store submitted successfully. It is now pending admin review.';
        }
        $saved=pulsepoint_storefront_get_store_by_user($user_id);
        $json(true,$message,['store'=>$saved,'public_url'=>($saved&&$saved->status==='active')?pulsepoint_storefront_public_url($saved->slug):'']);
    }

    if ($action === 'save_product') {
        $require_woo(); [, $store]=$owner(); if(!$store)$json(false,'Create your store first.',[],400); if($store->status!=='active')$json(false,'Your store must be approved before you can publish products.',[],400);
        $id=(int)($_POST['id']??0); $name=sanitize_text_field(wp_unslash($_POST['name']??'')); $desc=wp_kses_post(wp_unslash($_POST['description']??'')); $price=wc_format_decimal(wp_unslash($_POST['price']??'0')); $stock=max(0,(int)($_POST['stock']??0)); $status=($_POST['status']??'publish')==='draft'?'draft':'publish'; $type=in_array($_POST['product_type']??'physical',['physical','digital','service'],true)?sanitize_key($_POST['product_type']):'physical'; $download=esc_url_raw(wp_unslash($_POST['download_url']??''));
        if($name===''||(float)$price<0)$json(false,'Product name and valid price are required.',[],400);
        $files=[]; foreach(['image1','image2','image3'] as $key){if(!empty($_FILES[$key]['name']))$files[]=$key;} if(count($files)>3)$json(false,'You can upload a maximum of 3 product images.',[],400);
        $product=$id?wc_get_product($id):null; if($id&&(!$product||!pulsepoint_storefront_product_belongs($id,$store->id)))$json(false,'Product not found for this store.',[],404); if(!$product)$product=new WC_Product_Simple();
        $product->set_name($name); $product->set_description($desc); $product->set_regular_price((string)$price); $product->set_price((string)$price); $product->set_manage_stock(true); $product->set_stock_quantity($stock); $product->set_stock_status($stock>0?'instock':'outofstock'); $product->set_status($status); $product->set_catalog_visibility('visible'); $product->set_virtual($type!=='physical'); $product->set_downloadable($type==='digital');
        if($type==='digital'&&$download&&class_exists('WC_Product_Download')){ $dl=new WC_Product_Download(); $dl->set_name($name); $dl->set_file($download); $dl->set_id(md5($download)); $product->set_downloads([$dl->get_id()=>['name'=>$name,'file'=>$download]]); }
        else if($type!=='digital')$product->set_downloadable(false);
        $product_id=$product->save(); update_post_meta($product_id,'_pulsepoint_store_id',$store->id); update_post_meta($product_id,'_pulsepoint_store_owner',$user_id); update_post_meta($product_id,'_pulsepoint_store_product_type',$type); update_post_meta($product_id,'_pulsepoint_store_download_url',$download);
        $image_ids=[];
        if($id){$old=(array)get_post_meta($product_id,'_pulsepoint_store_image_ids',true);foreach($old as $aid)$image_ids[]=(int)$aid;}
        foreach($files as $key){require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$attachment=media_handle_upload($key,$product_id);if(is_wp_error($attachment))$json(false,'One of the images failed to upload: '.$attachment->get_error_message(),[],400);$image_ids[]=(int)$attachment;}
        $image_ids=array_values(array_unique(array_filter($image_ids))); if(count($image_ids)>3)$image_ids=array_slice($image_ids,0,3); update_post_meta($product_id,'_pulsepoint_store_image_ids',$image_ids); if($image_ids)$product->set_image_id($image_ids[0]); if(count($image_ids)>1)$product->set_gallery_image_ids(array_slice($image_ids,1)); else $product->set_gallery_image_ids([]); $product->save();
        $json(true,$id?'Product updated.':'Product created.',['product_id'=>$product_id]);
    }

    if($action==='delete_product'){ $require_woo(); [, $store]=$owner(); $id=(int)($_POST['id']??0); if(!$store||!pulsepoint_storefront_product_belongs($id,$store->id))$json(false,'Product not found.',[],404); wp_trash_post($id); $json(true,'Product removed.'); }

    if($action==='orders'){
        $require_woo(); [, $store]=$owner(); if(!$store)$json(false,'Create your store first.',[],400); $orders=wc_get_orders(['limit'=>100,'orderby'=>'date','order'=>'DESC','status'=>array_keys(wc_get_order_statuses())]); $out=[];
        foreach($orders as $order){$items=pulsepoint_storefront_order_store_items($order,$store->id);if(!$items)continue;$out[]=['id'=>$order->get_id(),'status'=>$order->get_status(),'date'=>$order->get_date_created()?$order->get_date_created()->date_i18n('Y-m-d H:i'):'','total'=>array_sum(array_column($items,'seller_total')),'customer'=>$order->get_formatted_billing_full_name()?:'Customer','email'=>$order->get_billing_email(),'phone'=>$order->get_billing_phone(),'address'=>$order->get_formatted_shipping_address()?:$order->get_formatted_billing_address(),'items'=>$items];}
        $json(true,'OK',['orders'=>$out]);
    }
    if($action==='update_order'){
        $require_woo(); [, $store]=$owner(); if(!$store)$json(false,'Create your store first.',[],400); $oid=(int)($_POST['order_id']??0);$status=sanitize_key($_POST['status']??'');$order=wc_get_order($oid);if(!$order||!in_array($status,array_keys(wc_get_order_statuses()),true))$json(false,'Invalid order.',[],400);$items=pulsepoint_storefront_order_store_items($order,$store->id);if(!$items)$json(false,'Order does not belong to this store.',[],403);$order->update_status($status,'Updated by Storefront owner.');if($status==='completed')pulsepoint_storefront_payout_order($oid);$json(true,'Order status updated.');
    }
    $json(false,'Unknown storefront action.',[],400);
}
}
add_action('wp_ajax_pulsepoint_storefront','pulsepoint_storefront_api_handler');
add_action('wp_ajax_nopriv_pulsepoint_storefront','pulsepoint_storefront_api_handler');
