<?php
/**
 * Provider: NCWallet Virtual Account API
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/virtual-account/ncwallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Create Virtual Account on NCWallet (Normalized for main file)
 *
 * @param int    $user_id
 * @param string $name
 * @param string $email
 * @param string $phone
 * @return array
 */
function create_virtual_account($user_id = 0, $name = '', $email = '', $phone = '')
{
    global $wpdb;

    // Normalize inputs
    $name  = trim($name ?: 'Guest User');
    $email = trim($email ?: 'unknown@example.com');
    $phone = trim($phone ?: '00000000000');

    if (empty($user_id) || empty($name) || empty($email)) {
        return [
            'success' => false,
            'message' => 'Invalid parameters passed to create_virtual_account().',
            'account' => ['bank'=>'','name'=>'','number'=>'','provider'=>'ncwallet']
        ];
    }

    // Plugin table
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_name  = "{$base_prefix}settings";

    // Fetch credentials
    $apiKey   = trim($wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key='pay_token' LIMIT 1"));
    $trnxPin  = trim($wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key='pay_biz' LIMIT 1"));

    if (empty($apiKey) || empty($trnxPin)) {
        return [
            'success' => false,
            'message' => 'NCWallet credentials not set.',
            'account' => ['bank'=>'','name'=>'','number'=>'','provider'=>'ncwallet']
        ];
    }

    // Endpoint
    $endpoint = 'https://ncwallet.africa/api/v1/bank/create';

    // Payload (STATIC SAFEHAVEN – exactly per example)
    $payload = [
        'bank_code'          => '9psb',
        'account_name'       => $name,
        'email'              => $email,
        'phone_number'       => $phone,
        'account_type'       => 'static',
        'validation_type'    => 'BVN',
        'validation_number'  => '22400000000',
        'validation_otp'     => '772094',
        'validation_id'      => '665856ced4d2e4b2c4387edd'
    ];

    // Headers
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        "trnx_pin: {$trnxPin}",
        "Authorization: {$apiKey}"
    ];

    // cURL request
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);

    $response = curl_exec($ch);
    $error    = curl_error($ch);
    curl_close($ch);

    // cURL error
    if ($error) {
        return [
            'success' => false,
            'message' => 'cURL error: ' . $error,
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'ncwallet']
        ];
    }

    // Decode response
    $data = json_decode($response, true);
    if (!is_array($data)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response from NCWallet.',
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'ncwallet']
        ];
    }

    // Normalize account
    $acc = $data['data'] ?? [];

    $normalized_account = [
        'bank' => '9Payment Service Bank (9PSB)',
        'name'     => $acc['account_name'] ?? $name,
        'number'   => $acc['account_number'] ?? '',
        'provider' => 'ncwallet'
    ];

    // Success check (REAL API RESPONSE)
    if (
        !empty($normalized_account['number']) &&
        isset($data['status']) &&
        strtolower($data['status']) === 'success'
    ) {
        return [
            'success' => true,
            'message' => $data['message'] ?? 'Virtual account created successfully.',
            'account' => $normalized_account
        ];
    }

    // Failure (RAW INCLUDED)
    return [
        'success' => false,
        'message' => $data['message'] ?? 'Account creation failed at NCWallet.',
        'account' => $normalized_account,
        'errors'  => $data['errors'] ?? [],
        'raw'     => $data
    ];
}