<?php
/**
 * Provider: Whogopay Dot MFB Virtual Account API
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/virtual-account/dotmfb.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Create Virtual Account (Dot MFB)
 *
 * @param int    $user_id
 * @param string $name
 * @param string $email
 * @param string $phone
 * @param string $token
 * @return array
 */
function create_virtual_account($user_id = 0, $name = '', $email = '', $phone = '', $token = '')
{
    global $wpdb;

    // Simulate small delay
    usleep(500000); // 0.5s delay for realism

    // ✅ Validate & normalize inputs
    $name  = trim($name ?: 'Guest User');
    $email = trim($email ?: 'unknown@example.com');
    $phone = trim($phone ?: '00000000000');

    if (empty($user_id) || empty($name) || empty($email)) {
        return [
            'success' => false,
            'message' => 'Invalid parameters passed to create_virtual_account().',
        ];
    }

    // ✅ Plugin table prefix
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_name  = "{$base_prefix}settings";

    // ✅ Get API token
    if (empty($token)) {
        $token = $wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key = 'pay_token' LIMIT 1");
        if (empty($token)) {
            $token = bin2hex(random_bytes(16));
        }
    }

    // ✅ Endpoint (DOT MFB)
    $endpoint = 'https://whogopay.com.ng/api/v1/generate-dotmfb-va';

    // ✅ Split name into first/last
    $name_parts = explode(' ', $name, 2);
    $firstname  = $name_parts[0] ?? $name;
    $lastname   = $name_parts[1] ?? 'PS-NG';

    // ✅ Request payload (Dot MFB format)
    $payload = [
        "dateOfBirth" => "1999-01-01",
        "externalId"  => 'USER-' . $user_id . '-' . uniqid(),
        "firstname"   => $firstname,
        "gender"      => "MALE",
        "lastname"    => $lastname,
        "useremail"   => $email,
        "userphone"   => $phone,
    ];

    // ✅ Headers
    $headers = [
        "Authorization: Bearer {$token}",
        "Content-Type: application/json",
        "Accept: application/json",
    ];

    // ✅ Send request
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
    ]);

    $response = curl_exec($ch);
    $error    = curl_error($ch);
    curl_close($ch);

    // ✅ Handle cURL error
    if ($error) {
        return [
            'success' => false,
            'message' => 'cURL error: ' . $error,
        ];
    }

    // ✅ Decode JSON
    $data = json_decode($response, true);
    if (!is_array($data)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response from Dot MFB.',
        ];
    }

    // ✅ Normalize Dot MFB response (same pattern as your file)
    $success = $data['status'] ?? false;
    $message = $data['message'] ?? 'Unknown response from Dot MFB.';
    $acc     = $data['data'] ?? [];

    if ($success && !empty($acc)) {
        return [
            'success' => true,
            'message' => $message,
            'account' => [
                'bank'     => $acc['bank'] ?? 'DOTBANK',
                'name'     => $acc['account_name'] ?? $name,
                'number'   => $acc['account_number'] ?? '',
                'provider' => 'dotmfb-whogopay',
            ],
        ];
    }

    // ❌ Failed or malformed
    return [
        'success' => false,
        'message' => $message ?: 'Account creation failed at Dot MFB.',
    ];
}