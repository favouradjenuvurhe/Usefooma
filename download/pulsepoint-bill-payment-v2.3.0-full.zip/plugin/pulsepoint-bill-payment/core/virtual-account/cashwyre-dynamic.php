<?php
/**
 * Cashwyre Dynamic Account Gateway
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

function create_dynamic_account($amount, $requestId, $user) {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $business_code = $settings['pay_biz'] ?? '';
    $secret_key    = $settings['pay_secret'] ?? '';

    if (!$business_code || !$secret_key) {
        return ['success'=>false, 'message'=>'Cashwyre credentials not configured.'];
    }

    $url = 'https://businessapi.cashwyre.com/api/v1.0/Account/createDynamicAccount';

    $payload = [
        'appId'        => $business_code,
        'requestId'    => $requestId,
        'Amount'       => $amount,
        'businessCode' => $business_code,
        'currency'     => 'NGN'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $secret_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $result = curl_exec($ch);
    $error  = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success'=>false, 'message'=>'Curl error: '.$error];
    }

    $response = json_decode($result, true);

    if (!$response || !isset($response['success'])) {
        return ['success'=>false, 'message'=>'Invalid response from Cashwyre.'];
    }

    if (!$response['success']) {
        return ['success'=>false, 'message'=>$response['message'] ?? 'Dynamic account creation failed.'];
    }

    // Extract account number from data or message
    $account_number = $response['data']['accountNumber'] ?? null;
    if (!$account_number && isset($response['message'])) {
        if (preg_match('/\b\d{10,12}\b/', $response['message'], $matches)) {
            $account_number = $matches[0];
        }
    }

    // Extract optional fields (simulate if not returned by API)
    $bank_name       = $response['data']['bankName'] ?? 'Unknown Bank';
    $expired_minutes = $response['data']['expiredMinutes'] ?? 30;
    $time            = date('H:i:s'); // current time
    $total_payable   = $amount + ($settings['dynamic_fee'] ?? 0);

    $account_data = [
        'accountName'    => $response['data']['accountName'] ?? '',
        'accountNumber'  => $account_number ?? '',
        'bankName'       => $bank_name,
        'expiredMinutes' => $expired_minutes,
        'time'           => $time,
        'amount'         => $amount,
        'totalPayable'   => $total_payable,
        'requestId'      => $requestId
    ];

    return ['success'=>true, 'message'=>'Dynamic account created successfully.', 'account'=>$account_data];
}