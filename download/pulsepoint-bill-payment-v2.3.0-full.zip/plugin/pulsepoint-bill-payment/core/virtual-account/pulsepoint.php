<?php
/**
 * Pulsepoint Virtual Account Creation
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/virtual-account/pulsepoint.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// Hook for AJAX requests
add_action('wp_ajax_nopriv_pulsepoint_virtual_account', 'pulsepoint_virtual_account');
add_action('wp_ajax_pulsepoint_virtual_account', 'pulsepoint_virtual_account');

function pulsepoint_virtual_account() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_accnt = $wpdb->prefix . 'pulsepoint_account';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Fetch user record
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id = %d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';
    $payment_gateway  = $settings['payment_gateway'] ?? 'payvessel';
    $virtual_token    = $settings['virtual_token'] ?? '';

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    // Rate limiter (1 request / 15s)
    $now = time();
    if (isset($_SESSION['last_virtual_request'][$user_id]) && ($now - $_SESSION['last_virtual_request'][$user_id]) < 15) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds before retrying.']);
    }
    $_SESSION['last_virtual_request'][$user_id] = $now;

    // Check existing account
    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_accnt} WHERE user_id = %d LIMIT 1", $user_id));
    if ($existing) {
        wp_send_json([
            'success' => true,
            'message' => 'Account already exists.',
            'account' => [
                'bank'     => $existing->bank,
                'name'     => $existing->name,
                'number'   => $existing->number,
                'provider' => $existing->provider
            ]
        ]);
    }

    // Sandbox mode
    if ($api_mode === 'sandbox') {
        $account = [
            'bank'     => 'Sandbox Bank',
            'name'     => strtoupper($user->name ?? 'SANDBOX USER'),
            'number'   => '10000' . mt_rand(1000, 9999),
            'provider' => 'sandbox'
        ];

        $wpdb->insert($table_accnt, [
            'user_id'  => $user_id,
            'bank'     => $account['bank'],
            'name'     => $account['name'],
            'number'   => $account['number'],
            'provider' => $account['provider']
        ], ['%d','%s','%s','%s','%s']);

        wp_send_json(['success' => true, 'message' => 'Sandbox account created.', 'account' => $account]);
    }

    // API disabled
    if ($api_mode === 'off') {
        wp_send_json(['success' => false, 'message' => 'Account creation currently disabled.']);
    }

    // Include provider handler
    $api_file = __DIR__ . '/' . strtolower($payment_gateway) . '.php';
    if (!file_exists($api_file)) {
        wp_send_json(['success' => false, 'message' => "Virtual account handler not found for '{$payment_gateway}'"]);
    }

    require_once $api_file;

    if (!function_exists('create_virtual_account')) {
        wp_send_json(['success' => false, 'message' => 'create_virtual_account() not implemented in gateway file']);
    }

    // Prepare payload
    $payload = [
        'user_id' => $user_id,
        'name'    => $user->firstname ?? 'Unknown User',
        'email'   => $user->email ?? 'noemail@example.com',
        'phone'   => $user->phone ?? '',
        'token'   => $virtual_token
    ];

    // Call provider
    $response = create_virtual_account(...array_values($payload));

    if (!is_array($response) || !isset($response['success'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid provider response format.']);
    }

    if (!$response['success']) {
        wp_send_json(['success' => false, 'message' => $response['message'] ?? 'Account creation failed.']);
    }

    $acc = $response['account'] ?? [];
    if (empty($acc['bank']) || empty($acc['name']) || empty($acc['number'])) {
        wp_send_json(['success' => false, 'message' => 'Incomplete account data returned from provider.']);
    }

    // Save new account
    $wpdb->insert($table_accnt, [
        'user_id'  => $user_id,
        'bank'     => $acc['bank'],
        'name'     => $acc['name'],
        'number'   => $acc['number'],
        'provider' => $payment_gateway
    ], ['%d','%s','%s','%s','%s']);

    wp_send_json([
        'success' => true,
        'message' => 'Virtual account created successfully.',
        'account' => $acc
    ]);
}