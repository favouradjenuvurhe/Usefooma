<?php
if (!defined('ABSPATH')) exit;

/**
 * Create STATIC Virtual Account on XIXAPAY (STATIC ONLY)
 */
function create_virtual_account(
    $user_id = 0,
    $name = '',
    $email = '',
    $phone = ''
) {
    global $wpdb;

    $name  = trim($name ?: 'Guest User');
    $email = trim($email ?: 'unknown@example.com');
    $phone = trim($phone ?: '00000000000');

    if (empty($email)) {
        return [
            'success' => false,
            'message' => 'Email is required.',
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'xixapay'
            ]
        ];
    }

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_users = "{$base_prefix}users";
    $table_name  = "{$base_prefix}settings";

    /**
     * API Credentials
     */
    $apiKey = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='pay_token' LIMIT 1"
    ));

    $secret = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='pay_secret' LIMIT 1"
    ));

    $bizId = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='pay_biz' LIMIT 1"
    ));

    if (empty($apiKey) || empty($secret) || empty($bizId)) {
        return [
            'success' => false,
            'message' => 'XIXAPAY credentials not set.',
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'xixapay'
            ]
        ];
    }

    /**
     * BANK CODE
     */
    $bankCode = ['20987'];

    $endpoint = 'https://api.xixapay.com/api/v1/createVirtualAccount';

    /**
     * STATIC PAYLOAD ONLY
     */
    $payload = [
        'email'       => $email,
        'name'        => $name,
        'phoneNumber' => $phone,
        'bankCode'    => $bankCode,
        'businessId'  => $bizId,
        'accountType' => 'static',
        'id_type'     => 'nin',
        'id_number'   => '75119848423'
    ];

    /**
     * Headers
     */
    $headers = [
        "Authorization: Bearer {$secret}",
        "api-key: {$apiKey}",
        "Content-Type: application/json",
        "Accept: application/json"
    ];

    /**
     * CURL REQUEST
     */
    $ch = curl_init($endpoint);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);

    $response = curl_exec($ch);
    $error    = curl_error($ch);

    curl_close($ch);

    /**
     * CURL ERROR
     */
    if ($error) {
        return [
            'success' => false,
            'message' => 'cURL error: ' . $error,
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'xixapay'
            ]
        ];
    }

    $data = json_decode($response, true);

    /**
     * INVALID RESPONSE
     */
    if (!is_array($data)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response from XIXAPAY.',
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'xixapay'
            ]
        ];
    }

    /**
     * Extract account
     */
    $acc = $data['bankAccounts'][0] ?? [];

    $normalized_account = [
        'bank'     => $acc['bankName'] ?? '',
        'name'     => $acc['accountName'] ?? $name,
        'number'   => $acc['accountNumber'] ?? '',
        'provider' => 'xixapay'
    ];

    /**
     * SUCCESS RESPONSE
     */
    if (
        !empty($normalized_account['number']) &&
        isset($data['status']) &&
        strtolower($data['status']) === 'success'
    ) {
        return [
            'success' => true,
            'message' => $data['message'] ?? 'Virtual account created successfully.',
            'account' => $normalized_account,
            'customer' => $data['customer'] ?? null
        ];
    }

    /**
     * FAILURE RESPONSE
     */
    return [
        'success' => false,
        'message' => $data['message'] ?? 'Account creation failed at XIXAPAY.',
        'account' => $normalized_account,
        'errors'  => $data['errors'] ?? [],
        'raw'     => $data
    ];
}