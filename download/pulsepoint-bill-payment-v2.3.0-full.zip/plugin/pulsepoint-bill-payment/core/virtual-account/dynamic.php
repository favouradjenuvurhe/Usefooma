<?php
/**
 * Pulsepoint Dynamic Account Creation
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/virtual-account/dynamic.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_dynamic_account', 'pulsepoint_dynamic_account');
add_action('wp_ajax_pulsepoint_dynamic_account', 'pulsepoint_dynamic_account');

function pulsepoint_dynamic_account() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = (int) $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Fetch user
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id)
    );

    if (!$user || (int) $user->status !== 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    if (($settings['maintenance_mode'] ?? '0') === '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    // Rate limit
    $now = time();
    if (!empty($_SESSION['last_dynamic_request'][$user_id]) &&
        ($now - $_SESSION['last_dynamic_request'][$user_id]) < 15
    ) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds before retrying.']);
    }
    $_SESSION['last_dynamic_request'][$user_id] = $now;

    // Amount
    $amount = (float) ($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Invalid amount supplied.']);
    }

    // Gateway
    $payment_gateway = strtolower($settings['payment_gateway'] ?? 'cashwyre');
    $gateway_file = __DIR__ . '/' . $payment_gateway . '-dynamic.php';

    if (!file_exists($gateway_file)) {
        wp_send_json(['success' => false, 'message' => 'Dynamic gateway handler not found.']);
    }

    require_once $gateway_file;

    if (!function_exists('create_dynamic_account')) {
        wp_send_json(['success' => false, 'message' => 'Gateway function missing.']);
    }

    // Create account
    $response = create_dynamic_account($amount, uniqid('DYN-', true), $user);

    if (empty($response['success'])) {
        wp_send_json(['success' => false, 'message' => 'Dynamic account creation failed.']);
    }

    $account       = $response['account'] ?? [];
    $accountNumber = sanitize_text_field($account['accountNumber'] ?? '');
    $bankName      = sanitize_text_field($account['bankName'] ?? '');

    if (!$accountNumber) {
        wp_send_json(['success' => false, 'message' => 'Account number missing from gateway.']);
    }

    // ✅ FIXED DESCRIPTION
    $description = 'Checkout | ' . $accountNumber;

    // ✅ INSERT (ORDER + FORMAT LOCKED)
    $wpdb->insert(
        $table_trnx,
        [
            'user_id'          => $user_id,
            'details'          => wp_json_encode($account),
            'recipient'        => $bankName,
            'amount'           => $amount,
            'reference'        => $accountNumber,
            'payment'          => 'wallet',
            'category'         => 'virtual-account',
            'status'           => 'pending',
            'type'             => 'credit',
            'gateway_response' => wp_json_encode($response),
            'session'          => session_id(),
            'description'      => (string) $description
        ],
        [
            '%d', // user_id
            '%s', // details
            '%s', // recipient
            '%f', // amount
            '%s', // reference
            '%s', // payment
            '%s', // category
            '%s', // status
            '%s', // type
            '%s', // gateway_response
            '%s', // session
            '%s'  // description ✅ FIXED
        ]
    );

    wp_send_json([
        'success' => true,
        'message' => 'Dynamic account created. Await webhook confirmation.',
        'account' => $account
    ]);
}