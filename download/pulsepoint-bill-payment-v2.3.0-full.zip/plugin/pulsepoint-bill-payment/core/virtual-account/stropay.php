<?php  
/**  
 * Provider: Strowallet Virtual Account API  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/virtual-account/stropay.php  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
/**  
 * Create Virtual Account (Strowallet)  
 *  
 * @param int    $user_id  
 * @param string $name  
 * @param string $email  
 * @param string $phone  
 * @param string $token  
 * @return array  
 */  
function create_virtual_account($user_id = 0, $name = '', $email = '', $phone = '', $token = '')  
{  
    global $wpdb;  
  
    usleep(500000); // small delay for realism  
  
    $name  = trim($name ?: 'Guest User');  
    $email = trim($email ?: 'unknown@example.com');  
    $phone = trim($phone ?: '00000000000');  
  
    if (empty($user_id) || empty($name) || empty($email)) {  
        return [  
            'success' => false,  
            'message' => 'Invalid parameters passed to create_virtual_account().',  
        ];  
    }  
  
    $base_prefix = $wpdb->prefix . 'pulsepoint_';  
    $table_name  = "{$base_prefix}settings";  
  
    if (empty($token)) {  
        $token = $wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key = 'pay_token' LIMIT 1");  
        if (empty($token)) $token = '#';  
    }  
  
    $endpoint = 'https://strowallet.com/api/virtual-bank/new-customer/';  
  
    $payload = [        
        'public_key'     => $token,  
        'email'          => $email,  
        'phone'          => $phone,  
        'account_name'   => $name,  
        'webhook_url'    => site_url('/callback/stropay'),  
        'developer_code' => 'amaaavl',  
    ];  
  
    $headers = [  
        "Content-Type: application/json",  
        "Accept: application/json",  
    ];  
  
    $ch = curl_init();  
    curl_setopt_array($ch, [  
        CURLOPT_URL            => $endpoint,  
        CURLOPT_RETURNTRANSFER => true,  
        CURLOPT_HTTPHEADER     => $headers,  
        CURLOPT_POST           => true,  
        CURLOPT_POSTFIELDS     => json_encode($payload),  
        CURLOPT_TIMEOUT        => 30,  
    ]);  
  
    $response = curl_exec($ch);  
    $error    = curl_error($ch);  
    curl_close($ch);  
  
    if ($error) {  
        return ['success' => false, 'message' => 'cURL error: ' . $error];  
    }  
  
    $data = json_decode($response, true);  
  
    if (!is_array($data)) {  
        return ['success' => false, 'message' => 'Invalid JSON response from Strowallet.'];  
    }  
  
    // ✅ Fix: use new response keys  
    $success = !empty($data['success']);  
    $message = $data['message'] ?? ($success ? 'Virtual account created successfully.' : 'Unknown response from Strowallet.');  
    $acc     = $data;  
  
    if ($success && !empty($acc)) {  
        return [  
            'success' => true,  
            'message' => $message,  
            'account' => [  
                'bank'     => $acc['bank_name'] ?? 'Strowallet Bank',  
                'name'     => $acc['account_name'] ?? $name,  
                'number'   => $acc['account_number'] ?? '',  
                'provider' => 'Strowallet',  
            ],  
        ];  
    }  
  
    return [  
        'success' => false,  
        'message' => $message ?: 'Account creation failed at Strowallet.',  
    ];  
}