<?php
if (!defined('ABSPATH')) exit;

/**
 * Create Virtual Account on PaymentPoint (Normalized for main file)
 *
 * @param int    $user_id
 * @param string $name
 * @param string $email
 * @param string $phone
 * @return array
 */
function create_virtual_account($user_id = 0, $name = '', $email = '', $phone = '')
{
    global $wpdb;

    $name  = trim($name ?: 'Guest User');
    $email = trim($email ?: 'unknown@example.com');
    $phone = trim($phone ?: '00000000000');

    if (empty($user_id) || empty($name) || empty($email)) {
        return [
            'success' => false,
            'message' => 'Invalid parameters passed to create_virtual_account().',
            'account' => ['bank'=>'','name'=>'','number'=>'','provider'=>'paymentpoint']
        ];
    }

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_name  = "{$base_prefix}settings";

    $apiKey  = trim($wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key='pay_token' LIMIT 1"));
    $secret  = trim($wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key='pay_secret' LIMIT 1"));
    $bizId   = trim($wpdb->get_var("SELECT opt_value FROM {$table_name} WHERE opt_key='pay_biz' LIMIT 1"));

    if (empty($apiKey) || empty($secret) || empty($bizId)) {
        return [
            'success' => false,
            'message' => 'PaymentPoint credentials not set.',
            'account' => ['bank'=>'','name'=>'','number'=>'','provider'=>'paymentpoint']
        ];
    }

    $endpoint = 'https://api.paymentpoint.co/api/v1/createVirtualAccount';

    $payload = [
        'email'       => $email,
        'name'        => $name,
        'phoneNumber' => $phone,
        'bankCode'    => ['20946'], // OPAY only
        'businessId'  => $bizId
    ];

    $headers = [
        "Authorization: Bearer {$secret}",
        "api-key: {$apiKey}",
        "Content-Type: application/json",
        "Accept: application/json"
    ];

    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);

    $response = curl_exec($ch);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return [
            'success' => false,
            'message' => 'cURL error: ' . $error,
            'account' => ['bank'=>'','name'=>'','number'=>'','provider'=>'paymentpoint']
        ];
    }

    $data = json_decode($response, true);

    if (!is_array($data)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response from PaymentPoint.',
            'account' => ['bank'=>'','name'=>'','number'=>'','provider'=>'paymentpoint']
        ];
    }

    // Take first bank account
    $acc = $data['bankAccounts'][0] ?? [];

    $normalized_account = [
        'bank'     => $acc['bankName'] ?? '',
        'name'     => $acc['accountName'] ?? $name,
        'number'   => $acc['accountNumber'] ?? '',
        'provider' => 'paymentpoint'
    ];

    // Check if success and account number exists
    if (!empty($normalized_account['number']) && isset($data['status']) && strtolower($data['status']) === 'success') {
        return [
            'success' => true,
            'message' => $data['message'] ?? 'Virtual account created successfully.',
            'account' => $normalized_account
        ];
    }

    // Failure
    return [
        'success' => false,
        'message' => $data['message'] ?? 'Account creation failed at PaymentPoint.',
        'account' => $normalized_account,
        'errors'  => $data['errors'] ?? [],
        'raw'     => $data
    ];
}