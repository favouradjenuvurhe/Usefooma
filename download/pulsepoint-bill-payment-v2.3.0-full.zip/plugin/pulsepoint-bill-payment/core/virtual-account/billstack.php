<?php
if (!defined('ABSPATH')) exit;

/**
 * Create STATIC Virtual Account on BILLSTACK (PALMPAY ONLY)
 */
function create_virtual_account(
    $user_id = 0,
    $name = '',
    $email = '',
    $phone = ''
) {
    global $wpdb;

    $name  = trim($name ?: 'Guest User');
    $email = trim($email ?: '');
    $phone = trim($phone ?: '00000000000');

    if (empty($email)) {
        return [
            'success' => false,
            'message' => 'Email is required.',
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'billstack'
            ]
        ];
    }

    /**
     * DB TABLES
     */
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_users = "{$base_prefix}users";
    $table_name  = "{$base_prefix}settings";

    /**
     * API KEY
     */
    $secret = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='pay_secret' LIMIT 1"
    ));

    if (empty($secret)) {
        return [
            'success' => false,
            'message' => 'BillStack credentials not set.',
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'billstack'
            ]
        ];
    }

    /**
     * CUSTOMER LOOKUP (optional reference system)
     */
    $customer_ref = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT username FROM {$table_users} WHERE email = %s LIMIT 1",
            $email
        )
    );

    if (empty($customer_ref)) {
        $customer_ref = 'CUST' . time();
    }

    /**
     * BILLSTACK ENDPOINT
     */
    $endpoint = 'https://api.billstack.co/v2/thirdparty/generateVirtualAccount/';

    /**
     * FORCE PALMPAY ONLY
     */
    $payload = [
        'email'     => $email,
        'reference' => $customer_ref,
        'firstName' => $name,
        'lastName'  => $name,
        'phone'     => $phone,
        'bank'      => 'PALMPAY'
    ];

    /**
     * HEADERS
     */
    $headers = [
        "Authorization: Bearer {$secret}",
        "Content-Type: application/json",
        "Accept: application/json"
    ];

    /**
     * CURL REQUEST
     */
    $ch = curl_init($endpoint);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);

    $response = curl_exec($ch);
    $error    = curl_error($ch);

    curl_close($ch);

    /**
     * CURL ERROR
     */
    if ($error) {
        return [
            'success' => false,
            'message' => 'cURL error: ' . $error,
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'billstack'
            ]
        ];
    }

    $data = json_decode($response, true);

    /**
     * INVALID RESPONSE
     */
    if (!is_array($data)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response from BillStack.',
            'account' => [
                'bank'     => '',
                'name'     => '',
                'number'   => '',
                'provider' => 'billstack'
            ]
        ];
    }

    /**
     * EXTRACT ACCOUNT
     */
    $acc = $data['data']['account'][0] ?? [];

    $normalized_account = [
        'bank'     => $acc['bank_name'] ?? 'PALMPAY',
        'name'     => $acc['account_name'] ?? $name,
        'number'   => $acc['account_number'] ?? '',
        'provider' => 'billstack'
    ];

    /**
     * SUCCESS
     */
    if (
        !empty($normalized_account['number']) &&
        !empty($data['status'])
    ) {
        return [
            'success' => true,
            'message' => $data['message'] ?? 'Virtual account created successfully.',
            'account' => $normalized_account,
            'reference' => $data['data']['reference'] ?? null
        ];
    }

    /**
     * FAILURE
     */
    return [
        'success' => false,
        'message' => $data['message'] ?? 'Account creation failed at BillStack.',
        'account' => $normalized_account,
        'raw'     => $data
    ];
}