<?php
/**
 * Pulsepoint SMEPlug Data API Integration
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/smeplug.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * SMEPlug Data API Handler
 *
 * @param string $network
 * @param string $plan
 * @param string $phone
 * @param float  $amount
 * @param string $token
 * @param mixed  $value
 * @param string $reference
 * @param int    $transaction_id
 * @return array
 */
function send_data($network, $plan, $phone, $amount, $token, $value, $reference, $transaction_id)
{
    // Map network names
    $network_map = [
        'MTN'     => 1,
        'GLO'     => 4,
        '9MOBILE' => 3,
        'AIRTEL'  => 2
    ];

    $network_id = $network_map[strtoupper($network)] ?? 0;

    if ($network_id === 0) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    // Decode $value (API URL or JSON from DB)
    if (is_string($value)) {
        $decoded = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded['endpoint'])) {
            $value = $decoded['endpoint']; // fetched endpoint from DB
        }
    }

    // Default API endpoint
    $api_url = trim($value ?: 'https://smeplug.ng/api/v1/data/purchase');

    // Generate unique reference
    $request_id = $reference ?: 'SMEPLUG_DATA_' . mt_rand(1000000, 9999999);

    // Prepare payload for SMEPlug API
    $payload = [
        "network_id" => $network_id,
        "plan_id"    => intval($plan),
        "phone"      => $phone
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    // Set headers
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$token}",
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "CURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    // Decode API response
    $decoded = json_decode($response, true);

    if (!is_array($decoded)) {
        return [
            'success' => false,
            'message' => "Invalid API response format",
            'details' => ['raw_response' => $response]
        ];
    }

    // Determine transaction success
    $success = isset($decoded['status']) && $decoded['status'] === true;

    // Keep this 100% as requested
    $message = $success  
        ? "Data purchase successful"  
        : ($decoded['Status'] ?? 'Data purchase failed');

    // Return structured response
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $decoded['data']['reference'] ?? $request_id,
            'network'        => $network,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'SMEPlug',
            'api_response'   => $decoded
        ]
    ];
}