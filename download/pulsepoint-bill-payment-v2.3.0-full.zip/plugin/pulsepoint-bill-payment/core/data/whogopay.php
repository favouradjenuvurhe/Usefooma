<?php
/**
 * WhoGoPay Data API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/whogopay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send data via WhoGoPay
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param string $plan    Plan/Product ID
 * @param string $phone   Recipient phone number
 * @param float  $amount  Amount to charge (optional, for record keeping)
 * @param string $token   API token
 * @param string $reference Optional unique reference
 * @return array Standardized response
 */
function send_data($network, $plan, $phone, $amount, $token, $reference = '') {

    $network_map = [
        'MTN'     => 1,
        'GLO'     => 2,
        'AIRTEL'  => 3,
        '9MOBILE' => 4
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_id = $network_map[$network_upper];
    $unique_ref = $reference ?: 'WGP_DATA_' . mt_rand(1000000, 9999999);

    // Prepare payload
    $payload = [
        "billers_number"       => $phone,
        "billers_network_id"   => $network_id,
        "billers_product_id"   => $plan,
        "billers_uniqueRef"    => $unique_ref
    ];

    $url = "https://whogopay.com.ng/api/v1/data-plan/vending";

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$token}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;
    $message = $success
        ? ($api_response['message'] ?? 'Data purchase successful')
        : ($api_response['message'] ?? 'Data purchase failed');

    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['content']['ref'] ?? $unique_ref,
            'network'        => $network_upper,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'WhoGoPay',
            'api_response'   => $api_response
        ]
    ];
}