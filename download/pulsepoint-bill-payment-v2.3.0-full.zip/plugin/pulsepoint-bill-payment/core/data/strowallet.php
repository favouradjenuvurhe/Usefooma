<?php
/**
 * Strowallet Data API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/strowallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send data via Strowallet
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param string $plan    Plan/Product ID
 * @param string $phone   Recipient phone number
 * @param float  $amount  Amount to charge (optional, for record keeping)
 * @param string $token   Strowallet Public Key
 * @param string $reference Optional unique reference
 * @return array Standardized response
 */
function send_data($network, $plan, $phone, $amount, $token, $reference = '') {

    $network_map = [
        'MTN'     => 'MTN',
        'GLO'     => 'GLO',
        'AIRTEL'  => 'AIRTEL',
        '9MOBILE' => '9MOBILE'
    ];

    $network_upper = strtoupper($network);
    if (!isset($network_map[$network_upper])) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $network_name = $network_map[$network_upper];
    $unique_ref   = $reference ?: 'STROWALLET_DATA_' . mt_rand(1000000, 9999999);

    // Build request URL (Strowallet format)
    $url = add_query_arg([
        'public_key'  => $token,
        'network'     => $network_name,
        'dataPlan'    => $plan,
        'phoneNumber' => $phone
    ], 'https://strowallet.com/api/buy_smedata/');

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json'
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => [
                'url' => $url
            ]
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid JSON or empty response
    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;

    $message = $success
        ? ($api_response['message'] ?? 'Data purchase successful')
        : ($api_response['message'] ?? 'Data purchase failed');

    // Standardized response (MATCHES WHOGOPAY)
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $api_response['reference'] ?? $unique_ref,
            'network'        => $network_upper,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'Strowallet',
            'api_response'   => $api_response
        ]
    ];
}