<?php
/**
 * Pulsepoint Data Purchase Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/pulsepoint.php
 * Author: Amaaavl
 *
 * UPDATE (same pattern as the airtime purchase update):
 * 1. Wallet + Referral Balance can now BOTH fund a data purchase.
 *    Wallet is drawn from first, then referral_balance covers the rest.
 * 2. Email notifications sent for success / failed / pending, rendered
 *    from templates/data.html.
 * 3. Extra security layer:
 *    - Network whitelist (no longer accepts an arbitrary string).
 *    - Phone number format validation.
 *    - Plan is now looked up by id AND network together, so a manipulated
 *      request can't pair a valid plan_id with a different network than
 *      the plan actually belongs to.
 *    - Per-transaction hard amount cap (configurable via settings).
 *    - Idempotency: duplicate reference is rejected before anything is
 *      charged.
 *    - Final debit is re-locked and re-verified against the LIVE balance
 *      right before money moves (closes the race window between the
 *      pre-check and the actual deduction).
 *    - Refunds on failed purchases restore money to the exact buckets
 *      (wallet vs referral_balance) it was taken from, instead of
 *      overwriting the wallet with a stale pre-transaction snapshot.
 *    - Daily limit now checks category='data' AND status='success' only
 *      (previously summed every debit of every category/status, which
 *      could block a user from a data purchase because of, say, airtime
 *      spend or even still-pending transactions).
 *
 * NOTE: buy_amount (the API's cost price) is only ever sent to the
 * provider's API. Every wallet/referral deduction always uses `amount`
 * (the customer's selling price) — these two must never be swapped.
 */

if (!defined('ABSPATH')) exit;

// AJAX Hooks
add_action('wp_ajax_nopriv_pulsepoint_data_purchase', 'pulsepoint_data_purchase');
add_action('wp_ajax_pulsepoint_data_purchase', 'pulsepoint_data_purchase');

const PULSEPOINT_DATA_ALLOWED_NETWORKS = ['MTN', 'GLO', 'AIRTEL', '9MOBILE', 'ETISALAT'];
const PULSEPOINT_DATA_DEFAULT_MAX_AMOUNT = 50000.00; // hard per-transaction cap fallback

/**
 * Render the data email template with escaped values.
 * Falls back to a minimal safe message if the template file is missing.
 */
if (!function_exists('pulsepoint_render_data_email')) {
    function pulsepoint_render_data_email(array $vars): string {
        $template_path = dirname(__DIR__, 2) . '/templates/data.html';

        if (!file_exists($template_path)) {
            return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
        }

        $html = file_get_contents($template_path);

        $defaults = [
            'platform_name' => 'Pulsepoint',
            'color_hex'     => '#6C63FF',
            'status_label'  => '',
            'status_color'  => '#6C63FF',
            'firstname'     => '',
            'network'       => '',
            'phone'         => '',
            'plan'          => '',
            'amount'        => '',
            'reference'     => '',
            'date'          => date('Y-m-d H:i:s'),
            'message'       => '',
            'year'          => date('Y'),
            'support_email' => get_option('admin_email'),
        ];

        $vars = array_merge($defaults, $vars);

        foreach ($vars as $key => $value) {
            $safe = $key === 'message'
                ? $value
                : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
            $html = str_replace('{{' . $key . '}}', $safe, $html);
        }

        return $html;
    }
}

/**
 * Send the status email for a data transaction (success/failed/pending).
 */
if (!function_exists('pulsepoint_send_data_email')) {
    function pulsepoint_send_data_email(
        object $user,
        string $status,
        string $network,
        string $phone,
        string $plan_description,
        float $amount,
        string $reference,
        array $branding
    ): void {
        if (empty($user->email)) {
            return;
        }

        $status_map = [
            'success' => ['label' => 'Successful', 'color' => '#16a34a', 'subject' => 'Data Purchase Successful'],
            'failed'  => ['label' => 'Failed',     'color' => '#dc2626', 'subject' => 'Data Purchase Failed'],
            'pending' => ['label' => 'Pending',    'color' => '#d97706', 'subject' => 'Data Purchase Pending'],
        ];

        $meta = $status_map[$status] ?? $status_map['pending'];

        $message = match ($status) {
            'success' => "Your data purchase was completed successfully.",
            'failed'  => "Your data purchase could not be completed. If any amount was deducted, it has been refunded to your balance.",
            default   => "Your data purchase is currently being processed. You'll be notified once it's confirmed.",
        };

        @wp_mail(
            $user->email,
            $meta['subject'],
            pulsepoint_render_data_email([
                'platform_name' => $branding['platform_name'],
                'color_hex'     => $branding['color_hex'],
                'status_label'  => $meta['label'],
                'status_color'  => $meta['color'],
                'firstname'     => $user->firstname,
                'network'       => $network,
                'phone'         => $phone,
                'plan'          => $plan_description,
                'amount'        => number_format($amount, 2),
                'reference'     => $reference,
                'date'          => current_time('mysql'),
                'message'       => $message,
            ]),
            ['Content-Type: text/html; charset=UTF-8']
        );
    }
}

function pulsepoint_data_purchase() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = (int) $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    /* =====================================================
       SECURITY LOGGING FUNCTION (NO NEW TABLE)
    ====================================================== */
    $log_security = function ($event, $meta = []) use ($wpdb, $base_prefix) {
        $wpdb->insert(
            "{$base_prefix}logs",
            [
                'event'      => $event,
                'meta'       => json_encode($meta),
                'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );
    };

    // Rate limiter
    $now = time();
    if (isset($_SESSION['last_data_request'][$user_id]) && ($now - $_SESSION['last_data_request'][$user_id]) < 10) {
        $log_security('rate_limited', ['user' => $user_id]);
        wp_send_json(['success' => false, 'message' => 'Please wait 10 seconds.']);
    }
    $_SESSION['last_data_request'][$user_id] = $now;

    // Fetch user (LOCKED)
    $wpdb->query('START TRANSACTION');

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id = %d FOR UPDATE", $user_id)
    );

    if (!$user || $user->status != 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'User not active or not found.']);
    }

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';
    $max_amount       = isset($settings['data_max_amount']) && $settings['data_max_amount'] > 0
        ? (float) $settings['data_max_amount']
        : PULSEPOINT_DATA_DEFAULT_MAX_AMOUNT;

    $branding = [
        'platform_name' => $settings['platform_name'] ?? 'Pulsepoint',
        'color_hex'     => $settings['color_hex'] ?? '#6C63FF',
    ];

    // KYC SETTING
    $require_kyc = isset($settings['data_kyc']) && $settings['data_kyc'] == 1;

    if ($require_kyc && $user->statuskyc != 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }

    if ($maintenance_mode == '1') {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Service under maintenance.']);
    }

    // Inputs
    $network   = isset($_POST['network']) ? strtoupper(trim(sanitize_text_field($_POST['network']))) : '';
    $plan_id   = isset($_POST['plan']) ? intval($_POST['plan']) : 0;
    $phone     = isset($_POST['phone']) ? preg_replace('/[^0-9+]/', '', sanitize_text_field($_POST['phone'])) : '';
    $reference = isset($_POST['reference']) ? sanitize_text_field($_POST['reference']) : '';

    /* =====================================================
       INPUT VALIDATION (SECURITY LAYER)
    ====================================================== */
    if (!in_array($network, PULSEPOINT_DATA_ALLOWED_NETWORKS, true)) {
        $log_security('invalid_network_rejected', ['user' => $user_id, 'network' => $network]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Unsupported network selected.']);
    }

    // Nigerian mobile number: 11 digits starting with 0, or 234 followed by 10 digits
    $phone_digits = preg_replace('/\D/', '', $phone);
    $valid_phone = (bool) preg_match('/^0\d{10}$/', $phone_digits)
        || (bool) preg_match('/^234\d{10}$/', $phone_digits);

    if (empty($phone) || !$valid_phone) {
        $log_security('invalid_phone_rejected', ['user' => $user_id, 'phone' => $phone]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Please enter a valid phone number.']);
    }

    if (empty($plan_id)) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Network, Plan, and Phone are required.']);
    }

    // Plan — looked up by id AND network together, so a manipulated
    // plan_id can't be paired with a different network than it belongs to.
    $data_plan = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$base_prefix}data WHERE id = %d AND network = %s AND status = 'active'",
            $plan_id,
            $network
        )
    );

    if (!$data_plan) {
        $log_security('invalid_plan_rejected', ['user' => $user_id, 'plan_id' => $plan_id, 'network' => $network]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Invalid or unavailable data plan selected.']);
    }

    // Selling price (what the user pays) vs buying price (API cost) — never swap these.
    $amount     = floatval($data_plan->amount);
    $buy_amount = floatval($data_plan->purchase);
    $api_plan   = $data_plan->plan;

    if ($amount <= 0 || !is_finite($amount)) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Invalid plan amount.']);
    }

    /* =====================================================
       STRICT AMOUNT RULES
    ====================================================== */
    if ($amount > $max_amount) {
        $log_security('amount_cap_exceeded', ['user' => $user_id, 'amount' => $amount, 'cap' => $max_amount]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Maximum data purchase per transaction is ₦' . number_format($max_amount, 2)]);
    }

    // Provider
    $provider_id = intval($data_plan->provider);
    $provider = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$base_prefix}provider WHERE id = %d", $provider_id)
    );

    if (!$provider) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Invalid provider.']);
    }

    $api_name  = strtolower(trim($provider->name));
    $api_token = trim($provider->token);
    $api_value = maybe_unserialize($provider->value);

    $description = "{$data_plan->details} ({$data_plan->type} - " . strtoupper($network) . ")";

    /* =====================================================
       COMBINED BALANCE CHECK (WALLET + REFERRAL BALANCE)
       Wallet is drawn from first, referral_balance covers the rest.
    ====================================================== */
    $wallet_balance   = (float) $user->wallet;
    $referral_balance = (float) $user->referral_balance;
    $combined_balance = $wallet_balance + $referral_balance;

    if ($api_mode === 'live' && $combined_balance < $amount) {
        $needed = $amount - $combined_balance;

        $log_security('balance_insufficient', [
            'user'     => $user_id,
            'amount'   => $amount,
            'wallet'   => $wallet_balance,
            'referral' => $referral_balance,
        ]);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'You need ₦' . number_format($needed, 2) . ' more to proceed.'
        ]);
    }

    if (empty($reference)) {
        $reference = 'PSNG' . bin2hex(random_bytes(6));
    }

    /* =====================================================
       IDEMPOTENCY + UNIQUE REFERENCE ENFORCEMENT
    ====================================================== */
    $exists = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM {$table_trnx} WHERE reference=%s LIMIT 1", $reference)
    );

    if ($exists) {
        $log_security('duplicate_reference_blocked', ['user' => $user_id, 'reference' => $reference]);
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Duplicate transaction blocked']);
    }

    /* =====================================================
       DAILY LIMIT (data category, success only)
    ====================================================== */
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');

    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx}
         WHERE user_id=%d
         AND date BETWEEN %s AND %s
         AND type='debit'
         AND category='data'
         AND status='success'
         FOR UPDATE",
        $user_id, $today_start, $today_end
    )) ?: 0;

    $account_limit = $user->account_limit ?: 5000;

    if (($spent_today + $amount) > $account_limit) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$account_limit} per day"]);
    }

    /* =====================================================
       INSERT PENDING (SAFE)
    ====================================================== */
    $wpdb->insert($table_trnx, [
        'user_id'     => $user_id,
        'details'     => json_encode(['network' => $network, 'plan' => $api_plan, 'phone' => $phone]),
        'recipient'   => $phone,
        'amount'      => $amount,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'data',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description
    ], ['%d', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s']);

    $trnx_id = $wpdb->insert_id;

    if (!$trnx_id) {
        $wpdb->query('ROLLBACK');
        wp_send_json(['success' => false, 'message' => 'Transaction initialization failed']);
    }

    $wallet_debited = false;
    $wallet_used     = 0.0;
    $referral_used   = 0.0;

    /* =====================================================
       MANUAL / QUEUED PLANS (api_plan == 0) — no live API call
    ====================================================== */
    if ($api_plan == 0) {
        $locked_user = $wpdb->get_row(
            $wpdb->prepare("SELECT wallet, referral_balance FROM `{$table_users}` WHERE id=%d FOR UPDATE", $user_id)
        );

        $live_wallet   = (float) $locked_user->wallet;
        $live_referral = (float) $locked_user->referral_balance;

        if (($live_wallet + $live_referral) < $amount) {
            $wpdb->query('ROLLBACK');
            $log_security('wallet_race_blocked', ['user' => $user_id, 'amount' => $amount]);
            wp_send_json(['success' => false, 'message' => 'Insufficient balance']);
        }

        $wallet_used   = min($live_wallet, $amount);
        $referral_used = round($amount - $wallet_used, 2);

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_users}
                 SET wallet = wallet - %f, referral_balance = referral_balance - %f
                 WHERE id=%d AND wallet >= %f AND referral_balance >= %f",
                $wallet_used, $referral_used, $user_id, $wallet_used, $referral_used
            )
        );

        if ($wpdb->rows_affected !== 1) {
            $wpdb->query('ROLLBACK');
            $log_security('wallet_race_blocked', ['user' => $user_id]);
            wp_send_json(['success' => false, 'message' => 'Insufficient balance']);
        }

        $wpdb->update(
            $table_trnx,
            [
                'status'     => 'pending',
                'updated_at' => current_time('mysql'),
                'details'    => json_encode([
                    'network'       => $network,
                    'plan'          => $api_plan,
                    'phone'         => $phone,
                    'wallet_used'   => $wallet_used,
                    'referral_used' => $referral_used,
                ]),
            ],
            ['id' => $trnx_id]
        );

        $wpdb->query('COMMIT');

        pulsepoint_send_data_email($user, 'pending', $network, $phone, $description, $amount, $reference, $branding);

        wp_send_json([
            'success'   => true,
            'message'   => 'Queued successfully',
            'reference' => $reference
        ]);
    }

    $wpdb->query('COMMIT');

    // Notify: pending (purchase is now in flight)
    pulsepoint_send_data_email($user, 'pending', $network, $phone, $description, $amount, $reference, $branding);

    /* =====================================================
       API CALL (OUTSIDE TRANSACTION)
    ====================================================== */
    $api_file = __DIR__ . '/' . $api_name . '.php';
    if (!file_exists($api_file)) {
        wp_send_json(['success' => false, 'message' => 'API missing']);
    }
    require_once $api_file;

    if (!function_exists('send_data')) {
        wp_send_json(['success' => false, 'message' => 'API missing']);
    }

    // API is always charged the buying price, never the selling price.
    $api_response = send_data($network, $api_plan, $phone, $buy_amount, $api_token, $api_value, $reference, $trnx_id);

    $status = ($api_response['success'] ?? false) ? 'success' : 'failed';

    // Final debit (LOCKED, RE-VERIFIED AGAINST LIVE BALANCE)
    if (in_array($status, ['success', 'pending'], true) && $api_mode === 'live') {
        $wpdb->query('START TRANSACTION');

        $locked_user = $wpdb->get_row(
            $wpdb->prepare("SELECT wallet, referral_balance FROM `{$table_users}` WHERE id=%d FOR UPDATE", $user_id)
        );

        $live_wallet   = (float) $locked_user->wallet;
        $live_referral = (float) $locked_user->referral_balance;

        if (($live_wallet + $live_referral) < $amount) {
            $wpdb->query('ROLLBACK');
            $log_security('wallet_race_blocked', ['user' => $user_id, 'amount' => $amount]);
            wp_send_json(['success' => false, 'message' => 'Balance integrity violation blocked']);
        }

        $wallet_used   = min($live_wallet, $amount);
        $referral_used = round($amount - $wallet_used, 2);

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_users}
                 SET wallet = wallet - %f, referral_balance = referral_balance - %f
                 WHERE id=%d AND wallet >= %f AND referral_balance >= %f",
                $wallet_used, $referral_used, $user_id, $wallet_used, $referral_used
            )
        );

        if ($wpdb->rows_affected !== 1) {
            $wpdb->query('ROLLBACK');
            $log_security('wallet_race_blocked', ['user' => $user_id]);
            wp_send_json(['success' => false, 'message' => 'Wallet error']);
        }

        $wallet_debited = true;

        $wpdb->update(
            $table_trnx,
            ['details' => json_encode([
                'network'       => $network,
                'plan'          => $api_plan,
                'phone'         => $phone,
                'wallet_used'   => $wallet_used,
                'referral_used' => $referral_used,
            ])],
            ['id' => $trnx_id],
            ['%s'],
            ['%d']
        );

        $wpdb->query('COMMIT');

        if ($status === 'success' && (float) $data_plan->cashback > 0) {
            pulsepoint_credit_cashback(
                $user_id,
                (float) $data_plan->cashback,
                'data',
                $reference,
                'Cashback — ' . $data_plan->details
            );
        }
    }

    /* =====================================================
       AUTO-REFUND ON FAILED API (FAIL-SAFE, SPLIT-AWARE)
    ====================================================== */
    if ($status === 'failed' && $api_mode === 'live' && $wallet_debited === true) {
        $wpdb->query('START TRANSACTION');

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table_users} SET wallet = wallet + %f, referral_balance = referral_balance + %f WHERE id=%d",
                $wallet_used, $referral_used, $user_id
            )
        );

        $wpdb->update(
            $table_trnx,
            ['status' => 'failed', 'updated_at' => current_time('mysql')],
            ['id' => $trnx_id],
            ['%s', '%s'],
            ['%d']
        );

        $wpdb->query('COMMIT');

        $log_security('auto_refund_executed', [
            'user'          => $user_id,
            'amount'        => $amount,
            'wallet_used'   => $wallet_used,
            'referral_used' => $referral_used,
            'reference'     => $reference,
            'trnx_id'       => $trnx_id
        ]);
    }

    $wpdb->update($table_trnx, [
        'status'           => $status,
        'gateway_response' => json_encode($api_response['details'] ?? []),
        'updated_at'       => current_time('mysql')
    ], ['id' => $trnx_id], ['%s', '%s', '%s'], ['%d']);

    // Notify: final outcome
    pulsepoint_send_data_email($user, $status, $network, $phone, $description, $amount, $reference, $branding);

    if ($status === 'success' && function_exists('pulsepoint_save_beneficiary')) {
        pulsepoint_save_beneficiary($user_id, 'data', $phone, $phone, $network, ['network' => $network]);
    }

    wp_send_json([
        'success'     => in_array($status, ['success', 'pending'], true),
        'message'     => $api_response['message'] ?? $status,
        'reference'   => $reference,
        'details'     => $api_response['details'] ?? [],
        'description' => $description
    ]);
}
