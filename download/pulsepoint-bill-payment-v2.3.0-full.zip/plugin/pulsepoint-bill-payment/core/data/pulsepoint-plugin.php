<?php
/**
 * Pulsepoint Data API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/pulsepoint-api.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send data via Pulsepoint API
 *
 * @param string $network
 * @param string $plan
 * @param string $phone
 * @param float  $amount
 * @param string $token
 * @param mixed  $value
 * @param string $reference
 * @param int    $transaction_id
 * @return array
 */
function send_data_pulsepoint($network, $plan, $phone, $amount, $token, $value, $reference, $transaction_id)
{
    // Validate network
    $valid_networks = ['MTN', 'AIRTEL', 'GLO', '9MOBILE'];
    $network_upper = strtoupper($network);
    if (!in_array($network_upper, $valid_networks)) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    // Decode $value (API URL or JSON from DB)
    if (is_string($value)) {
        $decoded = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded['endpoint'])) {
            $value = $decoded['endpoint']; // fetched endpoint from DB
        }
    }

    // Default API endpoint
    $api_url = trim($value ?: 'https://yourdomain.com/api/data');

    // Generate unique reference
    $request_id = $reference ?: 'PULSEPOINT_DATA_' . mt_rand(1000000, 9999999);

    // Prepare payload for Pulsepoint API
    $payload = [
        "network"        => $network_upper,
        "mobile_number"  => $phone,
        "plan"           => $plan,
        "Ported_number"  => false
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    // Set headers
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Token {$token}",
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "CURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    // Decode API response
    $decoded = json_decode($response, true);

    if (!is_array($decoded) || !isset($decoded['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => ['raw_response' => $response]
        ];
    }

    // Only consider success = true from API
    $success = $decoded['success'] === true;
    $message = $decoded['message'] ?? ($success ? "Data purchase successful" : "Data purchase failed");

    // Return structured response like msorg.php
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $request_id,
            'network'        => $network_upper,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'Pulsepoint',
            'api_response'   => $decoded
        ]
    ];
}