<?php
/**
 * NCWallet Data API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/ncwallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send data via NCWallet
 *
 * TOKEN FORMAT:
 *   PIN:API_KEY
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param string $plan    NCWallet data plan ID
 * @param string $phone   Recipient phone number
 * @param float  $amount  Amount (for record keeping)
 * @param string $token   PIN:API_KEY
 * @param string $reference Optional reference
 * @return array
 */
function send_data($network, $plan, $phone, $amount, $token, $reference = '')
{
    // ✅ NCWallet endpoint
    $url = "https://ncwallet.africa/api/v1/data";

    // ✅ Split token => PIN : API KEY
    $parts  = explode(':', $token, 2);
    $pin    = trim($parts[0] ?? '');
    $apiKey = trim($parts[1] ?? '');

    if (empty($pin) || empty($apiKey)) {
        return [
            'success' => false,
            'message' => 'Invalid NCWallet token format. Expected PIN:API_KEY.',
            'details' => ['provider' => 'NCWallet']
        ];
    }

    // ✅ Network mapping (NCWallet spec)
    $network_map = [
        'MTN'     => 1,
        '9MOBILE' => 4,
        'GLO'     => 3,
        'AIRTEL'  => 2
    ];

    $network_upper = strtoupper(trim($network));
    $network_code  = $network_map[$network_upper] ?? null;

    if (!$network_code) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    $unique_ref = $reference ?: 'NCD_' . time();

    // ✅ Payload (EXACT NCWallet format)
    $payload = [
        "network"      => $network_code,
        "phone_number" => $phone,
        "data_plan"    => (string)$plan,
        "country_code"       => "NG",
        "bypass"       => true
    ];

    // ✅ Initialize cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            "Accept: application/json",
            "Content-Type: application/json",
            "trnx_pin: {$pin}",
            "Authorization: {$apiKey}"
        ],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // ❌ cURL error
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    // ✅ Decode response
    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid or empty API response from NCWallet.',
            'details' => $response_raw
        ];
    }

    /**
     * NCWallet may return "error" even when delivered
     * We only mark success when status === success
     */
    $status  = strtolower($api_response['status'] ?? '');
    $success = ($status === 'success');

    // ✅ Standardized response
    return [
        'success' => $success,
        'message' => $api_response['message'] ?? 'Data request processed.',
        'details' => [
            'transaction_id' => $api_response['ref_id'] ?? $unique_ref,
            'network'        => $api_response['data']['network'] ?? $network_upper,
            'phone'          => $api_response['data']['phone_number'] ?? $phone,
            'plan'           => $api_response['data']['plan_name'] ?? $plan,
            'amount'         => $amount,
            'old_balance'    => $api_response['data']['oldbal'] ?? null,
            'new_balance'    => $api_response['data']['newbal'] ?? null,
            'provider'       => 'NCWallet',
            'api_response'   => $api_response
        ]
    ];
}