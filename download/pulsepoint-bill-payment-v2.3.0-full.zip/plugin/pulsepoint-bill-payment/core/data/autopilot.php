<?php
/**
 * Pulsepoint Autopilot Data API Integration
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/autopilot.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Autopilot Data API Handler (Direct Gifting)
 *
 * @param string $network
 * @param string $plan
 * @param string $phone
 * @param float  $amount
 * @param string $token
 * @param mixed  $value
 * @param string $reference
 * @param int    $transaction_id
 * @return array
 */
function send_data_autopilot($network, $plan, $phone, $amount, $token, $value, $reference, $transaction_id)
{
    // Map network names to Autopilot IDs
    $network_map = [
        'MTN'     => 1,
        'GLO'     => 3,
        '9MOBILE' => 4,
        'AIRTEL'  => 2
    ];

    $network_id = $network_map[strtoupper($network)] ?? 0;

    if ($network_id === 0) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    // Decode $value if it's JSON from DB
    if (is_string($value)) {
        $decoded = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded['endpoint'])) {
            $value = $decoded['endpoint'];
        }
    }

    // Default API endpoint
    $api_url = trim($value ?: 'https://autopilotng.com/api/live/v1/data');

    // Generate unique reference
    $request_id = $reference ?: 'AUTOPILOT_DATA_' . mt_rand(1000000, 9999999);

    // Prepare payload
    $payload = [
        "networkId" => $network_id,
        "dataType"  => "DIRECT GIFTING",
        "planId"    => $plan, // e.g., "MTN_DG_100MB_DAILY"
        "phone"     => $phone,
        "reference" => $request_id
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    // Set headers
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$token}",
        "Content-Type: application/json",
        "Accept: application/json"
    ]);

    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "CURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    // Decode API response
    $decoded = json_decode($response, true);

    if (!is_array($decoded)) {
        return [
            'success' => false,
            'message' => "Invalid API response format",
            'details' => ['raw_response' => $response]
        ];
    }

    // Determine transaction success
    $success = isset($decoded['status']) && $decoded['status'] === true;

    // Keep this 100% identical to previous
    $message = $success  
        ? "Data purchase successful"  
        : ($decoded['Status'] ?? 'Data purchase failed');

    // Return structured response
    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $decoded['data']['reference'] ?? $request_id,
            'network'        => $network,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'Autopilot',
            'api_response'   => $decoded
        ]
    ];
}