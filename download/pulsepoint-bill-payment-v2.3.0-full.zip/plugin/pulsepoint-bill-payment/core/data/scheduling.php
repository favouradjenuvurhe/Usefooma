<?php
/**
 * Pulsepoint Data Scheduling Input
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/scheduling/data.php
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_data_schedule', 'pulsepoint_data_schedule');
add_action('wp_ajax_pulsepoint_data_schedule', 'pulsepoint_data_schedule');

function pulsepoint_data_schedule() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_users = $base_prefix . 'users';
    $table_jobs  = $base_prefix . 'data_jobs';

    // =========================================
    // GET INPUT (API STYLE JSON)
    // =========================================
    $input = json_decode(file_get_contents("php://input"), true);

    $token   = $input['token'] ?? '';
    $network = strtoupper(trim($input['network'] ?? ''));
    $plan    = trim($input['plan'] ?? '');
    $phone   = sanitize_text_field($input['mobile_number'] ?? '');
    $ported  = !empty($input['Ported_number']) ? 1 : 0;

    // scheduling fields
    $schedule_type    = $input['schedule_type'] ?? 'one_time';
    $run_at           = $input['run_at'] ?? current_time('mysql');
    $interval_minutes = isset($input['interval_minutes']) ? intval($input['interval_minutes']) : null;

    // =========================================
    // VALIDATE USER TOKEN
    // =========================================
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table_users} WHERE token=%s LIMIT 1",
            $token
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid token'
        ]);
    }

    // =========================================
    // VALIDATION RULES
    // =========================================
    if (!$network || !$plan || !$phone) {
        wp_send_json([
            'success' => false,
            'message' => 'Network, Plan, and Phone are required'
        ]);
    }

    if (!in_array($schedule_type, ['one_time','recurring'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid schedule type'
        ]);
    }

    if ($schedule_type === 'recurring' && empty($interval_minutes)) {
        wp_send_json([
            'success' => false,
            'message' => 'Recurring schedule requires interval_minutes'
        ]);
    }

    // =========================================
    // INSERT DATA JOB
    // =========================================
    $insert = $wpdb->insert($table_jobs, [
        'token'            => $token,
        'network'          => $network,
        'plan'             => $plan,
        'mobile_number'    => $phone,
        'ported_number'    => $ported,

        'schedule_type'    => $schedule_type,
        'run_at'           => $run_at,
        'interval_minutes' => $interval_minutes,
        'next_run'         => $run_at,

        'is_active'        => 1
    ], [
        '%s','%s','%s','%s','%d',
        '%s','%s','%d','%s','%d'
    ]);

    if (!$insert) {
        wp_send_json([
            'success' => false,
            'message' => 'Failed to create data schedule'
        ]);
    }

    // =========================================
    // SUCCESS RESPONSE
    // =========================================
    wp_send_json([
        'success'  => true,
        'message'  => 'Data schedule created successfully',
        'job_id'   => $wpdb->insert_id,
        'next_run' => $run_at
    ]);
}