<?php
/**
 * Pulsepoint ADEX Live Data API Integration
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/adex.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * ADEX MansurData Live API Handler
 *
 * @param string $network
 * @param string $plan
 * @param string $phone
 * @param float  $amount
 * @param string $token
 * @param mixed  $value
 * @param string $reference
 * @param int    $transaction_id
 * @return array
 */
function send_data($network, $plan, $phone, $amount, $token, $value, $reference, $transaction_id)
{
    // Map network to MansurData API IDs
    $network_map = [
        'MTN'      => 1,
        'AIRTEL'   => 2,
        'GLO'      => 3,
        '9MOBILE'  => 4
    ];

    $network_id = $network_map[strtoupper($network)] ?? 0;

    if ($network_id === 0) {
        return [
            'success' => false,
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    // Decode $value (API URL)
    if (is_string($value)) {
        $decoded = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded['endpoint'])) {
            $value = $decoded['endpoint']; // from DB value field
        }
    }

    $api_url = trim($value ?: 'https://mansurdata.net/api/data');

    // Generate unique request ID
    $request_id = 'Data_' . mt_rand(10000000000, 99999999999);

    // Prepare payload for MansurData
    $payload = [
        'network'     => $network_id,
        'phone'       => $phone,
        'data_plan'   => intval($plan), // data plan ID
        'bypass'      => false,
        'request-id'  => $request_id
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    // Set headers
    $headers = [
        "Authorization: Token {$token}",
        "Content-Type: application/json"
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute request
    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // Handle CURL error
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "CURL Error: {$curl_error}",
            'details' => []
        ];
    }

    // Decode API response
    $decoded = json_decode($response, true);

    if (!is_array($decoded)) {
        return [
            'success' => false,
            'message' => 'Invalid API response format',
            'details' => ['raw_response' => $response]
        ];
    }

    // Determine success
    $success = isset($decoded['status']) && strtolower($decoded['status']) === 'success';

    // Return structured result
    return [
        'success' => $success,
        'message' => $decoded['message'] ?? ($success ? 'Data purchase successful' : 'Data purchase failed'),
        'details' => $decoded
    ];
}