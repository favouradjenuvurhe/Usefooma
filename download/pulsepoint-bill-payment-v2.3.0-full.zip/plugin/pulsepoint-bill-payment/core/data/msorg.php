<?php
/**
 * Pulsepoint Msorg (MaskawaSub) Data API Integration
 */

if (!defined('ABSPATH')) exit;

function send_data($network, $plan, $phone, $amount, $token, $value, $reference, $transaction_id)
{
    // Map network names
    $network_map = [
        'MTN'     => 1,
        'AIRTEL'  => 4,
        'GLO'     => 2,
        '9MOBILE' => 3
    ];

    $network_id = $network_map[strtoupper($network)] ?? 0;

    if ($network_id === 0) {
        return [
            'success' => false,
            'status'  => 'failed',
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    // Decode endpoint
    if (is_string($value)) {
        $decoded_val = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded_val['endpoint'])) {
            $value = $decoded_val['endpoint'];
        }
    }

    $api_url = trim($value ?: 'https://www.maskawasub.com/api/data/');
    $request_id = $reference ?: 'MSORG_DATA_' . mt_rand(1000000, 9999999);

    // Payload
    $payload = [
        "network"        => $network_id,
        "mobile_number"  => $phone,
        "plan"           => intval($plan),
        "Ported_number"  => true
    ];

    // cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_HTTPHEADER => [
            "Authorization: Token {$token}",
            "Content-Type: application/json"
        ]
    ]);

    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // ❌ CURL ERROR
    if ($curl_error) {
        return [
            'success' => false,
            'status'  => 'failed',
            'message' => "CURL Error: {$curl_error}",
            'details' => ['payload' => $payload]
        ];
    }

    $decoded = json_decode($response, true);

    // ❌ INVALID RESPONSE
    if (!is_array($decoded)) {
        return [
            'success' => false,
            'status'  => 'failed',
            'message' => "Invalid API response format",
            'details' => ['raw_response' => $response]
        ];
    }

    // 🔥 NORMALIZE STATUS
    $raw_status = strtolower(trim($decoded['Status'] ?? ''));

    $success_states = ['success', 'successful'];
    $pending_states = ['pending', 'processing', 'process'];
    $failed_states  = ['fail', 'failed', 'failure'];

    if (in_array($raw_status, $success_states)) {
        $status = 'success';
        $success = true;
    } elseif (in_array($raw_status, $pending_states)) {
        $status = 'pending';
        $success = true; // IMPORTANT: still true so wallet deducts once
    } elseif (in_array($raw_status, $failed_states)) {
        $status = 'failed';
        $success = false;
    } else {
        // Unknown response → treat as pending (safe fallback)
        $status = 'pending';
        $success = true;
    }

    // Message handling
    $message = $decoded['message']
        ?? $decoded['Message']
        ?? ucfirst($status);

    return [
        'success' => $success,
        'status'  => $status,
        'message' => $message,
        'reference' => $decoded['reference'] ?? $request_id,
        'details' => [
            'transaction_id' => $request_id,
            'network'        => $network,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'Msorg',
            'api_response'   => $decoded
        ]
    ];
}