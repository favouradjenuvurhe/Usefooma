<?php
/**
 * Cashwyre Data API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/data/cashwyre.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send data via Cashwyre
 *
 * @param string $network Network name (MTN, GLO, AIRTEL, 9MOBILE)
 * @param string $plan    Plan/Product ID
 * @param string $phone   Recipient phone number
 * @param float  $amount  Amount to charge (optional, for record keeping)
 * @param string $token   Combined token in format businessCode:secretKey
 * @param string $reference Optional unique reference
 * @return array Standardized response
 */
function send_data($network, $plan, $phone, $amount, $token, $reference = '') {

    // Validate token format
    if (!strpos($token, ':')) {
        return [
            'success' => false,
            'message' => 'Invalid token format. Must be businessCode:secretKey',
            'details' => null
        ];
    }

    list($businessCode, $secretKey) = explode(':', $token, 2);
    $businessCode = trim($businessCode);
    $secretKey    = trim($secretKey);

    if (!$businessCode || !$secretKey) {
        return [
            'success' => false,
            'message' => 'Both businessCode and secretKey must be provided in token',
            'details' => null
        ];
    }

    $baseUrl = "https://businessapi.cashwyre.com/api/v1.0/DataPurchase/buyData";
    $unique_ref = $reference ?: 'CW_DATA_' . time();

    $network_lower = strtolower($network);

    // Prepare payload
    $payload = [
        "appId"        => $businessCode,
        "requestId"    => $unique_ref,
        "businessCode" => $businessCode,
        "network"      => $network_lower,
        "phoneNumber"  => $phone,
        "providerPlanCode"  => $plan,
        "amount"       => (float)$amount,
        "reference"    => $unique_ref
    ];

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $baseUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$secretKey}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // Handle cURL errors
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    // Handle invalid or empty API response
    if (!$api_response || !isset($api_response['success'])) {
        return [
            'success' => false,
            'message' => "Invalid or empty API response",
            'details' => $response_raw
        ];
    }

    $success = $api_response['success'] === true;
    $message = $success
        ? ($api_response['message'] ?? 'Data purchase successful')
        : ($api_response['message'] ?? 'Data purchase failed');

    $data = $api_response['data'] ?? [];

    return [
        'success' => $success,
        'message' => $message,
        'details' => [
            'transaction_id' => $data['reference'] ?? $unique_ref,
            'network'        => $network_lower,
            'phone'          => $phone,
            'plan'           => $plan,
            'amount'         => $amount,
            'provider'       => 'Cashwyre',
            'api_response'   => $api_response
        ]
    ];
}