<?php
/**
 * Verify PulsePoint 2FA
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__DIR__) . 'libs/PHPGangsta/GoogleAuthenticator.php';

add_action('wp_ajax_pulsepoint_verify_2fa', 'pulsepoint_verify_2fa');

function pulsepoint_verify_2fa() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Login required.'
        ]);
    }

    $code = isset($_POST['code'])
        ? sanitize_text_field($_POST['code'])
        : '';

    $method = in_array($_POST['method'] ?? 'app', ['app', 'email'], true) ? $_POST['method'] : 'app';

    if (empty($code)) {
        wp_send_json([
            'success' => false,
            'message' => 'Authentication code required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    // ===================================================================
    // EMAIL METHOD
    // ===================================================================
    if ($method === 'email') {

        if (empty($user->twofa_email_code) || empty($user->twofa_email_code_expires)) {
            wp_send_json(['success' => false, 'message' => 'No pending email code. Please request a new one.']);
        }

        if (strtotime($user->twofa_email_code_expires) < time()) {
            wp_send_json(['success' => false, 'message' => 'This code has expired. Please request a new one.']);
        }

        if (!hash_equals((string) $user->twofa_email_code, $code)) {
            wp_send_json(['success' => false, 'message' => 'Invalid verification code.']);
        }

        $wpdb->update(
            $table,
            [
                'twofa_enabled'            => 1,
                'twofa_method'             => 'email',
                'twofa_email_code'         => null,
                'twofa_email_code_expires' => null,
            ],
            ['id' => $user_id]
        );

        wp_send_json([
            'success' => true,
            'message' => '2FA (email) enabled successfully.'
        ]);
    }

    // ===================================================================
    // APP METHOD
    // ===================================================================
    if (empty($user->twofa_secret)) {
        wp_send_json(['success' => false, 'message' => '2FA app setup not started. Please scan the QR code first.']);
    }

    $ga = new PHPGangsta_GoogleAuthenticator();

    $checkResult = $ga->verifyCode(
        $user->twofa_secret,
        $code,
        2
    );

    if (!$checkResult) {

        wp_send_json([
            'success' => false,
            'message' => 'Invalid authentication code.'
        ]);
    }

    // Enable 2FA after successful verification
    $wpdb->update(
        $table,
        [
            'twofa_enabled' => 1,
            'twofa_method'  => 'app',
        ],
        [
            'id' => $user_id
        ]
    );

    wp_send_json([
        'success' => true,
        'message' => '2FA enabled successfully.'
    ]);
}

/**
 * Disable 2FA — requires the current TOTP code as confirmation, same as
 * enabling does, so a stolen session alone can't turn off 2FA protection.
 */
add_action('wp_ajax_pulsepoint_disable_2fa', 'pulsepoint_disable_2fa');

function pulsepoint_disable_2fa() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Login required.'
        ]);
    }

    $code = isset($_POST['code']) ? sanitize_text_field($_POST['code']) : '';

    if (empty($code)) {
        wp_send_json([
            'success' => false,
            'message' => 'Authentication code required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", $user_id)
    );

    if (!$user || (int) $user->twofa_enabled !== 1) {
        wp_send_json([
            'success' => false,
            'message' => '2FA is not currently enabled.'
        ]);
    }

    if (($user->twofa_method ?? 'app') === 'email') {

        if (empty($user->twofa_email_code) || empty($user->twofa_email_code_expires)) {
            wp_send_json(['success' => false, 'message' => 'No pending email code. Please request a new one.']);
        }

        if (strtotime($user->twofa_email_code_expires) < time()) {
            wp_send_json(['success' => false, 'message' => 'This code has expired. Please request a new one.']);
        }

        if (!hash_equals((string) $user->twofa_email_code, $code)) {
            wp_send_json(['success' => false, 'message' => 'Invalid verification code.']);
        }

    } else {

        if (empty($user->twofa_secret)) {
            wp_send_json(['success' => false, 'message' => '2FA is not currently enabled.']);
        }

        $ga = new PHPGangsta_GoogleAuthenticator();
        $valid = $ga->verifyCode($user->twofa_secret, $code, 2);

        if (!$valid) {
            wp_send_json([
                'success' => false,
                'message' => 'Invalid authentication code.'
            ]);
        }
    }

    $wpdb->update(
        $table,
        [
            'twofa_enabled'            => 0,
            'twofa_secret'             => null,
            'twofa_email_code'         => null,
            'twofa_email_code_expires' => null,
        ],
        ['id' => $user_id]
    );

    wp_send_json([
        'success' => true,
        'message' => '2FA disabled successfully.'
    ]);
}