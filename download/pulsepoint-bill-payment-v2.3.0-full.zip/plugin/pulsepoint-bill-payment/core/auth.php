<?php
/**
 * Auth & Access Control for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/auth.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

$table_users    = $wpdb->prefix . 'pulsepoint_users';
$table_trnx     = $wpdb->prefix . 'trnx';
$table_settings = $wpdb->prefix . 'settings';

// You can set $user_id manually if needed, e.g., from POST/GET or session
// $user_id = $_SESSION['pulsepoint_user']['id']; // removed login check

// Fetch user data (replace $user_id with actual id if known)
$user_id = isset($user_id) ? $user_id : 0; // 0 means no user
$user = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d LIMIT 1",
    $user_id
));


// Check if account status is active
if ((int)$user->status !== 1) {
    wp_die('Your account is blocked. Please contact support.', 'Account Blocked');
}

// Fetch daily transaction limit
$limit_option = $wpdb->get_row($wpdb->prepare(
    "SELECT opt_value FROM {$table_settings} WHERE opt_key = %s LIMIT 1",
    'transaction_limit'
));
$daily_limit = $limit_option ? (float)$limit_option->opt_value : 1000.00; // default 1000

// Calculate user's total transactions today
$today_start = date('Y-m-d 00:00:00');
$today_end   = date('Y-m-d 23:59:59');

$total_today = $wpdb->get_var($wpdb->prepare(
    "SELECT SUM(amount) FROM {$table_trnx} 
     WHERE `date` BETWEEN %s AND %s 
       AND user_id = %d",
    $today_start, $today_end, $user_id
));

$total_today = $total_today ? (float)$total_today : 0.00;

if ($total_today >= $daily_limit) {
    wp_die('You have reached your daily transaction limit. Try again tomorrow.', 'Transaction Limit Reached');
}