<?php
/**
 * NCWallet Cable API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/cable/ncwallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send cable TV subscription via NCWallet
 *
 * TOKEN FORMAT:
 *   PIN:API_KEY
 *
 * @param string $provider       Cable provider code (dstv, gotv, startimes)
 * @param string $plan_name      NCWallet cable plan ID
 * @param string $smartcard      Smartcard / IUC number
 * @param array  $details        Customer details (optional)
 * @param float  $amount         Amount to charge
 * @param string $reference      Unique reference
 * @param string $transaction_id Internal transaction ID
 * @param string $verified_name  Verified customer name
 * @return array
 */
function send_cable($provider, $plan_name, $smartcard, $details, $amount, $reference, $transaction_id, $verified_name)
{
    global $wpdb;

    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Load NCWallet token from settings
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);
    $token    = trim($settings['cable_token']->opt_value ?? '');

    if (!$token || !str_contains($token, ':')) {
        return [
            'success' => false,
            'message' => 'Invalid NCWallet token format. Expected PIN:API_KEY.',
            'details' => null
        ];
    }

    // Split token
    [$pin, $apiKey] = explode(':', $token, 2);
    $pin    = trim($pin);
    $apiKey = trim($apiKey);

    if (!$pin || !$apiKey) {
        return [
            'success' => false,
            'message' => 'PIN or API key missing in token.',
            'details' => null
        ];
    }

    // NCWallet endpoint
    $url = "https://ncwallet.africa/api/v1/cable";

    // Provider → NCWallet cable_id
    $provider_map = [
        'dstv'       => 2,
        'gotv'       => 1,
        'startimes'  => 3
    ];

    $provider_key = strtolower(trim($provider));
    $cable_id     = $provider_map[$provider_key] ?? null;

    if (!$cable_id) {
        return [
            'success' => false,
            'message' => "Invalid cable provider: {$provider}",
            'details' => null
        ];
    }

    $unique_ref = $reference ?: 'NCC_' . time();

    // Payload (EXACT NCWallet format)
    $payload = [
        "ref_id"        => $unique_ref,
        "cable_id"      => (string)$cable_id,
        "cable_number"  => (string)$smartcard,
        "cable_plan"    => (string)$plan_name,
        "bypass"        => false
    ];

    // Init cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            "Accept: application/json",
            "Content-Type: application/json",
            "trnx_pin: {$pin}",
            "Authorization: {$apiKey}"
        ]
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    // cURL failure
    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    // Decode response
    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid or empty API response from NCWallet.',
            'details' => $response_raw
        ];
    }

    $status  = strtolower($api_response['status'] ?? '');
    $success = ($status === 'success');

    return [
        'success' => $success,
        'message' => $api_response['message'] ?? 'Cable request processed.',
        'details' => [
            'transaction_id' => $api_response['ref_id'] ?? $unique_ref,
            'provider'       => $api_response['data']['cable_company'] ?? strtoupper($provider),
            'plan'           => $api_response['data']['cable_plan_name'] ?? $plan_name,
            'smartcard'      => $api_response['data']['cable_number'] ?? $smartcard,
            'amount'         => $api_response['data']['amount'] ?? $amount,
            'old_balance'    => $api_response['data']['oldbal'] ?? null,
            'new_balance'    => $api_response['data']['newbal'] ?? null,
            'customer_name'  => $api_response['data']['customer_name'] ?? $verified_name,
            'provider_code'  => $cable_id,
            'provider_name'  => 'NCWallet',
            'api_response'   => $api_response
        ]
    ];
}