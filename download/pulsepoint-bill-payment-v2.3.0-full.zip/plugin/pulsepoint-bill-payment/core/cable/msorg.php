<?php
/**
 * Pulsepoint MaskawaSub Cable API Integration
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/cable/msorg_cable.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send cable TV subscription via MaskawaSub
 *
 * @param string $cablename     Cable provider id (e.g., 1=GOTV, 2=DSTV, 3=STARTIMES)
 * @param string $cableplan     Plan id
 * @param string $smartcard     Smart card / Meter number
 * @param float  $amount        Amount
 * @param string $reference     Transaction reference
 * @param int    $transaction_id Internal transaction ID
 * @param string $verified_name Customer name (optional)
 * @return array
 */
function send_cable($cablename, $cableplan, $smartcard, $amount, $reference = null, $transaction_id = null, $verified_name = '')
{
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    /* ---------------- LOAD SETTINGS ---------------- */
    $settings = $wpdb->get_results(
        "SELECT opt_key, opt_value FROM {$base_prefix}settings",
        OBJECT_K
    );

    $endpoint = trim($settings['cable_api']->opt_value ?? 'https://www.maskawasub.com/api/cablesub/');
    $token    = trim($settings['cable_token']->opt_value ?? '');

    if (!$endpoint || !$token) {
        return [
            'success' => false,
            'message' => 'MaskawaSub Cable API endpoint or token not configured.'
        ];
    }

    /* ---------------- REQUEST ID ---------------- */
    $unique_ref = $reference ?: 'MSORG_CABLE_' . time();

    /* ---------------- PAYLOAD ---------------- */
    $payload = [
        'cablename'         => $cablename,
        'cableplan'         => $cableplan,
        'smart_card_number' => $smartcard
    ];

    /* ---------------- cURL REQUEST ---------------- */
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Token {$token}",
            "Content-Type: application/json"
        ]
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}"
        ];
    }

    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid API response from MaskawaSub',
            'details' => ['raw_response' => $response_raw]
        ];
    }

    $status_lower = strtolower($api_response['status'] ?? '');
    $success = in_array($status_lower, ['success', 'successful'], true);

    /* ---------------- STANDARD RESPONSE ---------------- */
    return [
        'success' => $success,
        'message' => $api_response['status'] ?? 'Cable processed successfully',
        'details' => [
            'transaction_id' => $api_response['request-id'] ?? $unique_ref,
            'cablename'      => $cablename,
            'cableplan'      => $cableplan,
            'smartcard'      => $smartcard,
            'amount'         => $amount,
            'customer_name'  => $verified_name,
            'provider_name'  => 'MaskawaSub',
            'api_response'   => $api_response
        ]
    ];
}