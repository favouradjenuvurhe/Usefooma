<?php
/**
 * Cashwyre Cable API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/cable/cashwyre.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send cable TV subscription via Cashwyre
 *
 * @param string $provider       Cable provider code (dstv, gotv, startimes)
 * @param string $plan_name      Provider plan code
 * @param string $smartcard      Customer smartcard number
 * @param array  $details        Customer details (optional)
 * @param float  $amount         Amount to pay
 * @param string $reference      Unique transaction reference
 * @param string $transaction_id Internal transaction ID
 * @param string $verified_name  Customer full name
 * @return array Standardized response
 */
function send_cable($provider, $plan_name, $smartcard, $details, $amount, $reference, $transaction_id, $verified_name)
{
    global $wpdb;

    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Load settings from DB
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);

    $token    = trim($settings['cable_token']->opt_value ?? '');
    $baseUrl  = trim($settings['cable_api']->opt_value ?? 'https://businessapi.cashwyre.com/api/v1.0/CableTV/buyCableTV');

    if (!$token) {
        return [
            'success' => false,
            'message' => 'Cable API token not configured in settings.',
            'details' => null
        ];
    }

    if (!strpos($token, ':')) {
        return [
            'success' => false,
            'message' => 'Invalid token format in settings. Must be businessCode:secretKey',
            'details' => null
        ];
    }

    list($businessCode, $secretKey) = explode(':', $token, 2);
    $businessCode = trim($businessCode);
    $secretKey    = trim($secretKey);

    if (!$businessCode || !$secretKey) {
        return [
            'success' => false,
            'message' => 'Both businessCode and secretKey must be provided in token',
            'details' => null
        ];
    }

    $unique_ref   = $reference ?: 'CW_CABLE_' . time();
    $phone        = "09064873505";   // Hardcoded as requested
    $customerName = $verified_name;

    // Build payload
    $payload = [
        "appId"            => $businessCode,
        "requestId"        => $unique_ref,
        "businessCode"     => $businessCode,
        "providerCode"     => strtolower($provider),
        "providerPlanCode" => $plan_name,
        "phoneNumber"      => $phone,
        "smartCardNumber"  => $smartcard,
        "customerName"     => $customerName,
        "reference"        => $unique_ref,
        "amount"           => (float)$amount
    ];

    $log_file = __DIR__ . '/cashwyre_cable_log.txt';
    $log  = "=========== CASHWYRE CABLE REQUEST ===========\n";
    $log .= "Date: " . date('Y-m-d H:i:s') . "\n";
    $log .= "Transaction ID: {$transaction_id}\n";
    $log .= "Provider: {$provider}\n";
    $log .= "Plan: {$plan_name}\n";
    $log .= "Smartcard: {$smartcard}\n";
    $log .= "Amount: {$amount}\n";
    $log .= "Reference: {$unique_ref}\n";
    $log .= "Payload: " . json_encode($payload) . "\n";

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $baseUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer {$secretKey}",
        "Content-Type: application/json"
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        file_put_contents($log_file, $log . "CURL ERROR: {$curl_error}\n\n", FILE_APPEND);

        return [
            'success' => false,
            'message' => 'Connection error.',
            'details' => ['curl_error' => $curl_error]
        ];
    }

    $decoded = json_decode($response_raw, true);
    $log .= "API RESPONSE: {$response_raw}\n\n";
    file_put_contents($log_file, $log, FILE_APPEND);

    $success = isset($decoded['success']) && $decoded['success'] === true;
    $data    = $decoded['data'] ?? [];

    return [
        'success' => $success,
        'message' => $decoded['message'] ?? ($success ? 'Cable purchase successful' : 'Unknown error'),
        'details' => [
            'transaction_id' => $data['reference'] ?? $unique_ref,
            'provider'       => strtolower($provider),
            'plan'           => $plan_name,
            'smartcard'      => $smartcard,
            'amount'         => $amount,
            'customer_name'  => $customerName,
            'phone'          => $phone,
            'provider_code'  => $data['code'] ?? null,
            'api_response'   => $decoded
        ]
    ];
}