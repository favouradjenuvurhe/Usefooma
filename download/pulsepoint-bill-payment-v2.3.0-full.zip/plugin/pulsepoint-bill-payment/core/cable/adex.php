<?php
/**
 * ADEX Cable API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/cable/adex.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send cable TV subscription via ADEX (mansurdata.net)
 */
function send_cable(
    $provider,        // kept for backward compatibility (not used)
    $plan_name,
    $smartcard,
    $details,
    $amount,
    $reference,
    $transaction_id,
    $cable_type,
    $verified_name
) {
    global $wpdb;

    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    /* ---------------- LOAD SETTINGS ---------------- */
    $settings = $wpdb->get_results(
        "SELECT opt_key, opt_value FROM {$base_prefix}settings",
        OBJECT_K
    );

    $endpoint = trim($settings['cable_api']->opt_value ?? '');
    $token    = trim($settings['cable_token']->opt_value ?? '');

    if (!$endpoint || !$token) {
        return [
            'success' => false,
            'message' => 'Cable API endpoint or token not configured.'
        ];
    }

    /* ---------------- NORMALIZE CABLE TYPE ---------------- */
    $normalized = strtolower(trim((string)$cable_type));

    /**
     * ADEX Cable IDs
     * 1 = GOTV
     * 2 = DSTV
     * 3 = STARTIMES
     */
    $name_map = [
        'dstv'      => 2,
        'gotv'      => 1,
        'startimes' => 3,
    ];

    if (ctype_digit($normalized) && in_array((int)$normalized, [1, 2, 3], true)) {
        $cable_id = (int)$normalized;
    } elseif (isset($name_map[$normalized])) {
        $cable_id = $name_map[$normalized];
    } else {
        return [
            'success' => false,
            'message' => 'Invalid cable type supplied'
        ];
    }

    /* ---------------- REQUEST ID ---------------- */
    $unique_ref = $reference ?: 'CABLE_' . time();

    /* ---------------- PAYLOAD ---------------- */
    $payload = [
        'cable'      => $cable_id,
        'iuc'        => (string)$smartcard,
        'cable_plan' => (string)$plan_name,
        'bypass'     => false,
        'request-id' => $unique_ref
    ];

    /* ---------------- cURL REQUEST ---------------- */
    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Token {$token}",
            "Content-Type: application/json",
            "Accept: application/json"
        ]
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}"
        ];
    }

    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid API response from ADEX'
        ];
    }

    $success = strtolower($api_response['status'] ?? '') === 'success';

    /* ---------------- STANDARD RESPONSE ---------------- */
    return [
        'success' => $success,
        'message' => $api_response['message'] ?? 'Cable processed successfully',
        'details' => [
            'transaction_id' => $api_response['request-id'] ?? $unique_ref,
            'cable_id'       => $cable_id,
            'plan'           => $api_response['plan_name'] ?? $plan_name,
            'smartcard'      => $api_response['iuc'] ?? $smartcard,
            'amount'         => $api_response['amount'] ?? $amount,
            'old_balance'    => $api_response['oldbal'] ?? null,
            'new_balance'    => $api_response['newbal'] ?? null,
            'charges'        => $api_response['charges'] ?? null,
            'customer_name'  => $verified_name,
            'provider_name'  => 'ADEX',
            'api_response'   => $api_response
        ]
    ];
}