<?php
/**
 * Pulsepoint Plugin Core Loader
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/index.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// ✅ Include domain verification service
require_once plugin_dir_path(__DIR__) . 'base/pulsepoint.php';