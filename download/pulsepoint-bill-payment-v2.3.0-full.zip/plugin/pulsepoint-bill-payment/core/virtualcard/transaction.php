<?php
/**
 * Card Transactions for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/transaction.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_card_transactions', 'pulsepoint_card_transactions');
add_action('wp_ajax_nopriv_pulsepoint_card_transactions', 'pulsepoint_card_transactions');

function pulsepoint_card_transactions() {
    global $wpdb;
    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';
    function pulsepoint_trnx_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }

    pulsepoint_trnx_log("==== Card Transactions Request Started ====", $log_file);

    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'GET') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    // Start session
    if (!session_id()) session_start();
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        pulsepoint_trnx_log("Session expired or user not logged in", $log_file);
        wp_send_json(['success' => false, 'message' => 'Session expired. Please login again.']);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $user_table = $base_prefix . 'users';
    $settings_table = $base_prefix . 'settings';

    // Get user data
    $user = $wpdb->get_row($wpdb->prepare("SELECT id, cardid FROM {$user_table} WHERE id = %d LIMIT 1", $user_id));
    if (!$user || empty($user->cardid)) {
        pulsepoint_trnx_log("User or Card ID not found", $log_file);
        wp_send_json(['success' => false, 'message' => 'Card not found. Please create a virtual card first.']);
    }

    $card_id = sanitize_text_field($_POST['card_id'] ?? $_GET['card_id'] ?? $user->cardid);
    $page = intval($_POST['page'] ?? $_GET['page'] ?? 1);
    $take = intval($_POST['take'] ?? $_GET['take'] ?? 10);

    // Get Strowallet public key
    $public_key = $wpdb->get_var("SELECT opt_value FROM {$settings_table} WHERE opt_key = 'stropay_pkey' LIMIT 1");
    if (empty($public_key)) {
        pulsepoint_trnx_log("Public key missing", $log_file);
        wp_send_json(['success' => false, 'message' => 'Strowallet public key not configured.']);
    }

    // Build API request
    $api_url = "https://strowallet.com/api/apicard-transactions/?card_id={$card_id}&page={$page}&take={$take}&public_key={$public_key}";
    pulsepoint_trnx_log("Requesting Transactions: $api_url", $log_file);

    $response = wp_remote_get($api_url, [
        'headers' => ['accept' => 'application/json'],
        'timeout' => 40,
    ]);

    if (is_wp_error($response)) {
        pulsepoint_trnx_log("API Error: " . $response->get_error_message(), $log_file);
        wp_send_json(['success' => false, 'message' => 'Failed to contact Strowallet API.']);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    pulsepoint_trnx_log("API Response: " . json_encode($body), $log_file);

    if (empty($body) || !isset($body['success'])) {
        wp_send_json(['success' => false, 'message' => 'Invalid API response.']);
    }

    if ($body['success'] !== true) {
        wp_send_json(['success' => false, 'message' => $body['message'] ?? 'Failed to retrieve transactions.']);
    }

    $transactions = $body['response']['card_transactions'] ?? [];

    // Format result
    $formatted = [];
    foreach ($transactions as $tx) {
        $formatted[] = [
            'id'         => $tx['id'] ?? '',
            'amount'     => $tx['amount'] ?? '0',
            'type'       => ucfirst($tx['type'] ?? ''),
            'method'     => ucfirst($tx['method'] ?? ''),
            'narrative'  => $tx['narrative'] ?? '',
            'status'     => ucfirst($tx['status'] ?? ''),
            'currency'   => strtoupper($tx['currency'] ?? 'USD'),
            'reference'  => $tx['reference'] ?? '',
            'date'       => date('Y-m-d H:i:s', strtotime($tx['createdAt'] ?? 'now'))
        ];
    }

    pulsepoint_trnx_log("Returned " . count($formatted) . " transactions for Card {$card_id}", $log_file);
    pulsepoint_trnx_log("==== Card Transactions Request Completed ====", $log_file);

    wp_send_json([
        'success' => true,
        'message' => $body['message'] ?? 'Transactions retrieved successfully.',
        'transactions' => $formatted
    ]);
}
?>