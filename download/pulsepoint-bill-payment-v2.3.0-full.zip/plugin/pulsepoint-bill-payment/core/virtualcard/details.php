<?php  
/**
 * Pulsepoint Card AJAX Sync
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Register AJAX actions
 */
add_action('wp_ajax_pulsepoint_card_sync', 'pulsepoint_card_sync_ajax');
add_action('wp_ajax_nopriv_pulsepoint_card_sync', 'pulsepoint_card_sync_ajax'); // remove if auth-only

function pulsepoint_card_sync_ajax() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    // 🔐 Optional nonce check
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'pulsepoint_card_sync')) {
        wp_send_json(['success' => false, 'message' => 'Invalid nonce']);
    }

    $user_id = intval($_POST['user_id'] ?? 0);
    if (!$user_id) {
        wp_send_json(['success' => false, 'message' => 'Invalid user_id']);
    }

    $base = $wpdb->prefix . 'pulsepoint_';
    $users_table = $base . 'users';
    $settings_table = $base . 'settings';
    $cards_table = $base . 'virtual_cards';
    $txn_table = $base . 'virtualcard_transactions';

    // 🔐 Logger
    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';
    $log = function ($msg) use ($log_file) {
        file_put_contents($log_file, '[' . date('Y-m-d H:i:s') . "] $msg\n", FILE_APPEND);
    };

    $log("==== CARD AJAX SYNC STARTED ====");

    /** Fetch user */
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$users_table} WHERE id = %d LIMIT 1", $user_id)
    );

    if (!$user || empty($user->cardid)) {
        $log("User or card not found");
        wp_send_json(['success' => false, 'message' => 'User or card not found']);
    }

    /** Fetch API key */
    $public_key = $wpdb->get_var(
        $wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'stropay_pkey')
    );

    if (!$public_key) {
        wp_send_json(['success' => false, 'message' => 'Strowallet key missing']);
    }

    /** FETCH CARD DETAILS */
    $card_res = wp_remote_post(
        'https://strowallet.com/api/bitvcard/fetch-card-detail/',
        [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode([
                'public_key' => $public_key,
                'card_id'    => $user->cardid,
            ]),
            'timeout' => 40,
        ]
    );

    if (is_wp_error($card_res)) {
        wp_send_json(['success' => false, 'message' => 'Card API error']);
    }

    $card_body = json_decode(wp_remote_retrieve_body($card_res), true);

    // Validate API response
    if (empty($card_body['success']) || empty($card_body['response']['card_detail'])) {
        $log("Invalid card response: " . wp_remote_retrieve_body($card_res));
        wp_send_json(['success' => false, 'message' => 'Invalid card response']);
    }

    // Map API card data safely
    $api_card = $card_body['response']['card_detail'];

    $card = [
        'card_holder_name'  => $api_card['card_holder_name'] ?? null,
        'card_name'         => $api_card['card_name'] ?? null,
        'card_id'           => $api_card['card_id'] ?? $api_card['id'] ?? null,
        'card_created_date' => $api_card['card_created_date'] ?? null,
        'card_type'         => $api_card['card_type'] ?? null,
        'card_brand'        => $api_card['card_brand'] ?? null,
        'card_user_id'      => $api_card['card_user_id'] ?? null,
        'reference'         => $api_card['reference'] ?? null,
        'card_status'       => $api_card['card_status'] ?? 'inactive',
        'card_number'       => $api_card['card_number'] ?? null,
        'last4'             => $api_card['last4'] ?? null,
        'cvv'               => $api_card['cvv'] ?? null,
        'expiry'            => $api_card['expiry'] ?? null,
        'customer_email'    => $api_card['customer_email'] ?? null,
        'customer_id'       => $api_card['customer_id'] ?? null,
        'balance'           => floatval($api_card['balance'] ?? 0.00),
    ];

    /** UPSERT CARD */
    $wpdb->replace($cards_table, array_merge(['user_id' => $user_id], $card));

    /** FETCH TRANSACTIONS */
    $txn_res = wp_remote_post(
        'https://strowallet.com/api/bitvcard/card-transactions/',
        [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode([
                'public_key' => $public_key,
                'card_id'    => $user->cardid,              
            ]),
            'timeout' => 40,
        ]
    );

    $transactions = [];
    if (!is_wp_error($txn_res)) {
        $txn_body = json_decode(wp_remote_retrieve_body($txn_res), true);
        $transactions = $txn_body['response']['card_transactions'] ?? [];
    }

    foreach ($transactions as $t) {
        if (empty($t['id'])) continue;

        $wpdb->replace($txn_table, [
            'transaction_id' => $t['id'],
            'card_id'        => $card['card_id'],
            'created_at'     => $t['createdAt'] ?? null,
            'updated_at'     => $t['updatedAt'] ?? null,
            'amount'         => $t['amount'] ?? 0.00,
            'cent_amount'    => $t['cent_amount'] ?? 0,
            'type'           => $t['type'] ?? null,
            'method'         => $t['method'] ?? null,
            'narrative'      => $t['narrative'] ?? null,
            'status'         => $t['status'] ?? null,
            'currency'       => strtoupper($t['currency'] ?? 'USD'),
            'reference'      => $t['reference'] ?? null,
        ]);
    }

    $log("==== CARD AJAX SYNC COMPLETED ====");

    wp_send_json([
        'success' => true,
        'message' => 'Card & transactions synced successfully',
        'card_id' => $card['card_id'],
        'transactions_synced' => count($transactions),
    ]);
}