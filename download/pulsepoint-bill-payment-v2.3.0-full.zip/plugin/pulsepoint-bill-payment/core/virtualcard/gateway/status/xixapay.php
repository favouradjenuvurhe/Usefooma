<?php
/**
 * XIXAPAY Card Status Provider
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/gateway/status/xixapay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * REQUIRED FUNCTION
 * update_card_status()
 */
function update_card_status($payload = [])
{
    global $wpdb;

    /**
     * VALIDATE PAYLOAD
     */
    if (empty($payload) || !is_array($payload)) {

        return [
            'success' => false,
            'message' => 'Invalid payload supplied.',
            'response' => []
        ];
    }

    /**
     * EXTRACT PAYLOAD
     */
    $card_id = trim($payload['card_id'] ?? '');
    $action  = trim($payload['action'] ?? '');

    /**
     * CARD ID CHECK
     */
    if (empty($card_id)) {

        return [
            'success' => false,
            'message' => 'Card ID is required.',
            'response' => []
        ];
    }

    /**
     * MAP PULSEPOINT ACTION -> XIXAPAY STATUS
     * Pulsepoint uses freeze/unfreeze/block internally (matches the UI
     * language), XIXAPAY's API expects active/frozen/blocked.
     */
    $status_map = [
        'freeze'   => 'frozen',
        'unfreeze' => 'active',
        'block'    => 'blocked'
    ];

    if (!isset($status_map[$action])) {

        return [
            'success' => false,
            'message' => "Unsupported action '{$action}' for XIXAPAY.",
            'response' => []
        ];
    }

    $status = $status_map[$action];

    /**
     * TABLES
     */
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_name  = $base_prefix . 'settings';

    /**
     * API CREDENTIALS
     * Same credentials used by card creation/funding/withdrawal (XIXAPAY
     * treats all card actions as one API surface).
     */
    $apiKey = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_pkey' LIMIT 1"
    ));

    $secret = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_skey' LIMIT 1"
    ));

    $bizId = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='strowallet_vip_key' LIMIT 1"
    ));

    /**
     * VALIDATE CREDENTIALS
     */
    if (
        empty($apiKey) ||
        empty($secret) ||
        empty($bizId)
    ) {

        return [
            'success' => false,
            'message' => 'XIXAPAY credentials not configured.',
            'response' => []
        ];
    }

    /**
     * ENDPOINT
     * PUT /api/card/{id}/status
     */
    $endpoint = 'https://api.xixapay.com/api/card/' . rawurlencode($card_id) . '/status';

    /**
     * PAYLOAD
     */
    $requestBody = [

        'status'     => $status,
        'businessId' => $bizId

    ];

    /**
     * HEADERS
     */
    $headers = [

        'Authorization' => 'Bearer ' . $secret,
        'api-key'       => $apiKey,
        'Content-Type'  => 'application/json',
        'Accept'        => 'application/json'

    ];

    /**
     * SEND REQUEST
     * This endpoint is a PUT, not a POST — wp_remote_post() always sends
     * POST, so we use wp_remote_request() with an explicit method here.
     */
    $response = wp_remote_request($endpoint, [

        'method'  => 'PUT',
        'headers' => $headers,
        'body'    => wp_json_encode($requestBody),
        'timeout' => 40

    ]);

    /**
     * REQUEST ERROR
     */
    if (is_wp_error($response)) {

        return [
            'success' => false,
            'message' => $response->get_error_message(),
            'response' => []
        ];
    }

    /**
     * RESPONSE BODY
     */
    $body = json_decode(
        wp_remote_retrieve_body($response),
        true
    );

    /**
     * INVALID RESPONSE
     */
    if (
        empty($body) ||
        !is_array($body)
    ) {

        return [
            'success' => false,
            'message' => 'Invalid API response.',
            'response' => []
        ];
    }

    /**
     * API FAILED
     */
    if (
        !isset($body['status']) ||
        strtolower($body['status']) !== 'success'
    ) {

        return [
            'success' => false,
            'message' => $body['message'] ?? "Failed to {$action} card.",
            'response' => $body
        ];
    }

    /**
     * EXTRACT RESPONSE
     * Example success payload:
     * {
     *   "status": "success",
     *   "message": "Card status updated",
     *   "data": { "card_id": "...", "status": "blocked", "balance": 0.00, "currency": "USD" }
     * }
     */
    $data = $body['data'] ?? [];

    /**
     * SUCCESS RESPONSE
     */
    return [

        'success' => true,

        'message' => $body['message'] ?? (ucfirst($action) . ' successful.'),

        'response' => [

            'card_id'      => sanitize_text_field($data['card_id'] ?? $card_id),
            'card_status'  => sanitize_text_field($data['status'] ?? $status),
            'balance'      => $data['balance'] ?? null,
            'currency'     => $data['currency'] ?? null,

            /**
             * EXTRA OPTIONAL DATA
             */
            'raw' => $data

        ]

    ];
}
?>
