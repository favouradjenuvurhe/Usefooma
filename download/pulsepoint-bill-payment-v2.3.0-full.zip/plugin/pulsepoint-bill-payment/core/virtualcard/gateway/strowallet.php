<?php
/**
 * Test Provider File
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/strowallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Create Virtual Card
 *
 * REQUIRED FUNCTION NAME:
 * create_virtual_card()
 */
function create_virtual_card($payload = [])
{
    global $wpdb;

    /**
     * VALIDATE PAYLOAD
     */
    if (empty($payload) || !is_array($payload)) {

        return [
            'success' => false,
            'message' => 'Invalid payload supplied.',
            'response' => []
        ];
    }

    /**
     * USER DATA
     */
    $user_id   = intval($payload['user_id'] ?? 0);
    $name      = trim($payload['name'] ?? '');
    $email     = trim($payload['email'] ?? '');
    $phone     = trim($payload['phone'] ?? '');
    $amount    = floatval($payload['amount'] ?? 0);
    $card_type = trim($payload['card_type'] ?? 'visa');

    /**
     * BASIC VALIDATION
     */
    if (empty($name) || empty($email)) {

        return [
            'success' => false,
            'message' => 'Name and email are required.',
            'response' => []
        ];
    }

    /**
     * SETTINGS TABLE
     */
    $base_prefix   = $wpdb->prefix . 'pulsepoint_';
    $settings_table = $base_prefix . 'settings';

    /**
     * API CONFIG
     */
    $public_key = trim(
        $wpdb->get_var(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key='stropay_pkey' LIMIT 1"
        )
    );

    if (empty($public_key)) {

        return [
            'success' => false,
            'message' => 'Strowallet public key not configured.',
            'response' => []
        ];
    }

    /**
     * API URL
     */
    $api_url = 'https://strowallet.com/api/bitvcard/create-card/';

    /**
     * API PARAMETERS
     */
    $params = [

        'name_on_card'   => $name,
        'card_type'      => $card_type,
        'public_key'     => $public_key,
        'amount'         => $amount,
        'customerEmail'  => $email,
        'developer_code' => 'amaaavl'

    ];

    /**
     * SEND REQUEST
     */
    $response = wp_remote_post($api_url, [

        'headers' => [
            'accept'       => 'application/json',
            'content-type' => 'application/json'
        ],

        'body'    => wp_json_encode($params),
        'timeout' => 40,

    ]);

    /**
     * REQUEST FAILED
     */
    if (is_wp_error($response)) {

        return [
            'success' => false,
            'message' => $response->get_error_message(),
            'response' => []
        ];
    }

    /**
     * DECODE RESPONSE
     */
    $body = json_decode(
        wp_remote_retrieve_body($response),
        true
    );

    /**
     * INVALID RESPONSE
     */
    if (
        empty($body) ||
        !isset($body['success'])
    ) {

        return [
            'success' => false,
            'message' => 'Invalid API response.',
            'response' => $body
        ];
    }

    /**
     * API FAILED
     */
    if ($body['success'] !== true) {

        return [
            'success' => false,
            'message' => $body['message'] ?? 'Card creation failed.',
            'response' => $body
        ];
    }

    /**
     * EXTRACT RESPONSE
     */
    $resp = $body['response'] ?? [];

    /**
     * CARD ID CHECK
     */
    $card_id = sanitize_text_field(
        $resp['card_id'] ?? ''
    );

    if (empty($card_id)) {

        return [
            'success' => false,
            'message' => 'No card ID returned from API.',
            'response' => $body
        ];
    }

    /**
     * SUCCESS RESPONSE
     */
    return [

        'success' => true,

        'message' => $body['message'] ?? 'Card creation successful.',

        'response' => [

            'card_id'     => $resp['card_id'] ?? '',
            'reference'   => $resp['reference'] ?? '',
            'card_status' => $resp['card_status'] ?? 'pending',

            /**
             * EXTRA OPTIONAL DATA
             */
            'raw' => $resp

        ]

    ];
}
?>