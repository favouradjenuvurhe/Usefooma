<?php
/**
 * XIXAPAY Card Provider
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/xixapay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * REQUIRED FUNCTION
 * create_virtual_card()
 */
function create_virtual_card($payload = [])
{
    global $wpdb;

    /**
     * VALIDATE PAYLOAD
     */
    if (empty($payload) || !is_array($payload)) {

        return [
            'success' => false,
            'message' => 'Invalid payload supplied.',
            'response' => []
        ];
    }

    /**
     * EXTRACT PAYLOAD
     */
    $email = trim($payload['email'] ?? '');
    $amount = floatval($payload['amount'] ?? 0);

    /**
     * US CARD ONLY
     */
    $country = 'US';

    /**
     * MINIMUM CHECK
     */
    if ($amount < 3) {

        return [
            'success' => false,
            'message' => 'Minimum amount for US card is $3.',
            'response' => []
        ];
    }

    /**
     * EMAIL CHECK
     */
    if (empty($email)) {

        return [
            'success' => false,
            'message' => 'Email is required.',
            'response' => []
        ];
    }

    /**
     * TABLES
     */
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    $table_users = $base_prefix . 'users';
    $table_name  = $base_prefix . 'settings';

    /**
     * GET CUSTOMER ID
     */
    $customer_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT customerId FROM {$table_users} WHERE email = %s LIMIT 1",
            $email
        )
    );

    /**
     * API CREDENTIALS
     */
    $apiKey = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_pkey' LIMIT 1"
    ));

    $secret = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_skey' LIMIT 1"
    ));

    $bizId = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='strowallet_vip_key' LIMIT 1"
    ));

    /**
     * VALIDATE CREDENTIALS
     */
    if (
        empty($apiKey) ||
        empty($secret) ||
        empty($bizId)
    ) {

        return [
            'success' => false,
            'message' => 'XIXAPAY credentials not configured.',
            'response' => []
        ];
    }

    /**
     * ENDPOINT
     */
    $endpoint = 'https://api.xixapay.com/api/card/create';

    /**
     * PAYLOAD
     */
    $requestBody = [

        'customer_id' => $customer_id,
        'businessId'  => $bizId,
        'country'     => $country,
        'amount'      => $amount

    ];

    /**
     * HEADERS
     */
    $headers = [

        'Authorization' => 'Bearer ' . $secret,
        'api-key'       => $apiKey,
        'Content-Type'  => 'application/json',
        'Accept'        => 'application/json'

    ];

    /**
     * SEND REQUEST
     */
    $response = wp_remote_post($endpoint, [

        'headers' => $headers,
        'body'    => wp_json_encode($requestBody),
        'timeout' => 40

    ]);

    /**
     * REQUEST ERROR
     */
    if (is_wp_error($response)) {

        return [
            'success' => false,
            'message' => $response->get_error_message(),
            'response' => []
        ];
    }

    /**
     * RESPONSE BODY
     */
    $body = json_decode(
        wp_remote_retrieve_body($response),
        true
    );

    /**
     * INVALID RESPONSE
     */
    if (
        empty($body) ||
        !is_array($body)
    ) {

        return [
            'success' => false,
            'message' => 'Invalid API response.',
            'response' => []
        ];
    }

    /**
     * API FAILED
     */
    if (
        !isset($body['status']) ||
        strtolower($body['status']) !== 'success'
    ) {

        return [
            'success' => false,
            'message' => $body['message'] ?? 'Card creation failed.',
            'response' => $body
        ];
    }

    /**
     * EXTRACT RESPONSE
     */
    $resp = [

        'card_id'     => $body['data']['card_id'] ?? '',
        'reference'   => $body['data']['card_id'] ?? '',
        'card_status' => 'success',

        /**
         * EXTRA OPTIONAL DATA
         */
        'raw' => $body['data'] ?? []

    ];

    /**
     * CARD ID CHECK
     */
    $card_id = sanitize_text_field(
        $resp['card_id'] ?? ''
    );

    if (empty($card_id)) {

        return [
            'success' => false,
            'message' => 'No card ID returned from API.',
            'response' => $body
        ];
    }

    /**
     * SUCCESS RESPONSE
     */
    return [

        'success' => true,

        'message' => $body['message'] ?? 'Card creation successful.',

        'response' => [

            'card_id'     => $resp['card_id'] ?? '',
            'reference'   => $resp['reference'] ?? '',
            'card_status' => $resp['card_status'] ?? 'pending',

            /**
             * EXTRA OPTIONAL DATA
             */
            'raw' => $resp

        ]

    ];
}
?>