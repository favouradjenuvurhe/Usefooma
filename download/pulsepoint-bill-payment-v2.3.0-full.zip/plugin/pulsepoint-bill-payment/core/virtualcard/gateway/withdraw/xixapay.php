<?php
/**
 * XIXAPAY Card Withdrawal Provider
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/gateway/withdraw-way/xixapay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * REQUIRED FUNCTION
 * withdraw_virtual_card()
 */
function withdraw_virtual_card($payload = [])
{
    global $wpdb;

    /**
     * VALIDATE PAYLOAD
     */
    if (empty($payload) || !is_array($payload)) {

        return [
            'success' => false,
            'message' => 'Invalid payload supplied.',
            'response' => []
        ];
    }

    /**
     * EXTRACT PAYLOAD
     * Note: withdrawal.php passes the ORIGINAL amount as 'amount' and the
     * post-fee amount as 'final_amount' — the fee is Pulsepoint's own cut,
     * so it's final_amount that should actually be pulled off the card.
     */
    $card_id = trim($payload['card_id'] ?? '');
    $amount  = floatval($payload['final_amount'] ?? $payload['amount'] ?? 0);

    /**
     * CARD ID CHECK
     */
    if (empty($card_id)) {

        return [
            'success' => false,
            'message' => 'Card ID is required.',
            'response' => []
        ];
    }

    /**
     * MINIMUM CHECK
     */
    if ($amount <= 0) {

        return [
            'success' => false,
            'message' => 'Invalid withdrawal amount.',
            'response' => []
        ];
    }

    /**
     * TABLES
     */
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_name  = $base_prefix . 'settings';

    /**
     * API CREDENTIALS
     * Same credentials used by card creation/funding (XIXAPAY treats
     * create, fund, and withdraw as one API surface).
     */
    $apiKey = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_pkey' LIMIT 1"
    ));

    $secret = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_skey' LIMIT 1"
    ));

    $bizId = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='strowallet_vip_key' LIMIT 1"
    ));

    /**
     * VALIDATE CREDENTIALS
     */
    if (
        empty($apiKey) ||
        empty($secret) ||
        empty($bizId)
    ) {

        return [
            'success' => false,
            'message' => 'XIXAPAY credentials not configured.',
            'response' => []
        ];
    }

    /**
     * ENDPOINT
     * POST /api/cards/{card_id}/withdraw
     * Note the plural "cards" — different from the singular "card" used
     * by the create and fund endpoints.
     */
    $endpoint = 'https://api.xixapay.com/api/cards/' . rawurlencode($card_id) . '/withdraw';

    /**
     * PAYLOAD
     */
    $requestBody = [

        'amount'     => $amount,
        'businessId' => $bizId

    ];

    /**
     * HEADERS
     */
    $headers = [

        'Authorization' => 'Bearer ' . $secret,
        'api-key'       => $apiKey,
        'Content-Type'  => 'application/json',
        'Accept'        => 'application/json'

    ];

    /**
     * SEND REQUEST
     */
    $response = wp_remote_post($endpoint, [

        'headers' => $headers,
        'body'    => wp_json_encode($requestBody),
        'timeout' => 40

    ]);

    /**
     * REQUEST ERROR
     */
    if (is_wp_error($response)) {

        return [
            'success' => false,
            'message' => $response->get_error_message(),
            'response' => []
        ];
    }

    /**
     * RESPONSE BODY
     */
    $body = json_decode(
        wp_remote_retrieve_body($response),
        true
    );

    /**
     * INVALID RESPONSE
     */
    if (
        empty($body) ||
        !is_array($body)
    ) {

        return [
            'success' => false,
            'message' => 'Invalid API response.',
            'response' => []
        ];
    }

    /**
     * API FAILED
     */
    if (
        !isset($body['status']) ||
        strtolower($body['status']) !== 'success'
    ) {

        return [
            'success' => false,
            'message' => $body['message'] ?? 'Card withdrawal failed.',
            'response' => $body
        ];
    }

    /**
     * EXTRACT RESPONSE
     * Example success payload:
     * {
     *   "status": "success",
     *   "message": "Withdrawal completed and funds transferred.",
     *   "transaction_id": "wd_123456789",
     *   "data": { "card_id": "...", "amount": 75.00, "currency": "USD", "remaining_balance": 125.00 }
     * }
     */
    $data = $body['data'] ?? [];

    $returned_card_id = sanitize_text_field($data['card_id'] ?? $card_id);

    /**
     * SUCCESS RESPONSE
     * withdrawal.php expects response['reference'] / response['status'] —
     * XIXAPAY does return a top-level transaction_id for withdrawals
     * (unlike its fund endpoint), so we use that directly as the reference.
     */
    return [

        'success' => true,

        'message' => $body['message'] ?? 'Card withdrawal successful.',

        'response' => [

            'card_id'           => $returned_card_id,
            'reference'         => sanitize_text_field($body['transaction_id'] ?? ('XIXAWD-' . $returned_card_id . '-' . time())),
            'status'            => 'success',
            'amount'            => $data['amount'] ?? $amount,
            'currency'          => $data['currency'] ?? null,
            'remaining_balance' => $data['remaining_balance'] ?? null,

            /**
             * EXTRA OPTIONAL DATA
             */
            'raw' => $data

        ]

    ];
}
?>
