<?php
/**
 * XIXAPAY Card Funding Provider
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/gateway/fund-way/xixapay.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * REQUIRED FUNCTION
 * fund_virtual_card()
 */
function fund_virtual_card($payload = [])
{
    global $wpdb;

    /**
     * VALIDATE PAYLOAD
     */
    if (empty($payload) || !is_array($payload)) {

        return [
            'success' => false,
            'message' => 'Invalid payload supplied.',
            'response' => []
        ];
    }

    /**
     * EXTRACT PAYLOAD
     */
    $card_id = trim($payload['card_id'] ?? '');
    $amount  = floatval($payload['amount'] ?? 0);

    /**
     * CARD ID CHECK
     */
    if (empty($card_id)) {

        return [
            'success' => false,
            'message' => 'Card ID is required.',
            'response' => []
        ];
    }

    /**
     * MINIMUM CHECK
     */
    if ($amount <= 0) {

        return [
            'success' => false,
            'message' => 'Invalid funding amount.',
            'response' => []
        ];
    }

    /**
     * TABLES
     */
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_name  = $base_prefix . 'settings';

    /**
     * API CREDENTIALS
     * Same credentials used by card creation (XIXAPAY treats card
     * creation and funding as one API surface).
     */
    $apiKey = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_pkey' LIMIT 1"
    ));

    $secret = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='stropay_skey' LIMIT 1"
    ));

    $bizId = trim($wpdb->get_var(
        "SELECT opt_value FROM {$table_name} WHERE opt_key='strowallet_vip_key' LIMIT 1"
    ));

    /**
     * VALIDATE CREDENTIALS
     */
    if (
        empty($apiKey) ||
        empty($secret) ||
        empty($bizId)
    ) {

        return [
            'success' => false,
            'message' => 'XIXAPAY credentials not configured.',
            'response' => []
        ];
    }

    /**
     * ENDPOINT
     * POST /api/card/{id}/fund
     */
    $endpoint = 'https://api.xixapay.com/api/card/' . rawurlencode($card_id) . '/fund';

    /**
     * PAYLOAD
     */
    $requestBody = [

        'amount'     => $amount,
        'businessId' => $bizId

    ];

    /**
     * HEADERS
     */
    $headers = [

        'Authorization' => 'Bearer ' . $secret,
        'api-key'       => $apiKey,
        'Content-Type'  => 'application/json',
        'Accept'        => 'application/json'

    ];

    /**
     * SEND REQUEST
     */
    $response = wp_remote_post($endpoint, [

        'headers' => $headers,
        'body'    => wp_json_encode($requestBody),
        'timeout' => 40

    ]);

    /**
     * REQUEST ERROR
     */
    if (is_wp_error($response)) {

        return [
            'success' => false,
            'message' => $response->get_error_message(),
            'response' => []
        ];
    }

    /**
     * RESPONSE BODY
     */
    $body = json_decode(
        wp_remote_retrieve_body($response),
        true
    );

    /**
     * INVALID RESPONSE
     */
    if (
        empty($body) ||
        !is_array($body)
    ) {

        return [
            'success' => false,
            'message' => 'Invalid API response.',
            'response' => []
        ];
    }

    /**
     * API FAILED
     */
    if (
        !isset($body['status']) ||
        strtolower($body['status']) !== 'success'
    ) {

        return [
            'success' => false,
            'message' => $body['message'] ?? 'Card funding failed.',
            'response' => $body
        ];
    }

    /**
     * EXTRACT RESPONSE
     * Example success payload:
     * {
     *   "status": "success",
     *   "message": "Funded USD Card Successfully",
     *   "data": { "card_id": "...", "balance": 300.00, "currency": "USD", "status": "active" }
     * }
     */
    $data = $body['data'] ?? [];

    $returned_card_id = sanitize_text_field($data['card_id'] ?? $card_id);

    /**
     * SUCCESS RESPONSE
     * fund-card.php expects response['reference'] / response['status'] —
     * XIXAPAY's fund endpoint doesn't return a dedicated reference, so we
     * build one from the card id + timestamp for trnx bookkeeping.
     */
    return [

        'success' => true,

        'message' => $body['message'] ?? 'Card funded successfully.',

        'response' => [

            'card_id'   => $returned_card_id,
            'reference' => 'XIXAFUND-' . $returned_card_id . '-' . time(),
            'status'    => 'success',
            'balance'   => $data['balance'] ?? null,
            'currency'  => $data['currency'] ?? null,

            /**
             * EXTRA OPTIONAL DATA
             */
            'raw' => $data

        ]

    ];
}
?>
