<?php
/**
 * Multi Provider Virtual Card Withdrawal for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/withdrawal.php
 * Author: Amaaavl
 *
 * UPDATED: Withdrawal now supports multiple providers via
 * /gateway/withdraw-way/{provider}.php files, the same way card creation
 * and card funding do — instead of calling Strowallet's REST API directly.
 *
 * UPDATED: Withdrawn amount now credits the user's NAIRA wallet balance
 * instead of the DOLLAR balance. The final $ amount (after fees) is
 * converted to Naira using the configured rate before crediting.
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_withdraw_card', 'pulsepoint_withdraw_card');
add_action('wp_ajax_nopriv_pulsepoint_withdraw_card', 'pulsepoint_withdraw_card');

/**
 * LOG FUNCTION
 * Guarded with function_exists() so this file can safely load alongside
 * create-card.php / fund-card.php without a fatal "cannot redeclare" error.
 */
if (!function_exists('pulsepoint_withdraw_log')) {
    function pulsepoint_withdraw_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }
}

function pulsepoint_withdraw_card() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';

    pulsepoint_withdraw_log("==== Card Withdrawal Started ====", $log_file);

    /**
     * REQUEST METHOD
     */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    /**
     * SESSION
     */
    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {

        pulsepoint_withdraw_log("Session expired or user not found", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    /**
     * TABLES
     */
    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $user_table     = $base_prefix . 'users';
    $trnx_table     = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    /**
     * USER (locked for update since we're about to credit a balance)
     */
    $wpdb->query('START TRANSACTION');

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$user_table} WHERE id = %d LIMIT 1 FOR UPDATE",
            $user_id
        )
    );

    if (!$user) {

        pulsepoint_withdraw_log("User not found in DB.", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    /**
     * FORM INPUT
     */
    $card_id = sanitize_text_field($_POST['card_id'] ?? '');
    $amount  = floatval($_POST['amount'] ?? 0); // amount is still entered in $

    if (empty($card_id)) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Card ID is required.'
        ]);
    }

    if ($amount < 1) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Minimum withdrawal amount is $1.'
        ]);
    }

    /**
     * GET ACTIVE CARD PROVIDER
     * Same setting used by card creation/funding, so withdrawal always
     * targets whichever provider actually issued the card.
     * Example:
     * virtualcard_type => strowallet
     */
    $payment_gateway = strtolower(trim(
        $wpdb->get_var(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key='virtualcard_type' LIMIT 1"
        )
    ));

    if (empty($payment_gateway)) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Virtual card provider not configured.'
        ]);
    }

    pulsepoint_withdraw_log("Selected Gateway: {$payment_gateway}", $log_file);

    /**
     * INCLUDE PROVIDER FILE
     * Withdrawal gateways live in their own withdraw-way/ subfolder,
     * separate from create-way and fund-way, since each is a distinct
     * API call per provider.
     * Example:
     * /gateway/withdraw-way/strowallet.php
     * /gateway/withdraw-way/xixapay.php
     */
    $api_file = __DIR__ . '/gateway/withdraw/' . strtolower($payment_gateway) . '.php';

    if (!file_exists($api_file)) {

        pulsepoint_withdraw_log("Provider file missing: {$api_file}", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => "Virtual card handler not found for '{$payment_gateway}'"
        ]);
    }

    require_once $api_file;

    /**
     * CHECK PROVIDER FUNCTION
     * Each gateway file must implement withdraw_virtual_card(), the
     * withdrawal counterpart to create_virtual_card() / fund_virtual_card().
     */
    if (!function_exists('withdraw_virtual_card')) {

        pulsepoint_withdraw_log("withdraw_virtual_card() missing in provider file", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'withdraw_virtual_card() not implemented in gateway file'
        ]);
    }

    /**
     * FEES (still calculated in $, same as before)
     */
    $flat_fee = (float) $wpdb->get_var(
        $wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_withdraw_flat_fee')
    );
    if (!$flat_fee) $flat_fee = 1.00;

    $percent_fee = (float) $wpdb->get_var(
        $wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_withdraw_percent_fee')
    );
    if (!$percent_fee) $percent_fee = 1.5;

    $total_fee    = $flat_fee + ($amount * ($percent_fee / 100));
    $final_amount = $amount - $total_fee; // $ actually withdrawn from the card, after fees

    if ($final_amount <= 0) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Withdrawal amount too low after fees.'
        ]);
    }

    /**
     * CONVERSION RATE
     * Uses the same rate_usd as card creation/funding, since we're
     * effectively "selling" dollars for Naira here.
     */
    $rate_usd = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key = 'rate_usd'"
    );

    if (!$rate_usd) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Conversion rate not configured.'
        ]);
    }

    $final_amount_naira = round($final_amount * $rate_usd, 2);

    pulsepoint_withdraw_log(
        "Withdrawal Amount: \${$amount}, Flat Fee: {$flat_fee}, Percent Fee: {$percent_fee}, Final \$: {$final_amount}, Rate: {$rate_usd}, Final Naira Credit: {$final_amount_naira}",
        $log_file
    );

    /**
     * PREPARE PAYLOAD
     */
    $payload = [
        'user_id'      => $user->id,
        'name'         => trim($user->firstname . ' ' . $user->lastname),
        'firstname'    => $user->firstname,
        'lastname'     => $user->lastname,
        'email'        => $user->email,
        'phone'        => $user->phone,
        'card_id'      => $card_id,
        'amount'       => $amount,
        'final_amount' => $final_amount,
        'user'         => $user
    ];

    /**
     * WITHDRAW FROM CARD USING PROVIDER FILE
     */
    $result = withdraw_virtual_card($payload);

    pulsepoint_withdraw_log(
        "Provider Response: " . json_encode($result),
        $log_file
    );

    /**
     * VALIDATE RESPONSE
     */
    if (
        !is_array($result) ||
        !isset($result['success'])
    ) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Invalid provider response.'
        ]);
    }

    /**
     * API FAILED
     */
    if ($result['success'] !== true) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => $result['message'] ?? 'Withdrawal failed.'
        ]);
    }

    $response = $result['response'] ?? [];

    $reference = sanitize_text_field(
        $response['reference'] ??
        uniqid('CARDWD-')
    );

    $withdraw_status = sanitize_text_field(
        $response['status'] ??
        'pending'
    );

    /**
     * CREDIT USER'S NAIRA WALLET
     */
    $new_wallet_balance = $user->wallet + $final_amount_naira;

    $wpdb->update(
        $user_table,
        ['wallet' => $new_wallet_balance],
        ['id' => $user_id]
    );

    /**
     * SAVE TRANSACTION
     */
    $wpdb->insert($trnx_table, [

        'user_id'          => $user_id,
        'details'          => 'Virtual Card Withdrawal',
        'recipient'        => $card_id,
        'amount'           => $final_amount_naira,
        'reference'        => $reference,
        'payment'          => 'card',
        'category'         => 'withdrawal',
        'status'           => $withdraw_status === 'pending' ? 'pending' : 'success',
        'type'             => 'credit',
        'description'      => "Card withdrawal: \${$amount} - fee (\${$total_fee}) = \${$final_amount}, credited as ₦{$final_amount_naira} to Naira wallet at rate ₦{$rate_usd}/\$",
        'gateway_response' => json_encode($result)

    ]);

    $wpdb->query('COMMIT');

    pulsepoint_withdraw_log(
        "Withdrawal Transaction Recorded, User #{$user_id}, Naira Credited: {$final_amount_naira}",
        $log_file
    );

    pulsepoint_withdraw_log(
        "==== Card Withdrawal Completed ====",
        $log_file
    );

    /**
     * FINAL RESPONSE
     */
    wp_send_json([

        'success'     => true,
        'message'     => $result['message'] ?? 'Withdrawal submitted',
        'reference'   => $reference,
        'status'      => $withdraw_status,
        'response'    => $response,
        'provider'    => $payment_gateway,
        'new_balance' => $new_wallet_balance

    ]);
}
?>
