<?php
/**
 * Multi Provider Virtual Card Funding for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/fund-card.php
 * Author: Amaaavl
 *
 * UPDATED: Card funding now supports multiple providers via /gateway/{provider}.php
 * files, the same way create-card.php does — instead of calling Strowallet's
 * REST API directly.
 *
 * UPDATED: Funding amount now deducts from the user's NAIRA wallet balance
 * instead of the DOLLAR balance. The amount (entered in $) is converted to
 * Naira using the configured rate before deduction, same as card creation.
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_fund_card', 'pulsepoint_fund_card');
add_action('wp_ajax_nopriv_pulsepoint_fund_card', 'pulsepoint_fund_card');

/**
 * LOG FUNCTION
 * Guarded with function_exists() because create-card.php declares a
 * function with the same name — without the guard, loading both files
 * in the same request causes a fatal "cannot redeclare" error.
 */
if (!function_exists('pulsepoint_card_log')) {
    function pulsepoint_card_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }
}

function pulsepoint_fund_card() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';

    pulsepoint_card_log("==== Card Funding Started ====", $log_file);

    /**
     * REQUEST METHOD
     */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    /**
     * SESSION
     */
    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {

        pulsepoint_card_log("Session expired or user not found", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    /**
     * TABLES
     */
    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $user_table     = $base_prefix . 'users';
    $trnx_table     = $base_prefix . 'trnx';
    $settings_table = $base_prefix . 'settings';

    /**
     * USER (locked for update since we're about to deduct a balance)
     */
    $wpdb->query('START TRANSACTION');

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$user_table} WHERE id = %d LIMIT 1 FOR UPDATE",
            $user_id
        )
    );

    if (!$user) {

        pulsepoint_card_log("User not found in DB.", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    /**
     * FORM INPUT
     */
    $card_id = sanitize_text_field($_POST['card_id'] ?? '');
    $amount  = floatval($_POST['amount'] ?? 0); // amount is still entered in $

    if (empty($card_id)) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Card ID is required.'
        ]);
    }

    if ($amount <= 0) {
        $wpdb->query('ROLLBACK');
        wp_send_json([
            'success' => false,
            'message' => 'Invalid amount.'
        ]);
    }

    /**
     * GET ACTIVE CARD PROVIDER
     * Same setting used by card creation, so funding always targets
     * whichever provider actually issued the card.
     * Example:
     * virtualcard_type => strowallet
     */
    $payment_gateway = strtolower(trim(
        $wpdb->get_var(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key='virtualcard_type' LIMIT 1"
        )
    ));

    if (empty($payment_gateway)) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Virtual card provider not configured.'
        ]);
    }

    pulsepoint_card_log("Selected Gateway: {$payment_gateway}", $log_file);

    /**
     * INCLUDE PROVIDER FILE
     * Funding gateways live in a separate fund-way/ subfolder from the
     * card-creation gateways, since a provider's fund logic is a distinct
     * API call from its create logic.
     * Example:
     * /gateway/fund-way/strowallet.php
     * /gateway/fund-way/xixapay.php
     */
    $api_file = __DIR__ . '/gateway/fund/' . strtolower($payment_gateway) . '.php';

    if (!file_exists($api_file)) {

        pulsepoint_card_log("Provider file missing: {$api_file}", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => "Virtual card handler not found for '{$payment_gateway}'"
        ]);
    }

    require_once $api_file;

    /**
     * CHECK PROVIDER FUNCTION
     * Each gateway file must implement fund_virtual_card(), the funding
     * counterpart to create_virtual_card().
     */
    if (!function_exists('fund_virtual_card')) {

        pulsepoint_card_log("fund_virtual_card() missing in provider file", $log_file);

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'fund_virtual_card() not implemented in gateway file'
        ]);
    }

    /**
     * FEES (still calculated in $, same as before)
     */
    $flat_fee = (float) $wpdb->get_var(
        $wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_funding_flat_fee')
    );
    if (!$flat_fee) $flat_fee = 1.90;

    $percent_fee = (float) $wpdb->get_var(
        $wpdb->prepare("SELECT opt_value FROM {$settings_table} WHERE opt_key = %s", 'card_funding_percent_fee')
    );
    if (!$percent_fee) $percent_fee = 1.9;

    $total_fee = $flat_fee + ($amount * ($percent_fee / 100));

    $total_deduction_usd = $amount + $total_fee;

    /**
     * CONVERT $ DEDUCTION TO NAIRA
     * Uses the same rate_usd used by card creation, since we're
     * effectively "buying" dollars with Naira here too.
     */
    $rate_usd = (float) $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key = 'rate_usd'"
    );

    if (!$rate_usd) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Conversion rate not configured.'
        ]);
    }

    $total_deduction_naira = round($total_deduction_usd * $rate_usd, 2);

    pulsepoint_card_log(
        "Funding Amount: \${$amount}, Flat Fee: {$flat_fee}, Percent Fee: {$percent_fee}, Total \$ Deduction: {$total_deduction_usd}, Rate: {$rate_usd}, Total Naira Deduction: {$total_deduction_naira}",
        $log_file
    );

    /**
     * CHECK NAIRA WALLET BALANCE
     */
    if ($user->wallet < $total_deduction_naira) {

        pulsepoint_card_log(
            "Insufficient naira wallet balance for user #{$user_id}. Has: {$user->wallet}, Needs: {$total_deduction_naira}",
            $log_file
        );

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Insufficient wallet balance.'
        ]);
    }

    /**
     * PREPARE PAYLOAD
     */
    $payload = [
        'user_id'   => $user->id,
        'name'      => trim($user->firstname . ' ' . $user->lastname),
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'card_id'   => $card_id,
        'amount'    => $amount,
        'user'      => $user
    ];

    /**
     * FUND CARD USING PROVIDER FILE
     */
    $result = fund_virtual_card($payload);

    pulsepoint_card_log(
        "Provider Response: " . json_encode($result),
        $log_file
    );

    /**
     * VALIDATE RESPONSE
     */
    if (
        !is_array($result) ||
        !isset($result['success'])
    ) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => 'Invalid provider response.'
        ]);
    }

    /**
     * API FAILED
     */
    if ($result['success'] !== true) {

        $wpdb->query('ROLLBACK');

        wp_send_json([
            'success' => false,
            'message' => $result['message'] ?? 'Card funding failed.'
        ]);
    }

    $response = $result['response'] ?? [];

    $reference = sanitize_text_field(
        $response['reference'] ??
        $response['ref'] ??
        uniqid('CARDFUND-')
    );

    $fund_status = sanitize_text_field(
        $response['status'] ??
        'pending'
    );

    /**
     * DEDUCT USER'S NAIRA WALLET
     */
    $new_wallet_balance = $user->wallet - $total_deduction_naira;

    $wpdb->update(
        $user_table,
        ['wallet' => $new_wallet_balance],
        ['id' => $user_id]
    );

    /**
     * SAVE TRANSACTION
     */
    $wpdb->insert($trnx_table, [

        'user_id'          => $user_id,
        'details'          => 'Virtual Card Funding',
        'recipient'        => $card_id,
        'amount'           => $total_deduction_naira,
        'reference'        => $reference,
        'payment'          => 'wallet',
        'category'         => 'funding',
        'status'           => ($fund_status === 'pending' || $fund_status === true) ? 'pending' : 'success',
        'type'             => 'debit',
        'description'      => "Card funding: \${$amount} + fee (\${$total_fee}) deducted as ₦{$total_deduction_naira} from Naira wallet at rate ₦{$rate_usd}/\$",
        'gateway_response' => json_encode($result)

    ]);

    $wpdb->query('COMMIT');

    pulsepoint_card_log(
        "Funding Transaction Recorded, User #{$user_id}, Naira Deducted: {$total_deduction_naira}",
        $log_file
    );

    pulsepoint_card_log(
        "==== Card Funding Completed ====",
        $log_file
    );

    /**
     * FINAL RESPONSE
     */
    wp_send_json([

        'success'     => true,
        'message'     => $result['message'] ?? 'Funding in progress',
        'response'    => $response,
        'provider'    => $payment_gateway,
        'new_balance' => $new_wallet_balance

    ]);
}
?>
