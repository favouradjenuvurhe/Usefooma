<?php
/**
 * Multi Provider Freeze / Unfreeze Virtual Card for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/freeze.php
 * Author: Amaaavl
 *
 * UPDATED: Card status changes now route through /gateway/status/{provider}.php
 * files, the same way create/fund/withdraw do — instead of calling
 * Strowallet's REST API directly.
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_pulsepoint_card_action', 'pulsepoint_card_action');
add_action('wp_ajax_nopriv_pulsepoint_card_action', 'pulsepoint_card_action');

/**
 * LOG FUNCTION
 * Guarded with function_exists() so this file can safely load alongside
 * create-card.php / fund-card.php / withdrawal.php without a fatal
 * "cannot redeclare" error.
 */
if (!function_exists('pulsepoint_freeze_log')) {
    function pulsepoint_freeze_log($message, $file) {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($file, "[$timestamp] $message\n", FILE_APPEND);
    }
}

function pulsepoint_card_action() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    $log_file = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/log.txt';

    pulsepoint_freeze_log("==== Card Freeze/Unfreeze Request Started ====", $log_file);

    /**
     * REQUEST METHOD
     */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    /**
     * SESSION
     */
    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {

        pulsepoint_freeze_log("Session expired or user not logged in", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    /**
     * TABLES
     */
    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $user_table     = $base_prefix . 'users';
    $settings_table = $base_prefix . 'settings';

    /**
     * USER + CARD
     */
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, cardid FROM {$user_table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user || empty($user->cardid)) {

        pulsepoint_freeze_log("User or Card ID not found", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'No card found for this user.'
        ]);
    }

    /**
     * FORM INPUT
     */
    $card_id = sanitize_text_field($_POST['card_id'] ?? $user->cardid);
    $action  = sanitize_text_field($_POST['action_type'] ?? 'freeze'); // 'freeze', 'unfreeze', or 'block'

    /**
     * VALIDATE ACTION
     */
    if (!in_array($action, ['freeze', 'unfreeze', 'block'])) {

        wp_send_json([
            'success' => false,
            'message' => 'Invalid action type.'
        ]);
    }

    /**
     * GET ACTIVE CARD PROVIDER
     * Same setting used by create/fund/withdraw, so status changes always
     * target whichever provider actually issued the card.
     * Example:
     * virtualcard_type => strowallet
     */
    $payment_gateway = strtolower(trim(
        $wpdb->get_var(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key='virtualcard_type' LIMIT 1"
        )
    ));

    if (empty($payment_gateway)) {

        wp_send_json([
            'success' => false,
            'message' => 'Virtual card provider not configured.'
        ]);
    }

    pulsepoint_freeze_log("Selected Gateway: {$payment_gateway}", $log_file);

    /**
     * INCLUDE PROVIDER FILE
     * Status gateways live in their own status/ subfolder, separate from
     * create-way, fund-way, and withdraw-way.
     * Example:
     * /gateway/status/strowallet.php
     * /gateway/status/xixapay.php
     */
    $api_file = __DIR__ . '/gateway/status/' . strtolower($payment_gateway) . '.php';

    if (!file_exists($api_file)) {

        pulsepoint_freeze_log("Provider file missing: {$api_file}", $log_file);

        wp_send_json([
            'success' => false,
            'message' => "Virtual card handler not found for '{$payment_gateway}'"
        ]);
    }

    require_once $api_file;

    /**
     * CHECK PROVIDER FUNCTION
     * Each gateway file must implement update_card_status(), the status
     * counterpart to create_virtual_card() / fund_virtual_card() /
     * withdraw_virtual_card().
     */
    if (!function_exists('update_card_status')) {

        pulsepoint_freeze_log("update_card_status() missing in provider file", $log_file);

        wp_send_json([
            'success' => false,
            'message' => 'update_card_status() not implemented in gateway file'
        ]);
    }

    /**
     * PREPARE PAYLOAD
     */
    $payload = [
        'user_id' => $user->id,
        'card_id' => $card_id,
        'action'  => $action
    ];

    /**
     * UPDATE STATUS USING PROVIDER FILE
     */
    $result = update_card_status($payload);

    pulsepoint_freeze_log(
        "Provider Response: " . json_encode($result),
        $log_file
    );

    /**
     * VALIDATE RESPONSE
     */
    if (
        !is_array($result) ||
        !isset($result['success'])
    ) {

        wp_send_json([
            'success' => false,
            'message' => 'Invalid provider response.'
        ]);
    }

    /**
     * RESPOND
     */
    if ($result['success'] === true) {

        pulsepoint_freeze_log("Card {$action} successful for {$card_id}", $log_file);

        wp_send_json([
            'success'  => true,
            'message'  => $result['message'] ?? (ucfirst($action) . ' successful.'),
            'provider' => $payment_gateway,
            'response' => $result['response'] ?? []
        ]);

    } else {

        pulsepoint_freeze_log("Card {$action} failed: " . ($result['message'] ?? 'Unknown error'), $log_file);

        wp_send_json([
            'success'  => false,
            'message'  => $result['message'] ?? "Failed to {$action} card.",
            'provider' => $payment_gateway,
            'response' => $result['response'] ?? []
        ]);
    }
}
?>
