<?php    
/**    
 * Strowallet Bank Transfer Handler    
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/bank/strowallet.php    
 * Author: Amaaavl    
 */    
    
if (!defined('ABSPATH')) exit;    
    
function send_bank_transfer($bank_code, $account_number, $account_name, $amount, $narration, $reference, $token, $transaction_id) {    
    global $wpdb;    
    $base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
    /** -----------------------------------------    
     * 1. ALWAYS FETCH STROWALLET TOKEN FROM DB    
     * ----------------------------------------- */    
    $db_token = $wpdb->get_var(    
        $wpdb->prepare(    
            "SELECT opt_value FROM {$base_prefix}settings WHERE opt_key = %s LIMIT 1",    
            'bank_token'    
        )    
    );    
    
    // override empty or invalid token    
    if (empty($token) || $token === null) {    
        $token = $db_token;    
    }    
    
    /** fallback narration */    
    if (empty($narration)) {    
        $narration = "Wallet Transfer - $reference";    
    }    
    
    /** -----------------------------------------    
     * LOGGING SETUP    
     * ----------------------------------------- */    
    $log_dir = WP_CONTENT_DIR . '/plugins/pulsepoint-bill-payment/logs/';    
    if (!file_exists($log_dir)) {    
        wp_mkdir_p($log_dir);    
    }    
    
    $log_file = $log_dir . 'strowallet_log.txt';    
    $timestamp = date('Y-m-d H:i:s');    
    
    $write_log = function($text) use ($log_file, $timestamp, $transaction_id) {    
        $line = "[$timestamp] (Transaction: $transaction_id) $text" . PHP_EOL;    
        file_put_contents($log_file, $line, FILE_APPEND);    
    };    
    
    /** RAW INPUT LOG AFTER FIX */    
    $write_log("INPUT AFTER FIX: " . json_encode([    
        'bank_code'      => $bank_code,    
        'account_number' => $account_number,    
        'amount'         => $amount,    
        'narration'      => $narration,    
        'reference'      => $reference,    
        'account_name'   => $account_name,    
        'token_from_db'  => $db_token,    
        'final_token'    => $token    
    ]));    
    
    /** -----------------------------------------    
     * 2. BUILD JSON BODY    
     * ----------------------------------------- */    
    $payload = [    
        'public_key'             => $token,    
        'amount'                 => intval($amount),    
        'bank_code'              => $bank_code,    
        'account_number'         => $account_number,    
        'narration'              => $narration,    
        'name_enquiry_reference' => $account_name   // ✅ FIXED: Use account_name    
    ];    
    
    $write_log("POST BODY: " . json_encode($payload));    
    
    /** -----------------------------------------    
     * 3. SEND POST REQUEST    
     * ----------------------------------------- */    
    $api_url = "https://strowallet.com/api/banks/request/";    
    
    $ch = curl_init($api_url);    
    curl_setopt($ch, CURLOPT_POST, true);    
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    
    curl_setopt($ch, CURLOPT_HTTPHEADER, [    
        'Accept: application/json',    
        'Content-Type: application/json'    
    ]);    
    
    $response = curl_exec($ch);    
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);    
    
    $write_log("HTTP CODE: $httpcode");    
    $write_log("RAW RESPONSE: $response");    
    
    if (curl_errno($ch)) {    
        $err = curl_error($ch);    
        $write_log("cURL ERROR: $err");    
        curl_close($ch);    
        return [    
            'success' => false,    
            'message' => "cURL Error: $err",    
            'details' => []    
        ];    
    }    
    
    curl_close($ch);    
    
    /** -----------------------------------------    
     * 4. PARSE RESPONSE    
     * ----------------------------------------- */    
    $data = json_decode($response, true);    
    
    if (!$data) {    
        $write_log("INVALID JSON RESPONSE");    
        return [    
            'success' => false,    
            'message' => "Invalid response from Strowallet",    
            'details' => ['raw_response' => $response]    
        ];    
    }    
    
    $success = $data['success'] ?? false;    
    $message = $data['message'] ?? 'No message from API';    
    $details = $data['data'] ?? [];    
    
    $write_log("PARSED SUCCESS: " . json_encode($success));    
    $write_log("PARSED MESSAGE: $message");    
    $write_log("PARSED DETAILS: " . json_encode($details));    
    
    return [    
        'success' => $success,    
        'message' => $message,    
        'details' => $details    
    ];    
}