<?php
/**
 * Pulsepoint Wallet-to-Wallet Transfer
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/wallet/wallet2.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// Hook for AJAX requests
add_action('wp_ajax_nopriv_pulsepoint_wallet_transfer', 'pulsepoint_wallet_transfer');
add_action('wp_ajax_pulsepoint_wallet_transfer', 'pulsepoint_wallet_transfer');

function pulsepoint_wallet_transfer() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx  = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Rate limiter: 1 request per 15 seconds
    $now = time();
    if (isset($_SESSION['last_wallet_request'][$user_id]) && ($now - $_SESSION['last_wallet_request'][$user_id]) < 15) {
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);
    }
    $_SESSION['last_wallet_request'][$user_id] = $now;

    // Fetch sender
    $sender = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id));
    if (!$sender || $sender->status != 1 || $sender->close_account == 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or restricted.']);
    }

    if ($sender->statuskyc != 1) {
        wp_send_json(['success' => false, 'message' => 'Complete KYC to continue.']);
    }

    // Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    // Sanitize inputs
    $receiver_phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $amount         = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
    $narration      = isset($_POST['narration']) ? sanitize_text_field($_POST['narration']) : '';
    $receiver_phone = ltrim($receiver_phone, '0');

    $description = !empty($narration) ? $narration : 'Wallet Transfer';
    $reference   = 'PSW2W' . mt_rand(1000000, 9999999);

    if (empty($receiver_phone) || $amount <= 0) {
        wp_send_json(['success' => false, 'message' => 'Phone number and amount required.']);
    }

    // Fetch receiver
    $receiver = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE phone=%s", $receiver_phone));
    if (!$receiver || $receiver->status != 1) {
        wp_send_json(['success' => false, 'message' => 'Receiver not found or inactive.']);
    }

    // Anti-fraud: same user, similar phone/email
    if ($receiver->id == $sender->id ||
        strtolower($receiver->email) === strtolower($sender->email) ||
        $receiver->phone === $sender->phone
    ) {
        wp_send_json(['success' => false, 'message' => 'Transfer blocked due to suspicious similarity.']);
    }

    // Daily limit check
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');
    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx} WHERE user_id=%d AND date BETWEEN %s AND %s AND category='wallet' AND type='debit'",
        $user_id, $today_start, $today_end
    )) ?: 0;

    $account_limit = $sender->account_limit ?: 100000;
    if (($spent_today + $amount) > $account_limit) {
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$account_limit} exceeded"]);
    }

    // Wallet balance check
    if ($api_mode === 'live' && $sender->wallet < $amount) {
        wp_send_json(['success' => false, 'message' => 'Insufficient wallet balance.']);
    }

    // Sandbox mode
    if ($api_mode === 'sandbox') {
        wp_send_json(['success' => true, 'message' => 'Wallet Transfer Successful (Sandbox)', 'reference' => $reference]);
    }

    /** -----------------------------
     * Record sender transaction as pending
     * ----------------------------- */
    $wpdb->insert($table_trnx, [
        'user_id'     => $sender->id,
        'details'     => json_encode([
            'receiver_phone' => $receiver_phone,
            'receiver_id'    => $receiver->id
        ]),
        'recipient'   => $receiver_phone,
        'amount'      => $amount,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'wallet',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description
    ], ['%d','%s','%s','%f','%s','%s','%s','%s','%s','%s','%s']);

    $trnx_id_sender = $wpdb->insert_id;

    /** -----------------------------
     * Record receiver transaction as pending
     * ----------------------------- */
    $wpdb->insert($table_trnx, [
        'user_id'     => $receiver->id,
        'details'     => json_encode([
            'sender_phone' => $sender->phone,
            'sender_id'    => $sender->id
        ]),
        'recipient'   => $sender->phone,
        'amount'      => $amount,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'wallet',
        'status'      => 'pending',
        'type'        => 'credit',
        'session'     => session_id(),
        'description' => $description
    ], ['%d','%s','%s','%f','%s','%s','%s','%s','%s','%s','%s']);

    $trnx_id_receiver = $wpdb->insert_id;

    // Execute wallet debit/credit
    $wpdb->query('START TRANSACTION');

    try {
        // Deduct sender wallet
        $wpdb->query($wpdb->prepare("UPDATE {$table_users} SET wallet=wallet-%f WHERE id=%d", $amount, $sender->id));

        // Credit receiver wallet
        $wpdb->query($wpdb->prepare("UPDATE {$table_users} SET wallet=wallet+%f WHERE id=%d", $amount, $receiver->id));

        // Update both transactions
        $wpdb->update($table_trnx, ['status'=>'success','updated_at'=>current_time('mysql')], ['id'=>$trnx_id_sender], ['%s','%s'], ['%d']);
        $wpdb->update($table_trnx, ['status'=>'success','updated_at'=>current_time('mysql')], ['id'=>$trnx_id_receiver], ['%s','%s'], ['%d']);

        $wpdb->query('COMMIT');

        $new_wallet = $sender->wallet - $amount;

        wp_send_json([
            'success'    => true,
            'message'    => 'Wallet transfer successful',
            'new_wallet' => $new_wallet,
            'reference'  => $reference,
            'receiver'   => $receiver_phone
        ]);

    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');

        // Mark transactions as failed
        $wpdb->update($table_trnx, ['status'=>'failed','updated_at'=>current_time('mysql')], ['id'=>$trnx_id_sender], ['%s','%s'], ['%d']);
        $wpdb->update($table_trnx, ['status'=>'failed','updated_at'=>current_time('mysql')], ['id'=>$trnx_id_receiver], ['%s','%s'], ['%d']);

        wp_send_json([
            'success' => false,
            'message' => 'Wallet transfer failed'
        ]);
    }
}