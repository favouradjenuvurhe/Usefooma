<?php
/**
 * Bank Account Verification - Pulsepoint Plugin
 * Path: core/transfer/verification.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// Register AJAX action for logged-in users
add_action('wp_ajax_pulsepoint_resolve_account', 'pulsepoint_resolve_account');

function pulsepoint_resolve_account() {

    // Get parameters from query string
    $bank_code = sanitize_text_field($_GET['bank_code'] ?? '');
    $account_number = sanitize_text_field($_GET['account_number'] ?? '');

    if (!$bank_code || !$account_number) {
        wp_send_json([
            'success' => false,
            'message' => 'Bank code and account number are required.'
        ]);
        wp_die();
    }

    // External API endpoint (STROWALLET GET REQUEST)
    $api_url = "https://strowallet.com/api/banks/get-customer-name/?public_key=D659RDO3O492PDX6H1ODXTTZWNZGZK&bank_code={$bank_code}&account_number={$account_number}";

    // Initialize cURL
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['accept: application/json']);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

    // Execute request
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Show EXACT raw error if network fails
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        wp_send_json([
            'success' => false,
            'message' => $error_msg
        ]);
        wp_die();
    }

    curl_close($ch);

    // Decode API response
    $result = json_decode($response, true);

    // If API sent invalid JSON OR non-200 code → return EXACT API response
    if (!$result || $http_code !== 200) {
        wp_send_json([
            'success' => false,
            'message' => $response   // return EXACT API text
        ]);
        wp_die();
    }

    // SUCCESS (return EXACT SAME FORMAT YOU USED BEFORE)
    if (isset($result['success']) && $result['success'] === true) {
        wp_send_json([
            'success' => true,
            'account_name' => $result['data']['account_name'] ?? 'Unknown'
        ]);
    } else {
        // FAILED → return EXACT API message
        wp_send_json([
            'success' => false,
            'message' => $result['message'] ?? $response
        ]);
    }

    wp_die();
}