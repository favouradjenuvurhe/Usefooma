<?php
/**
 * Pulsepoint SMM (Boost) Purchase Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/smm/pulsepoint.php
 * Author: Amaaavl
 *
 * Same shape as core/betting/pulsepoint.php and core/education/pulsepoint.php:
 * user picks a service (synced from the provider's catalog into
 * `pulsepoint_smm_services`), enters a link/username and quantity, and
 * it's charged from wallet. A provider file (core/smm/{provider}.php
 * exposing send_smm()) is dynamically loaded, same convention as
 * airtime/data/education/betting.
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_smm_purchase', 'pulsepoint_smm_purchase');
add_action('wp_ajax_pulsepoint_smm_purchase', 'pulsepoint_smm_purchase');

function pulsepoint_smm_purchase() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in']);
    }

    $user_id     = $_SESSION['pulsepoint_user']['id'];
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_users = "{$base_prefix}users";
    $table_trnx  = "{$base_prefix}trnx";
    $table_smm   = "{$base_prefix}smm_services";
    $table_orders= "{$base_prefix}smm_orders";

    /** RATE LIMIT **/
    $now = time();
    if (isset($_SESSION['last_smm_request'][$user_id]) && ($now - $_SESSION['last_smm_request'][$user_id]) < 10) {
        wp_send_json(['success' => false, 'message' => 'Please wait a few seconds before trying again']);
    }
    $_SESSION['last_smm_request'][$user_id] = $now;

    /** FETCH USER **/
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $user_id));

    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active']);
    }

    /** LOAD SETTINGS **/
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';
    $markup           = (float) ($settings['smm_markup'] ?? 0);
    $provider         = strtolower(trim($settings['smm_api_provider'] ?? 'owlet'));

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);
    }

    /** SANITIZE INPUT **/
    $service_row_id = intval($_POST['service_id'] ?? 0);
    $link           = esc_url_raw(trim($_POST['link'] ?? ''));
    $quantity       = intval($_POST['quantity'] ?? 0);
    $reference      = sanitize_text_field($_POST['reference'] ?? '');

    if (!$service_row_id || empty($link) || $quantity <= 0) {
        wp_send_json(['success' => false, 'message' => 'Service, link, and quantity are required']);
    }

    /** GET SERVICE **/
    $service = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_smm} WHERE id=%d AND status='active'",
        $service_row_id
    ));

    if (!$service) {
        wp_send_json(['success' => false, 'message' => 'Invalid or unavailable service']);
    }

    if ($quantity < (int) $service->min || ($service->max > 0 && $quantity > (int) $service->max)) {
        wp_send_json(['success' => false, 'message' => "Quantity must be between {$service->min} and {$service->max}"]);
    }

    /** COMPUTE COST: Owlet rates are per 1000; NCWallet rates are per quantity. **/
    $provider_rate = (float) $service->rate;
    $base_cost = ($provider === 'ncwallet')
        ? ($provider_rate * $quantity)
        : (($provider_rate / 1000) * $quantity);
    $amount     = $base_cost + ($base_cost * ($markup / 100));
    $amount     = round($amount, 2);

    if (empty($reference)) {
        $reference = 'PSNG' . mt_rand(10000, 99999) . 'S';
    }

    $description = strtoupper($service->category) . " - {$service->name} ({$quantity})";

    /** DAILY LIMIT **/
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');

    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx}
        WHERE user_id=%d AND date BETWEEN %s AND %s AND type='debit'",
        $user_id, $today_start, $today_end
    ));

    $spent_today = $spent_today ?: 0;
    $limit = $user->account_limit ?: 5000;

    if (($spent_today + $amount) > $limit) {
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$limit} reached"]);
    }

    /** WALLET CHECK **/
    if ($api_mode === 'live' && $user->wallet < $amount) {
        wp_send_json(['success' => false, 'message' => 'Insufficient balance']);
    }

    if ($api_mode === 'off') {
        wp_send_json(['success' => false, 'message' => 'Service not available']);
    }

    if ($api_mode === 'sandbox') {
        wp_send_json(['success' => true, 'message' => 'Boost order placed (Sandbox Mode)']);
    }

    /** LOAD PROVIDER FILE **/
    $safe_provider = preg_replace('/[^a-z0-9]/i', '', $provider);
    $api_file = __DIR__ . "/{$safe_provider}.php";

    if (!file_exists($api_file)) {
        wp_send_json(['success' => false, 'message' => 'Provider file missing. Ask admin to add core/smm/' . $safe_provider . '.php']);
    }

    require_once $api_file;

    if (!function_exists('send_smm')) {
        wp_send_json(['success' => false, 'message' => 'send_smm() missing']);
    }

    /** INSERT PENDING ORDER **/
    $wpdb->insert($table_orders, [
        'user_id'        => $user_id,
        'smm_service_id' => $service->id,
        'provider'       => $provider,
        'reference'      => $reference,
        'category'       => $service->category,
        'service_name'   => $service->name,
        'link'           => $link,
        'quantity'       => $quantity,
        'amount'         => $amount,
        'status'         => 'pending',
    ]);

    $order_row_id = $wpdb->insert_id;

    /** INSERT LEDGER (pending) **/
    $wpdb->insert($table_trnx, [
        'user_id'     => $user_id,
        'details'     => json_encode(['provider' => $provider, 'service' => $service->name, 'link' => $link]),
        'recipient'   => $link,
        'amount'      => $amount,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'others',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description,
    ]);

    $trnx_id = $wpdb->insert_id;

    /** CALL PROVIDER **/
    try {
        $api_response = send_smm($provider, $service->external_id, $link, $quantity, $reference, $order_row_id, (string) $service->category);
    } catch (Exception $e) {
        $api_response = ['success' => false, 'message' => 'Provider Error'];
    }

    $status = (!empty($api_response['success'])) ? 'success' : 'failed';

    /** UPDATE TRANSACTION + ORDER **/
    $wpdb->update($table_trnx, [
        'status'           => $status,
        'gateway_response' => json_encode($api_response),
        'updated_at'       => current_time('mysql'),
    ], ['id' => $trnx_id]);

    $wpdb->update($table_orders, [
        'status'             => $status,
        'provider_order_id'  => $api_response['provider_order_id'] ?? null,
        'order_status'       => $status === 'success' ? 'pending' : 'failed',
    ], ['id' => $order_row_id]);

    /** DEDUCT WALLET **/
    $new_wallet = $user->wallet;

    if ($status === 'success' && $api_mode === 'live') {
        $new_wallet -= $amount;
        $wpdb->update($table_users, ['wallet' => $new_wallet], ['id' => $user_id]);

        if (function_exists('pulsepoint_save_beneficiary')) {
            pulsepoint_save_beneficiary($user_id, 'smm', $link, $link, $service->category, ['service_id' => $service->id]);
        }
    }

    /** EMAIL NOTIFICATION **/
    if ($status === 'success' && function_exists('pulsepoint_send_transaction_email')) {
        pulsepoint_send_transaction_email(
            $user->email,
            'Boost Order Placed',
            [
                'status_label' => 'SUCCESS',
                'status_color' => '#22c55e',
                'heading'      => 'Boost Order Placed',
                'firstname'    => $user->firstname,
                'message'      => 'Your order has been placed successfully.',
                'details'      => [
                    'Service'   => $service->name,
                    'Link'      => $link,
                    'Quantity'  => $quantity,
                    'Amount'    => '₦' . number_format($amount, 2),
                    'Reference' => $reference,
                ],
            ]
        );
    }

    wp_send_json([
        'success'    => $status === 'success',
        'message'    => $api_response['message'] ?? 'Order Completed',
        'reference'  => $reference,
        'new_wallet' => $new_wallet,
    ]);
}
