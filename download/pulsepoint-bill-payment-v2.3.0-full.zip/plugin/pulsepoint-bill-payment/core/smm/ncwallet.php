<?php
/**
 * NCWallet SMM Provider
 * File: core/smm/ncwallet.php
 * Author: Amaaavl
 *
 * GET  https://ncwallet.africa/api/v1/smm/get-services — service list
 * POST https://ncwallet.africa/api/v1/smm/order       — place order
 * POST https://ncwallet.africa/api/v1/smm/status      — order status
 *
 * Headers: Accept, Content-Type, trnx_pin, Authorization
 * Same pin:token settings convention as core/betting/ncwallet.php —
 * the `smm_token` setting is stored as "pin:token".
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_smm_ncwallet_settings')) {
    function pulsepoint_smm_ncwallet_settings(): array {

        global $wpdb;
        $base_prefix = $wpdb->prefix . 'pulsepoint_';

        $rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings WHERE opt_key IN ('smm_api','smm_token')", OBJECT_K);

        $base_url = $rows['smm_api']->opt_value ?? 'https://ncwallet.africa/api/v1';
        $token    = $rows['smm_token']->opt_value ?? '';

        $parts    = explode(':', $token);
        $trnx_pin = trim($parts[0] ?? '');
        $auth     = trim($parts[1] ?? '');

        return ['base_url' => rtrim($base_url, '/'), 'trnx_pin' => $trnx_pin, 'auth' => $auth];
    }
}

if (!function_exists('pulsepoint_smm_ncwallet_request')) {
    function pulsepoint_smm_ncwallet_request(string $method, string $url, array $payload = []): ?array {

        $creds = pulsepoint_smm_ncwallet_settings();

        if (!$creds['auth']) return null;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $headers = [
            "Accept: application/json",
            "Content-Type: application/json",
            "trnx_pin: {$creds['trnx_pin']}",
            "Authorization: {$creds['auth']}",
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        if (strtoupper($method) === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            curl_close($ch);
            return null;
        }

        curl_close($ch);

        $decoded = json_decode($response, true);
        return is_array($decoded) ? $decoded : null;
    }
}

/**
 * Fetch the full service catalog — used by the admin "Sync Services" action.
 */
if (!function_exists('pulsepoint_smm_ncwallet_fetch_services')) {
    function pulsepoint_smm_ncwallet_fetch_services(): array {

        $creds = pulsepoint_smm_ncwallet_settings();
        $result = pulsepoint_smm_ncwallet_request('GET', $creds['base_url'] . '/smm/get-services');

        if (!is_array($result) || strtolower($result['status'] ?? '') !== 'success' || empty($result['data'])) {
            return [];
        }

        $services = [];

        foreach ($result['data'] as $row) {
            if (empty($row['id'])) continue;

            $services[] = [
                'external_id' => (string) $row['id'],
                'category'    => $row['category'] ?? 'General',
                'name'        => $row['name'] ?? ('Service ' . $row['id']),
                'rate'        => (float) ($row['rate'] ?? 0),
                'min'         => (int) ($row['minimum'] ?? 1),
                'max'         => (int) ($row['maximum'] ?? 0),
                'refill'      => stripos((string) ($row['refill'] ?? ''), 'not') === false && !empty($row['refill']),
                'cancel'      => false,
            ];
        }

        return $services;
    }
}

/**
 * Place an order. Called by core/smm/pulsepoint.php.
 */
function send_smm(string $provider, string $external_service_id, string $link, int $quantity, string $reference, int $order_row_id, string $category = '') {

    $creds = pulsepoint_smm_ncwallet_settings();

    if (!$creds['auth']) {
        return ['success' => false, 'message' => 'NCWallet SMM API not configured'];
    }

    $result = pulsepoint_smm_ncwallet_request('POST', $creds['base_url'] . '/smm/order', [
        'category'   => $category,
        'service_id' => (string) $external_service_id,
        'link'       => $link,
        'quantity'   => $quantity,
        'ref_id'     => $reference,
    ]);

    if (!is_array($result)) {
        return ['success' => false, 'message' => 'No response from SMM provider'];
    }

    if (strtolower($result['status'] ?? '') !== 'success') {
        return ['success' => false, 'message' => $result['message'] ?? 'Order failed'];
    }

    return [
        'success'           => true,
        'message'           => $result['message'] ?? 'Order placed successfully',
        'provider_order_id' => $result['ref_id'] ?? $reference,
    ];
}

/**
 * Check order status. Called by cron/jobs/smm-status.php.
 */
if (!function_exists('pulsepoint_smm_ncwallet_check_status')) {
    function pulsepoint_smm_ncwallet_check_status(string $provider_order_id): ?array {

        $creds = pulsepoint_smm_ncwallet_settings();

        $result = pulsepoint_smm_ncwallet_request('POST', $creds['base_url'] . '/smm/status', [
            'ref_id' => $provider_order_id,
        ]);

        if (!is_array($result) || strtolower($result['status'] ?? '') !== 'success') {
            return null;
        }

        return [
            'order_status' => $result['order_status'] ?? null,
            'remains'      => null,
        ];
    }
}
