<?php
if (!defined('ABSPATH')) exit;

// ✅ Fetch education services
add_action('wp_ajax_pulsepoint_get_education', 'pulsepoint_get_education');
add_action('wp_ajax_nopriv_pulsepoint_get_education', 'pulsepoint_get_education');

function pulsepoint_get_education() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    $provider = sanitize_text_field($_GET['provider'] ?? '');

    // ✅ Fetch user account type
    $user_id = get_current_user_id();
    $account_type = 'Customer'; // default

    if ($user_id) {
        $account_type = $wpdb->get_var($wpdb->prepare(
            "SELECT account_type FROM {$base_prefix}users WHERE id = %d",
            $user_id
        )) ?: 'Customer';
    }

    // ✅ Fetch discount settings
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);

    $agent_discount = isset($settings['agent_discount']->opt_value) 
        ? floatval($settings['agent_discount']->opt_value) : 0;

    $api_discount = isset($settings['api_discount']->opt_value) 
        ? floatval($settings['api_discount']->opt_value) : 0;

    // ✅ Fetch education services
    $sql = "SELECT id, serviceid, servicename, cashback, price, price_api, provider 
            FROM {$base_prefix}education";

    if ($provider) {
        $sql .= $wpdb->prepare(" WHERE provider = %s", $provider);
    }

    $rows = $wpdb->get_results($sql);

    if (!$rows) {
        wp_send_json([]);
    }

    $services = [];

    foreach ($rows as $r) {

        // ✅ Base price logic
        $base_price = ($account_type === 'API') 
            ? floatval($r->price_api) 
            : floatval($r->price);

        // ✅ Apply discount
        if ($account_type === 'Agent') {
            $discount = ($agent_discount / 100) * $base_price;
            $final_price = $base_price - $discount;

        } elseif ($account_type === 'API') {
            $discount = ($api_discount / 100) * $base_price;
            $final_price = $base_price - $discount;

        } else {
            $final_price = $base_price;
        }

        $services[] = [
            'id'           => $r->id,
            'serviceid'    => $r->serviceid,
            'servicename'  => $r->servicename,
            'cashback'     => number_format($r->cashback, 2, '.', ''),
            'price'        => number_format($final_price, 2, '.', ''),
            'price_api'    => $r->price_api,
            'account_type' => $account_type,
        ];
    }

    wp_send_json($services);
}