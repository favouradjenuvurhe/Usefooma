<?php
/**
 * NCWallet Electricity API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/electricity/ncwallet.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send electricity token via NCWallet
 *
 * TOKEN FORMAT:
 *   PIN:API_KEY
 *
 * @param string $disco         Electricity provider (jos, ikeja, eko, abuja, etc)
 * @param string $plan_name     Plan name (not used by NCWallet, kept for compatibility)
 * @param string $meter_type    prepaid | postpaid
 * @param string $meter_number  Meter number
 * @param float  $amount        Amount to pay
 * @param bool   $bypass        Bypass validation
 * @param string $reference     Transaction reference
 * @param int    $transaction_id Internal transaction ID
 * @return array
 */
function send_electricity($disco, $plan_name, $meter_type, $meter_number, $amount, $bypass, $reference, $transaction_id)
{
    global $wpdb;

    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Load token from settings
    $settings = $wpdb->get_results(
        "SELECT opt_key, opt_value FROM {$base_prefix}settings",
        OBJECT_K
    );

    $token = trim($settings['electricity_token']->opt_value ?? '');

    if (!$token || !str_contains($token, ':')) {
        return [
            'success' => false,
            'message' => 'Invalid NCWallet electricity token format. Use PIN:API_KEY',
            'details' => null
        ];
    }

    // Split PIN and API KEY
    [$pin, $apiKey] = explode(':', $token, 2);
    $pin    = trim($pin);
    $apiKey = trim($apiKey);

    if (!$pin || !$apiKey) {
        return [
            'success' => false,
            'message' => 'Electricity PIN or API key missing.',
            'details' => null
        ];
    }

    // NCWallet endpoint
    $url = "https://ncwallet.africa/api/v1/electricity";

    /**
     * Disco → NCWallet meter_provider IDs
     * (Adjust if NCWallet updates their mapping)
     */
    $disco_map = [
        'ikeja'   => 1,
        'eko'     => 2,
        'abuja'   => 3,
        'ibadan'  => 4,
        'jos'     => 5,
        'kaduna'  => 6,
        'kano'    => 7,
        'portharcourt' => 8,
        'benin'   => 9,
        'enugu'   => 10,
        'uyo'     => 11,
        'yola'    => 12
    ];

    $disco_key = strtolower(trim($disco));
    $meter_id = $disco_map[$disco_key] ?? null;

    if (!$meter_id) {
        return [
            'success' => false,
            'message' => "Unsupported electricity provider: {$disco}",
            'details' => null
        ];
    }

    $unique_ref = $reference ?: 'NCE_' . time();

    // Payload (STRICT NCWallet FORMAT)
    $payload = [
        "meter_provider" => (string)$meter_id,
        "meter_type"     => strtolower($meter_type) === 'postpaid' ? 'postpaid' : 'prepaid',
        "meter_number"   => (string)$meter_number,
        "amount"         => (string)$amount,
        "bypass"         => (bool)$bypass
    ];

    // cURL request
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            "Accept: application/json",
            "Content-Type: application/json",
            "trnx_pin: {$pin}",
            "Authorization: {$apiKey}"
        ]
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid or empty response from NCWallet.',
            'details' => $response_raw
        ];
    }

    /**
     * NCWallet uses:
     * status = success | error
     * (error can still mean processed, but we respect status)
     */
    $status  = strtolower($api_response['status'] ?? '');
    $success = ($status === 'success');

    return [
        'success' => $success,
        'message' => $api_response['message'] ?? 'Electricity request processed.',
        'details' => [
            'transaction_id' => $api_response['ref_id'] ?? $unique_ref,
            'meter_provider' => $api_response['data']['meter_company'] ?? ucfirst($disco),
            'meter_number'   => $api_response['data']['meter_number'] ?? $meter_number,
            'meter_type'     => $api_response['data']['meter_type'] ?? $meter_type,
            'customer_name'  => $api_response['data']['customer_name'] ?? null,
            'meter_address'  => $api_response['data']['meter_address'] ?? null,
            'token'           => $api_response['data']['token'] ?? null,
            'amount'          => $api_response['data']['amount'] ?? $amount,
            'old_balance'     => $api_response['data']['oldbal'] ?? null,
            'new_balance'     => $api_response['data']['newbal'] ?? null,
            'provider'        => 'NCWallet',
            'api_response'    => $api_response
        ]
    ];
}