<?php
/**
 * Adex Electricity API Handler
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/electricity/adex.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

/**
 * Send electricity token via Adex API
 *
 * @param string $disco         Electricity provider (IKEJA, EKO, ADEX, etc)
 * @param string $plan_name     Plan name (used as fallback if disco not found)
 * @param string $meter_type    prepaid | postpaid
 * @param string $meter_number  Meter number
 * @param float  $amount        Amount to pay
 * @param bool   $bypass        Bypass validation
 * @param string $reference     Transaction reference
 * @param int    $transaction_id Internal transaction ID
 * @return array
 */
function send_electricity($disco, $plan_name, $meter_type, $meter_number, $amount, $bypass = false, $reference = '', $transaction_id = 0)
{
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // === Load settings from DB ===
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);
    $token   = trim($settings['electricity_token']->opt_value ?? '');
    $api_url = trim($settings['electricity_api']->opt_value ?? 'https://n3tdata.com/api/bill');

    if (!$token) {
        return [
            'success' => false,
            'message' => 'Electricity API token not set.',
            'details' => null
        ];
    }

    // === Fetch disco ID from bill table ===
    $bill_table = "{$base_prefix}bill";
    $bill_data  = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$bill_table} WHERE details = %s LIMIT 1",
        $disco
    ));

    // Fallback to plan_name if disco not found
    if (!$bill_data) {
        $bill_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$bill_table} WHERE details = %s LIMIT 1",
            $plan_name
        ));

        // If still not found, use plan_name as disco ID
        $disco_id = $bill_data->disco ?? $plan_name;
    } else {
        $disco_id = $bill_data->disco ?? $plan_name;
    }

    $unique_ref = $reference ?: 'Bill_' . time();

    // === Payload ===
    $payload = [
        'disco'        => $disco_id,
        'meter_type'   => strtolower($meter_type) === 'postpaid' ? 'POSTPAID' : 'PREPAID',
        'meter_number' => (string)$meter_number,
        'amount'       => (float)$amount,
        'bypass'       => (bool)$bypass,
        'request-id'   => $unique_ref
    ];

    // === cURL Request ===
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $api_url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Token {$token}",
            "Content-Type: application/json"
        ]
    ]);

    $response_raw = curl_exec($ch);
    $curl_error   = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        return [
            'success' => false,
            'message' => "cURL Error: {$curl_error}",
            'details' => $payload
        ];
    }

    $api_response = json_decode($response_raw, true);

    if (!is_array($api_response)) {
        return [
            'success' => false,
            'message' => 'Invalid or empty response from Adex API.',
            'details' => $response_raw
        ];
    }

    $status  = strtolower($api_response['status'] ?? '');
    $success = $status === 'success';

    return [
        'success' => $success,
        'message' => $api_response['message'] ?? 'Electricity request processed.',
        'details' => [
            'transaction_id' => $api_response['request-id'] ?? $unique_ref,
            'disco_name'     => $api_response['disco_name'] ?? ucfirst($disco),
            'meter_number'   => $api_response['meter_number'] ?? $meter_number,
            'meter_type'     => $api_response['meter_type'] ?? $meter_type,
            'amount'         => $api_response['amount'] ?? $amount,
            'charges'        => $api_response['charges'] ?? 0,
            'old_balance'    => $api_response['oldbal'] ?? null,
            'new_balance'    => $api_response['newbal'] ?? null,
            'token'          => $api_response['token'] ?? null,
            'wallet_vending' => $api_response['wallet_vending'] ?? 'wallet',
            'system'         => $api_response['system'] ?? 'API',
            'provider'       => 'ADEX',
            'api_response'   => $api_response
        ]
    ];
}