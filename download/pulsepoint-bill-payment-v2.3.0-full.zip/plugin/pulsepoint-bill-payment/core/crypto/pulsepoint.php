<?php
/**
 * Pulsepoint USDT Wallet Address Generator
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/pulsepoint.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// Hook for AJAX requests
add_action('wp_ajax_nopriv_pulsepoint_create_usdt', 'pulsepoint_create_usdt');
add_action('wp_ajax_pulsepoint_create_usdt', 'pulsepoint_create_usdt');

function pulsepoint_create_usdt() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);
    }

    $user_id     = $_SESSION['pulsepoint_user']['id'];
    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_wallet = $wpdb->prefix . 'pulsepoint_wallets';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    // Fetch user record
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_users}` WHERE id = %d", $user_id));
    if (!$user || $user->status != 1) {
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);
    }

    // Get settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'sandbox';
    $strowallet_key   = $settings['strowallet_public_key'] ?? 'pub_znm1oNOuVE7Yurhr8Du85Ub8iCMIXbxjiN465zZN';
    $strowallet_vip   = $settings['strowallet_vip_key'] ?? '6518cca3-5fa4-47a0-a30c-87ca2241a67b';

    if ($maintenance_mode == '1') {
        wp_send_json(['success' => false, 'message' => 'System under maintenance.']);
    }

    // Check if wallet already exists
    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_wallet} WHERE user_id = %d AND network = 'USDT' LIMIT 1", $user_id));
    if ($existing) {
        wp_send_json([
            'success' => true,
            'message' => 'USDT wallet already exists.',
            'wallet'  => [
                'address' => $existing->address,
                'network' => $existing->network,
            ]
        ]);
    }

    // Build API URL
    $query = http_build_query([
        'label'       => $user->phone ?? 'User-' . $user_id,
        'public_key'  => $strowallet_key,
        'webhook_url' => home_url('/callback/strowallet'),
        'vip_key'     => $strowallet_vip
    ]);

    $api_url = "https://strowallet.com/api/generate-address/?" . $query;

    // Send CURL request
    $ch = curl_init($api_url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['accept: application/json']
    ]);
    $response = curl_exec($ch);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($error) {
        wp_send_json(['success' => false, 'message' => "CURL Error: $error"]);
    }

    $result = json_decode($response, true);

    if (isset($result['errors'])) {
        wp_send_json(['success' => false, 'message' => json_encode($result['errors'])]);
    }

    if (!isset($result['address'])) {
        wp_send_json(['success' => false, 'message' => 'No address returned from API.', 'raw' => $result]);
    }

    // Save to database
    $wpdb->insert($table_wallet, [
        'user_id' => $user_id,
        'network' => 'USDT',
        'address' => $result['address'],
        'created_at' => current_time('mysql')
    ], ['%d','%s','%s','%s']);

    wp_send_json([
        'success' => true,
        'message' => $result['message'] ?? 'USDT wallet created successfully.',
        'wallet'  => [
            'address' => $result['address'],
            'network' => 'USDT'
        ]
    ]);
}
?>