<?php
/**
 * Secure Logout Function for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/logout.php
 * Route: /auth/logout
 *
 * This is the ONLY file that should declare pulsepoint_expire_cookie()
 * and pulsepoint_user_logout(). includes/app/view/logout.php has been
 * reduced to a thin wrapper that calls into this file instead of
 * redeclaring the same logic — that's what was causing the fatal error.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file access
}

if (!function_exists('pulsepoint_expire_cookie')) {
    /**
     * Expire a cookie using the exact attribute set it was created with.
     * Must match login.php's setcookie() call for the browser to actually clear it.
     */
    function pulsepoint_expire_cookie(string $name): void {
        if (!isset($_COOKIE[$name])) {
            return;
        }

        setcookie($name, '', [
            'expires'  => time() - 3600,
            'path'     => '/',
            'domain'   => $_SERVER['SERVER_NAME'] ?? '',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        unset($_COOKIE[$name]);
    }
}

if (!function_exists('pulsepoint_user_logout')) {
    /**
     * Route handler for /auth/logout.
     */
    function pulsepoint_user_logout() {
        global $wpdb;

        // Buffer output so nothing (whitespace, an accidental echo further
        // up the include chain, etc.) can send headers before we call
        // session_start() / setcookie() below. This is what was producing
        // the "session_start(): Session cannot be started after headers
        // have already been sent" warnings.
        if (!headers_sent() && ob_get_level() === 0) {
            ob_start();
        }

        if (session_status() !== PHP_SESSION_ACTIVE && !headers_sent()) {
            session_start();
        }

        $user_id = $_SESSION['pulsepoint_user']['id'] ?? null;

        // Rotates the stored token/passcode so any other device/session/API
        // caller holding the old token is also logged out. Remove this
        // block if you only want the current browser signed out.
        if ($user_id) {
            $table = $wpdb->prefix . 'pulsepoint_users';
            $wpdb->update($table, [
                'token'    => bin2hex(random_bytes(16)),
                'passcode' => random_int(1000, 9999),
            ], ['id' => (int) $user_id]);
        }

        $_SESSION = [];

        pulsepoint_expire_cookie('pulsepoint_user_session');
        pulsepoint_expire_cookie(session_name());

        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }

        $login_url = esc_url(site_url('/auth/login'));

        // Flush any buffered output now that cookies/session are safely set,
        // before we print the bridge page below.
        if (ob_get_level() > 0) {
            ob_end_clean();
        }
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Logging out…</title>
        </head>
        <body>
            <script>
                (async function () {
                    try { localStorage.clear(); } catch (e) {}
                    try { sessionStorage.clear(); } catch (e) {}

                    try {
                        if ('caches' in window) {
                            const names = await caches.keys();
                            await Promise.all(names.map(name => caches.delete(name)));
                        }
                    } catch (e) {}

                    try {
                        if ('indexedDB' in window && indexedDB.databases) {
                            const dbs = await indexedDB.databases();
                            dbs.forEach(db => db.name && indexedDB.deleteDatabase(db.name));
                        }
                    } catch (e) {}

                    window.location.replace(<?php echo json_encode($login_url); ?>);
                })();
            </script>
            <noscript>
                <meta http-equiv="refresh" content="0;url=<?php echo $login_url; ?>">
                <p>Logging out… <a href="<?php echo $login_url; ?>">Continue</a></p>
            </noscript>
        </body>
        </html>
        <?php
        exit;
    }
}

add_action('wp_ajax_nopriv_pulsepoint_user_logout', 'pulsepoint_user_logout');
add_action('wp_ajax_pulsepoint_user_logout', 'pulsepoint_user_logout');
