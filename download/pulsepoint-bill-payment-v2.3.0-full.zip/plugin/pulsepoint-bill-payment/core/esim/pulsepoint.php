<?php
/**
 * Pulsepoint eSIM Core - v2.2.1
 * Provider: SMSPool eSIM API
 */
if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_esim_settings')) {
function pulsepoint_esim_settings() {
    global $wpdb;
    $prefix = $wpdb->prefix . 'pulsepoint_';
    $rows = $wpdb->get_results("SELECT opt_key,opt_value FROM {$prefix}settings WHERE opt_key IN ('esim_api_key','esim_markup','esim_usd_rate','rate_usd','api_mode','maintenance_mode')", OBJECT_K);
    $out = [];
    foreach ($rows as $row) $out[$row->opt_key] = maybe_unserialize($row->opt_value);
    return $out;
}
}

if (!function_exists('pulsepoint_esim_request')) {
function pulsepoint_esim_request($endpoint, $body = []) {
    $settings = pulsepoint_esim_settings();
    $key = trim((string)($settings['esim_api_key'] ?? ''));
    if ($key === '') return ['success'=>0,'errors'=>[['message'=>'eSIM API key is not configured.']]];
    $body['key'] = $key;
    $response = wp_remote_post('https://api.smspool.net/esim/' . ltrim($endpoint,'/'), [
        'timeout' => 30,
        'headers' => ['Accept'=>'application/json'],
        'body' => $body,
    ]);
    if (is_wp_error($response)) return ['success'=>0,'errors'=>[['message'=>$response->get_error_message()]]];
    $code = wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $json = json_decode($raw, true);
    if (!is_array($json)) return ['success'=>0,'errors'=>[['message'=>'Invalid provider response','http_code'=>$code]]];
    $json['_http_code'] = $code;
    return $json;
}
}

function pulsepoint_esim_countries($start='', $length='', $search='') {
    return pulsepoint_esim_request('pricing', ['start'=>$start,'length'=>$length,'Search'=>$search]);
}
function pulsepoint_esim_plans($country) {
    return pulsepoint_esim_request('plans', ['country'=>strtoupper(sanitize_text_field($country))]);
}
function pulsepoint_esim_history($start='', $length='', $search='') {
    return pulsepoint_esim_request('history', ['start'=>$start,'length'=>$length,'search'=>$search]);
}
function pulsepoint_esim_profile($transaction_id) {
    return pulsepoint_esim_request('profile', ['transactionId'=>sanitize_text_field($transaction_id)]);
}
function pulsepoint_esim_delete($transaction_id) {
    return pulsepoint_esim_request('delete', ['transactionId'=>sanitize_text_field($transaction_id)]);
}
function pulsepoint_esim_topup_plans($plan_id) {
    return pulsepoint_esim_request('topup_plans', ['plan'=>(int)$plan_id]);
}

function pulsepoint_esim_purchase($user_id, $plan_id, $reference='') {
    global $wpdb;
    $prefix = $wpdb->prefix . 'pulsepoint_';
    $users = $prefix.'users'; $orders=$prefix.'esim_orders'; $trnx=$prefix.'trnx';
    $settings = pulsepoint_esim_settings();
    if (($settings['maintenance_mode'] ?? '0') == '1') return ['success'=>false,'message'=>'Under Maintenance'];
    if (($settings['api_mode'] ?? 'live') === 'off') return ['success'=>false,'message'=>'eSIM service not available'];
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE id=%d",$user_id));
    if (!$user || (int)$user->status !== 1) return ['success'=>false,'message'=>'User not active'];
    $plan_id=(int)$plan_id;
    if ($plan_id<=0) return ['success'=>false,'message'=>'Invalid eSIM plan'];

    // Validate the plan against the provider before charging the wallet.
    $plans = pulsepoint_esim_request('plans', ['country'=>sanitize_text_field($_POST['country'] ?? '')]);
    if (!is_array($plans) || (isset($plans['success']) && (int)$plans['success']===0)) return ['success'=>false,'message'=>'Unable to validate eSIM plan'];
    $plan=null;
    foreach ($plans as $row) if (is_array($row) && isset($row['ID']) && (int)$row['ID']===$plan_id) { $plan=$row; break; }
    if (!$plan) return ['success'=>false,'message'=>'Selected eSIM plan is no longer available'];
    $usd=(float)($plan['price'] ?? 0);
    if ($usd<=0) return ['success'=>false,'message'=>'Invalid provider plan price'];
    $rate=(float)($settings['esim_usd_rate'] ?? 0); if ($rate<=0) $rate=(float)($settings['rate_usd'] ?? 0); if ($rate<=0) $rate=1600;
    $markup=(float)($settings['esim_markup'] ?? 0);
    $amount=round(($usd*$rate)*(1+$markup/100),2);
    if ($amount<=0) return ['success'=>false,'message'=>'Invalid eSIM amount'];
    if (($settings['api_mode'] ?? 'live') === 'live' && (float)$user->wallet < $amount) return ['success'=>false,'message'=>'Insufficient balance'];
    if (!$reference) $reference='PESIM'.date('YmdHis').wp_rand(100,999);

    // Provider purchase happens before wallet debit; if it fails, no user funds are removed.
    $provider = pulsepoint_esim_request('purchase',['plan'=>$plan_id]);
    if (empty($provider['success']) || empty($provider['transactionId'])) {
        return ['success'=>false,'message'=>$provider['message'] ?? 'eSIM purchase failed','provider'=>$provider];
    }
    $tx=(string)$provider['transactionId'];
    $country_code=sanitize_text_field($_POST['country'] ?? '');
    $country_name=sanitize_text_field($_POST['country_name'] ?? '');
    $wpdb->insert($orders,[
        'user_id'=>$user_id,'operation'=>'purchase','transaction_id'=>$tx,'reference'=>$reference,
        'country_code'=>$country_code,'country_name'=>$country_name,'plan_id'=>$plan_id,
        'data_gb'=>(float)($plan['dataInGb']??0),'duration_days'=>(int)($plan['duration']??0),
        'provider_cost_usd'=>$usd,'amount'=>$amount,'status'=>'success','provider_response'=>wp_json_encode($provider)
    ]);
    $order_id=$wpdb->insert_id;
    $wpdb->insert($trnx,[
        'user_id'=>$user_id,'details'=>wp_json_encode(['service'=>'eSIM','country'=>$country_name,'country_code'=>$country_code,'plan'=>$plan_id,'transactionId'=>$tx]),
        'recipient'=>$country_code,'amount'=>$amount,'reference'=>$reference,'payment'=>'wallet','category'=>'others','status'=>'pending','type'=>'debit','description'=>'eSIM - '.($country_name?:$country_code)
    ]);
    $trnx_id=$wpdb->insert_id;

    $charged=true; $new_wallet=(float)$user->wallet;
    if (($settings['api_mode'] ?? 'live') === 'live') {
        $updated=$wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet = wallet - %f WHERE id=%d AND wallet >= %f",$amount,$user_id,$amount));
        $charged=($updated===1);
        if ($charged) $new_wallet-=$amount;
    }
    if (!$charged) {
        $wpdb->update($orders,['status'=>'wallet_failed'],['id'=>$order_id]);
        $wpdb->update($trnx,['status'=>'failed','gateway_response'=>wp_json_encode(['message'=>'Wallet debit failed after provider purchase'])],['id'=>$trnx_id]);
        return ['success'=>false,'message'=>'Wallet debit failed. Contact support with reference '.$reference,'reference'=>$reference,'provider_transaction_id'=>$tx];
    }
    $wpdb->update($trnx,['status'=>'success','gateway_response'=>wp_json_encode($provider),'updated_at'=>current_time('mysql')],['id'=>$trnx_id]);
    if (function_exists('pulsepoint_save_beneficiary')) pulsepoint_save_beneficiary($user_id,'esim',$tx,$country_name?:$country_code,'eSIM',['plan_id'=>$plan_id,'country'=>$country_code]);
    return ['success'=>true,'message'=>'eSIM purchased successfully','reference'=>$reference,'transactionId'=>$tx,'amount'=>$amount,'new_wallet'=>$new_wallet,'plan'=>$plan,'profile'=>$provider];
}

function pulsepoint_esim_topup($user_id,$transaction_id,$plan_id,$reference='') {
    global $wpdb; $prefix=$wpdb->prefix.'pulsepoint_'; $users=$prefix.'users'; $orders=$prefix.'esim_orders'; $trnx=$prefix.'trnx';
    $settings=pulsepoint_esim_settings();
    $user=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE id=%d",$user_id));
    if (!$user || (int)$user->status!==1) return ['success'=>false,'message'=>'User not active'];
    $transaction_id=sanitize_text_field($transaction_id); $plan_id=(int)$plan_id;
    $history=$wpdb->get_row($wpdb->prepare("SELECT plan_id FROM {$orders} WHERE transaction_id=%s ORDER BY id DESC LIMIT 1",$transaction_id));
    $base_plan=(int)($history->plan_id??0);
    $plans=pulsepoint_esim_topup_plans($base_plan);
    if (isset($plans['success']) && !$plans['success']) return ['success'=>false,'message'=>$plans['message']??'Unable to load top-up plans'];
    $plan=null; foreach ((array)$plans as $row) if (is_array($row) && isset($row['ID']) && (int)$row['ID']===$plan_id) {$plan=$row;break;}
    if (!$plan) return ['success'=>false,'message'=>'Invalid top-up plan'];
    $usd=(float)($plan['price']??0); $rate=(float)($settings['esim_usd_rate']??0); if($rate<=0)$rate=(float)($settings['rate_usd']??1600); $markup=(float)($settings['esim_markup']??0); $amount=round(($usd*$rate)*(1+$markup/100),2);
    if ((float)$user->wallet<$amount && ($settings['api_mode']??'live')==='live') return ['success'=>false,'message'=>'Insufficient balance'];
    if (!$reference)$reference='PESIMT'.date('YmdHis').wp_rand(100,999);
    $provider=pulsepoint_esim_request('topup',['transactionId'=>$transaction_id,'plan'=>$plan_id]);
    if (empty($provider['success'])) return ['success'=>false,'message'=>$provider['message']??'eSIM top-up failed','provider'=>$provider];
    $wpdb->insert($orders,['user_id'=>$user_id,'operation'=>'topup','transaction_id'=>$transaction_id,'reference'=>$reference,'plan_id'=>$plan_id,'data_gb'=>(float)($plan['dataInGb']??0),'duration_days'=>(int)($plan['duration']??0),'provider_cost_usd'=>$usd,'amount'=>$amount,'status'=>'success','provider_response'=>wp_json_encode($provider)]);
    $wpdb->insert($trnx,['user_id'=>$user_id,'details'=>wp_json_encode(['service'=>'eSIM Top Up','transactionId'=>$transaction_id,'plan'=>$plan_id]),'recipient'=>$transaction_id,'amount'=>$amount,'reference'=>$reference,'payment'=>'wallet','category'=>'others','status'=>'pending','type'=>'debit','description'=>'eSIM top-up']);
    $tid=$wpdb->insert_id; $charged=true; $new=(float)$user->wallet;
    if (($settings['api_mode']??'live')==='live') {$updated=$wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet-%f WHERE id=%d AND wallet>=%f",$amount,$user_id,$amount));$charged=($updated===1);if($charged)$new-=$amount;}
    if(!$charged){$wpdb->update($trnx,['status'=>'failed'],['id'=>$tid]);return ['success'=>false,'message'=>'Wallet debit failed after top-up','reference'=>$reference];}
    $wpdb->update($trnx,['status'=>'success','gateway_response'=>wp_json_encode($provider)],['id'=>$tid]);
    return ['success'=>true,'message'=>'eSIM topped up successfully','reference'=>$reference,'transactionId'=>$transaction_id,'amount'=>$amount,'new_wallet'=>$new];
}
