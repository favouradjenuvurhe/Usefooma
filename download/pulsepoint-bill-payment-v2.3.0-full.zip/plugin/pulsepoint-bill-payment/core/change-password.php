<?php
/**
 * Pulsepoint Change Password
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/change-password.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_pulsepoint_change_password', 'pulsepoint_change_password');
add_action('wp_ajax_nopriv_pulsepoint_change_password', 'pulsepoint_change_password');

function pulsepoint_change_password() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json([
            'success' => false,
            'message' => 'User not logged in.'
        ]);
    }

    $previous_password = sanitize_text_field($_POST['previous_password'] ?? '');
    $new_password      = sanitize_text_field($_POST['new_password'] ?? '');
    $confirm_password  = sanitize_text_field($_POST['confirm_password'] ?? '');

    if (
        empty($previous_password) ||
        empty($new_password) ||
        empty($confirm_password)
    ) {
        wp_send_json([
            'success' => false,
            'message' => 'All fields are required.'
        ]);
    }

    if ($new_password !== $confirm_password) {
        wp_send_json([
            'success' => false,
            'message' => 'New password and confirm password do not match.'
        ]);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $_SESSION['pulsepoint_user']['id']
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'User account not found.'
        ]);
    }

    if (!password_verify($previous_password, $user->password)) {
        wp_send_json([
            'success' => false,
            'message' => 'Previous password is incorrect.'
        ]);
    }

    if (password_verify($new_password, $user->password)) {
        wp_send_json([
            'success' => false,
            'message' => 'New password cannot be the same as current password.'
        ]);
    }

    $updated = $wpdb->update(
        $table,
        [
            'password'   => password_hash($new_password, PASSWORD_DEFAULT),
            'updated_at' => current_time('mysql', 1)
        ],
        [
            'id' => $user->id
        ],
        [
            '%s',
            '%s'
        ],
        [
            '%d'
        ]
    );

    if ($updated === false) {
        wp_send_json([
            'success' => false,
            'message' => 'Failed to update password.'
        ]);
    }

    // Email Notification
    @wp_mail(
        $user->email,
        'Password Changed Successfully',
        "
        Hi {$user->firstname},<br><br>

        Your account password was changed successfully.<br><br>

        <strong>Date:</strong> " . current_time('mysql') . "<br>
        <strong>IP Address:</strong> " . ($_SERVER['REMOTE_ADDR'] ?? 'Unknown') . "<br><br>

        If you did not make this change, please contact support immediately.

        <br><br>
        Regards,<br>
        Pulsepoint Security Team
        ",
        ['Content-Type: text/html; charset=UTF-8']
    );

    wp_send_json([
        'success' => true,
        'message' => 'Password changed successfully.'
    ]);
}