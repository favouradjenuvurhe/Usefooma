<?php
if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_forgot_password', 'pulsepoint_forgot_password');
add_action('wp_ajax_pulsepoint_forgot_password', 'pulsepoint_forgot_password');

function pulsepoint_forgot_password() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    if (!$email) wp_send_json(['success'=>false,'message'=>'Email is required']);

    $table = $wpdb->prefix . 'pulsepoint_users';
    $user = $wpdb->get_row($wpdb->prepare("SELECT id, firstname, email FROM {$table} WHERE email=%s LIMIT 1", $email));

    if (!$user) wp_send_json(['success'=>false,'message'=>'Email not found']);

    $token = bin2hex(random_bytes(16));

    $updated = $wpdb->update(
        $table,
        ['reset_token'=>$token,'account_limit'=>0.00,'updated_at'=>current_time('mysql',1)],
        ['id'=>$user->id],
        ['%s','%f','%s'],
        ['%d']
    );

    if ($updated === false) wp_send_json(['success'=>false,'message'=>'Failed to process request']);

    $reset_link = site_url('/auth/reset-password?token='.$token);
    $subject = 'Password Reset Request';
    $message = "
    Hi {$user->firstname},<br><br>
    We received a request to reset your password.<br>
    Click the link below:<br><br>
    <a href='{$reset_link}'>{$reset_link}</a><br><br>
    If you did not request this, ignore this email.<br><br>
    ";
    $headers = ['Content-Type: text/html; charset=UTF-8'];

    $mail_sent = wp_mail($user->email, $subject, $message, $headers);
    if (!$mail_sent) wp_send_json(['success'=>false,'message'=>'Failed to send reset email']);

    wp_send_json(['success'=>true,'message'=>'Reset link has been sent to your email']);
}