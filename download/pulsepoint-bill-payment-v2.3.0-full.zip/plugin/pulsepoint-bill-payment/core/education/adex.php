<?php
/**
 * ADEX Education Provider
 * File: adex.php
 */

if (!defined('ABSPATH')) exit;

function send_education($provider, $exam_id, $quantity, $amount, $reference, $trnx_id) {

    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_settings = "{$base_prefix}settings";

    // ✅ Fetch API settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}", OBJECT_K);

    $edu_api   = $settings_rows['edu_api']->opt_value ?? '';
    $edu_token = $settings_rows['edu_token']->opt_value ?? '';

    if (!$edu_api || !$edu_token) {
        return [
            'success' => false,
            'message' => 'Education API not configured',
        ];
    }

    // ✅ Prepare payload
    $payload = [
        'exam'     => $exam_id,
        'quantity' => $quantity
    ];

    // ✅ CURL REQUEST
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $edu_api);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $headers = [
        "Authorization: Token {$edu_token}",
        "Content-Type: application/json"
    ];

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return [
            'success' => false,
            'message' => 'Curl Error: ' . curl_error($ch)
        ];
    }

    curl_close($ch);

    // ✅ Decode response
    $res = json_decode($response, true);

    if (!$res) {
        return [
            'success' => false,
            'message' => 'Invalid API response'
        ];
    }

    // ✅ Check API status
    if (($res['status'] ?? '') !== 'success') {
        return [
            'success' => false,
            'message' => $res['message'] ?? 'API Failed'
        ];
    }

    // ✅ Extract PIN + SERIAL
    $pin_raw = $res['pin'] ?? '';

    $pin = '';
    $serial = '';

    if ($pin_raw) {
        $parts = explode('<=>', $pin_raw);
        $pin = trim($parts[0] ?? '');
        $serial = trim($parts[1] ?? '');
    }

    // ✅ FINAL RESPONSE (MATCH YOUR MOCK)
    return [
        'success' => true,
        'message' => $res['message'] ?? 'Education purchase successful',
        'data' => [
            'pin' => $pin,
            'serial' => $serial
        ]
    ];
}