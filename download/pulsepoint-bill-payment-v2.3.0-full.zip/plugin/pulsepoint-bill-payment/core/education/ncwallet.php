<?php
/**
 * NCWallet Education Provider
 * File: ncwallet.php
 */

if (!defined('ABSPATH')) exit;

function send_education($provider, $exam_id, $quantity, $amount, $reference, $trnx_id) {

    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_settings = "{$base_prefix}settings";

    // ✅ Fetch settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}", OBJECT_K);

    $edu_api   = $settings_rows['edu_api']->opt_value ?? 'https://ncwallet.africa/api/v1/exam';
    $edu_token = $settings_rows['edu_token']->opt_value ?? '';

    if (!$edu_token) {
        return [
            'success' => false,
            'message' => 'NCWallet API not configured'
        ];
    }

    // ✅ SPLIT pin:token
    $parts = explode(':', $edu_token);
    $trnx_pin = trim($parts[0] ?? '');
    $token    = trim($parts[1] ?? '');

    if (!$token) {
        return [
            'success' => false,
            'message' => 'Invalid NCWallet token format. Expected pin:token'
        ];
    }

    // ✅ Build payload
    $payload = [
        'ref_id'  => $reference,
        'exam_type' => $exam_id,
        'quantity'=> (string) $quantity
    ];

    // ✅ CURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $edu_api);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        "trnx_pin: {$trnx_pin}",
        "Authorization: {$token}"
    ];

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return [
            'success' => false,
            'message' => 'Curl Error: ' . curl_error($ch)
        ];
    }

    curl_close($ch);

    // ✅ Decode response
    $res = json_decode($response, true);

    if (!$res) {
        return [
            'success' => false,
            'message' => 'Invalid API response'
        ];
    }

    // ❌ API can return "error" but still include data
    $status = strtolower($res['status'] ?? '');

    if ($status !== 'success') {
        return [
            'success' => false,
            'message' => $res['message'] ?? 'Transaction failed',
        ];
    }

    // ✅ Extract PIN + SERIAL (safe fallback)
    $pin = $res['data']['pin'] ?? '';
    $serial = $res['data']['serial'] ?? '';

    // FINAL RESPONSE (STANDARD FORMAT)
    return [
        'success' => true,
        'message' => $res['message'] ?? 'Exam purchase successful',
        'data' => [
            'pin' => $pin,
            'serial' => $serial
        ]
    ];
}