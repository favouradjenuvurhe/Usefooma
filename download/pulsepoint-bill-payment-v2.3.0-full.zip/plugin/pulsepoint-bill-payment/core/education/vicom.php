<?php
/**
 * VICOM Education Provider
 * File: vicom.php
 */

if (!defined('ABSPATH')) exit;

function send_education($provider, $exam_id, $quantity, $amount, $reference, $trnx_id) {

    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_settings = "{$base_prefix}settings";

    // ✅ Fetch API settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}", OBJECT_K);

    $edu_api   = $settings_rows['edu_api']->opt_value ?? 'https://telecomabode.com.ng/api/exam';
    $edu_token = $settings_rows['edu_token']->opt_value ?? '';

    if (!$edu_token) {
        return [
            'success' => false,
            'message' => 'VICOM API token not configured'
        ];
    }

    // ✅ Prepare payload
    $payload = [
        'exam'     => (int) $exam_id,
        'quantity' => (int) $quantity
    ];

    // ✅ INIT CURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $edu_api);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $headers = [
        "Authorization: Token {$edu_token}",
        "Content-Type: application/json"
    ];

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return [
            'success' => false,
            'message' => 'Curl Error: ' . curl_error($ch)
        ];
    }

    curl_close($ch);

    // ✅ Decode response
    $res = json_decode($response, true);

    if (!$res) {
        return [
            'success' => false,
            'message' => 'Invalid API response'
        ];
    }

    // ✅ Check status
    if (($res['status'] ?? '') !== 'success') {
        return [
            'success' => false,
            'message' => $res['message'] ?? 'API Failed'
        ];
    }

    // ✅ Extract PIN
    $pin = trim($res['pin'] ?? '');

    // VICOM does not provide serial → fallback
    $serial = '';

    // ✅ FINAL RESPONSE (SAME FORMAT AS YOUR SYSTEM)
    return [
        'success' => true,
        'message' => $res['message'] ?? 'Exam PIN Purchase Successful',
        'data' => [
            'pin' => $pin,
            'serial' => $serial
        ]
    ];
}