<?php
/**
 * Pulsepoint Education Purchase Function
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/education/pulsepoint.php
 */

if (!defined('ABSPATH')) exit;

// AJAX Hooks
add_action('wp_ajax_nopriv_pulsepoint_education_purchase', 'pulsepoint_education_purchase');
add_action('wp_ajax_pulsepoint_education_purchase', 'pulsepoint_education_purchase');

function pulsepoint_education_purchase() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success'=>false,'message'=>'Invalid request method']);
    }

    if (!session_id()) session_start();

    if (!isset($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json(['success'=>false,'message'=>'User not logged in']);
    }

    $user_id      = $_SESSION['pulsepoint_user']['id'];
    $table_users  = $wpdb->prefix . 'pulsepoint_users';
    $table_trnx   = $wpdb->prefix . 'pulsepoint_trnx';
    $base_prefix  = $wpdb->prefix . 'pulsepoint_';

    /** RATE LIMIT **/
    $now = time();
    if (isset($_SESSION['last_edu_request'][$user_id]) && ($now - $_SESSION['last_edu_request'][$user_id]) < 15) {
        wp_send_json(['success'=>false,'message'=>'Please wait 15 seconds']);
    }
    $_SESSION['last_edu_request'][$user_id] = $now;

    /** FETCH USER **/
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d",$user_id)
    );

    if (!$user || $user->status != 1) {
        wp_send_json(['success'=>false,'message'=>'User not active']);
    }

    /** LOAD SETTINGS **/
    $settings_rows = $wpdb->get_results("SELECT opt_key,opt_value FROM {$base_prefix}settings");

    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $maintenance_mode = $settings['maintenance_mode'] ?? '0';
    $api_mode         = $settings['api_mode'] ?? 'live';

    if ($maintenance_mode == '1') {
        wp_send_json(['success'=>false,'message'=>'Under Maintenance']);
    }

    /** SANITIZE INPUT **/
    $plan_id   = intval($_POST['plan'] ?? 0);
    $quantity  = intval($_POST['quantity'] ?? 1);
    $reference = sanitize_text_field($_POST['reference'] ?? '');

    if (!$plan_id) {
        wp_send_json(['success'=>false,'message'=>'Education plan required']);
    }

    /** GET EDUCATION SERVICE **/
    $edu_plan = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$base_prefix}education WHERE id=%d",$plan_id)
    );

    if (!$edu_plan) {
        wp_send_json(['success'=>false,'message'=>'Invalid education plan']);
    }

    $provider    = strtolower(trim($edu_plan->provider));
    $exam_id     = trim($edu_plan->serviceid);
    $serviceName = trim($edu_plan->servicename);
    $amount      = $edu_plan->price * $quantity;

    /** REFERENCE **/
    if (empty($reference)) {
        $reference = 'PSNG' . mt_rand(10000,99999) . 'E';
    }

    $description = strtoupper($serviceName) . " - Result PIN";

    /** DAILY LIMIT **/
    $today_start = date('Y-m-d 00:00:00');
    $today_end   = date('Y-m-d 23:59:59');

    $spent_today = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(amount) FROM {$table_trnx}
        WHERE user_id=%d
        AND date BETWEEN %s AND %s
        AND type='debit'",
        $user_id,$today_start,$today_end
    ));

    $spent_today = $spent_today ?: 0;
    $limit = $user->account_limit ?: 5000;

    if (($spent_today + $amount) > $limit) {
        wp_send_json(['success'=>false,'message'=>"Daily Max ₦{$limit} reached"]);
    }

    /** WALLET CHECK **/
    if ($api_mode === 'live' && $user->wallet < $amount) {
        wp_send_json(['success'=>false,'message'=>'Insufficient balance']);
    }

    /** API MODE **/
    if ($api_mode === 'off') {
        wp_send_json(['success'=>false,'message'=>'Stock not available']);
    }

    if ($api_mode === 'sandbox') {
        wp_send_json(['success'=>true,'message'=>'Education Success (Sandbox Mode)']);
    }

    /** LOAD PROVIDER FILE **/
    $safe_provider = preg_replace('/[^a-z0-9]/i','',$provider);

    $api_file = __DIR__ . "/{$safe_provider}.php";

    if (!file_exists($api_file)) {
        wp_send_json(['success'=>false,'message'=>'Provider file missing']);
    }

    require_once $api_file;

    if (!function_exists('send_education')) {
        wp_send_json(['success'=>false,'message'=>'send_education() missing']);
    }

    /** INSERT PENDING **/
    $wpdb->insert($table_trnx,[
        'user_id'     => $user_id,
        'details'     => json_encode([
            'provider'=>$provider,
            'exam'=>$exam_id,
            'quantity'=>$quantity
        ]),
        'recipient'   => '',
        'amount'      => $amount,
        'reference'   => $reference,
        'payment'     => 'wallet',
        'category'    => 'education',
        'status'      => 'pending',
        'type'        => 'debit',
        'session'     => session_id(),
        'description' => $description
    ]);

    $trnx_id = $wpdb->insert_id;

    /** CALL PROVIDER **/
    try {

        $api_response = send_education(
            $provider,
            $exam_id,
            $quantity,
            $amount,
            $reference,
            $trnx_id
        );

    } catch (Exception $e) {
        wp_send_json(['success'=>false,'message'=>'Provider Error']);
    }

    $status = (!empty($api_response['success'])) ? 'success' : 'failed';

    /** EXTRACT PIN **/
    $pin    = $api_response['data']['pin'] ?? '';
    $serial = $api_response['data']['serial'] ?? '';

    /** UPDATE TRANSACTION **/
    $wpdb->update($table_trnx,[
        'status'           => $status,
        'recipient'        => $pin,
        'gateway_response' => json_encode($api_response),
        'updated_at'       => current_time('mysql')
    ],['id'=>$trnx_id]);

    /** DEDUCT WALLET **/
    $new_wallet = $user->wallet;

    if ($status === 'success' && $api_mode === 'live') {

        $new_wallet -= $amount;

        $wpdb->update(
            $table_users,
            ['wallet'=>$new_wallet],
            ['id'=>$user_id]
        );

        if ((float) $edu_plan->cashback > 0) {
            pulsepoint_credit_cashback(
                $user_id,
                (float) $edu_plan->cashback * $quantity,
                'education',
                $reference,
                'Cashback — ' . $serviceName
            );
        }
    }

    wp_send_json([
        'success'    => $status === 'success',
        'message'    => $api_response['message'] ?? 'Education Completed',
        'reference'  => $reference,
        'pin'        => $pin,
        'serial'     => $serial,
        'new_wallet' => $new_wallet
    ]);
}