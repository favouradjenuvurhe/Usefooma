<?php
if (!defined('ABSPATH')) exit;

// ✅ Fetch data plans by network (with user discount logic)
add_action('wp_ajax_pulsepoint_get_data_plans', 'pulsepoint_get_data_plans');
add_action('wp_ajax_nopriv_pulsepoint_get_data_plans', 'pulsepoint_get_data_plans');

function pulsepoint_get_data_plans() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $network = sanitize_text_field($_GET['network'] ?? '');

    // ✅ Fetch user account type (if logged in)
    $user_id = get_current_user_id();
    $account_type = 'Customer'; // default
    if ($user_id) {
        $account_type = $wpdb->get_var($wpdb->prepare(
            "SELECT account_type FROM {$base_prefix}users WHERE id = %d",
            $user_id
        )) ?: 'Customer';
    }

    // ✅ Fetch discount settings
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);
    $agent_discount = isset($settings['agent_discount']->opt_value) ? floatval($settings['agent_discount']->opt_value) : 0;
    $api_discount   = isset($settings['api_discount']->opt_value) ? floatval($settings['api_discount']->opt_value) : 0;

    // ✅ Fetch plans for the selected network
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, plan, details, network, amount, cashback, apiamount, type, provider
         FROM {$base_prefix}data
         WHERE network = %s
         ORDER BY amount ASC",
        $network
    ));

    if (!$rows) {
        wp_send_json([]); // no plans found
    }

    // ✅ Apply discount logic based on account type
    $plans = [];
    foreach ($rows as $r) {
        $base_price = ($account_type === 'API') ? floatval($r->apiamount) : floatval($r->amount);

        // Apply discount depending on account type
        if ($account_type === 'Agent') {
            $discount = ($agent_discount / 100) * $base_price;
            $final_price = $base_price - $discount;
        } elseif ($account_type === 'API') {
            $discount = ($api_discount / 100) * $base_price;
            $final_price = $base_price - $discount;
        } else {
            $final_price = $base_price;
        }

        $plans[] = [
            'id'           => $r->id,
            'plan'         => $r->plan,
            'details'      => $r->details,
            'network'      => $r->network,
            'amount'       => number_format($final_price, 2, '.', ''), // unified key for frontend
            'cashback'     => $r->cashback,
            'apiamount'    => $r->apiamount,
            'type'         => $r->type,
            'provider'     => $r->provider,
            'account_type' => $account_type,
        ];
    }

    wp_send_json($plans);
}