<?php
/**
 * Email Verification Handler for Pulsepoint Plugin
 * Author: Amaaavl
 *
 * SECURITY / RELIABILITY PATCH (matches login.php / register.php):
 * 1. OTP brute-force protection: a 6-digit code only has 1,000,000
 *    combinations, so verify attempts are now rate-limited per user
 *    (5 failed attempts locks that user out for 15 minutes).
 * 2. Resend-OTP cooldown: prevents email-bombing a user's inbox by
 *    limiting resends to once every 60 seconds per user.
 * 3. Session fixation protection: session_regenerate_id(true) is called
 *    once the session moves from "pending verification" to "verified".
 * 4. Session cookie hardened: HttpOnly + Secure (when on HTTPS) + SameSite=Lax,
 *    set via the array-options form of setcookie() (PHP 7.3+/8.3 safe).
 *    The old 6-argument setcookie() call did not set HttpOnly/SameSite at all.
 * 5. Resend OTP emails now render from the shared /templates/register.html
 *    template (same one register.php uses) with real branding (platform
 *    name / color) pulled from settings, instead of a hardcoded inline
 *    HTML string with "Pulsepoint" always hardcoded regardless of branding.
 * 6. Inputs go through wp_unslash() before sanitizing, and session_status()
 *    is used instead of session_id() to check for an active session.
 */

if (!defined('ABSPATH')) exit;

const PULSEPOINT_VERIFY_MAX_ATTEMPTS  = 5;
const PULSEPOINT_VERIFY_LOCKOUT_SECS  = 900;  // 15 minutes
const PULSEPOINT_RESEND_COOLDOWN_SECS = 60;   // 1 minute between resends

add_action('wp_ajax_nopriv_pulsepoint_email_verify', 'pulsepoint_email_verify');
add_action('wp_ajax_pulsepoint_email_verify', 'pulsepoint_email_verify');

/**
 * Rate-limit helpers for OTP verification attempts (keyed by user id,
 * since the session is already tied to that one user either way).
 */
function pulsepoint_verify_rl_key(int $user_id): string {
    return 'pp_verify_rl_' . $user_id;
}

function pulsepoint_verify_get_attempts(int $user_id): int {
    $val = get_transient(pulsepoint_verify_rl_key($user_id));
    return $val ? (int) $val : 0;
}

function pulsepoint_verify_record_failure(int $user_id): void {
    $key = pulsepoint_verify_rl_key($user_id);
    $attempts = pulsepoint_verify_get_attempts($user_id) + 1;
    set_transient($key, $attempts, PULSEPOINT_VERIFY_LOCKOUT_SECS);
}

function pulsepoint_verify_clear_attempts(int $user_id): void {
    delete_transient(pulsepoint_verify_rl_key($user_id));
}

/**
 * Load and render the shared register/verification email template.
 * Same template register.php uses, so branding stays consistent.
 */
function pulsepoint_render_verify_email_template(array $vars): string {
    $template_path = dirname(__DIR__) . '/templates/register.html';

    if (!file_exists($template_path)) {
        return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
    }

    $html = file_get_contents($template_path);

    $defaults = [
        'platform_name' => 'Pulsepoint',
        'heading'       => '',
        'firstname'     => '',
        'message'       => '',
        'code'          => '',
        'year'          => date('Y'),
        'support_email' => get_option('admin_email'),
        'color_hex'     => '#6C63FF',
    ];

    $vars = array_merge($defaults, $vars);

    foreach ($vars as $key => $value) {
        $safe = $key === 'message'
            ? $value
            : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');

        $html = str_replace('{{' . $key . '}}', $safe, $html);
    }

    return $html;
}

/**
 * Fetch platform_name / color_hex branding settings.
 */
function pulsepoint_verify_get_branding(\wpdb $wpdb, string $base_prefix): array {
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    return [
        'platform_name' => $settings['platform_name'] ?? 'Pulsepoint',
        'color_hex'     => $settings['color_hex'] ?? '#6C63FF',
    ];
}

function pulsepoint_email_verify() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request']);
    }

    // Start session if not started
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    // Only logged-in session can verify
    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Verification session expired. Please login again.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);
    $code    = isset($_POST['code']) ? sanitize_text_field(wp_unslash($_POST['code'])) : '';

    // === Brute-force check (before touching the DB) ===
    if (pulsepoint_verify_get_attempts($user_id) >= PULSEPOINT_VERIFY_MAX_ATTEMPTS) {
        wp_send_json([
            'success' => false,
            'message' => 'Too many attempts. Please try again in a few minutes.'
        ]);
    }

    if (!preg_match('/^\d{6}$/', $code)) {
        pulsepoint_verify_record_failure($user_id);
        wp_send_json(['success' => false, 'message' => 'Invalid code']);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    // Fetch user by ID, OTP code, and status_email=0 (pending verification)
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id=%d AND security_code=%s AND status_email=0 LIMIT 1",
            $user_id,
            $code
        )
    );

    if (!$user) {
        pulsepoint_verify_record_failure($user_id);
        wp_send_json(['success' => false, 'message' => 'Invalid or expired code']);
    }

    // Correct code — clear the failure counter for this user
    pulsepoint_verify_clear_attempts($user_id);

    // Update user status to active
    $wpdb->update(
        $table,
        [
            'status_email'  => 1,
            'security_code' => null,
            'updated_at'    => current_time('mysql', 1)
        ],
        ['id' => $user->id]
    );

    // New verified identity → rotate the session id.
    session_regenerate_id(true);

    // Update session to reflect verified status
    $_SESSION['pulsepoint_user'] = [
        'id'            => $user->id,
        'firstname'     => $user->firstname,
        'lastname'      => $user->lastname,
        'email'         => $user->email,
        'phone'         => $user->phone,
        'wallet'        => $user->wallet,
        'token'         => $user->token ?? '',
        'account_limit' => $user->account_limit ?? 0,
    ];

    // Refresh HTTP-only, hardened session cookie
    setcookie('pulsepoint_user_session', session_id(), [
        'expires'  => time() + 86400,
        'path'     => '/',
        'domain'   => $_SERVER['SERVER_NAME'] ?? '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    wp_send_json([
        'success'  => true,
        'message'  => 'Email verified successfully.',
        'redirect' => site_url('/app/dashboard'),
        'user'     => $_SESSION['pulsepoint_user']
    ]);
}

/**
 * Resend OTP function
 */
add_action('wp_ajax_nopriv_pulsepoint_resend_otp', 'pulsepoint_resend_otp');
add_action('wp_ajax_pulsepoint_resend_otp', 'pulsepoint_resend_otp');

function pulsepoint_resend_otp() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request']);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json([
            'success' => false,
            'message' => 'Session expired. Please login again.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_user']['id']);

    // === Resend cooldown check ===
    $cooldown_key = 'pp_resend_cd_' . $user_id;
    if (get_transient($cooldown_key)) {
        wp_send_json([
            'success' => false,
            'message' => 'Please wait a moment before requesting another code.'
        ]);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id=%d AND status_email=0 LIMIT 1",
            $user_id
        )
    );

    if (!$user) {
        wp_send_json([
            'success' => false,
            'message' => 'Account already verified or invalid user.'
        ]);
    }

    // Generate new OTP
    $security_code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

    $wpdb->update(
        $table,
        ['security_code' => $security_code, 'updated_at' => current_time('mysql', 1)],
        ['id' => $user->id]
    );

    // Start cooldown before sending, so a slow mailer can't be raced
    set_transient($cooldown_key, 1, PULSEPOINT_RESEND_COOLDOWN_SECS);

    // Clear any prior verify-attempt lockout, since this is a fresh code
    pulsepoint_verify_clear_attempts($user_id);

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $branding    = pulsepoint_verify_get_branding($wpdb, $base_prefix);

    @wp_mail(
        $user->email,
        "Verify your {$branding['platform_name']} account",
        pulsepoint_render_verify_email_template([
            'platform_name' => $branding['platform_name'],
            'color_hex'     => $branding['color_hex'],
            'heading'       => 'Verify Your Account',
            'firstname'     => $user->firstname,
            'code'          => $security_code,
            'message'       => 'Here is your new verification code. Enter it to activate your account.',
        ]),
        ['Content-Type: text/html; charset=UTF-8']
    );

    wp_send_json([
        'success' => true,
        'message' => 'New verification code sent to your email.'
    ]);
}
