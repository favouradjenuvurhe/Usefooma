<?php
if (!defined('ABSPATH')) exit;

// ✅ Fetch cable plans by type (DSTV, GOTV, STARTIMES)
add_action('wp_ajax_pulsepoint_get_cable_plans', 'pulsepoint_get_cable_plans');
add_action('wp_ajax_nopriv_pulsepoint_get_cable_plans', 'pulsepoint_get_cable_plans');

function pulsepoint_get_cable_plans() {
    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $type = sanitize_text_field($_GET['type'] ?? 'DSTV');

    // ✅ Fetch user account type (if logged in)
    $user_id = get_current_user_id();
    $account_type = 'Customer'; // default
    if ($user_id) {
        $account_type = $wpdb->get_var($wpdb->prepare(
            "SELECT account_type FROM {$base_prefix}users WHERE id = %d",
            $user_id
        )) ?: 'Customer';
    }

    // ✅ Fetch discount settings
    $settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings", OBJECT_K);
    $agent_discount = isset($settings['agent_discount']->opt_value) ? floatval($settings['agent_discount']->opt_value) : 0;
    $api_discount   = isset($settings['api_discount']->opt_value) ? floatval($settings['api_discount']->opt_value) : 0;

    // ✅ Fetch cable plans
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, plan, details, type, amount, cashback, apiamount, provider
         FROM {$base_prefix}cable
         WHERE type = %s
         ORDER BY amount ASC",
        $type
    ));

    if (!$rows) {
        wp_send_json([]);
    }

    $plans = [];
    foreach ($rows as $r) {
        $base_price = ($account_type === 'API') ? floatval($r->apiamount) : floatval($r->amount);

        if ($account_type === 'Agent') {
            $discount = ($agent_discount / 100) * $base_price;
            $final_price = $base_price - $discount;
        } elseif ($account_type === 'API') {
            $discount = ($api_discount / 100) * $base_price;
            $final_price = $base_price - $discount;
        } else {
            $final_price = $base_price;
        }

        $plans[] = [
            'id'           => $r->id,
            'plan'         => $r->plan,
            'details'      => $r->details,
            'type'         => $r->type,
            'amount'       => number_format($final_price, 2, '.', ''),
            'cashback'     => $r->cashback,
            'apiamount'    => $r->apiamount,
            'provider'     => $r->provider,
            'account_type' => $account_type,
        ];
    }

    wp_send_json($plans);
}