<?php
if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_reset_password', 'pulsepoint_reset_password');
add_action('wp_ajax_pulsepoint_reset_password', 'pulsepoint_reset_password');

function pulsepoint_reset_password(){
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method']);
    }

    $token    = isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($token) || empty($password)) {
        wp_send_json(['success' => false, 'message' => 'All fields are required']);
    }

    if (strlen($password) < 6) {
        wp_send_json(['success' => false, 'message' => 'Password must be at least 6 characters']);
    }

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id FROM {$table} WHERE reset_token = %s LIMIT 1",
            $token
        )
    );

    if (!$user) {
        wp_send_json(['success' => false, 'message' => 'Invalid or expired reset token']);
    }

    // ✅ USE SAME HASHING AS REGISTRATION
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $updated = $wpdb->update(
        $table,
        [
            'password'    => $password_hash,
            'reset_token' => null,
            'updated_at'  => current_time('mysql', true),
        ],
        ['id' => $user->id],
        ['%s','%s','%s'],
        ['%d']
    );

    if ($updated === false) {
        wp_send_json(['success' => false, 'message' => 'Failed to reset password']);
    }

    wp_send_json([
        'success' => true,
        'message' => 'Password has been reset successfully. You can now log in.'
    ]);
}