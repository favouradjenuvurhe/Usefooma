<?php

if (!defined('ABSPATH')) exit;

/**
 * Pulsepoint Airtime Scheduler (FINAL VERSION)
 * - One-time + Recurring support
 * - Uses run_at logic
 * - Auto server domain
 */

add_action('pulsepoint_airtime_scheduler', function () {

    global $wpdb;

    $table_jobs = $wpdb->prefix . 'pulsepoint_airtime_jobs';

    // =========================================
    // GET DUE JOBS
    // =========================================
    $jobs = $wpdb->get_results("
        SELECT * FROM {$table_jobs}
        WHERE is_active = 1
        AND run_at <= NOW()
        LIMIT 200
    ");

    if (empty($jobs)) return;

    // =========================================
    // AUTO SERVER DOMAIN
    // =========================================
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        ? "https://"
        : "http://";

    $base_url = rtrim($scheme . $_SERVER['HTTP_HOST'], '/');
    $api_url  = $base_url . "/api/airtime";

    foreach ($jobs as $job) {

        // =========================================
        // BUILD PAYLOAD
        // =========================================
        $payload = [
            "network"        => $job->network,
            "amount"         => floatval($job->amount),
            "mobile_number"  => $job->mobile_number,
            "Ported_number"  => (bool) $job->ported_number,
            "airtime_type"   => $job->airtime_type
        ];

        // =========================================
        // CALL API
        // =========================================
        $ch = curl_init($api_url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Token " . $job->token
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        $decoded = json_decode($response, true);
        $success = isset($decoded['success']) && $decoded['success'] === true;

        // =========================================
        // ONE-TIME JOB
        // =========================================
        if ($job->schedule_type === 'one_time') {

            $wpdb->update(
                $table_jobs,
                [
                    'is_active'     => 0,
                    'last_run'      => current_time('mysql'),
                    'last_response' => $response
                ],
                ['id' => $job->id],
                ['%d','%s','%s'],
                ['%d']
            );

        }

        // =========================================
        // RECURRING JOB
        // =========================================
        else {

            $wpdb->update(
                $table_jobs,
                [
                    'last_run' => current_time('mysql'),

                    // NEXT RUN = NOW + interval
                    'next_run' => date(
                        'Y-m-d H:i:s',
                        strtotime("+{$job->interval_minutes} minutes")
                    ),

                    // MOVE RUN SLOT FOR NEXT EXECUTION
                    'run_at' => date(
                        'Y-m-d H:i:s',
                        strtotime("+{$job->interval_minutes} minutes")
                    ),

                    'last_response' => $response
                ],
                ['id' => $job->id],
                ['%s','%s','%s','%s'],
                ['%d']
            );
        }

        // =========================================
        // OPTIONAL LOG
        // =========================================
        $wpdb->insert(
            $wpdb->prefix . 'pulsepoint_logs',
            [
                'event' => 'airtime_scheduler_run',
                'meta'  => json_encode([
                    'job_id'  => $job->id,
                    'success' => $success,
                    'response'=> $decoded
                ]),
                'created_at' => current_time('mysql')
            ]
        );
    }

});