<?php

if (!defined('ABSPATH')) exit;

/**
 * XIXAPAY LOG FUNCTION
 */
function xixapay_log($message, $card_id = '') {

    $upload = wp_upload_dir();
    $log_file = $upload['basedir'] . '/xixapay-log.txt';

    $time = date('Y-m-d H:i:s');

    $log = "[" . $time . "] ";

    if (!empty($card_id)) {
        $log .= "[CARD: {$card_id}] ";
    }

    $log .= $message . PHP_EOL;

    file_put_contents($log_file, $log, FILE_APPEND | LOCK_EX);
}

/**
 * CRON JOB
 */
add_action('pulsepoint_xixapay_card_refresh', function () {

    global $wpdb;

    xixapay_log("CRON STARTED");

    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $table_users    = $base_prefix . 'users';
    $table_cards    = $base_prefix . 'virtual_cards';
    $table_settings = $base_prefix . 'settings';

    /**
     * CHECK GATEWAY
     */
    $gateway_type = strtolower(trim($wpdb->get_var("
        SELECT opt_value FROM {$table_settings}
        WHERE opt_key='virtualcard_type'
        LIMIT 1
    ")));

    if ($gateway_type !== 'xixapay') {
        xixapay_log("GATEWAY NOT XIXAPAY");
        return;
    }

    /**
     * API KEYS
     */
    $apiKey = trim($wpdb->get_var("SELECT opt_value FROM {$table_settings} WHERE opt_key='pay_token' LIMIT 1"));
    $secret = trim($wpdb->get_var("SELECT opt_value FROM {$table_settings} WHERE opt_key='pay_secret' LIMIT 1"));
    $bizId  = trim($wpdb->get_var("SELECT opt_value FROM {$table_settings} WHERE opt_key='pay_biz' LIMIT 1"));

    if (!$apiKey || !$secret || !$bizId) {
        xixapay_log("MISSING API KEYS");
        return;
    }

    /**
     * GET USERS (SOURCE OF CARD IDS)
     */
    $users = $wpdb->get_results("
        SELECT id, cardid
        FROM {$table_users}
        WHERE cardid IS NOT NULL
        AND cardid != ''
        LIMIT 200
    ");

    if (empty($users)) {
        xixapay_log("NO USERS FOUND");
        return;
    }

    xixapay_log("USERS FOUND: " . count($users));

    foreach ($users as $user) {

        $card_id = trim($user->cardid);
        $user_id  = intval($user->id);

        if (!$card_id) continue;

        xixapay_log("PROCESSING", $card_id);

        $endpoint = "https://api.xixapay.com/api/card/{$card_id}/balance";

        $response = wp_remote_post($endpoint, [
            'headers' => [
                'Authorization' => 'Bearer ' . $secret,
                'api-key'       => $apiKey,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json'
            ],
            'body' => wp_json_encode([
                'businessId' => $bizId
            ]),
            'timeout' => 40
        ]);

        if (is_wp_error($response)) {
            xixapay_log("API ERROR: " . $response->get_error_message(), $card_id);
            continue;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!is_array($body)) {
            xixapay_log("INVALID RESPONSE", $card_id);
            continue;
        }

        $status = strtolower($body['status'] ?? '');

        if (!in_array($status, ['success', 'succcess'])) {

            xixapay_log("API FAIL: " . ($body['message'] ?? ''), $card_id);

            $msg = strtolower($body['message'] ?? '');

            if (
                strpos($msg, 'not found') !== false ||
                strpos($msg, 'terminated') !== false ||
                strpos($msg, 'expired') !== false ||
                strpos($msg, 'deleted') !== false ||
                strpos($msg, 'invalid') !== false ||
                strpos($msg, 'blocked') !== false
            ) {
                $wpdb->delete($table_cards, ['card_id' => $card_id], ['%s']);
                xixapay_log("CARD DELETED", $card_id);
            }

            continue;
        }

        /**
         * API DATA
         */
        $data = $body['data'];

        $balance  = floatval($data['balance'] ?? 0);
        $statusDb = sanitize_text_field($data['status'] ?? 'inactive');
        $card_no  = sanitize_text_field($data['card_number'] ?? '');
        $cvv      = sanitize_text_field($data['cvv'] ?? '');
        $expiry   = sanitize_text_field($data['expiry_date'] ?? '');
        $currency = sanitize_text_field($data['currency'] ?? 'USD');

        $billing = $data['billingAddress'] ?? [];

        $city    = sanitize_text_field($billing['city'] ?? '');
        $street  = sanitize_text_field($billing['line1'] ?? '');
        $country = sanitize_text_field($billing['country'] ?? '');
        $zip     = sanitize_text_field($billing['postalCode'] ?? '');

        $last4 = $card_no ? substr(preg_replace('/\D/', '', $card_no), -4) : '';

        /**
         * CHECK EXISTING
         */
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_cards} WHERE card_id = %s",
            $card_id
        ));

        $data_to_save = [
            'user_id'                      => $user_id,
            'card_id'                      => $card_id,
            'card_status'                  => $statusDb,
            'card_number'                  => $card_no,
            'last4'                       => $last4,
            'cvv'                         => $cvv,
            'expiry'                      => $expiry,
            'card_brand'                  => 'Mastercard',
            'balance'                     => $balance,

            // FULL BILLING
            'billing_address_city'        => $city,
            'billing_address_street'      => $street,
            'billing_address_country'     => $country,
            'billing_address_zipcode'     => $zip,
            'billing_address_country_code'=> strtoupper(substr($country, 0, 2)),

            'updated_at'                  => current_time('mysql')
        ];

        if ($exists) {

            $wpdb->update(
                $table_cards,
                $data_to_save,
                ['card_id' => $card_id]
            );

            xixapay_log("UPDATED", $card_id);

        } else {

            $wpdb->insert(
                $table_cards,
                array_merge($data_to_save, [
                    'created_at' => current_time('mysql')
                ])
            );

            xixapay_log("INSERTED", $card_id);
        }

        /**
         * EXPIRY DELETE
         */
        if (!empty($expiry)) {

            $expParts = explode('/', $expiry);

            if (count($expParts) === 2) {

                $expMonth = intval($expParts[0]);
                $expYear  = intval('20' . $expParts[1]);

                $expiryTimestamp = strtotime($expYear . '-' . $expMonth . '-01 +1 month');

                if (time() > $expiryTimestamp) {
                    $wpdb->delete($table_cards, ['card_id' => $card_id], ['%s']);
                    xixapay_log("EXPIRED CARD DELETED", $card_id);
                }
            }
        }

        xixapay_log("SYNC DONE", $card_id);
    }

    xixapay_log("CRON FINISHED");
});
?>