<?php

if (!defined('ABSPATH')) exit;

add_action('pulsepoint_cron_cleanup', function () {

    global $wpdb;

    // Delete old logs / expired sessions
    $wpdb->query("
        DELETE FROM {$wpdb->prefix}pulsepoint_trnx
        WHERE status = 'failed'
        AND date < DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");

});