<?php
/**
 * Pulsepoint Fraud Detection Cron
 * Path: cron/jobs/fraud-detection.php
 * Author: Amaaavl
 *
 * Runs on every cron tick and scans the `trnx` (transactions) table for
 * suspicious activity patterns per user. Any user who trips a rule is:
 *   1. Automatically suspended (`users.status` set to 0)
 *   2. Emailed a suspension notice (via the shared branded template)
 *   3. Reported to the admin, also by email
 *   4. Logged to the `logs` table with the matched rule + evidence
 *   5. Given an in-app notification row
 *
 * Only currently-active users (`status = 1`) are scanned, so an
 * already-suspended account is never re-flagged or re-emailed on
 * subsequent runs.
 *
 * RULES (tune these via the constants below):
 *
 *   A. VELOCITY  — too many transactions in a short window.
 *      More than FRAUD_VELOCITY_MAX_TRNX transactions inside
 *      FRAUD_VELOCITY_WINDOW_MINUTES minutes.
 *
 *   B. FAILED SPIKE — repeated failed transactions in a short window,
 *      a common signature of card testing / brute-force attempts.
 *      More than FRAUD_FAILED_MAX failed transactions inside
 *      FRAUD_FAILED_WINDOW_MINUTES minutes.
 *
 *   C. FUND-AND-DRAIN — a large funding credit immediately followed by
 *      a debit that empties most of it back out, inside a very short
 *      window. Classic wallet-abuse / money-laundering pattern.
 *
 *   D. AMOUNT SPIKE — a single transaction far larger than the user's
 *      own historical average, above an absolute floor so small/new
 *      accounts don't get flagged over trivial amounts.
 */

if (!defined('ABSPATH')) exit;

// ---- Tunable thresholds ----
if (!defined('FRAUD_VELOCITY_WINDOW_MINUTES')) define('FRAUD_VELOCITY_WINDOW_MINUTES', 10);
if (!defined('FRAUD_VELOCITY_MAX_TRNX'))       define('FRAUD_VELOCITY_MAX_TRNX', 12);

if (!defined('FRAUD_FAILED_WINDOW_MINUTES'))   define('FRAUD_FAILED_WINDOW_MINUTES', 15);
if (!defined('FRAUD_FAILED_MAX'))              define('FRAUD_FAILED_MAX', 6);

if (!defined('FRAUD_DRAIN_WINDOW_MINUTES'))    define('FRAUD_DRAIN_WINDOW_MINUTES', 5);
if (!defined('FRAUD_DRAIN_MIN_AMOUNT'))        define('FRAUD_DRAIN_MIN_AMOUNT', 20000); // ₦20,000 floor
if (!defined('FRAUD_DRAIN_RATIO'))             define('FRAUD_DRAIN_RATIO', 0.85); // debit >= 85% of the credit

if (!defined('FRAUD_AMOUNT_SPIKE_MULTIPLIER')) define('FRAUD_AMOUNT_SPIKE_MULTIPLIER', 6);
if (!defined('FRAUD_AMOUNT_SPIKE_FLOOR'))      define('FRAUD_AMOUNT_SPIKE_FLOOR', 50000); // ₦50,000 floor

add_action('pulsepoint_fraud_detection', function () {

    global $wpdb;

    $base_prefix   = $wpdb->prefix . 'pulsepoint_';
    $table_trnx    = "{$base_prefix}trnx";
    $table_users   = "{$base_prefix}users";
    $table_logs    = "{$base_prefix}logs";
    $table_notif   = "{$base_prefix}notifications";

    // Only look at users who are currently active — an already-suspended
    // user has nothing left to check and shouldn't be re-flagged.
    $active_user_ids = $wpdb->get_col("SELECT id FROM {$table_users} WHERE status = 1");

    if (empty($active_user_ids)) {
        return;
    }

    foreach ($active_user_ids as $user_id) {

        $flag_reason  = null;
        $flag_evidence = [];

        // ---------------------------------------------------------
        // RULE A: VELOCITY
        // ---------------------------------------------------------
        $recent_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_trnx}
             WHERE user_id = %d AND date >= DATE_SUB(NOW(), INTERVAL %d MINUTE)",
            $user_id,
            FRAUD_VELOCITY_WINDOW_MINUTES
        ));

        if ($recent_count > FRAUD_VELOCITY_MAX_TRNX) {
            $flag_reason = 'High transaction velocity';
            $flag_evidence = [
                'Transactions' => $recent_count,
                'Window'       => FRAUD_VELOCITY_WINDOW_MINUTES . ' minutes',
            ];
        }

        // ---------------------------------------------------------
        // RULE B: REPEATED FAILURES
        // ---------------------------------------------------------
        if (!$flag_reason) {

            $failed_count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_trnx}
                 WHERE user_id = %d AND status = 'failed'
                 AND date >= DATE_SUB(NOW(), INTERVAL %d MINUTE)",
                $user_id,
                FRAUD_FAILED_WINDOW_MINUTES
            ));

            if ($failed_count > FRAUD_FAILED_MAX) {
                $flag_reason = 'Repeated failed transactions';
                $flag_evidence = [
                    'Failed Transactions' => $failed_count,
                    'Window'              => FRAUD_FAILED_WINDOW_MINUTES . ' minutes',
                ];
            }
        }

        // ---------------------------------------------------------
        // RULE C: FUND-AND-DRAIN
        // ---------------------------------------------------------
        if (!$flag_reason) {

            $last_credit = $wpdb->get_row($wpdb->prepare(
                "SELECT id, amount, date FROM {$table_trnx}
                 WHERE user_id = %d AND type = 'credit' AND status = 'success'
                 AND amount >= %f
                 ORDER BY date DESC LIMIT 1",
                $user_id,
                FRAUD_DRAIN_MIN_AMOUNT
            ));

            if ($last_credit) {

                $draining_debit = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, amount, date FROM {$table_trnx}
                     WHERE user_id = %d AND type = 'debit' AND status = 'success'
                     AND date > %s
                     AND date <= DATE_ADD(%s, INTERVAL %d MINUTE)
                     ORDER BY date ASC LIMIT 1",
                    $user_id,
                    $last_credit->date,
                    $last_credit->date,
                    FRAUD_DRAIN_WINDOW_MINUTES
                ));

                if ($draining_debit && (float) $draining_debit->amount >= (float) $last_credit->amount * FRAUD_DRAIN_RATIO) {
                    $flag_reason = 'Fund-and-drain pattern';
                    $flag_evidence = [
                        'Funded'   => '₦' . number_format((float) $last_credit->amount, 2),
                        'Drained'  => '₦' . number_format((float) $draining_debit->amount, 2),
                        'Window'   => FRAUD_DRAIN_WINDOW_MINUTES . ' minutes',
                    ];
                }
            }
        }

        // ---------------------------------------------------------
        // RULE D: AMOUNT SPIKE vs. OWN HISTORY
        // ---------------------------------------------------------
        if (!$flag_reason) {

            $avg_amount = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT AVG(amount) FROM {$table_trnx}
                 WHERE user_id = %d AND status = 'success'
                 AND date < DATE_SUB(NOW(), INTERVAL %d MINUTE)",
                $user_id,
                FRAUD_VELOCITY_WINDOW_MINUTES
            ));

            if ($avg_amount > 0) {

                $spike = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, amount FROM {$table_trnx}
                     WHERE user_id = %d
                     AND date >= DATE_SUB(NOW(), INTERVAL %d MINUTE)
                     AND amount >= %f
                     AND amount >= %f
                     ORDER BY amount DESC LIMIT 1",
                    $user_id,
                    FRAUD_VELOCITY_WINDOW_MINUTES,
                    FRAUD_AMOUNT_SPIKE_FLOOR,
                    $avg_amount * FRAUD_AMOUNT_SPIKE_MULTIPLIER
                ));

                if ($spike) {
                    $flag_reason = 'Unusual transaction amount';
                    $flag_evidence = [
                        'Transaction Amount' => '₦' . number_format((float) $spike->amount, 2),
                        'Typical Amount'     => '₦' . number_format($avg_amount, 2),
                    ];
                }
            }
        }

        if (!$flag_reason) {
            continue; // nothing suspicious for this user
        }

        // ---------------------------------------------------------
        // SUSPEND THE ACCOUNT
        // ---------------------------------------------------------
        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT id, firstname, lastname, email FROM {$table_users} WHERE id = %d",
            $user_id
        ));

        if (!$user) {
            continue;
        }

        $wpdb->update(
            $table_users,
            ['status' => 0],
            ['id' => $user_id],
            ['%d'],
            ['%d']
        );

        // ---------------------------------------------------------
        // LOG IT
        // ---------------------------------------------------------
        $wpdb->insert($table_logs, [
            'event'      => 'fraud_auto_suspend',
            'meta'       => maybe_serialize([
                'user_id' => $user_id,
                'reason'  => $flag_reason,
                'evidence'=> $flag_evidence,
            ]),
            'ip'         => 'cron',
            'user_agent' => 'pulsepoint_fraud_detection',
            'created_at' => current_time('mysql'),
        ]);

        // ---------------------------------------------------------
        // IN-APP NOTIFICATION
        // ---------------------------------------------------------
        $wpdb->insert($table_notif, [
            'user_id' => $user_id,
            'title'   => 'Account Suspended',
            'message' => "Your account was automatically suspended due to suspicious activity ({$flag_reason}). Contact support if you believe this is a mistake.",
            'type'    => 'warning',
            'status'  => 'unread',
        ]);

        // ---------------------------------------------------------
        // EMAIL USER + ADMIN
        // ---------------------------------------------------------
        pulsepoint_notify_transaction([
            'user_email'    => $user->email,
            'firstname'     => $user->firstname,
            'heading'       => 'Account Suspended',
            'status_label'  => 'SUSPENDED',
            'status_color'  => '#ef4444',
            'user_message'  => 'For your security, your account has been temporarily suspended after our system detected unusual transaction activity. If this was you and you believe this is a mistake, please contact support to have your account reviewed and reinstated.',
            'admin_message' => "The fraud detection cron automatically suspended a user account.<br><br><strong>User:</strong> {$user->firstname} {$user->lastname} ({$user->email})<br><strong>User ID:</strong> {$user_id}<br><strong>Reason:</strong> {$flag_reason}",
            'details'       => $flag_evidence,
            'notify_admin'  => true,
            'user_subject'  => 'Your Account Has Been Suspended',
            'admin_subject' => 'Fraud Alert — Account Auto-Suspended',
        ]);
    }
});
