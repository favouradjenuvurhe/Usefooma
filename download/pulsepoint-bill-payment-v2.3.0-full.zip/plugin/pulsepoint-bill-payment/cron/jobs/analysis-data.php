<?php    

if (!defined('ABSPATH')) exit;    

add_action('pulsepoint_analysis_data', function () {    

    global $wpdb;    

    $table_trnx = $wpdb->prefix . 'pulsepoint_trnx';    
    $table_data = $wpdb->prefix . 'pulsepoint_data';    

    // 🔍 GET TARGET TRANSACTIONS
    $transactions = $wpdb->get_results("    
        SELECT * FROM $table_trnx    
        WHERE category = 'data'    
        AND status = 'success'    
        AND (profit_amount = 0 OR value IS NULL OR value = '')    
        LIMIT 200    
    ");    

    if (empty($transactions)) return;    

    foreach ($transactions as $tx) {    

        $selling_price = floatval($tx->amount);    
        $purchase_price = 0;
        $value_display = ''; // ✅ FINAL OUTPUT VALUE (GB/MB)    

        $details = json_decode($tx->details, true);    

        if (isset($details['plan'])) {    

            $plan_id = $details['plan'];    

            // ✅ GET PLAN DATA
            $plan = $wpdb->get_row($wpdb->prepare(    
                "SELECT purchase, value FROM $table_data 
                 WHERE plan = %s OR plan = %d 
                 LIMIT 1",    
                $plan_id,
                intval($plan_id)
            ));    

            if ($plan) {    

                $purchase_price = floatval($plan->purchase);    

                // ============================
                // ✅ KEEP ORIGINAL VALUE FORMAT
                // ============================
                $raw_value = trim($plan->value ?? '');

                if (!empty($raw_value)) {

                    $upper = strtoupper($raw_value);

                    if (strpos($upper, 'GB') !== false) {
                        // already GB format
                        $value_display = $raw_value;
                    } elseif (strpos($upper, 'MB') !== false) {
                        $value_display = $raw_value;
                    } elseif (is_numeric($raw_value)) {
                        // fallback assume GB
                        $value_display = $raw_value . 'GB';
                    } else {
                        $value_display = $raw_value;
                    }
                }
            }    
        }

        // ❌ skip if no purchase
        if ($purchase_price <= 0) continue;

        // ✅ PROFIT
        $profit = round($selling_price - $purchase_price, 2);    

        // ✅ UPDATE DB
        $wpdb->update(    
            $table_trnx,    
            [    
                'profit_amount' => $profit,    
                'value'         => $value_display,   // 🔥 FIXED HERE
                'updated_at'    => current_time('mysql')    
            ],    
            ['id' => $tx->id],    
            ['%f','%s','%s'],    
            ['%d']    
        );    

    }    

});