<?php

if (!defined('ABSPATH')) exit;

add_action('pulsepoint_cron_transactions', function () {

    global $wpdb;
    $table = $wpdb->prefix . 'pulsepoint_trnx';

    // Example: retry failed transactions
    $failed = $wpdb->get_results("
        SELECT * FROM $table
        WHERE status = 'pending'
        AND date < DATE_SUB(NOW(), INTERVAL 10 MINUTE)
    ");

    foreach ($failed as $tx) {

        // TODO: call API retry logic
        // Example:
        // pulsepoint_retry_transaction($tx->id);

        $wpdb->update(
            $table,
            ['status' => 'failed'],
            ['id' => $tx->id]
        );
    }

});