<?php

if (!defined('ABSPATH')) exit;

/**
 * Pulsepoint User Integrity Scheduler
 * - Every user gets a unique, non-null `token`
 * - Every user gets a unique, exactly-6-character `uniqueid`
 * - Runs in batches so it stays cron-friendly
 */

// =========================================
// SCHEDULE THE JOB (hourly — change to suit)
// =========================================
add_action('wp', function () {
    if (!wp_next_scheduled('pulsepoint_user_integrity_scheduler')) {
        wp_schedule_event(time(), 'hourly', 'pulsepoint_user_integrity_scheduler');
    }
});

// Clear the scheduled event on plugin deactivation
register_deactivation_hook(__FILE__, function () {
    $timestamp = wp_next_scheduled('pulsepoint_user_integrity_scheduler');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'pulsepoint_user_integrity_scheduler');
    }
});

add_action('pulsepoint_user_integrity_scheduler', function () {

    global $wpdb;

    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $table_logs  = $wpdb->prefix . 'pulsepoint_logs';

    $batch_limit = 200;

    // =========================================
    // HELPERS
    // =========================================

    // Unique token, checked against DB + everything already generated this run
    $generate_unique_token = function (array &$known_tokens) use ($wpdb, $table_users) {
        do {
            $token = wp_generate_password(64, false, false);
        } while (
            in_array($token, $known_tokens, true)
            || $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table_users} WHERE token = %s LIMIT 1",
                $token
            ))
        );
        $known_tokens[] = $token;
        return $token;
    };

    // Unique 6-char uniqueid (no 0/O/1/I, to avoid visual confusion)
    $generate_unique_id = function (array &$known_ids) use ($wpdb, $table_users) {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $id = '';
            for ($i = 0; $i < 6; $i++) {
                $id .= $chars[random_int(0, strlen($chars) - 1)];
            }
        } while (
            in_array($id, $known_ids, true)
            || $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table_users} WHERE uniqueid = %s LIMIT 1",
                $id
            ))
        );
        $known_ids[] = $id;
        return $id;
    };

    $fixed_tokens = 0;
    $fixed_ids    = 0;

    // Preload existing non-empty values so new ones can't collide with them
    $known_tokens = $wpdb->get_col("SELECT token FROM {$table_users} WHERE token IS NOT NULL AND token != ''");
    $known_ids    = $wpdb->get_col("SELECT uniqueid FROM {$table_users} WHERE uniqueid IS NOT NULL AND uniqueid != ''");

    // =========================================
    // 1) NULL / EMPTY TOKENS
    // =========================================
    $null_token_users = $wpdb->get_results("
        SELECT id FROM {$table_users}
        WHERE token IS NULL OR token = ''
        LIMIT {$batch_limit}
    ");

    foreach ($null_token_users as $user) {
        $new_token = $generate_unique_token($known_tokens);

        $wpdb->update(
            $table_users,
            ['token' => $new_token],
            ['id' => $user->id],
            ['%s'],
            ['%d']
        );

        $fixed_tokens++;
    }

    // =========================================
    // 2) DUPLICATE TOKENS (same token on 2+ users)
    //    Keeps the earliest-created user's token, regenerates the rest.
    // =========================================
    $dupe_tokens = $wpdb->get_col("
        SELECT token FROM {$table_users}
        WHERE token IS NOT NULL AND token != ''
        GROUP BY token
        HAVING COUNT(*) > 1
    ");

    foreach ($dupe_tokens as $dupe_token) {
        $user_ids = $wpdb->get_col($wpdb->prepare("
            SELECT id FROM {$table_users}
            WHERE token = %s
            ORDER BY id ASC
        ", $dupe_token));

        array_shift($user_ids); // leave the oldest account untouched

        foreach ($user_ids as $uid) {
            $new_token = $generate_unique_token($known_tokens);

            $wpdb->update(
                $table_users,
                ['token' => $new_token],
                ['id' => $uid],
                ['%s'],
                ['%d']
            );

            $fixed_tokens++;
        }
    }

    // =========================================
    // 3) NULL / EMPTY / WRONG-LENGTH uniqueid
    // =========================================
    $bad_uniqueid_users = $wpdb->get_results("
        SELECT id FROM {$table_users}
        WHERE uniqueid IS NULL
           OR uniqueid = ''
           OR CHAR_LENGTH(uniqueid) != 6
        LIMIT {$batch_limit}
    ");

    foreach ($bad_uniqueid_users as $user) {
        $new_id = $generate_unique_id($known_ids);

        $wpdb->update(
            $table_users,
            ['uniqueid' => $new_id],
            ['id' => $user->id],
            ['%s'],
            ['%d']
        );

        $fixed_ids++;
    }

    // =========================================
    // OPTIONAL LOG
    // =========================================
    if ($fixed_tokens > 0 || $fixed_ids > 0) {
        $wpdb->insert(
            $table_logs,
            [
                'event' => 'user_integrity_scheduler_run',
                'meta'  => json_encode([
                    'tokens_fixed'    => $fixed_tokens,
                    'uniqueids_fixed' => $fixed_ids
                ]),
                'created_at' => current_time('mysql')
            ]
        );
    }

});
