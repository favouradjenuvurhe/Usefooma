<?php
/**
 * Pulsepoint SMM Order Status Check Cron
 * Path: cron/jobs/smm-status.php
 * Author: Amaaavl
 *
 * Polls the provider for status updates on orders that are still
 * in-flight (pending/process), so a user isn't stuck looking at
 * "pending" forever when the order actually completed on the provider's
 * side. Only checks orders from the last 14 days to avoid polling very
 * old, abandoned records forever.
 */

if (!defined('ABSPATH')) exit;

add_action('pulsepoint_cron_smm_status', function () {

    global $wpdb;

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_orders = "{$base_prefix}smm_orders";
    $table_settings = "{$base_prefix}settings";

    $provider = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$table_settings} WHERE opt_key=%s", 'smm_api_provider'));
    $provider = $provider ? (maybe_unserialize($provider) ?: 'owlet') : 'owlet';
    $provider = strtolower(trim($provider));

    $safe_provider = preg_replace('/[^a-z0-9]/i', '', $provider);
    $provider_file = dirname(__DIR__, 2) . "/core/smm/{$safe_provider}.php";

    if (!file_exists($provider_file)) {
        return;
    }

    require_once $provider_file;

    $check_fn = "pulsepoint_smm_{$safe_provider}_check_status";

    if (!function_exists($check_fn)) {
        return;
    }

    $orders = $wpdb->get_results($wpdb->prepare(
        "SELECT id, provider_order_id FROM {$table_orders}
         WHERE status = 'success'
         AND provider_order_id IS NOT NULL
         AND (order_status IS NULL OR order_status NOT IN ('completed','canceled','cancelled'))
         AND created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
         LIMIT 50"
    ));

    foreach ($orders as $order) {

        $result = call_user_func($check_fn, $order->provider_order_id);

        if (!$result || empty($result['order_status'])) {
            continue;
        }

        $wpdb->update($table_orders, [
            'order_status' => strtolower($result['order_status']),
            'remains'      => $result['remains'] ?? null,
        ], ['id' => $order->id]);
    }
});
