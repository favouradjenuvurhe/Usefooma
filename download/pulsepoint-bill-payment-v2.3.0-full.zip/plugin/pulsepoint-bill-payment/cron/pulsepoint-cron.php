<?php
/**
 * Pulsepoint Cron Entry Point
 * URL: https://yourdomain.com/wp-json/pulsepoint/v1/cron
 */

if (!defined('ABSPATH')) {
    exit;
}

// SECURITY CHECK (VERY IMPORTANT)
if (!isset($_GET['key']) || $_GET['key'] !== 'pulsepoint') {
    http_response_code(403);
    exit('Unauthorized');
}

// Load cron jobs
require_once plugin_dir_path(__FILE__) . 'cron-loader.php';

// Run cron dispatcher
do_action('pulsepoint_run_cron');

echo json_encode([
    'status' => 'success',
    'message' => 'Pulsepoint cron executed',
    'time' => current_time('mysql')
]);
exit;