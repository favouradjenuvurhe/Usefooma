<?php

if (!defined('ABSPATH')) exit;

// Load all cron job modules
require_once __DIR__ . '/jobs/transactions-cron.php';
require_once __DIR__ . '/jobs/cleanup-cron.php';
require_once __DIR__ . '/jobs/analysis-data.php';
require_once __DIR__ . '/jobs/airtime-jobs.php';
require_once __DIR__ . '/jobs/data-jobs.php';
require_once __DIR__ . '/jobs/xixapay-card.php';
require_once __DIR__ . '/jobs/fraud-detection.php';
require_once __DIR__ . '/jobs/license-check.php';
require_once __DIR__ . '/jobs/smm-sync.php';
require_once __DIR__ . '/jobs/smm-status.php';

/**
 * MASTER CRON RUNNER
 */
add_action('pulsepoint_run_cron', function () {

    do_action('pulsepoint_cron_transactions');
    do_action('pulsepoint_cron_cleanup');
    do_action('pulsepoint_analysis_data');
    do_action('pulsepoint_airtime_scheduler');
    do_action('pulsepoint_data_scheduler');
    do_action('pulsepoint_xixapay_card_refresh');   
    do_action('pulsepoint_fraud_detection');
    do_action('pulsepoint_cron_license_check');
    do_action('pulsepoint_cron_smm_sync');
    do_action('pulsepoint_cron_smm_status');

});