Pulsepoint - Bill Payment (Plugin) - Base Test
--------------------------------------------------
What this test plugin does:
- Provides a front-end dashboard accessible at /app
- Adds an admin menu in WP admin called "Pulsepoint"
- Minimal, framework-free code so you can install and test quickly

Installation:
1. Upload pulsepoint-bill-payment.zip into Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to Settings > Permalinks and click "Save Changes" to flush rewrite rules (required).
4. Visit https://your-site.example/app

Notes:
- This is a minimal scaffold. To integrate Laravel components later, add Composer and initialize Illuminate packages inside the plugin folder, then update includes/public.php to bootstrap them.
