<?php
/**
 * AJAX Handler: Save License after Paystack Payment
 * Path: /wp-content/plugins/pulsepoint-bill-payment/base/license.php
 * Updated to use license_key from API
 */

if (!defined('ABSPATH')) exit;

// Register AJAX actions
add_action('wp_ajax_pulsepoint_save_license', 'pulsepoint_save_license');
add_action('wp_ajax_nopriv_pulsepoint_save_license', 'pulsepoint_save_license');

function pulsepoint_save_license() {
    // Required fields
    if (!isset($_POST['name'], $_POST['plan'], $_POST['reference'], $_POST['license_key'])) {
        wp_send_json(['status' => 'error', 'message' => 'Missing required fields.']);
    }

    $name        = sanitize_text_field($_POST['name']);
    $email       = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $phone       = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $plan        = sanitize_text_field($_POST['plan']);
    $reference   = sanitize_text_field($_POST['reference']);
    $license_key = sanitize_text_field($_POST['license_key']);
    $domain      = preg_replace('#^https?://#', '', $_SERVER['SERVER_NAME']);

    $license_data = [
        'name'        => $name,
        'email'       => $email,
        'phone'       => $phone,
        'plan'        => $plan,
        'reference'   => $reference,
        'domain'      => $domain,
        'license_key' => $license_key,
        'created_at'  => current_time('mysql'),
    ];

    // Ensure base directory exists
    $base_dir = plugin_dir_path(__FILE__);
    if (!is_dir($base_dir)) {
        if (!mkdir($base_dir, 0755, true)) {
            wp_send_json(['status' => 'error', 'message' => 'Failed to create base directory.']);
        }
    }

    // Path to license.txt
    $license_file = $base_dir . 'license.txt';

    // Save serialized data
    $saved = file_put_contents($license_file, maybe_serialize($license_data));

    if ($saved !== false) {
        wp_send_json([
            'status' => 'success',
            'message' => 'License saved successfully.',
            'data' => $license_data
        ]);
    } else {
        wp_send_json([
            'status' => 'error',
            'message' => 'Failed to save license.txt. Ensure folder is writable.'
        ]);
    }
}