<?php
if (!defined('ABSPATH')) {
    exit;
}

class Pulsepoint_Core
{
    /**
     * Initialize tracking and display message
     */
    public static function boot()
    {
        // Track site visits and load speed
        self::track_site_metrics();

        // Display Yoma Bot message
        add_action('admin_notices', function () {
            $total_visits = self::get_total_visits();
            $today_visits = self::get_today_visits();
            $avg_speed    = self::get_average_load_speed();

            $speed_message = $avg_speed > 2
                ? "😔 The site is a bit slow and users might be leaving."
                : "😊 The site is running smoothly.";

            echo '<div class="notice notice-info" style="padding:15px; font-size:14px;">';
            echo '<strong>Howdy, I\'m Yoma Bot, your plugin auto support!</strong><br>';
            echo "Total website views: <strong>{$total_visits}</strong><br>";
            echo "Total visits today: <strong>{$today_visits}</strong><br>";
            echo "Average load time: <strong>{$avg_speed}s</strong> — {$speed_message}";
            echo '</div>';
        });
    }

    /**
     * Track total visits and page load speed
     */
    private static function track_site_metrics()
    {
        global $wpdb;

        $table = $wpdb->base_prefix . 'pulsepoint_metrics';

        // Create table if not exists
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            visit_date DATETIME NOT NULL,
            load_time FLOAT NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        // Page load time in seconds
        $start_time = $_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true);
        $end_time   = microtime(true);
        $load_time  = round($end_time - $start_time, 4);

        // Insert visit
        $wpdb->insert($table, [
            'visit_date' => current_time('mysql'),
            'load_time'  => $load_time,
        ], ['%s', '%f']);
    }

    /**
     * Get total visits
     */
    public static function get_total_visits()
    {
        global $wpdb;
        $table = $wpdb->base_prefix . 'pulsepoint_metrics';
        return intval($wpdb->get_var("SELECT COUNT(*) FROM $table"));
    }

    /**
     * Get total visits today
     */
    public static function get_today_visits()
    {
        global $wpdb;
        $table = $wpdb->base_prefix . 'pulsepoint_metrics';
        $today_start = date('Y-m-d 00:00:00');
        $today_end   = date('Y-m-d 23:59:59');
        return intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE visit_date BETWEEN %s AND %s",
            $today_start,
            $today_end
        )));
    }

    /**
     * Get average load speed
     */
    public static function get_average_load_speed()
    {
        global $wpdb;
        $table = $wpdb->base_prefix . 'pulsepoint_metrics';
        return round(floatval($wpdb->get_var("SELECT AVG(load_time) FROM $table")), 3);
    }
}