<?php
if (!defined('ABSPATH')) exit;

/**
 * Detect active Pulsepoint theme plugin
 */
if (!function_exists('pulsepoint_get_theme_path')) {
function pulsepoint_get_theme_path() {

    $plugins = get_option('active_plugins');

    foreach ($plugins as $plugin) {

        // detect plugins like pulsepoint-oceanpay-theme
        if (strpos($plugin, 'pulsepoint-') !== false && strpos($plugin, '-theme') !== false) {

            $folder = dirname($plugin);

            return WP_PLUGIN_DIR . '/' . $folder . '/';
        }
    }

    return false;
}
}

/**
 * Return correct theme file (custom OR fallback)
 * $file example: 'view/default/dashboard.php'
 */
if (!function_exists('pulsepoint_theme_file')) {
function pulsepoint_theme_file($file) {

    // custom theme plugin path
    $custom_theme = pulsepoint_get_theme_path();

    if ($custom_theme) {

        $custom_file = $custom_theme . $file;

        if (file_exists($custom_file)) {
            return $custom_file;
        }
    }

    // default fallback: includes/app/view/default/{file}
    $default_file = __DIR__ . '/app/' . $file;

    if (file_exists($default_file)) {
        return $default_file;
    }

    return false;
}
}