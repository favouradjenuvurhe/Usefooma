<?php
/**
 * Pulsepoint Shared Email Helper
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/email-helper.php
 * Author: Amaaavl
 *
 * One shared, branded HTML email template (templates/transaction.html) used
 * by every callback webhook (PaymentPoint, Cashwyre, NCWallet, StroWallet,
 * StroPay, StroCard, WhoGoPay, XixaPay, Google Auth, etc.) and by cron jobs
 * such as fraud detection — the same visual style already used for
 * airtime/data purchase emails, instead of each webhook building its own
 * inline HTML string.
 */

if (!defined('ABSPATH')) exit;

/**
 * Load platform settings (platform_name, color_hex, support email) once,
 * with sane fallbacks if the settings table isn't reachable for some reason.
 */
if (!function_exists('pulsepoint_email_settings')) {
    function pulsepoint_email_settings(): array {
        global $wpdb;

        $base_prefix = $wpdb->prefix . 'pulsepoint_';
        $table       = $base_prefix . 'settings';

        $defaults = [
            'platform_name' => 'Pulsepoint',
            'color_hex'     => '#356cf9',
            'email_number'  => get_option('admin_email'),
        ];

        $rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table} WHERE opt_key IN ('platform_name','color_hex','email_number')");

        if ($rows) {
            foreach ($rows as $row) {
                $value = maybe_unserialize($row->opt_value);
                if ($value !== '' && $value !== null) {
                    $defaults[$row->opt_key] = $value;
                }
            }
        }

        return $defaults;
    }
}

/**
 * Build the {{rows}} table-row HTML from a simple label => value array.
 * Keeps every webhook's email consistent without repeating markup.
 *
 * Example:
 *   pulsepoint_build_email_rows([
 *       'Amount'    => '₦' . number_format($amount, 2),
 *       'Reference' => $reference,
 *       'Date'      => date('Y-m-d H:i:s'),
 *   ]);
 */
if (!function_exists('pulsepoint_build_email_rows')) {
    function pulsepoint_build_email_rows(array $pairs): string {
        $html  = '';
        $first = true;

        foreach ($pairs as $label => $value) {
            if ($value === null || $value === '') continue;

            $border = $first ? '' : 'border-top:1px solid #f2f2f2;';
            $first  = false;

            $safe_label = htmlspecialchars((string) $label, ENT_QUOTES, 'UTF-8');
            $safe_value = htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');

            $html .= '<tr>'
                . '<td style="padding:10px 0; font-size:13px; color:#888888; ' . $border . '">' . $safe_label . '</td>'
                . '<td style="padding:10px 0; font-size:13px; color:#1a1a1a; text-align:right; font-weight:600; ' . $border . '">' . $safe_value . '</td>'
                . '</tr>';
        }

        return $html;
    }
}

/**
 * Render templates/transaction.html with escaped values.
 * `message` and `rows` are allowed to contain HTML (they're built by us),
 * every other placeholder is escaped.
 */
if (!function_exists('pulsepoint_render_transaction_email')) {
    function pulsepoint_render_transaction_email(array $vars): string {

        $template_path = dirname(__DIR__) . '/templates/transaction.html';

        if (!file_exists($template_path)) {
            return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
        }

        $html = file_get_contents($template_path);

        $settings = pulsepoint_email_settings();

        $defaults = [
            'platform_name' => $settings['platform_name'],
            'color_hex'     => $settings['color_hex'],
            'status_label'  => '',
            'status_color'  => '#6C63FF',
            'heading'       => '',
            'firstname'     => '',
            'message'       => '',
            'rows'          => '',
            'date'          => date('Y-m-d H:i:s'),
            'year'          => date('Y'),
            'support_email' => $settings['email_number'],
        ];

        $vars = array_merge($defaults, $vars);

        foreach ($vars as $key => $value) {
            $raw_keys = ['message', 'rows'];
            $safe = in_array($key, $raw_keys, true)
                ? $value
                : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
            $html = str_replace('{{' . $key . '}}', $safe, $html);
        }

        return $html;
    }
}

/**
 * Render + send in one call. Never throws — webhook flows must not break
 * because a notification email failed; failures are just swallowed like
 * the existing @wp_mail(...) calls did.
 *
 * $vars accepts the same keys as pulsepoint_render_transaction_email(),
 * plus you can pass 'details' (label => value array) instead of a
 * pre-built 'rows' string and it will be converted automatically.
 */
if (!function_exists('pulsepoint_send_transaction_email')) {
    function pulsepoint_send_transaction_email(string $to, string $subject, array $vars): bool {

        if (empty($to) || !is_email($to)) {
            return false;
        }

        if (empty($vars['rows']) && !empty($vars['details']) && is_array($vars['details'])) {
            $vars['rows'] = pulsepoint_build_email_rows($vars['details']);
        }
        unset($vars['details']);

        $body = pulsepoint_render_transaction_email($vars);

        return (bool) @wp_mail($to, $subject, $body, ['Content-Type: text/html; charset=UTF-8']);
    }
}

/**
 * Convenience wrapper: sends the same event to both the user and the
 * platform admin in one call, with slightly different headings/messages
 * for each side (admin email is more of an internal log, user email is
 * the customer-facing notice).
 */
if (!function_exists('pulsepoint_notify_transaction')) {
    function pulsepoint_notify_transaction(array $args): void {

        $settings      = pulsepoint_email_settings();
        $platform_name = $settings['platform_name'];
        $admin_email   = $settings['email_number'];

        $status_label = $args['status_label'] ?? 'SUCCESS';
        $status_color = $args['status_color'] ?? '#22c55e';
        $details      = $args['details'] ?? [];

        if (!empty($args['user_email'])) {
            pulsepoint_send_transaction_email(
                $args['user_email'],
                $args['user_subject'] ?? ($platform_name . ' — ' . ($args['heading'] ?? 'Transaction Update')),
                [
                    'status_label' => $status_label,
                    'status_color' => $status_color,
                    'heading'      => $args['heading'] ?? 'Transaction Update',
                    'firstname'    => $args['firstname'] ?? 'there',
                    'message'      => $args['user_message'] ?? ($args['message'] ?? ''),
                    'details'      => $details,
                ]
            );
        }

        if (!empty($args['notify_admin']) && !empty($admin_email)) {
            pulsepoint_send_transaction_email(
                $admin_email,
                $args['admin_subject'] ?? ($platform_name . ' — ' . ($args['heading'] ?? 'Transaction Update') . ' (Admin Copy)'),
                [
                    'status_label' => $status_label,
                    'status_color' => $status_color,
                    'heading'      => $args['heading'] ?? 'Transaction Update',
                    'firstname'    => 'Admin',
                    'message'      => $args['admin_message'] ?? ($args['message'] ?? ''),
                    'details'      => $details,
                ]
            );
        }
    }
}
