<?php
// Block direct access
if (!defined('ABSPATH')) {
    exit('Direct access not allowed.');
}

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Determine current request path (strip query string)
$request_path = strtok($_SERVER['REQUEST_URI'], '?');

// Auth routes are always public — everything else requires login
$is_auth_route = (strpos($request_path, '/auth/') !== false || rtrim($request_path, '/') === '/auth');

if (!$is_auth_route && empty($_SESSION['pulsepoint_user']['id'])) {
    wp_safe_redirect(home_url('/auth/login'));
    exit;
}

// Load read-only data
require_once __DIR__ . '/Controller/labs.php';

// Page information
$page_title = 'Dashboard (' . $platform_name . ')';
$page_description = 'Manage your wallet, transactions, virtual cards and digital services.';
$page_favicon     = !empty($favicon_url)
    ? $favicon_url
    : get_site_icon_url();