<?php
/**
 * Pulsepoint Email Verification View
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/../index.php';

// Fixed prefixes per the current router: /auth/{route} and /dashboard
$pp_login_url     = home_url('/auth/login');
$pp_dashboard_url = home_url('/dashboard');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($page_title); ?></title>

    <!-- =====================================================
         Theme engine (light / dark / system)
         Same engine used on the dashboard, duplicated here since
         this page is served standalone (before login, so it can't
         rely on dashboard.php's <head>). Runs first, before
         anything paints, and reads/writes the same "pp-theme" key
         in localStorage — so a choice made here carries over once
         the person signs in, and vice versa.
         ===================================================== -->
    <meta name="color-scheme" content="light dark">
    <script>
    (function () {

        var STORAGE_KEY = 'pp-theme';
        var mql = window.matchMedia('(prefers-color-scheme: dark)');

        function systemTheme() {
            return mql.matches ? 'dark' : 'light';
        }

        function getMode() {
            try {
                return localStorage.getItem(STORAGE_KEY) || 'system';
            } catch (e) {
                return 'system';
            }
        }

        function resolveTheme(mode) {
            mode = mode || getMode();
            return mode === 'system' ? systemTheme() : mode;
        }

        function applyTheme(mode) {

            mode = mode || getMode();

            var resolved = resolveTheme(mode);

            document.documentElement.setAttribute('data-theme', resolved);
            document.documentElement.setAttribute('data-theme-mode', mode);

            var meta = document.querySelector('meta[name="theme-color"]');

            if (meta) {

                if (!meta.dataset.ppLightColor) {
                    meta.dataset.ppLightColor = meta.getAttribute('content') || '#ffffff';
                }

                meta.setAttribute('content', resolved === 'dark' ? '#0B1220' : meta.dataset.ppLightColor);

            }

            document.dispatchEvent(new CustomEvent('pp-theme-change', {
                detail: { mode: mode, resolved: resolved }
            }));

        }

        function setMode(mode) {

            try {

                if (mode === 'system') {
                    localStorage.removeItem(STORAGE_KEY);
                } else {
                    localStorage.setItem(STORAGE_KEY, mode);
                }

            } catch (e) {}

            applyTheme(mode);

        }

        applyTheme(getMode());

        if (mql.addEventListener) {
            mql.addEventListener('change', function () {
                if (getMode() === 'system') applyTheme('system');
            });
        } else if (mql.addListener) {
            mql.addListener(function () {
                if (getMode() === 'system') applyTheme('system');
            });
        }

        window.PPTheme = {
            get: getMode,
            resolved: function () { return resolveTheme(getMode()); },
            set: setMode
        };

    })();
    </script>

    <!-- SEO -->
    <meta name="description" content="Verify your email">
    <meta name="theme-color" content="<?php echo esc_attr($color_hex); ?>">

    <!-- Favicon -->
    <link rel="icon" href="<?php echo esc_url($page_favicon); ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: "<?php echo esc_js($color_hex); ?>",
                        secondary: "#111827",
                        success: "#16A34A",
                        warning: "#F59E0B",
                        danger: "#DC2626",
                        surface: "#F8FAFC"
                    }
                }
            }
        };
    </script>

    <!-- Hugeicons -->
    <script src="https://cdn.jsdelivr.net/npm/@hugeicons/core@latest/dist/hugeicons.min.js"></script>

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <!-- Alpine JS -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            background: #F8FAFC;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        html, body {
            height: 100%;
            overscroll-behavior: none;
            -webkit-text-size-adjust: 100%;
        }

        .btn-primary {
            background: #f85902;
            color: #fff;
        }

        .fa-spin {
            animation: faSpin 0.8s linear infinite;
        }

        @keyframes faSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /* =====================================================
           Dark / Light theme
           Controlled by <html data-theme="light|dark">, set by the
           theme engine script above. Every class below already
           exists in this page's markup — nothing here changes the
           HTML, it only remaps what those classes render as once
           data-theme="dark" is set, and reverts automatically when
           it's "light".
           ===================================================== */
        :root{
            --pp-bg:#F8FAFC;
            --pp-surface:#FFFFFF;
            --pp-surface-muted:#F9FAFB;
            --pp-surface-hover:#F3F4F6;
            --pp-border-300:#D1D5DB;
            --pp-text-900:#111827;
            --pp-text-800:#1F2937;
            --pp-text-700:#374151;
            --pp-text-600:#4B5563;
            --pp-text-400:#9CA3AF;
        }

        html[data-theme="dark"]{
            --pp-bg:#0B1220;
            --pp-surface:#131C2E;
            --pp-surface-muted:#182236;
            --pp-surface-hover:#1D2A40;
            --pp-border-300:#324162;
            --pp-text-900:#F1F5F9;
            --pp-text-800:#E2E8F0;
            --pp-text-700:#CBD5E1;
            --pp-text-600:#AAB8CC;
            --pp-text-400:#6B7B98;
        }

        html[data-theme="dark"] body{
            background:var(--pp-bg);
        }

        html[data-theme="dark"] .bg-surface{ background-color:var(--pp-bg) !important; }
        html[data-theme="dark"] .bg-white{ background-color:var(--pp-surface) !important; }
        html[data-theme="dark"] .bg-gray-100{ background-color:var(--pp-surface-hover) !important; }

        html[data-theme="dark"] .border-gray-300{ border-color:var(--pp-border-300) !important; }

        html[data-theme="dark"] .text-gray-900{ color:var(--pp-text-900) !important; }
        html[data-theme="dark"] .text-gray-800{ color:var(--pp-text-800) !important; }
        html[data-theme="dark"] .text-gray-700{ color:var(--pp-text-700) !important; }
        html[data-theme="dark"] .text-gray-600{ color:var(--pp-text-600) !important; }
        html[data-theme="dark"] .text-gray-400{ color:var(--pp-text-400) !important; }
        html[data-theme="dark"] .placeholder-gray-400::placeholder{ color:var(--pp-text-400) !important; }

        /* Status toasts / badges (success, error, warning) */
        html[data-theme="dark"] .bg-green-50{ background-color:rgba(74,222,128,0.16) !important; }
        html[data-theme="dark"] .text-green-700{ color:#86EFAC !important; }
        html[data-theme="dark"] .border-green-300{ border-color:rgba(74,222,128,0.4) !important; }

        html[data-theme="dark"] .bg-red-50{ background-color:rgba(248,113,113,0.16) !important; }
        html[data-theme="dark"] .text-red-700{ color:#FCA5A5 !important; }
        html[data-theme="dark"] .border-red-300{ border-color:rgba(248,113,113,0.4) !important; }

        html[data-theme="dark"] .bg-yellow-50{ background-color:rgba(250,204,21,0.16) !important; }
        html[data-theme="dark"] .text-yellow-700{ color:#FDE047 !important; }
        html[data-theme="dark"] .border-yellow-300{ border-color:rgba(250,204,21,0.4) !important; }

        /* Smooth, non-jarring switch */
        body, .bg-white, .bg-gray-100, .text-gray-900, .text-gray-800,
        .text-gray-700, .text-gray-600, .text-gray-400, .border-gray-300{
            transition:background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
        }

    </style>

</head>

<body class="bg-surface" x-data="verifyForm()">

    <!-- Toast container -->
    <div id="toast-container"
         class="fixed top-4 inset-x-0 z-50 flex flex-col items-center gap-2 px-4 pointer-events-none"></div>

    <div class="min-h-screen flex flex-col">

        <!-- Header block -->
        <div class="bg-gray-100 px-6 pt-10 pb-8">

            <div class="flex items-center justify-between mb-5">

                <button type="button"
                        onclick="window.history.back()"
                        class="h-9 w-9 rounded-lg border border-gray-300 flex items-center justify-center text-gray-700">
                    <iconify-icon icon="hugeicons:arrow-left-01" width="14" height="14"></iconify-icon>
                </button>

            </div>

            <h1 class="text-xl font-bold text-gray-900">Verify your email</h1>
            <p class="text-sm text-gray-400 mt-1">Enter the 6-digit code we sent to your email</p>

        </div>

        <!-- Body -->
        <div class="flex-1 flex flex-col px-6 pt-6 pb-8">

            <form @submit.prevent="verify" class="flex-1 flex flex-col">

                <div class="space-y-3">

                    <!-- Code -->
                    <div class="flex items-center gap-2.5 bg-gray-100 rounded-xl px-3.5 py-3">
                        <iconify-icon icon="hugeicons:message-02" width="16" height="16" class="text-gray-400"></iconify-icon>
                        <input type="text"
                               x-model="code"
                               inputmode="numeric"
                               pattern="[0-9]*"
                               maxlength="6"
                               required
                               autocomplete="one-time-code"
                               aria-label="Verification code"
                               class="flex-1 bg-transparent outline-none text-sm text-gray-800 placeholder-gray-400 tracking-[0.3em]"
                               placeholder="123456"
                               @input="code = code.replace(/[^0-9]/g, '').slice(0, 6)">
                    </div>

                    <!-- Resend -->
                    <div class="flex justify-end pt-0.5">
                        <button type="button"
                                @click="resendOtp"
                                :disabled="resendDisabled"
                                class="text-xs font-semibold text-primary disabled:text-gray-400 disabled:cursor-not-allowed"
                                x-text="resendText">
                        </button>
                    </div>

                    <!-- Continue -->
                    <button
                        type="submit"
                        :disabled="loading || code.length !== 6"
                        class="w-full bg-primary text-white rounded-full py-3.5 text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed mt-4">
                        <iconify-icon icon="hugeicons:reload" width="14" height="14" class="fa-spin" x-show="loading"></iconify-icon>
                        <span x-text="loading ? 'Verifying...' : 'Verify'"></span>
                    </button>

                    <!-- Back to login -->
                    <p class="text-center text-xs text-gray-600 mt-5">
                        Wrong account?
                        <a href="<?php echo esc_url($pp_login_url); ?>" class="text-primary font-bold">Sign in again</a>
                    </p>

                </div>

            </form>

        </div>

    </div>

    <script>
        // ---- Theme toggle icon sync ----
        (function () {
            function syncThemeToggleIcon() {
                var el = document.getElementById('themeToggleIcon');
                if (!el || !window.PPTheme) return;
                el.setAttribute('icon', window.PPTheme.resolved() === 'dark' ? 'hugeicons:sun-03' : 'hugeicons:moon-02');
            }
            window.togglePPTheme = function () {
                var next = (window.PPTheme && window.PPTheme.resolved() === 'dark') ? 'light' : 'dark';
                if (window.PPTheme) window.PPTheme.set(next);
            };
            document.addEventListener('pp-theme-change', syncThemeToggleIcon);
            document.addEventListener('DOMContentLoaded', syncThemeToggleIcon);
        })();
    </script>

    <script>
        // ---- Toast system ----
        function showToast(message, type = 'success') {
            const colors = {
                success: { bg: 'bg-green-50', border: 'border-green-300', text: 'text-green-700', icon: 'hugeicons:checkmark-circle-02' },
                error:   { bg: 'bg-red-50',   border: 'border-red-300',   text: 'text-red-700',   icon: 'hugeicons:cancel-circle' },
                warning: { bg: 'bg-yellow-50',border: 'border-yellow-300',text: 'text-yellow-700', icon: 'hugeicons:alert-02' }
            };

            const style = colors[type] || colors.success;
            const container = document.getElementById('toast-container');

            if (!container) return;

            const toast = document.createElement('div');
            toast.className = `pointer-events-auto flex items-center gap-2 ${style.bg} ${style.border} ${style.text} border rounded-xl px-4 py-3 shadow-lg text-sm font-medium max-w-sm w-full transition-all duration-300 ease-out opacity-0 -translate-y-4`;
            toast.innerHTML = `
                <iconify-icon icon="${style.icon}" width="18" class="shrink-0"></iconify-icon>
                <span class="flex-1">${message}</span>
            `;

            container.appendChild(toast);

            requestAnimationFrame(() => {
                toast.classList.remove('opacity-0', '-translate-y-4');
            });

            setTimeout(() => {
                toast.classList.add('opacity-0', '-translate-y-4');
                setTimeout(() => toast.remove(), 300);
            }, 3500);
        }

        // ---- Verification form ----
        function verifyForm() {
            return {
                code: '',
                loading: false,
                resendDisabled: false,
                resendText: 'Resend code',
                countdown: 30,

                async verify() {
                    if (this.code.length !== 6) {
                        showToast('Enter a valid 6-digit code', 'error');
                        return;
                    }

                    this.loading = true;

                    const formData = new FormData();
                    formData.append('action', 'pulsepoint_email_verify');
                    formData.append('code', this.code);

                    try {
                        const res = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                            method: 'POST',
                            body: formData,
                            credentials: 'same-origin',
                        });

                        const data = await res.json();
                        this.loading = false;

                        if (data.success) {
                            showToast(data.message || 'Email verified', 'success');

                            const redirectTo = data.redirect || '<?php echo esc_url($pp_dashboard_url); ?>';

                            setTimeout(() => {
                                window.location.href = redirectTo;
                            }, 800);
                        } else {
                            showToast(data.message || 'Invalid or expired code', 'error');
                        }
                    } catch (err) {
                        this.loading = false;
                        showToast('Network error, please try again', 'error');
                    }
                },

                async resendOtp() {
                    if (this.resendDisabled) return;

                    this.resendDisabled = true;
                    this.resendText = 'Resending...';

                    const formData = new FormData();
                    formData.append('action', 'pulsepoint_resend_otp');

                    try {
                        const res = await fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                            method: 'POST',
                            body: formData,
                            credentials: 'same-origin',
                        });

                        const data = await res.json();

                        if (data.success) {
                            showToast(data.message || 'Code resent', 'success');
                            this.startCountdown();
                        } else {
                            showToast(data.message || 'Could not resend code', 'error');
                            this.resendDisabled = false;
                            this.resendText = 'Resend code';
                        }
                    } catch (err) {
                        showToast('Network error, please try again', 'error');
                        this.resendDisabled = false;
                        this.resendText = 'Resend code';
                    }
                },

                startCountdown() {
                    let sec = this.countdown;
                    this.resendText = `Resend in ${sec}s`;
                    const timer = setInterval(() => {
                        sec--;
                        if (sec <= 0) {
                            clearInterval(timer);
                            this.resendDisabled = false;
                            this.resendText = 'Resend code';
                        } else {
                            this.resendText = `Resend in ${sec}s`;
                        }
                    }, 1000);
                }
            };
        }
    </script>

</body>
</html>
