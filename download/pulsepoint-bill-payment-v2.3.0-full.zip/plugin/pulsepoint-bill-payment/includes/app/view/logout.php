<?php
/**
 * View wrapper for the /auth/logout route.
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/app/view/logout.php
 *
 * IMPORTANT: this file does NOT declare pulsepoint_expire_cookie() or
 * pulsepoint_user_logout() — those live in core/logout.php only. This
 * file's previous version redeclared them, which caused:
 *   PHP Fatal error: Cannot redeclare pulsepoint_expire_cookie()
 * and had a syntax error (unclosed brace/tag) causing the parse error
 * at line 20. Replacing the whole file removes both problems at once.
 *
 * If your router already calls pulsepoint_user_logout() directly and
 * never includes this file, you can delete this file entirely instead.
 * Keep it only if something in your route dispatch still points at
 * includes/app/view/logout.php specifically.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file access
}

// Make sure core/logout.php has been loaded (it should already be
// required by your plugin bootstrap — this is just a safety net).
if (!function_exists('pulsepoint_user_logout')) {
    require_once dirname(__DIR__, 3) . '/core/logout.php';
}

pulsepoint_user_logout();
