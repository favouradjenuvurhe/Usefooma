<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/../index.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Iconify -->
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: "<?php echo esc_js($color_hex); ?>",
                    }
                }
            }
        }
    </script>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Inter',sans-serif;
        }

        body{
            background:#F8FAFC;
        }

        @keyframes notFoundFade{
            0%{
                opacity:0;
                transform:translateY(16px) scale(.96);
            }
            100%{
                opacity:1;
                transform:translateY(0) scale(1);
            }
        }

        @keyframes notFoundBounce{
            0%,100%{
                transform:translateY(0);
            }
            50%{
                transform:translateY(-8px);
            }
        }

        .nf-wrap{
            animation:notFoundFade .4s ease-out both;
        }

        .nf-number{
            animation:notFoundBounce 2s ease-in-out infinite;
        }
    </style>
</head>

<body>

<div class="min-h-screen flex items-center justify-center px-6">

    <div class="nf-wrap text-center">

        <div class="nf-number text-[72px] font-extrabold text-primary leading-none">
            404
        </div>

        <p class="mt-4 text-sm text-gray-500 leading-relaxed max-w-[260px]">
                      Hi, I'm Usefooma — looks like I wandered off. page isn't ready yet.
                    </p>

        <a href="/dashboard"
           class="mt-8 inline-flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-full font-semibold hover:opacity-90 transition">

            <iconify-icon icon="hugeicons:home-09" width="20"></iconify-icon>
            Go Home

        </a>

    </div>

</div>

</body>
</html>