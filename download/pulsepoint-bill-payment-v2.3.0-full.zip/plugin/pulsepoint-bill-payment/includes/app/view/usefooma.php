<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Pulsepoint — Unauthorized / Invalid License View
 * Path: includes/app/view/usefooma.php
 * Author: Amaaavl
 *
 * Rendered instead of the normal app whenever the license-check cron
 * (cron/jobs/license-check.php) has marked this domain's subscription
 * as invalid. Deliberately self-contained — it does NOT require
 * includes/app/index.php, since that file redirects logged-out visitors
 * to /auth/login, which would just loop back into this same page.
 */

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings WHERE opt_key IN ('platform_name','color_hex')");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Usefooma';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

status_header(503);
nocache_headers();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized Access — <?php echo esc_html($platform_name); ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.iconify.design/iconify-icon/3.0.0/iconify-icon.min.js"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: "<?php echo esc_js($color_hex); ?>",
                    }
                }
            }
        }
    </script>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Inter',sans-serif;
        }

        body{
            background:#F8FAFC;
        }

        @keyframes notFoundFade{
            0%{
                opacity:0;
                transform:translateY(16px) scale(.96);
            }
            100%{
                opacity:1;
                transform:translateY(0) scale(1);
            }
        }

        @keyframes notFoundBounce{
            0%,100%{
                transform:translateY(0);
            }
            50%{
                transform:translateY(-8px);
            }
        }

        .nf-wrap{
            animation:notFoundFade .4s ease-out both;
        }

        .nf-icon{
            animation:notFoundBounce 2s ease-in-out infinite;
        }
    </style>
</head>

<body>

<div class="min-h-screen flex items-center justify-center px-6">

    <div class="nf-wrap text-center">

        <div class="nf-icon flex items-center justify-center mx-auto mb-4 w-20 h-20 rounded-full bg-red-50">
            <iconify-icon icon="hugeicons:shield-key" width="36" style="color:#ef4444;"></iconify-icon>
        </div>

        <div class="text-2xl font-extrabold text-gray-900 leading-none">
            Unauthorized Access
        </div>

        <p class="mt-4 text-sm text-gray-500 leading-relaxed max-w-[280px] mx-auto">
            Hi, I'm <?php echo esc_html($platform_name); ?> — this site's license or subscription is no longer active, so access has been temporarily suspended. Please contact your administrator to resolve this.
        </p>

    </div>

</div>

</body>
</html>
