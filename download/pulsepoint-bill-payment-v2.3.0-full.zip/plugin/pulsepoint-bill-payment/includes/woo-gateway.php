<?php
if (!defined('ABSPATH')) exit;

/**
 * Pulsepoint WooCommerce Payment Gateway
 *
 * BUGS FOUND & FIXED (this is almost certainly why it "never worked"):
 *
 * 1. FATAL ERROR ON CHECKOUT (the main bug): process_payment() called
 *    wc_add_order_item_meta($order_id, ...) — but that function's first
 *    argument is an ORDER ITEM ID (a line item), not an order ID, and it
 *    has been deprecated for years. On current WooCommerce/PHP 8.3 it
 *    either throws a deprecation notice that corrupts the checkout AJAX
 *    JSON response, or is flat out undefined and throws a fatal
 *    "Call to undefined function" error the instant someone clicks
 *    "Place order" with Pulsepoint selected. That alone would make it
 *    look completely broken from day one, even though it shows up fine
 *    in the admin gateway list. Replaced with the proper CRUD call:
 *    $order->update_meta_data() + $order->save().
 *
 * 2. No re-declaration guard around the class. If this file is ever
 *    included twice (a second require in your own bootstrap, a caching
 *    plugin, another add-on including core files, etc.) PHP throws
 *    "Cannot redeclare class WC_Gateway_Pulsepoint" — a fatal error that
 *    can take down the whole site, not just checkout. Now guarded with
 *    class_exists().
 *
 * 3. is_available() hid the gateway whenever WC()->cart was empty or
 *    unset. That's true on the "Pay for order" page (My Account > Orders
 *    > Pay), which doesn't use the cart at all — so a customer paying an
 *    existing unpaid order would never see Pulsepoint as an option.
 *    Standard WooCommerce gateways only check $this->enabled; removed
 *    the cart check.
 *
 * 4. Hooked at 'plugins_loaded' priority 20. WooCommerce's official
 *    gateway skeleton uses priority 11 — just after WooCommerce's own
 *    'plugins_loaded' work at priority 10 — which is the documented-safe
 *    point to guarantee WC_Payment_Gateway exists. 20 usually also
 *    works, but 11 is what WooCommerce's own docs specify, so switched
 *    to that.
 *
 * 5. Added an admin-configurable "Description" field (shown to customers
 *    at checkout under the gateway title) — WC_Payment_Gateway already
 *    prints $this->description automatically, it just was never set.
 *
 * 6. process_payment() now actually charges the Pulsepoint wallet instead
 *    of just marking the order "on-hold" and doing nothing:
 *    - Requires the customer to have an active Pulsepoint session
 *      (logged in via /app/login, same $_SESSION['pulsepoint_user']
 *      your login.php sets) — WooCommerce accounts and Pulsepoint
 *      accounts are separate systems, so this is the only way to know
 *      whose wallet to charge.
 *    - Deducts the order total from wp_pulsepoint_users.wallet with a
 *      single atomic "UPDATE ... WHERE wallet >= amount" query, so two
 *      simultaneous checkouts can't both succeed and push the balance
 *      negative (no separate check-then-update race condition).
 *    - Logs every attempt (success AND insufficient-balance failure) as
 *      a row in wp_pulsepoint_trnx, category 'bill', payment 'wallet',
 *      type 'debit', with the WooCommerce order ID as the reference —
 *      so it shows up in the user's transaction history like any other
 *      Pulsepoint transaction.
 *    - On success, moves the order to 'processing' (not 'on-hold', since
 *      the money has already actually moved) and keeps the session's
 *      cached wallet balance in sync.
 *
 *    NOTE: this assumes your WooCommerce store currency and the wallet
 *    balance are the same currency (e.g. both NGN). If they differ,
 *    the raw order total should NOT be deducted directly — add a
 *    conversion step first.
 */

add_action('plugins_loaded', 'pulsepoint_init_gateway_class', 11);

function pulsepoint_init_gateway_class() {

    if (!class_exists('WC_Payment_Gateway')) return;
    if (class_exists('WC_Gateway_Pulsepoint')) return; // prevent redeclare fatal error

    class WC_Gateway_Pulsepoint extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'usefooma';
            $this->method_title       = 'Usefooma';
            $this->method_description = 'Pay using Usefooma';
            $this->has_fields         = false;

            // Initialize form fields & settings
            $this->init_form_fields();
            $this->init_settings();

            // Enabled as boolean
            $this->enabled     = isset($this->settings['enabled']) && $this->settings['enabled'] === 'yes';
            $this->title       = !empty($this->settings['title']) ? $this->settings['title'] : 'Pulsepoint (Pay)';
            $this->description = $this->settings['description'] ?? '';

            // Save admin options
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        }

        // Admin settings
        public function init_form_fields() {
            $this->form_fields = [
                'enabled' => [
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Usefooma',
                    'default' => 'yes',
                ],
                'title' => [
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'Title customers see during checkout',
                    'default'     => 'Usefooma',
                ],
                'description' => [
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'Text shown to customers under the title at checkout',
                    'default'     => 'Pay securely using your Usefooma.',
                ],
            ];
        }

        // Payment processing
        public function process_payment($order_id) {
            global $wpdb;

            $order = wc_get_order($order_id);

            if (!$order) {
                wc_add_notice('Order could not be found.', 'error');
                return ['result' => 'fail'];
            }

            // === Require an active Pulsepoint session ===
            if (session_status() !== PHP_SESSION_ACTIVE) {
                session_start();
            }

            $pp_user_id = intval($_SESSION['pulsepoint_user']['id'] ?? 0);

            if (!$pp_user_id) {
                wc_add_notice('Please log in to your account before paying with your wallet.', 'error');
                return ['result' => 'fail'];
            }

            $base_prefix = $wpdb->prefix . 'pulsepoint_';
            $users_table = $base_prefix . 'users';
            $trnx_table  = $base_prefix . 'trnx';

            $amount    = (float) $order->get_total();
            $reference = 'WC-' . $order_id . '-' . time();

            if ($amount <= 0) {
                wc_add_notice('Invalid order amount.', 'error');
                return ['result' => 'fail'];
            }

            // === Atomic deduction ===
            // Single UPDATE with the balance check baked into the WHERE
            // clause. If two requests race, only one can affect a row —
            // the second will see rows_affected = 0, exactly like an
            // insufficient balance. This avoids needing a separate
            // "check balance, then update" pair of queries, which would
            // be vulnerable to a race condition (double-spend).
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE `{$users_table}` SET wallet = wallet - %f, updated_at = %s WHERE id = %d AND wallet >= %f",
                    $amount,
                    current_time('mysql', 1),
                    $pp_user_id,
                    $amount
                )
            );

            $deducted = $wpdb->rows_affected === 1;

            if (!$deducted) {
                // Log the failed attempt for the user's transaction history
                $wpdb->insert(
                    $trnx_table,
                    [
                        'user_id'          => $pp_user_id,
                        'details'          => 'WooCommerce order #' . $order_id,
                        'amount'           => $amount,
                        'reference'        => $reference,
                        'payment'          => 'wallet',
                        'category'         => 'bill',
                        'status'           => 'failed',
                        'type'             => 'debit',
                        'gateway_response' => 'Insufficient wallet balance',
                        'description'      => 'Checkout payment for order #' . $order_id,
                        'date'             => current_time('mysql', 1),
                        'updated_at'       => current_time('mysql', 1),
                    ],
                    ['%d','%s','%f','%s','%s','%s','%s','%s','%s','%s','%s','%s']
                );

                wc_add_notice('Insufficient wallet balance.', 'error');
                return ['result' => 'fail'];
            }

            // === Success: log the transaction ===
            $wpdb->insert(
                $trnx_table,
                [
                    'user_id'          => $pp_user_id,
                    'details'          => 'WooCommerce order #' . $order_id,
                    'amount'           => $amount,
                    'reference'        => $reference,
                    'payment'          => 'wallet',
                    'category'         => 'bill',
                    'status'           => 'success',
                    'type'             => 'debit',
                    'gateway_response' => 'Wallet debited successfully',
                    'session'          => session_id(),
                    'description'      => 'Checkout payment for order #' . $order_id,
                    'date'             => current_time('mysql', 1),
                    'updated_at'       => current_time('mysql', 1),
                ],
                ['%d','%s','%f','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s']
            );

            $trnx_id = $wpdb->insert_id;

            // Refresh cached balance for the session
            $new_balance = $wpdb->get_var(
                $wpdb->prepare("SELECT wallet FROM `{$users_table}` WHERE id = %d", $pp_user_id)
            );
            if ($new_balance !== null) {
                $_SESSION['pulsepoint_user']['wallet'] = $new_balance;
            }

            // Money has actually moved, so this goes to processing, not on-hold.
            $order->update_status('processing', 'Paid via Usefooma. Ref: ' . $reference);
            wc_reduce_stock_levels($order_id);

            $order->update_meta_data('_pulsepoint_txn_ref', $reference);
            $order->update_meta_data('_pulsepoint_trnx_id', $trnx_id);
            $order->save();

            if (WC()->cart) {
                WC()->cart->empty_cart();
            }

            return [
                'result'   => 'success',
                'redirect' => $this->get_return_url($order),
            ];
        }

        /**
         * Ensure gateway is available on checkout AND on the
         * "Pay for order" page, which doesn't use the cart at all.
         */
        public function is_available() {
            return (bool) $this->enabled;
        }

        /**
         * Show the customer's current wallet balance under the gateway
         * title at checkout, so they know before they commit to it.
         */
        public function payment_fields() {
            global $wpdb;

            if (!empty($this->description)) {
                echo wpautop(wp_kses_post($this->description));
            }

            if (session_status() !== PHP_SESSION_ACTIVE) {
                session_start();
            }

            $pp_user_id = intval($_SESSION['pulsepoint_user']['id'] ?? 0);

            if ($pp_user_id) {
                $base_prefix = $wpdb->prefix . 'pulsepoint_';
                $balance = $wpdb->get_var(
                    $wpdb->prepare("SELECT wallet FROM `{$base_prefix}users` WHERE id = %d", $pp_user_id)
                );
                if ($balance !== null) {
                    echo '<p>Wallet balance: <strong>' . wc_price((float) $balance) . '</strong></p>';
                }
            } else {
                echo '<p style="color:#a00;">You need to be logged in to your account to pay with your wallet.</p>';
            }
        }
    }
}

// Register gateway with WooCommerce
add_filter('woocommerce_payment_gateways', 'pulsepoint_add_gateway_class');

function pulsepoint_add_gateway_class($methods) {
    $methods[] = 'WC_Gateway_Pulsepoint';
    return $methods;
}
