<?php
/**
 * WasenderAPI Webhook
 * Receives WhatsApp messages, logs them to log.txt, and responds automatically
 */

// === Set headers ===
header("Content-Type: application/json; charset=utf-8");

// === Only accept POST requests ===
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// === Get incoming JSON payload ===
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON']);
    exit;
}

// === Check if it's a message received event ===
if (!isset($data['event']) || $data['event'] !== 'messages.received') {
    http_response_code(200); // Acknowledge other events
    echo json_encode(['success' => true, 'message' => 'Event ignored']);
    exit;
}

// === Extract message info ===
$messageData = $data['data']['messages'];
$senderPhone = $messageData['key']['cleanedSenderPn'] ?? '';
$messageText = $messageData['messageBody'] ?? '';
$messageId   = $messageData['key']['id'] ?? '';
$timestamp   = date("Y-m-d H:i:s");

// === Append message to log.txt ===
$logEntry = "[$timestamp] From: $senderPhone | Message: $messageText | ID: $messageId\n";
file_put_contents(__DIR__ . '/log.txt', $logEntry, FILE_APPEND | LOCK_EX);

// === Respond automatically ===
$apiUrl = "https://www.wasenderapi.com/api/send-message";
$apiKey = "a22b3dba564e092789bb1461b618397fa3cbc536d5ab9dc1d9e921f23300eec1"; // Replace with your API key

$responseText = "Hello! We received your message: \"$messageText\"";

// Prepare payload
$payload = [
    "to" => $senderPhone,
    "text" => $responseText
];

// Send reply via WasenderAPI
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $apiKey",
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$result = curl_exec($ch);
if (curl_errno($ch)) {
    error_log("Curl error: " . curl_error($ch));
}
curl_close($ch);

// === Respond to WasenderAPI webhook request ===
echo json_encode([
    'success' => true,
    'message_received' => $messageText,
    'reply_response' => json_decode($result, true)
]);