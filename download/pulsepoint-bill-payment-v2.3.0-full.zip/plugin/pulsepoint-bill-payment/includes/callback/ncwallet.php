<?php  
/**  
 * NCWallet Virtual Account Webhook Callback  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
  
// === BLOCK NON-POST REQUESTS ===
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {  
    header('Content-Type: application/json');  
    http_response_code(403);  
    echo json_encode([  
        'success' => false,  
        'message' => 'Access forbidden. POST requests only.'  
    ], JSON_PRETTY_PRINT);  
    exit;  
}  
  
header('Content-Type: application/json');  
  
// === STEP 1: READ RAW PAYLOAD ===
$raw = file_get_contents('php://input');  
  
// === STEP 2: FETCH API KEY FROM DB ===
$base_prefix   = $wpdb->prefix . 'pulsepoint_';  
$table_settings = "{$base_prefix}settings";  
  
$apiKey = trim($wpdb->get_var($wpdb->prepare(  
    "SELECT opt_value FROM {$table_settings} WHERE opt_key=%s LIMIT 1",  
    'pay_token'  
)));  
  
if (empty($apiKey)) {  
    http_response_code(500);  
    echo json_encode(['success'=>false,'message'=>'NCWallet API key not set.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 3: VERIFY HASH SIGNATURE ===
$headers  = getallheaders();  
$hashFromNc = $headers['api_key'] ?? '';  
  
$calculatedHash = hash_hmac('sha512', $raw, $apiKey);  
  
if (!hash_equals($calculatedHash, $hashFromNc)) {  
    http_response_code(400);  
    echo json_encode(['success'=>false,'message'=>'Invalid webhook signature.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 4: DECODE JSON ===
$data = json_decode($raw, true);  
if (!is_array($data)) {  
    http_response_code(400);  
    echo json_encode(['success'=>false,'message'=>'Invalid JSON payload.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 5: EXTRACT REQUIRED FIELDS ===
$reference        = sanitize_text_field($data['ref_id'] ?? '');  
$status           = sanitize_text_field($data['status'] ?? '');  
$amount           = floatval($data['amount'] ?? 0);  
$settled_amount   = floatval($data['settled_amount'] ?? 0);  
$bank_name        = sanitize_text_field($data['bank_name'] ?? '');  
$account_name     = sanitize_text_field($data['account_name'] ?? '');  
$account_number   = sanitize_text_field($data['account_number'] ?? '');  
$narration        = sanitize_text_field($data['narration'] ?? '');  
$session_id       = sanitize_text_field($data['session_id'] ?? '');  
$event_type       = sanitize_text_field($data['event_type'] ?? '');  
$datetime         = sanitize_text_field($data['datetime'] ?? '');  
  
if (!$reference || !$account_number || $amount <= 0) {  
    http_response_code(400);  
    echo json_encode(['success'=>false,'message'=>'Incomplete transaction data.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
// === STEP 6: LOG WEBHOOK ===
$log_file = __DIR__ . '/ncwallet-webhook-log.txt';  
file_put_contents($log_file, date('Y-m-d H:i:s') . " | " . $raw . PHP_EOL, FILE_APPEND);  
  
// === STEP 7: DEFINE TABLES ===
$table_account = "{$base_prefix}account";  
$table_users   = "{$base_prefix}users";  
$table_trnx    = "{$base_prefix}trnx";  
  
// === STEP 8: FIND USER ACCOUNT ===
$account = $wpdb->get_row($wpdb->prepare(  
    "SELECT * FROM {$table_account} WHERE number=%s LIMIT 1",  
    $account_number  
));  
  
if (!$account) {  
    echo json_encode(['success'=>false,'message'=>'Account not found.'], JSON_PRETTY_PRINT);  
    exit;  
}  
  
$user_id = intval($account->user_id);  
  
// === STEP 9: PREVENT DUPLICATE TRANSACTIONS ===
$exists = $wpdb->get_var($wpdb->prepare(  
    "SELECT COUNT(*) FROM {$table_trnx} WHERE reference=%s",  
    $reference  
));  
  
if ($exists > 0) {  
    echo json_encode(['success'=>true,'message'=>'Duplicate webhook ignored.'], JSON_PRETTY_PRINT);  
    exit;  
}  

// === LOAD SETTINGS (MOVED UP FOR FEE USAGE) ===
$settings_rows = $wpdb->get_results("SELECT opt_key,opt_value FROM {$table_settings}");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

// === FUNDING FEE ===
$fee_percent = floatval($settings['pay_fee'] ?? 0);
$fee = ($fee_percent > 0) ? ($fee_percent / 100) * $amount : 0;
$credited = max($amount - $fee, 0);

// === STEP 10: CREDIT USER WALLET ===
$wpdb->insert($table_trnx, [  
    'user_id'          => $user_id,  
    'details'          => $narration,  
    'recipient'        => $account_name,  
    'amount'           => $amount,  
    'reference'        => $reference,  
    'payment'          => 'wallet',  
    'category'         => 'funding',  
    'status'           => $status,  
    'type'             => 'credit',  
    'gateway_response' => maybe_serialize($data),  
    'description'      => "₦{$amount} via ({$bank_name}) | fee ₦{$fee}"  
]);  
  
$wpdb->query($wpdb->prepare(  
    "UPDATE {$table_users} SET wallet=wallet+%f WHERE id=%d",  
    $credited,  
    $user_id  
));  
  
// === STEP 11: EMAIL NOTIFICATIONS ===
$platform = $settings['platform_name'] ?? 'Pulsepoint';

$user = $wpdb->get_row($wpdb->prepare(  
    "SELECT firstname,lastname,email FROM {$table_users} WHERE id=%d",  
    $user_id  
));

pulsepoint_notify_transaction([
    'user_email'    => $user->email,
    'firstname'     => $user->firstname,
    'heading'       => 'Wallet Funding',
    'status_label'  => 'CREDITED',
    'status_color'  => '#22c55e',
    'user_message'  => 'Your wallet has been credited.',
    'admin_message' => "New NCWallet funding received.<br><br><strong>User:</strong> {$user->firstname}",
    'details'       => [
        'Amount Funded' => '₦' . number_format((float) $amount, 2),
        'Fee'           => '₦' . number_format((float) $fee, 2),
        'Amount Credited' => '₦' . number_format((float) $credited, 2),
        'Account'       => $account_number,
        'Reference'     => $reference,
    ],
    'notify_admin'  => true,
    'user_subject'  => 'Wallet Credited',
    'admin_subject' => 'New NCWallet Funding',
]);
  
// === STEP 12: RESPONSE ===
echo json_encode([  
    'success'   => true,  
    'message'   => 'Webhook processed successfully.',  
    'reference' => $reference,  
    'credited'  => $credited,
    'fee'       => $fee
], JSON_PRETTY_PRINT);  
  
exit;
?>