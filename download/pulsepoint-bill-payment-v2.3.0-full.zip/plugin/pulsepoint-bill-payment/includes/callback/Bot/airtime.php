<?php

if (!isset($chat_id) || !isset($user_id) || !isset($user)) {
    exit;
}

/**
 * STEP 1: START AIRTIME
 */
if ($user["step"] == "airtime_select_network") {

    $network = strtolower($text);

    if (!in_array($network, ["mtn","airtel","glo","9mobile","1","2","3","4"])) {
        sendMessage($chat_id,
        "❌ Invalid network.

Reply with:
1 - MTN
2 - Airtel
3 - Glo
4 - 9mobile"
        );
        exit;
    }

    // normalize
    $map = [
        "1" => "MTN",
        "2" => "Airtel",
        "3" => "Glo",
        "4" => "9mobile",
        "mtn" => "MTN",
        "airtel" => "Airtel",
        "glo" => "Glo",
        "9mobile" => "9mobile"
    ];

    $user["network"] = $map[$network];
    $user["step"] = "airtime_enter_phone";
    saveUser($user_file, $user);

    sendMessage($chat_id,
    "📲 Enter phone number:"
    );

    exit;
}

/**
 * STEP 2: PHONE NUMBER
 */
if ($user["step"] == "airtime_enter_phone") {

    if (!preg_match('/^[0-9]{10,15}$/', $text)) {
        sendMessage($chat_id,
        "❌ Invalid phone number.

Enter a valid number:"
        );
        exit;
    }

    $user["phone"] = $text;
    $user["step"] = "airtime_enter_amount";
    saveUser($user_file, $user);

    sendMessage($chat_id,
    "💰 Enter amount (e.g 500, 1000, 2000):"
    );

    exit;
}

/**
 * STEP 3: AMOUNT
 */
if ($user["step"] == "airtime_enter_amount") {

    if (!is_numeric($text) || $text < 50) {
        sendMessage($chat_id,
        "❌ Invalid amount.

Minimum is ₦50"
        );
        exit;
    }

    $user["amount"] = $text;
    $user["step"] = "airtime_confirm";
    saveUser($user_file, $user);

    sendMessage($chat_id,
    "🧾 <b>Confirm Airtime Purchase</b>

📡 Network: {$user["network"]}
📲 Phone: {$user["phone"]}
💰 Amount: ₦{$user["amount"]}

Reply YES to confirm or NO to cancel."
    );

    exit;
}

/**
 * STEP 4: CONFIRMATION (DEMO ONLY)
 */
if ($user["step"] == "airtime_confirm") {

    if (strtolower($text) == "yes") {

        $user["step"] = "home";
        saveUser($user_file, $user);

        sendMessage($chat_id,
        "✅ <b>DEMO SUCCESS</b>

📡 Network: {$user["network"]}
📲 Phone: {$user["phone"]}
💰 Amount: ₦{$user["amount"]}

⚠️ This is a demo transaction.
No API connected yet."
        );

        exit;
    }

    if (strtolower($text) == "no") {

        $user["step"] = "home";
        saveUser($user_file, $user);

        sendMessage($chat_id,
        "❌ Airtime cancelled."
        );

        exit;
    }
}