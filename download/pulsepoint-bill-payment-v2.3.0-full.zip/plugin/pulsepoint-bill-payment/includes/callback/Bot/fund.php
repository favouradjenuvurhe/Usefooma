<?php

// Safety check (prevents direct access)
if (!isset($chat_id) || !isset($user_id)) {
    exit;
}

sendMessage($chat_id,
"💳 <b>Fund Wallet</b>

🆔 Your Telegram ID: <code>$user_id</code>

Send money to:

🏦 Bank: PeplePay Bank
💳 Account: 1234567890

After payment, wallet will be credited automatically."
);