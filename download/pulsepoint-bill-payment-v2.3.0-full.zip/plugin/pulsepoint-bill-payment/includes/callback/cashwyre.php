<?php
/**
 * Pulsepoint Dynamic Account Webhook Handler
 * Updates existing transaction and credits user wallet (only if pending)
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

header('Content-Type: application/json');

// === STEP 1: Only POST requests allowed ===
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access forbidden. Only POST allowed.']);
    exit;
}

// === STEP 2: Read webhook payload ===
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

// Support both wrapped and raw payloads
$eventData = $data['eventData'] ?? $data;

// Extract fields safely
$requestId     = sanitize_text_field($eventData['RequestId'] ?? '');
$status        = sanitize_text_field($eventData['Status'] ?? '');
$accountNumber = sanitize_text_field($eventData['AccountNumber'] ?? '');
$bankName      = sanitize_text_field($eventData['BankName'] ?? '');
$amountSettled = floatval($eventData['AmountSettled'] ?? 0);
$amountPaid    = floatval($eventData['AmountPaid'] ?? 0);
$senderName    = sanitize_text_field($eventData['SourceOfPayment'] ?? '');
$fundingMethod = sanitize_text_field($eventData['FundingMethod'] ?? 'bank_transfer');

// Reference priority: accountNumber → requestId
$lookup_reference = $accountNumber ?: $requestId;

if (!$lookup_reference || $amountSettled <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing reference or AmountSettled.']);
    exit;
}

// === STEP 3: Find existing transaction ===
$table_trnx = $wpdb->prefix . 'pulsepoint_trnx';

$existing = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$table_trnx}
         WHERE reference=%s
           AND category='virtual-account'
         LIMIT 1",
        $lookup_reference
    )
);

if (!$existing) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'message' => 'Transaction not found for reference: '.$lookup_reference
    ]);
    exit;
}

// === STEP 3b: Only update if status is pending ===
if ($existing->status === 'success') {
    echo json_encode([
        'success' => true,
        'message' => 'Transaction already processed. No action taken.',
        'reference' => $lookup_reference
    ], JSON_PRETTY_PRINT);
    exit;
}

$user_id = intval($existing->user_id);

// === STEP 4: Calculate funding fee ===
$base_prefix    = $wpdb->prefix . 'pulsepoint_';
$table_settings = "{$base_prefix}settings";

$fundingFeeVal = floatval(
    $wpdb->get_var(
        $wpdb->prepare(
            "SELECT opt_value FROM {$table_settings} WHERE opt_key=%s LIMIT 1",
            'pay_fee'
        )
    )
);

// Round down amount to nearest Naira
$settled_int = floor($amountSettled);

// Fee logic (flat or percentage)
$fee = ($fundingFeeVal >= 30)
    ? $fundingFeeVal
    : ($fundingFeeVal / 100) * $settled_int;

// Final credited amount (rounded)
$credited_amount = max(floor($settled_int - $fee), 0);

// === STEP 5: Update transaction ===
$description = 'Checkout | ' . ($accountNumber ?: $existing->reference);

$wpdb->update(
    $table_trnx,
    [
        'status'           => 'success',
        'amount'           => $settled_int,
        'gateway_response' => json_encode($eventData),
        'description'      => $description
    ],
    ['id' => $existing->id],
    ['%s','%f','%s','%s'],
    ['%d']
);

// === STEP 6: Credit user wallet ===
$table_users = "{$base_prefix}users";

$wpdb->query(
    $wpdb->prepare(
        "UPDATE {$table_users}
         SET wallet = wallet + %f
         WHERE id = %d",
        $credited_amount,
        $user_id
    )
);

// === STEP 7: Notifications ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT firstname, lastname, email FROM {$table_users} WHERE id=%d",
        $user_id
    )
);

$date_time = date('Y-m-d H:i:s');

pulsepoint_notify_transaction([
    'user_email'    => $user->email,
    'firstname'     => $user->firstname,
    'heading'       => 'Dynamic Account Funding',
    'status_label'  => strtoupper($status),
    'status_color'  => '#22c55e',
    'user_message'  => 'Your wallet has been credited.',
    'admin_message' => "Dynamic account funding received.<br><br><strong>User:</strong> {$user->firstname} {$user->lastname}",
    'details'       => [
        'Reference'      => $lookup_reference,
        'Amount Settled' => '₦' . number_format((float) $settled_int, 2),
        'Fee'            => '₦' . number_format((float) $fee, 2),
        'Credited'       => '₦' . number_format((float) $credited_amount, 2),
        'Status'         => $status,
        'Date'           => $date_time,
    ],
    'notify_admin'  => true,
    'user_subject'  => "Wallet Credited on {$platform_name}",
    'admin_subject' => "Dynamic Account Funded on {$platform_name}",
]);

// === STEP 8: Webhook ACK ===
echo json_encode([
    'success'   => true,
    'message'   => 'Wallet funded successfully',
    'reference' => $lookup_reference,
    'credited'  => $credited_amount,
    'fee'       => $fee
], JSON_PRETTY_PRINT);

exit;