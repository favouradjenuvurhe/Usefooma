<?php
/**
 * Whogopay Webhook Callback (Updated for New Payload)
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

// === BLOCK DIRECT ACCESS ===
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'POST only']);
    exit;
}

header('Content-Type: application/json');

// === STEP 1: Read Payload ===
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

// === Log webhook ===
file_put_contents(__DIR__.'/whogopay-log.txt', date('Y-m-d H:i:s')." | ".$raw.PHP_EOL, FILE_APPEND);

// === Validate ===
if (!$data || empty($data['accountNumber']) || empty($data['amount'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid payload']);
    exit;
}

// === STEP 2: Extract Fields (UPDATED) ===
$metadata = $data['metadata'] ?? [];

$reference = sanitize_text_field(
    $data['transactionReference']
    ?? $data['sessionId']
    ?? $data['paymentReference']
    ?? $metadata['paymentReference']
    ?? ''
);

$accountNo   = sanitize_text_field($data['accountNumber']);
$accountName = sanitize_text_field($data['accountName'] ?? $metadata['beneficaryAccountName'] ?? '');
$narration   = sanitize_text_field($data['paymentDescription'] ?? $metadata['narration'] ?? '');

$amount      = floatval($data['amount']);

$sourceName    = sanitize_text_field($data['senderAccountName'] ?? $metadata['originatorAccountName'] ?? '');
$sourceAccount = sanitize_text_field($data['senderAccountNumber'] ?? $metadata['originatorAccountNumber'] ?? '');
$sourceBank    = sanitize_text_field($data['senderBankName'] ?? '');

$status = 'success';

if ($amount <= 0 || empty($accountNo) || empty($reference)) {
    echo json_encode(['success' => false, 'message' => 'Incomplete data']);
    exit;
}

// === TABLES ===
$base = $wpdb->prefix . 'pulsepoint_';
$table_users = "{$base}users";
$table_trnx  = "{$base}trnx";
$table_accnt = "{$base}account";
$table_settings = "{$base}settings";
$table_referrals = "{$base}referrals";

// === FIND ACCOUNT ===
$account = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_accnt} WHERE number = %s LIMIT 1",
    $accountNo
));

if (!$account) {
    echo json_encode(['success' => false, 'message' => 'Account not found']);
    exit;
}

$user_id = intval($account->user_id);

// === DUPLICATE CHECK ===
$exists = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$table_trnx} WHERE reference = %s",
    $reference
));

if ($exists > 0) {
    echo json_encode(['success' => true, 'message' => 'Duplicate ignored']);
    exit;
}

// === GET SETTINGS ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

// === FUNDING FEE ===
$fee_percent = floatval($settings['pay_fee'] ?? 0);
$fee = ($fee_percent > 0) ? ($fee_percent / 100) * $amount : 0;
$credited = max($amount - $fee, 0);

// === INSERT TRANSACTION ===
$wpdb->insert($table_trnx, [
    'user_id'   => $user_id,
    'details'   => $narration,
    'recipient' => $accountName,
    'amount'    => $amount,
    'reference' => $reference,
    'payment'   => 'wallet',
    'category'  => 'funding',
    'status'    => 'success',
    'type'      => 'credit',
    'gateway_response' => maybe_serialize($data),
    'description' => "{$sourceBank} - ₦{$amount} | fee ₦{$fee}"
]);

// === UPDATE WALLET ===
$wpdb->query($wpdb->prepare(
    "UPDATE {$table_users} SET wallet = wallet + %f WHERE id = %d",
    $credited, $user_id
));

// === REFERRAL BONUS (UNCHANGED LOGIC) ===
$ref_amount = floatval($settings['referral_amount'] ?? 200);

$referrer_id = $wpdb->get_var($wpdb->prepare(
    "SELECT referrer_id FROM {$table_referrals} WHERE referee_id = %d",
    $user_id
));

if ($referrer_id) {
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table_trnx} WHERE user_id = %d AND category = 'funding' AND status = 'success'",
        $user_id
    ));

    if ($count >= 3) {

        $bonus_given = $wpdb->get_var($wpdb->prepare(
            "SELECT bonus_given FROM {$table_referrals} WHERE referee_id = %d",
            $user_id
        ));

        if (!$bonus_given) {

            $wpdb->query($wpdb->prepare(
                "UPDATE {$table_users} 
                 SET wallet = wallet + %f, referral_balance = referral_balance + %f 
                 WHERE id = %d",
                $ref_amount, $ref_amount, $referrer_id
            ));

            $wpdb->query($wpdb->prepare(
                "UPDATE {$table_referrals} SET bonus_given = 1 WHERE referee_id = %d",
                $user_id
            ));
        }
    }
}

// === EMAIL NOTIFICATION ===
$user = $wpdb->get_row($wpdb->prepare(
    "SELECT firstname,email FROM {$table_users} WHERE id = %d",
    $user_id
));

pulsepoint_notify_transaction([
    'user_email'   => $user->email,
    'firstname'    => $user->firstname,
    'heading'      => 'Wallet Funding',
    'status_label' => 'CREDITED',
    'status_color' => '#22c55e',
    'user_message' => 'Your wallet has been credited.',
    'details'      => [
        'Amount Credited' => '₦' . number_format((float) $credited, 2),
        'Fee'              => '₦' . number_format((float) $fee, 2),
        'Reference'        => $reference,
    ],
    'user_subject' => 'Wallet Credited',
]);

// === RESPONSE ===
echo json_encode([
    'success' => true,
    'credited' => $credited,
    'fee' => $fee,
    'reference' => $reference
]);
exit;
?>