<?php
/**
 * Pulsepoint Shared Beneficiary Helper
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/beneficiary-helper.php
 * Author: Amaaavl
 *
 * Auto-saves a "recent beneficiary" row after every successful transaction
 * — no user action required, same as how Opay/PalmPay silently remember
 * who/what you last paid. Called from the success path of transfer,
 * airtime, data, cable, electricity, and betting purchase handlers.
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_save_beneficiary')) {
    function pulsepoint_save_beneficiary(int $user_id, string $category, string $identifier, string $label = '', string $sub_label = '', array $meta = []): void {

        if (empty($identifier) || empty($user_id)) {
            return;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'pulsepoint_beneficiaries';

        $wpdb->query($wpdb->prepare(
            "INSERT INTO {$table} (user_id, category, identifier, label, sub_label, meta, last_used, created_at)
             VALUES (%d, %s, %s, %s, %s, %s, NOW(), NOW())
             ON DUPLICATE KEY UPDATE
                label = VALUES(label),
                sub_label = VALUES(sub_label),
                meta = VALUES(meta),
                last_used = NOW()",
            $user_id,
            $category,
            $identifier,
            $label,
            $sub_label,
            maybe_serialize($meta)
        ));
    }
}
