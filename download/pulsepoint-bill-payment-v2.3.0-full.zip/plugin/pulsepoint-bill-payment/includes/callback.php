<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 🔹 Guard against any stray output before headers are sent
 *    (whitespace, BOM, notices from other plugins, etc.) so
 *    session_start() below never fires after headers have gone out.
 */
if (!ob_get_level()) {
    ob_start();
}

/**
 * 🔹 Add query var for callback
 */
add_filter('query_vars', function ($vars) {
    $vars[] = 'pulsepoint_callback';
    return $vars;
});

/**
 * 🔹 Add rewrite rules for callback URLs
 *    e.g. /callback/whogopay → includes/callback/whogopay.php
 */
add_action('init', function () {
    add_rewrite_rule('^callback/?$', 'index.php?pulsepoint_callback=index', 'top');
    add_rewrite_rule('^callback/([^/]*)/?', 'index.php?pulsepoint_callback=$matches[1]', 'top');
});

/**
 * 🔹 Start session (if needed) — safe against "headers already sent"
 *    Reuses the shared starter if public.php already defined one,
 *    so we never have two different session_start() call sites
 *    racing each other.
 */
if (!function_exists('pulsepoint_start_session')) {
    function pulsepoint_start_session() {
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            session_start([
                'cookie_httponly' => true,
                'cookie_samesite' => 'Lax',
                'use_strict_mode' => true,
            ]);
        }
    }
}
add_action('init', 'pulsepoint_start_session', 1);

/**
 * 🔹 Template redirect handler for /callback/*
 */
add_action('template_redirect', function () {
    $cb = get_query_var('pulsepoint_callback');
    if ($cb) {

        status_header(200);
        nocache_headers();

        // ✅ Define the callback directory
        $callback_dir = PULSEPOINT_DIR . 'includes/callback/';

        // Sanitize and find target file
        $callback_file = sanitize_file_name($cb);
        $file_path = $callback_dir . $callback_file . '.php';

        // Default to index.php if no file found
        if (!file_exists($file_path)) {
            $file_path = $callback_dir . 'index.php';
        }

        // ✅ Include the callback file
        include $file_path;
        exit;
    }
});
