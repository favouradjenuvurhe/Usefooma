<?php
/**
 * Pulsepoint API Router
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/api.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) {
    exit;
}

// === Ensure constants exist if this file is called early ===
if (!defined('PULSEPOINT_FILE')) {
    define('PULSEPOINT_FILE', dirname(__DIR__) . '/pulsepoint.php');
}
if (!defined('PULSEPOINT_DIR')) {
    define('PULSEPOINT_DIR', plugin_dir_path(PULSEPOINT_FILE));
}
if (!defined('PULSEPOINT_URL')) {
    define('PULSEPOINT_URL', plugin_dir_url(PULSEPOINT_FILE));
}

// === Add query var for API routing ===
add_filter('query_vars', function ($vars) {
    $vars[] = 'pulsepoint_api';
    return $vars;
});

// === Add rewrite rules for /api and /api/{endpoint} ===
add_action('init', function () {
    pulsepoint_add_api_rewrite();
});

function pulsepoint_add_api_rewrite() {
    add_rewrite_rule('^api/?$', 'index.php?pulsepoint_api=index', 'top');
    add_rewrite_rule('^api/([^/]*)/?', 'index.php?pulsepoint_api=$matches[1]', 'top');
}

// === Template redirect handler for API requests ===
add_action('template_redirect', function () {
    $endpoint = get_query_var('pulsepoint_api');

    if ($endpoint) {
        status_header(200);
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');

        $endpoint = sanitize_file_name($endpoint);
        $file = trailingslashit(PULSEPOINT_DIR) . 'includes/api/' . $endpoint . '.php';

        // Check if endpoint exists
        if (!file_exists($file)) {
            echo json_encode([
                'status'   => 'error',
                'message'  => 'Invalid API endpoint',
                'endpoint' => $endpoint
            ], JSON_PRETTY_PRINT);
            exit;
        }

        // === Load API endpoint file ===
        include $file;
        exit;
    }
});