<?php
/**
 * verify-bank.php
 * Dynamic Bank Account Verification (Strowallet API)
 * Author: Amaaavl
 */

// Hide PHP warnings/notices from breaking JSON output
error_reporting(0);
ini_set('display_errors', 0);

// Allow frontend requests (CORS)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Stop preflight OPTIONS requests early
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 🔑 Replace this with your actual Strowallet public key
$public_key = "pub_znm1oNOuVE7Yurhr8Du85Ub8iCMIXbxjiN465zZN";

// Accept inputs via GET or POST
$bank_code = isset($_REQUEST['bank_code']) ? trim($_REQUEST['bank_code']) : '';
$account_number = isset($_REQUEST['account_number']) ? trim($_REQUEST['account_number']) : '';

// Validate input
if (empty($bank_code) || empty($account_number)) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing required parameters: bank_code or account_number'
    ], JSON_PRETTY_PRINT);
    exit;
}

// Build API URL
$url = "https://strowallet.com/api/banks/get-customer-name/?public_key=" . urlencode($public_key)
     . "&bank_code=" . urlencode($bank_code)
     . "&account_number=" . urlencode($account_number);

// Initialize cURL
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
]);

$response = curl_exec($ch);
$error = curl_error($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Handle network/cURL errors
if ($error) {
    echo json_encode([
        'success' => false,
        'message' => "cURL Error: $error"
    ], JSON_PRETTY_PRINT);
    exit;
}

// Handle empty response
if (empty($response)) {
    echo json_encode([
        'success' => false,
        'message' => "Empty response from Strowallet API (HTTP $http_code)"
    ], JSON_PRETTY_PRINT);
    exit;
}

// Ensure the API returned valid JSON
$json = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid response format from Strowallet API (HTML or text received)',
        'raw_response' => substr($response, 0, 200) // show short preview only
    ], JSON_PRETTY_PRINT);
    exit;
}

// ✅ Return valid JSON result from Strowallet
echo json_encode($json, JSON_PRETTY_PRINT);