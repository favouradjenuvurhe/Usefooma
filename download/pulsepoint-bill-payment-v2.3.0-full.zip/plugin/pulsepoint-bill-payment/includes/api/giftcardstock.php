<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']);exit;}
$headers=function_exists('getallheaders')?getallheaders():[];$auth=$headers['Authorization']??($headers['authorization']??'');
if(!preg_match('/Token\s+(\S+)/',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]);
$users=$wpdb->prefix.'pulsepoint_users';$user=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$users} WHERE token=%s",$token));
if(!$user || (int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}
$stock=$wpdb->prefix.'pulsepoint_giftcard_stock';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';
$rows=$wpdb->get_results("SELECT s.id,s.giftcard_id,s.face_value,s.sale_price,s.type,s.status,s.expires_at,g.category,g.sub_category,g.image_url,g.rate FROM {$stock} s INNER JOIN {$settings} g ON g.id=s.giftcard_id WHERE s.status='available' AND g.status='active' ORDER BY g.category,g.sub_category,s.face_value,s.id DESC");
$data=[];foreach($rows as $r){$data[]=['id'=>(int)$r->id,'giftcard_id'=>(int)$r->giftcard_id,'category'=>$r->category,'sub_category'=>$r->sub_category,'face_value'=>(float)$r->face_value,'sale_price'=>(float)$r->sale_price,'type'=>$r->type,'image_url'=>$r->image_url,'rate'=>(float)$r->rate,'expires_at'=>$r->expires_at];}
echo wp_json_encode(['success'=>true,'data'=>$data]);exit;
