<?php
/**
 * Pulsepoint API Notifications
 * Path: /api/notifications.php
 * Author: Amaaavl
 *
 * POST (token, limit, page) -> paginated list of the user's notifications,
 * newest first. Response shape matches what component/notifications.html
 * expects: { success, data: [{ id, title, message, type, is_read, date }] }
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$base_prefix     = $wpdb->prefix . 'pulsepoint_';
$table_users     = $base_prefix . 'users';
$table_notif     = $base_prefix . 'notifications';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

// Token can come from the JSON body or the Authorization header
// ("Token xxxx"), matching how notifications.html calls this endpoint.
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Token\s+(\S+)/i', $auth_header, $m)) {
        $token = sanitize_text_field($m[1]);
    }
}

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$limit = isset($input['limit']) ? max(1, min(50, (int) $input['limit'])) : 20;
$page  = isset($input['page']) ? max(1, (int) $input['page']) : 1;
$offset = ($page - 1) * $limit;

$rows = $wpdb->get_results($wpdb->prepare(
    "SELECT id, title, message, type, status, created_at
     FROM `{$table_notif}`
     WHERE user_id = %d AND is_deleted = 0
     ORDER BY created_at DESC
     LIMIT %d OFFSET %d",
    $user->id,
    $limit,
    $offset
));

$data = array_map(function ($row) {
    return [
        'id'      => (int) $row->id,
        'title'   => $row->title,
        'message' => $row->message,
        'type'    => $row->type,
        'is_read' => $row->status === 'read' ? 1 : 0,
        'date'    => $row->created_at,
    ];
}, $rows);

echo json_encode([
    'success' => true,
    'data'    => $data,
    'page'    => $page,
]);
exit;
