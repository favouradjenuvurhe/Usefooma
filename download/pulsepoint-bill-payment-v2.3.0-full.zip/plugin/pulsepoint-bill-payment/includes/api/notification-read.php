<?php
/**
 * Pulsepoint API — Mark a single notification as read
 * Path: /api/notification-read.php
 * Author: Amaaavl
 *
 * POST (token, id) -> marks one notification (owned by this user) as read.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_users = $base_prefix . 'users';
$table_notif = $base_prefix . 'notifications';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Token\s+(\S+)/i', $auth_header, $m)) {
        $token = sanitize_text_field($m[1]);
    }
}

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$id = isset($input['id']) ? (int) $input['id'] : 0;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Notification id is required']);
    exit;
}

$updated = $wpdb->update(
    $table_notif,
    ['status' => 'read'],
    ['id' => $id, 'user_id' => $user->id],
    ['%s'],
    ['%d', '%d']
);

echo json_encode([
    'success' => $updated !== false,
    'message' => $updated !== false ? 'Notification marked as read' : 'Failed to update notification',
]);
exit;
