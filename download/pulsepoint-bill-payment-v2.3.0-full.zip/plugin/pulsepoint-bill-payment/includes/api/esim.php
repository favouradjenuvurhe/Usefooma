<?php
/** Pulsepoint eSIM API adapter - /api/esim */
require_once $_SERVER['DOCUMENT_ROOT'].'/wp-load.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD']!=='POST') wp_send_json(['success'=>false,'message'=>'Invalid request method'],405);
$headers=getallheaders(); $auth=$headers['Authorization']??$headers['authorization']??'';
if(!preg_match('/Token\s+(\S+)/i',$auth,$m)) wp_send_json(['success'=>false,'message'=>'Missing or invalid Authorization header'],401);
$token=sanitize_text_field($m[1]); $users=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE token=%s",$token));
if(!$user) wp_send_json(['success'=>false,'message'=>'Invalid or expired token'],401);
$input=json_decode(file_get_contents('php://input'),true); if(!is_array($input))$input=[];
$action=sanitize_key($input['action']??'countries');
$handler=WP_PLUGIN_DIR.'/pulsepoint-bill-payment/core/esim/pulsepoint.php';
if(!file_exists($handler))wp_send_json(['success'=>false,'message'=>'eSIM handler not found'],500);
require_once $handler;
if(!session_id())session_start(); $_SESSION['pulsepoint_user']['id']=$user->id; $_SESSION['pulsepoint_user']['token']=$token;
try {
 switch($action){
  case 'countries': $r=pulsepoint_esim_countries($input['start']??'', $input['length']??'', $input['search']??''); break;
  case 'plans': $r=pulsepoint_esim_plans($input['country']??''); break;
  case 'history': $r=pulsepoint_esim_history($input['start']??'', $input['length']??'', $input['search']??''); break;
  case 'profile': $r=pulsepoint_esim_profile($input['transactionId']??''); break;
  case 'delete': $r=pulsepoint_esim_delete($input['transactionId']??''); break;
  case 'topup_plans': $r=pulsepoint_esim_topup_plans((int)($input['plan']??0)); break;
  case 'purchase':
    $plan=(int)($input['plan']??0); $country=sanitize_text_field($input['country']??'');
    if(!$plan||!$country)wp_send_json(['success'=>false,'message'=>'plan and country are required'],422);
    $_POST['country']=$country; $_POST['country_name']=sanitize_text_field($input['country_name']??$country);
    $r=pulsepoint_esim_purchase($user->id,$plan,sanitize_text_field($input['reference']??'')); break;
  case 'topup':
    $tx=sanitize_text_field($input['transactionId']??''); $plan=(int)($input['plan']??0);
    if(!$tx||!$plan)wp_send_json(['success'=>false,'message'=>'transactionId and plan are required'],422);
    $r=pulsepoint_esim_topup($user->id,$tx,$plan,sanitize_text_field($input['reference']??'')); break;
  default: wp_send_json(['success'=>false,'message'=>'Unknown eSIM action'],422);
 }
} catch(Throwable $e){ wp_send_json(['success'=>false,'message'=>'eSIM service error','error'=>WP_DEBUG?$e->getMessage():null],500); }
wp_send_json($r);
