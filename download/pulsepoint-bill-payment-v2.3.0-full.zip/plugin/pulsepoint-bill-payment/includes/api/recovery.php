<?php
/**
 * Pulsepoint Password Recovery API Endpoint
 * Path: /api/recovery.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Get JSON body
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON body'
    ]);
    exit;
}

// Validate email
$email = sanitize_email($input['email'] ?? '');

if (empty($email)) {
    echo json_encode([
        'success' => false,
        'message' => 'Email is required'
    ]);
    exit;
}

// Simulate AJAX POST request
$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST['email'] = $email;

// Load forgot password handler
$handler = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/forgot-password.php';

if (!file_exists($handler)) {
    echo json_encode([
        'success' => false,
        'message' => 'Forgot password handler not found'
    ]);
    exit;
}

require_once $handler;

// Call existing function
if (function_exists('pulsepoint_forgot_password')) {
    pulsepoint_forgot_password();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Function pulsepoint_forgot_password() not found'
    ]);
}

exit;