<?php
/**
 * Pulsepoint API Fetch Referral Details
 * Path: /api/referrals.php
 * Author: Amaaavl
 *
 * NOTE: `bonus_given` is a flag, not an amount, so "total earnings" is
 * computed as (count of bonus_given = 1) x REFERRAL_BONUS_AMOUNT below.
 * Update the constant if the bonus per referral ever changes.
 */

// Naira amount credited per completed referral bonus
define('REFERRAL_BONUS_AMOUNT', 50.00);

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data POST
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$base_prefix     = $wpdb->prefix . 'pulsepoint_';
$users_table     = $base_prefix . 'users';
$referrals_table = $base_prefix . 'referrals';

// Fetch user by token (need id + uniqueid, which doubles as the referral code)
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, uniqueid, status
        FROM `{$users_table}` WHERE token = %s LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Check if account is active
if ((int)$user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Account inactive']);
    exit;
}

if (empty($user->uniqueid)) {
    echo json_encode(['success' => false, 'message' => 'Referral code not set for this account']);
    exit;
}

$referrer_id = (int)$user->id;

// Total referred
$total_referred = (int)$wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM `{$referrals_table}` WHERE referrer_id = %d",
        $referrer_id
    )
);

// Active (completed) referred
$active_referred = (int)$wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM `{$referrals_table}` WHERE referrer_id = %d AND completed = 1",
        $referrer_id
    )
);

// Total earnings from bonuses already paid out
$bonuses_paid = (int)$wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM `{$referrals_table}` WHERE referrer_id = %d AND bonus_given = 1",
        $referrer_id
    )
);

$total_earnings_raw = $bonuses_paid * REFERRAL_BONUS_AMOUNT;
$total_earnings = '₦' . number_format((float)$total_earnings_raw, 2, '.', ',');

// Return referral details
echo json_encode([
    'success' => true,
    'message' => 'Referral details fetched successfully',
    'referral' => [
        'referral_code'    => $user->uniqueid,
        'total_referred'   => $total_referred,
        'active_referred'  => $active_referred,
        'total_earnings'   => $total_earnings
    ]
]);
exit;
