<?php
/**
 * Pulsepoint Telegram Auth Endpoint
 * Path: /api/telegram-auth.php
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

/**
 * Telegram Data
 */
$telegram_id = sanitize_text_field($input['id'] ?? '');
$first_name  = sanitize_text_field($input['first_name'] ?? '');
$last_name   = sanitize_text_field($input['last_name'] ?? '');
$username    = sanitize_text_field($input['username'] ?? '');

/**
 * LOGIN CREDENTIALS FROM BOT
 */
$email_or_phone = sanitize_text_field($input['email'] ?? '');
$password        = sanitize_text_field($input['password'] ?? '');

if (empty($telegram_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Telegram data'
    ]);
    exit;
}

$table = $wpdb->prefix . 'pulsepoint_users';

/**
 * STEP 1: FIND USER BY EMAIL/PHONE (YOUR EXISTING SYSTEM)
 */
$user = null;

if (!empty($email_or_phone) && !empty($password)) {

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM `$table` WHERE (`email` = %s OR `phone` = %s) LIMIT 1",
            $email_or_phone,
            $email_or_phone
        )
    );

    if (!$user) {
        echo json_encode([
            'success' => false,
            'message' => 'Account not found'
        ]);
        exit;
    }

    if ((int)$user->status !== 1) {
        echo json_encode([
            'success' => false,
            'message' => 'Account inactive'
        ]);
        exit;
    }

    if (!password_verify($password, $user->password)) {
        echo json_encode([
            'success' => false,
            'message' => 'Incorrect password'
        ]);
        exit;
    }

    /**
     * STEP 2: LINK TELEGRAM ID TO USER (IMPORTANT PART)
     */
    $wpdb->update(
        $table,
        [
            'zid' => $telegram_id,
            'firstname' => $first_name ?: $user->firstname,
            'lastname'  => $last_name ?: $user->lastname,
            'username'  => $username ?: $user->username
        ],
        ['id' => $user->id]
    );

} else {

    /**
     * STEP 3: LOGIN DIRECTLY BY TELEGRAM ID
     */
    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM `$table` WHERE zid = %s LIMIT 1", $telegram_id)
    );

    if (!$user) {
        echo json_encode([
            'success' => false,
            'message' => 'No account linked to this Telegram'
        ]);
        exit;
    }
}

/**
 * STEP 4: START SESSION
 */
if (!session_id()) {
    session_start();
}

$_SESSION['pulsepoint_user'] = [
    'id'        => $user->id,
    'firstname' => $user->firstname,
    'lastname'  => $user->lastname,
    'email'     => $user->email,
    'phone'     => $user->phone,
    'wallet'    => $user->wallet,
    'token'     => $user->token,
    'telegram'  => $telegram_id
];

echo json_encode([
    'success' => true,
    'message' => 'Telegram login successful',
    'user' => [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'wallet'    => $user->wallet,
        'telegram'  => $telegram_id
    ]
]);

exit;