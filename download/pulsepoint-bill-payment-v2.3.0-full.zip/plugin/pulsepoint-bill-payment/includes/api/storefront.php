<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_storefront_api_handler')) {
    $handler = PULSEPOINT_DIR . 'core/storefront/api-handler.php';
    if (file_exists($handler)) require_once $handler;
}

if (function_exists('pulsepoint_storefront_api_handler')) {
    pulsepoint_storefront_api_handler();
}

wp_send_json(['success'=>false,'message'=>'Storefront API is unavailable.'], 500);
