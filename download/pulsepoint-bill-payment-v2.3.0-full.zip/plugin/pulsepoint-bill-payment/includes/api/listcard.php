<?php
/**
 * Pulsepoint Giftcard List API Endpoint
 * Path: /api/listcard.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// =====================================
// ALLOW ONLY POST
// =====================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// =====================================
// AUTHORIZATION
// =====================================
$headers = getallheaders();

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

$auth = trim($headers['Authorization']);

if (!preg_match('/Token\s+(\S+)/', $auth, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// =====================================
// VALIDATE USER TOKEN
// =====================================
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status FROM {$table_users} WHERE token = %s",
        $token
    )
);

if (!$user || (int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or inactive token'
    ]);
    exit;
}

// =====================================
// OPTIONAL FILTERS
// =====================================
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $input = $_POST;
}

$category     = sanitize_text_field($input['category'] ?? '');
$sub_category = sanitize_text_field($input['sub_category'] ?? '');
$type         = sanitize_text_field($input['type'] ?? '');

// =====================================
// FETCH GIFTCARDS
// =====================================
$table_giftcards = $wpdb->prefix . 'pulsepoint_giftcard_settings';

$where = ["status = 'active'"];
$params = [];

if (!empty($category)) {
    $where[] = "category = %s";
    $params[] = $category;
}

if (!empty($sub_category)) {
    $where[] = "sub_category = %s";
    $params[] = $sub_category;
}

if (!empty($type)) {
    $where[] = "type = %s";
    $params[] = $type;
}

$where_sql = 'WHERE ' . implode(' AND ', $where);

$query = "
SELECT *
FROM {$table_giftcards}
{$where_sql}
ORDER BY category ASC, sub_category ASC
";

$giftcards = $params
    ? $wpdb->get_results($wpdb->prepare($query, ...$params))
    : $wpdb->get_results($query);

if (!$giftcards) {
    echo json_encode([
        'success' => false,
        'message' => 'No giftcards found'
    ]);
    exit;
}

// =====================================
// GROUP RESULTS
// =====================================
$result = [];

foreach ($giftcards as $card) {

    $category = $card->category ?: 'Others';

    $result[$category][] = [
        'id'            => (int)$card->id,
        'category'      => $card->category,
        'sub_category'  => $card->sub_category,
        'image_url'     => $card->image_url,
        'type'          => $card->type,
        'rate'          => (float)$card->rate,
        'min_amount'    => (float)$card->min_amount,
        'max_amount'    => (float)$card->max_amount,
        'status'        => $card->status
    ];
}

// =====================================
// RESPONSE
// =====================================
echo json_encode([
    'success' => true,
    'message' => 'Giftcards fetched successfully',
    'data'    => $result
]);

exit;