<?php
/**
 * Pulsepoint Electricity Bill Plans API Endpoint
 * Path: /api/planbill.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// ================================
// ALLOW ONLY POST
// ================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// ================================
// AUTHORIZATION
// ================================
$headers = getallheaders();

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// ================================
// VALIDATE USER TOKEN
// ================================
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status FROM {$table_users} WHERE token = %s",
        $token
    )
);

if (!$user || (int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or inactive token'
    ]);
    exit;
}

// ================================
// INPUT FILTERS (OPTIONAL)
// ================================
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

// Optional filters
$provider = sanitize_text_field($input['provider'] ?? '');
$plan     = sanitize_text_field($input['plan'] ?? '');

// ================================
// FETCH BILL PLANS
// ================================
$table_bill = $wpdb->prefix . 'pulsepoint_bill';

$where  = [];
$params = [];

if (!empty($provider)) {
    $where[]  = "provider = %s";
    $params[] = $provider;
}

if (!empty($plan)) {
    $where[]  = "plan LIKE %s";
    $params[] = '%' . $wpdb->esc_like($plan) . '%';
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$query = "
    SELECT * FROM {$table_bill}
    {$where_sql}
    ORDER BY plan ASC
";

$bills = $params
    ? $wpdb->get_results($wpdb->prepare($query, ...$params))
    : $wpdb->get_results($query);

if (!$bills) {
    echo json_encode([
        'success' => false,
        'message' => 'No electricity bill plans found'
    ]);
    exit;
}

// ================================
// FORMAT RESPONSE DATA
// ================================
$result = [];

foreach ($bills as $bill) {
    $result[] = [
        'id'       => (int) $bill->id,
        'plan'     => $bill->plan,
        'details'  => $bill->details,
        'fee'      => (float) $bill->fee,
        'fee_api'  => (float) $bill->fee_api,
        'provider' => $bill->provider
    ];
}

// ================================
// RESPONSE
// ================================
echo json_encode([
    'success' => true,
    'message' => 'Electricity bill plans fetched successfully',
    'data'    => $result
]);
exit;