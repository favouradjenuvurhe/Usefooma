<?php
/**
 * Pulsepoint Airtime-to-Cash Rates API Endpoint
 * Path: /api/convertrates.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM {$table_users} WHERE token = %s", $token));

if (!$user || (int) $user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid or inactive token']);
    exit;
}

$table_rates = $wpdb->prefix . 'pulsepoint_airtime_to_cash';

$rates = $wpdb->get_results("SELECT * FROM {$table_rates} WHERE status = 'active' ORDER BY network ASC");

if (!$rates) {
    echo json_encode(['success' => false, 'message' => 'No active networks found']);
    exit;
}

$result = [];

foreach ($rates as $r) {
    $result[] = [
        'id'          => (int) $r->id,
        'network'     => $r->network,
        'rate'        => (float) $r->rate,
        'min_amount'  => (float) $r->min_amount,
        'max_amount'  => (float) $r->max_amount,
        'receiver_number' => $r->receiver_number,
        'receiver_name'   => $r->receiver_name,
        'instruction' => $r->instruction,
    ];
}

echo json_encode([
    'success' => true,
    'message' => 'Rates fetched successfully',
    'data'    => $result,
]);
exit;
