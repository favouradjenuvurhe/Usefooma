<?php
/**
 * Pulsepoint API Announcements
 * Path: /api/announcements.php
 * Author: Amaaavl
 *
 * POST (token) -> the single latest ACTIVE announcement, if any. The
 * frontend compares its id against the last one it already showed
 * (stored client-side) and only pops the sheet for a genuinely new one.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_users = $base_prefix . 'users';
$table_announcements = $base_prefix . 'announcements';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$user = $wpdb->get_var($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

if ($wpdb->get_var("SHOW TABLES LIKE '{$table_announcements}'") !== $table_announcements) {
    echo json_encode(['success' => true, 'announcement' => null]);
    exit;
}

$announcement = $wpdb->get_row(
    "SELECT id, title, message, type, created_at
     FROM `{$table_announcements}`
     WHERE status = 'active'
     ORDER BY created_at DESC
     LIMIT 1"
);

echo json_encode([
    'success'      => true,
    'announcement' => $announcement ? [
        'id'      => (int) $announcement->id,
        'title'   => $announcement->title,
        'message' => $announcement->message,
        'type'    => $announcement->type,
        'date'    => $announcement->created_at,
    ] : null,
]);
exit;
