<?php
/**
 * Pulsepoint - Get All Customers
 * File: /api/customer.php
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit;
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';


global $wpdb;

$secret = $_GET['secret'] ?? '';

if ($secret !== 'pulsepoint') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access'
    ]);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table = $base_prefix . 'users';

$users = $wpdb->get_results("
    SELECT
        id,
        firstname,
        lastname,
        email,
        phone,
        wallet,
        dollar,
        referby
    FROM `{$table}`
    ORDER BY id DESC
");

if (!$users) {
    echo json_encode([
        'success' => true,
        'count' => 0,
        'users' => []
    ]);
    exit;
}

$data = [];

foreach ($users as $user) {

    $referrer_name = null;

    if (!empty($user->referby)) {
        $referrer = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT firstname, lastname
                FROM `{$table}`
                WHERE id = %d
                LIMIT 1",
                $user->referby
            )
        );

        if ($referrer) {
            $referrer_name = trim(
                $referrer->firstname . ' ' . $referrer->lastname
            );
        }
    }

    $data[] = [
        'id' => (int)$user->id,
        'firstname' => $user->firstname,
        'lastname' => $user->lastname,
        'email' => $user->email,
        'phone' => $user->phone,
        'wallet' => (float)$user->wallet,
        'dollar' => (float)$user->dollar,
        'referby' => $referrer_name
    ];
}

echo json_encode([
    'success' => true,
    'message' => 'Customers fetched successfully',
    'count' => count($data),
    'users' => $data
], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

exit;