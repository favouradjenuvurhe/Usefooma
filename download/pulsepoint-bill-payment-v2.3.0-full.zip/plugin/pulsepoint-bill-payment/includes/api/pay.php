<?php
/**
 * Pulsepoint Bank Transfer API Endpoint
 * Path: /api/transfer.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

/** ----------------------------------
 *  AUTHORIZATION (TOKEN)
 * ---------------------------------- */
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token)
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

/** ----------------------------------
 *  READ JSON BODY
 * ---------------------------------- */
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

/** ----------------------------------
 *  SANITIZE INPUTS
 * ---------------------------------- */
$bank_code      = sanitize_text_field($input['bank_code'] ?? '');
$account_number = sanitize_text_field($input['account_number'] ?? '');
$account_name   = sanitize_text_field($input['account_name'] ?? '');
$amount         = floatval($input['amount'] ?? 0);
$narration      = sanitize_text_field($input['narration'] ?? '');

if (
    empty($bank_code) ||
    empty($account_number) ||
    $amount <= 0
) {
    echo json_encode([
        'success' => false,
        'message' => 'bank_code, account_number & amount are required'
    ]);
    exit;
}

/** ----------------------------------
 *  LOAD BANK TRANSFER HANDLER
 * ---------------------------------- */
$handler = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/bank/transfer.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Bank transfer handler not found']);
    exit;
}
require_once $handler;

/** ----------------------------------
 *  SIMULATE USER SESSION
 * ---------------------------------- */
if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

/** ----------------------------------
 *  MAP API → HANDLER INPUT
 * ---------------------------------- */
$_POST['bank_code']      = $bank_code;
$_POST['account_number'] = $account_number;
$_POST['account_name']   = $account_name;
$_POST['amount']         = $amount;
$_POST['narration']      = $narration;

/** ----------------------------------
 *  EXECUTE BANK TRANSFER
 * ---------------------------------- */
if (function_exists('pulsepoint_bank_transfer')) {
    pulsepoint_bank_transfer(); // outputs JSON directly
} else {
    echo json_encode([
        'success' => false,
        'message' => 'pulsepoint_bank_transfer() not found'
    ]);
}
exit;