<?php
/**
 * Pulsepoint API — Mark all notifications as read
 * Path: /api/notification-read-all.php
 * Author: Amaaavl
 *
 * POST (token) -> marks every unread notification owned by this user as read.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_users = $base_prefix . 'users';
$table_notif = $base_prefix . 'notifications';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Token\s+(\S+)/i', $auth_header, $m)) {
        $token = sanitize_text_field($m[1]);
    }
}

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$updated = $wpdb->update(
    $table_notif,
    ['status' => 'read'],
    ['user_id' => $user->id, 'status' => 'unread'],
    ['%s'],
    ['%d', '%s']
);

echo json_encode([
    'success' => $updated !== false,
    'message' => $updated !== false ? 'All notifications marked as read' : 'Failed to update notifications',
]);
exit;
