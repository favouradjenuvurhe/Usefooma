<?php
/**
 * Pulsepoint API — 2FA Disable
 * Path: /api/2fa-disable.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token = sanitize_text_field($input['token'] ?? '');
$code  = sanitize_text_field($input['code'] ?? '');

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$handler = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/verify_2fa.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => '2FA handler not found']);
    exit;
}
require_once $handler;

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;
$_POST['code'] = $code;

if (function_exists('pulsepoint_disable_2fa')) {
    pulsepoint_disable_2fa(); // outputs JSON
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_disable_2fa() not found']);
}
