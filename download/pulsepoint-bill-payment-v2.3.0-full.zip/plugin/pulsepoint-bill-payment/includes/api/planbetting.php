<?php
/**
 * Pulsepoint Betting Platform List API Endpoint
 * Path: /api/planbetting.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM {$table_users} WHERE token = %s", $token));

if (!$user || (int) $user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid or inactive token']);
    exit;
}

$table_bet = $wpdb->prefix . 'pulsepoint_betting';

$billers = $wpdb->get_results("SELECT * FROM {$table_bet} ORDER BY biller ASC");

if (!$billers) {
    echo json_encode(['success' => false, 'message' => 'No betting platforms found']);
    exit;
}

$result = [];

foreach ($billers as $b) {
    $result[] = [
        'id'        => (int) $b->id,
        'serviceid' => $b->serviceid,
        'biller'    => $b->biller,
        'fee'       => (float) $b->fee,
        'cashback'  => (float) $b->cashback,
        'provider'  => $b->provider,
    ];
}

echo json_encode([
    'success' => true,
    'message' => 'Betting platforms fetched successfully',
    'data'    => $result,
]);
exit;
