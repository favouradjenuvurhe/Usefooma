<?php
/**
 * Pulsepoint API Personal Information
 * Path: /api/personal-info.php
 * Author: Amaaavl
 *
 * GET  (token in query or JSON body): returns firstname, lastname, phone, email
 * POST (token + phone in JSON body): updates ONLY the phone number.
 *       firstname, lastname, and email are read-only from this endpoint —
 *       on purpose, since name/email changes usually need a support/KYC
 *       flow rather than a plain self-service form.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_users = $base_prefix . 'users';

$method = $_SERVER['REQUEST_METHOD'];

// Accept token from JSON body, form POST, or query string (for GET)
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$token = sanitize_text_field($input['token'] ?? ($_GET['token'] ?? ''));

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT id, firstname, lastname, phone, email, status FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

if ((int) $user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Account inactive']);
    exit;
}

// =========================
// GET → return current info
// =========================
if ($method === 'GET') {
    echo json_encode([
        'success' => true,
        'message' => 'Personal information fetched successfully',
        'info' => [
            'firstname' => $user->firstname,
            'lastname'  => $user->lastname,
            'fullname'  => trim($user->firstname . ' ' . $user->lastname),
            'phone'     => $user->phone,
            'email'     => $user->email,
        ]
    ]);
    exit;
}

// =========================
// POST → update phone only
// =========================
if ($method === 'POST') {

    $phone = sanitize_text_field($input['phone'] ?? '');

    if (empty($phone)) {
        echo json_encode(['success' => false, 'message' => 'Phone number is required']);
        exit;
    }

    // Basic Nigerian mobile number validation: 11 digits, starting 0,
    // or international +234 / 234 format normalized to 0-leading 11 digits.
    $digits = preg_replace('/\D/', '', $phone);

    if (strlen($digits) === 13 && substr($digits, 0, 3) === '234') {
        $digits = '0' . substr($digits, 3);
    } elseif (strlen($digits) === 10) {
        $digits = '0' . $digits;
    }

    if (!preg_match('/^0\d{10}$/', $digits)) {
        echo json_encode(['success' => false, 'message' => 'Enter a valid phone number']);
        exit;
    }

    // Prevent duplicate phone numbers across accounts
    $taken = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM `{$table_users}` WHERE phone = %s AND id != %d LIMIT 1",
        $digits,
        $user->id
    ));

    if ($taken) {
        echo json_encode(['success' => false, 'message' => 'This phone number is already in use']);
        exit;
    }

    if ($digits === $user->phone) {
        echo json_encode(['success' => false, 'message' => 'This is already your current phone number']);
        exit;
    }

    $updated = $wpdb->update(
        $table_users,
        ['phone' => $digits],
        ['id' => $user->id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        echo json_encode(['success' => false, 'message' => 'Failed to update phone number']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'Phone number updated successfully',
        'info' => [
            'firstname' => $user->firstname,
            'lastname'  => $user->lastname,
            'fullname'  => trim($user->firstname . ' ' . $user->lastname),
            'phone'     => $digits,
            'email'     => $user->email,
        ]
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid request method']);
exit;
