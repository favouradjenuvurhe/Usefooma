<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
$rows = $wpdb->get_results("SELECT id, category, sub_category, type, rate, min_amount, max_amount, status, image_url FROM {$wpdb->prefix}pulsepoint_giftcard_settings WHERE status='active' ORDER BY category, sub_category");
$data=[];
foreach($rows as $r){ $data[]=['id'=>(int)$r->id,'category'=>$r->category,'sub_category'=>$r->sub_category,'type'=>$r->type,'rate'=>(float)$r->rate,'min_amount'=>(float)$r->min_amount,'max_amount'=>(float)$r->max_amount,'image_url'=>$r->image_url]; }
echo wp_json_encode(['success'=>true,'data'=>$data]); exit;
