<?php
/**
 * Pulsepoint API Fetch Wallets
 * Path: /api/wallets.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data POST
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table = $base_prefix . 'users';

// Fetch user balances by token
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, wallet, dollar, referral_balance, status 
        FROM `{$table}` WHERE token = %s LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Check if account is active
if ((int)$user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Account inactive']);
    exit;
}

// Naira balance = wallet + referral balance (referral is paid out in Naira)
$naira_balance = (float)$user->wallet + (float)$user->referral_balance;
$dollar_balance = (float)$user->dollar;

// Return wallets in the shape the Wallets page expects
echo json_encode([
    'success' => true,
    'message' => 'Wallets fetched successfully',
    'data' => [
        [
            'type'     => 'fiat',
            'currency' => 'NGN',
            'label'    => 'Naira Balance',
            'balance'  => $naira_balance
        ],
        [
            'type'     => 'fiat',
            'currency' => 'USD',
            'label'    => 'Dollar Balance',
            'balance'  => $dollar_balance
        ]
    ]
]);
exit;
