<?php
/**
 * Pulsepoint API Leaderboard (Top 10 + your position)
 * Path: /api/leaderboard.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

header('Content-Type: application/json; charset=utf-8');

global $wpdb;

// Allow only GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// =========================
// TABLE DEFINITIONS
// =========================
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$user_table  = $base_prefix . 'users';
$trnx_table  = $base_prefix . 'trnx';

// =========================
// TOKEN AUTH
// (same "Authorization: Token xxx" header style used across the other APIs)
// =========================
$headers     = function_exists('getallheaders') ? getallheaders() : [];
$auth_header = $headers['Authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? '');

$token = '';
if (!empty($auth_header) && stripos($auth_header, 'Token ') === 0) {
    $token = trim(substr($auth_header, 6));
}

if (empty($token)) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing authentication token'
    ]);
    exit;
}

$current_user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, firstname, lastname FROM {$user_table} WHERE token = %s LIMIT 1",
        $token
    )
);

if (!$current_user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
    exit;
}

$current_user_id = intval($current_user->id);

// =========================
// TOP 10 LEADERBOARD
// Ranked by total value of each user's successful transactions.
// Only names + position are ever returned — no amounts, no balances.
// =========================
$top_rows = $wpdb->get_results(
    "SELECT u.id, u.firstname, u.lastname, SUM(t.amount) AS total_amount
     FROM {$user_table} u
     INNER JOIN {$trnx_table} t ON t.user_id = u.id AND t.status = 'success'
     GROUP BY u.id
     ORDER BY total_amount DESC
     LIMIT 10"
);

$leaderboard = [];
$position    = 1;

foreach ($top_rows as $row) {

    $leaderboard[] = [
        'position' => $position,
        'name'     => trim($row->firstname . ' ' . $row->lastname),
        'is_you'   => (intval($row->id) === $current_user_id)
    ];

    $position++;
}

// =========================
// CURRENT USER'S RANK
// Computed against ALL users' successful transaction totals, not just
// the top 10 — so someone ranked #47 still gets an accurate position.
// =========================
$user_total = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COALESCE(SUM(amount), 0) FROM {$trnx_table}
         WHERE user_id = %d AND status = 'success'",
        $current_user_id
    )
);

$user_total = floatval($user_total);

$user_rank = $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) + 1 FROM (
            SELECT user_id, SUM(amount) AS total_amount
            FROM {$trnx_table}
            WHERE status = 'success'
            GROUP BY user_id
            HAVING total_amount > %f
        ) ranked",
        $user_total
    )
);

$user_rank = intval($user_rank);

// A user with zero successful transactions has no meaningful rank yet —
// surface that plainly instead of returning a misleading position.
$has_activity = $user_total > 0;

echo json_encode([

    'success' => true,

    'message' => 'Leaderboard fetched successfully',

    'leaderboard' => $leaderboard,

    'you' => [
        'name'         => trim($current_user->firstname . ' ' . $current_user->lastname),
        'position'     => $has_activity ? $user_rank : null,
        'has_activity' => $has_activity,
        'in_top_10'    => $has_activity && $user_rank <= 10
    ]

]);

exit;
