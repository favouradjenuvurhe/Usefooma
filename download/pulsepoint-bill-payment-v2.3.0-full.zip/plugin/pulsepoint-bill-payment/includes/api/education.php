<?php
/**
 * Pulsepoint Education (Exams) Purchase API Endpoint
 * Path: /api/education.php
 * Author: Amaaavl
 *
 * Thin token-auth adapter — same pattern as /api/cable.php: resolve the
 * token, simulate the session the handler expects, map the JSON body into
 * $_POST, then hand off to the existing pulsepoint_education_purchase().
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE token=%s", $token));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

$plan_id   = intval($input['plan'] ?? 0);
$quantity  = intval($input['quantity'] ?? 1);
$reference = sanitize_text_field($input['reference'] ?? '');

if (!$plan_id || $quantity < 1) {
    echo json_encode(['success' => false, 'message' => 'plan & quantity required']);
    exit;
}

$handler = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/education/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Education handler not found']);
    exit;
}
require_once $handler;

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

$_POST['plan']      = $plan_id;
$_POST['quantity']  = $quantity;
$_POST['reference'] = $reference;

if (function_exists('pulsepoint_education_purchase')) {
    pulsepoint_education_purchase(); // outputs JSON
} else {
    echo json_encode(['success' => false, 'message' => 'pulsepoint_education_purchase() not found']);
}
