<?php
/**
 * Pulsepoint Education (Exams) Plan API Endpoint
 * Path: /api/planedu.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM {$table_users} WHERE token = %s", $token));

if (!$user || (int) $user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid or inactive token']);
    exit;
}

$table_edu = $wpdb->prefix . 'pulsepoint_education';

$plans = $wpdb->get_results("SELECT * FROM {$table_edu} ORDER BY servicename ASC");

if (!$plans) {
    echo json_encode(['success' => false, 'message' => 'No exam plans found']);
    exit;
}

$result = [];

foreach ($plans as $plan) {
    $result[] = [
        'id'          => (int) $plan->id,
        'serviceid'   => $plan->serviceid,
        'servicename' => $plan->servicename,
        'price'       => (float) $plan->price,
        'cashback'    => (float) $plan->cashback,
        'provider'    => $plan->provider,
    ];
}

echo json_encode([
    'success' => true,
    'message' => 'Exam plans fetched successfully',
    'data'    => $result,
]);
exit;
