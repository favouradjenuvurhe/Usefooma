<?php
/**
 * Pulsepoint API Registration Endpoint (Updated with account limit only)
 * Path: /api/create.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data
if (!$input) {
    $input = $_POST;
}

// Inputs
$fullname         = sanitize_text_field($input['fullname'] ?? '');
$phone            = sanitize_text_field($input['phone'] ?? '');
$email            = sanitize_email($input['email'] ?? '');
$refer_input      = sanitize_text_field($input['referby'] ?? '');
$password         = $input['password'] ?? '';
$confirm_password = $input['confirm_password'] ?? '';
$passcode         = sanitize_text_field($input['passcode'] ?? '');

// Validate required fields
if (empty($fullname) || empty($phone) || empty($email) || empty($password) || empty($confirm_password) || empty($passcode)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

// Validate passcode (4 digits)
if (!preg_match('/^\d{4}$/', $passcode)) {
    echo json_encode(['success' => false, 'message' => 'Passcode must be 4 digits']);
    exit;
}

// Password confirmation
if ($password !== $confirm_password) {
    echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
    exit;
}

// Split fullname → firstname & lastname
$name = preg_split('/\s+/', trim($fullname), 2);
$firstname = $name[0];
$lastname  = $name[1] ?? '';

// Table
$table = $wpdb->prefix . 'pulsepoint_users';

// Check if email or phone already exists
$exists = $wpdb->get_row(
    $wpdb->prepare("SELECT id FROM `$table` WHERE email = %s OR phone = %s LIMIT 1", $email, $phone)
);

if ($exists) {
    echo json_encode(['success' => false, 'message' => 'Email or phone already registered']);
    exit;
}

// Resolve referral (by phone or uniqueid)
$referby_id = null;
if (!empty($refer_input)) {
    $referby_id = $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM `$table` WHERE phone = %s OR uniqueid = %s LIMIT 1", $refer_input, $refer_input)
    );
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Generate token
try {
    $token = 'PS-APP-' . bin2hex(random_bytes(16));
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to generate token']);
    exit;
}

// Generate 6-character uniqueid (uppercase hex)
do {
    try {
        $uniqueid = substr(strtoupper(bin2hex(random_bytes(3))), 0, 6);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to generate unique ID']);
        exit;
    }
    $exists_uniqueid = $wpdb->get_var($wpdb->prepare("SELECT id FROM `$table` WHERE uniqueid = %s", $uniqueid));
} while ($exists_uniqueid);


/**
 * =========================
 * ACCOUNT LIMIT (NEW ONLY)
 * =========================
 */
$settings_table = $wpdb->prefix . 'pulsepoint_settings';

$account_limit = 5000.00; // default

$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM `$settings_table`");

if ($settings_rows) {
    foreach ($settings_rows as $row) {
        if ($row->opt_key === 'account_limit') {
            $account_limit = floatval($row->opt_value);
        }
    }
}

// Insert user
$insert = $wpdb->insert($table, [
    'firstname' => $firstname,
    'lastname'  => $lastname,
    'phone'     => $phone,
    'email'     => $email,
    'password'  => $hashed_password,
    'token'     => $token,
    'uniqueid'  => $uniqueid,
    'referby'   => $referby_id,
    'passcode'  => $passcode,
    'wallet'    => 0.00,
    'account_limit' => $account_limit,
    'status'    => 1
]);

if (!$insert) {
    echo json_encode(['success' => false, 'message' => 'Registration failed']);
    exit;
}

// Fetch newly created user
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$table` WHERE id = %d", $wpdb->insert_id));

// RESPONSE — SAME STRUCTURE AS LOGIN (UNCHANGED)
echo json_encode([
    'success'  => true,
    'message'  => 'Account created successfully',
    'new_user' => true,
    'user' => [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode,
        'uniqueid'  => $user->uniqueid
    ]
]);
exit;