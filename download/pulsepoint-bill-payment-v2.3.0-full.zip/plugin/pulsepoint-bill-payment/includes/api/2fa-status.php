<?php
/**
 * Pulsepoint API — 2FA Status
 * Path: /api/2fa-status.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token = sanitize_text_field($input['token'] ?? ($_GET['token'] ?? ''));

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row($wpdb->prepare(
    "SELECT twofa_enabled FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

echo json_encode([
    'success' => true,
    'enabled' => (int) $user->twofa_enabled === 1,
]);
exit;
