<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']);exit;}
$headers=function_exists('getallheaders')?getallheaders():[];$auth=$headers['Authorization']??($headers['authorization']??'');
if(!preg_match('/Token\s+(\S+)/',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]);
$users=$wpdb->prefix.'pulsepoint_users';$user=$wpdb->get_row($wpdb->prepare("SELECT id,wallet,passcode,status FROM {$users} WHERE token=%s",$token));
if(!$user || (int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}
$stock_id=absint($_POST['stock_id']??0);$pin=sanitize_text_field($_POST['passcode']??'');
if(!$stock_id || !preg_match('/^\d{4}$/',$pin)){echo wp_json_encode(['success'=>false,'message'=>'Stock item and 4-digit PIN are required']);exit;}
if(empty($user->passcode)||!hash_equals((string)$user->passcode,$pin)){echo wp_json_encode(['success'=>false,'message'=>'Incorrect transaction PIN']);exit;}
$stock=$wpdb->prefix.'pulsepoint_giftcard_stock';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';
$wpdb->query('START TRANSACTION');
try{
  $item=$wpdb->get_row($wpdb->prepare("SELECT s.*,g.category,g.sub_category FROM {$stock} s INNER JOIN {$settings} g ON g.id=s.giftcard_id WHERE s.id=%d AND s.status='available' AND g.status='active' FOR UPDATE",$stock_id));
  if(!$item) throw new Exception('This giftcard is no longer available.');
  if(!empty($item->expires_at) && strtotime($item->expires_at)!==false && strtotime($item->expires_at)<current_time('timestamp')){ $wpdb->update($stock,['status'=>'expired'],['id'=>$stock_id]); throw new Exception('This giftcard has expired.'); }
  $price=(float)$item->sale_price;$balance=(float)$user->wallet;
  if($balance<$price) throw new Exception('Insufficient wallet balance.');
  $ref='PGB'.strtoupper(wp_generate_password(12,false,false));
  $new=$balance-$price;
  if(false===$wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=%f WHERE id=%d AND wallet >= %f",$new,$user->id,$price))) throw new Exception('Unable to debit wallet.');
  $wpdb->update($stock,['status'=>'sold','sold_to'=>$user->id,'sold_at'=>current_time('mysql')],['id'=>$stock_id],['%s','%d','%s'],['%d']);
  $ok=$wpdb->insert($tx,['listing_id'=>null,'user_id'=>$user->id,'amount'=>$item->face_value,'selling_price'=>$price,'fee'=>0,'status'=>'completed','payment_method'=>'wallet','reference'=>$ref,'note'=>'Giftcard purchase: '.$item->category.' '.$item->sub_category,'transaction_type'=>'purchase','inventory_id'=>$stock_id,'delivered_code'=>$item->digital_code,'delivered_pin'=>$item->digital_pin],['%d','%d','%f','%f','%f','%s','%s','%s','%s','%d','%s','%s']);
  if(!$ok) throw new Exception('Failed to record purchase.');
  $wpdb->query('COMMIT');
  echo wp_json_encode(['success'=>true,'message'=>'Giftcard purchased successfully.','data'=>['reference'=>$ref,'category'=>$item->category,'sub_category'=>$item->sub_category,'face_value'=>(float)$item->face_value,'sale_price'=>$price,'code'=>$item->digital_code,'pin'=>$item->digital_pin,'new_balance'=>$new]]);exit;
}catch(Throwable $e){$wpdb->query('ROLLBACK');echo wp_json_encode(['success'=>false,'message'=>$e->getMessage()]);exit;}
