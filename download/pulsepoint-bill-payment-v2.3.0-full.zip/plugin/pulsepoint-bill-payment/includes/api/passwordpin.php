<?php
/**
 * Pulsepoint API — Change Password / Change Transaction PIN
 * Endpoint: /api/passwordpin
 *
 * Password and PIN changes use the Pulsepoint users table and the user's
 * current API/session token. Passwords are stored with password_hash().
 * PINs remain 4-digit values because the existing database column is VARCHAR(4).
 *
 * Password and PIN cooldowns are tracked independently. A normal users.updated_at
 * change must never block a password/PIN change.
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json(['success' => false, 'message' => 'Invalid request method'], 405);
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table       = $base_prefix . 'users';

/** Ensure older installations receive independent change timestamps. */
$columns = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);
if (!in_array('password_updated_at', $columns, true)) {
    $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `password_updated_at` DATETIME NULL DEFAULT NULL");
}
if (!in_array('pin_updated_at', $columns, true)) {
    $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `pin_updated_at` DATETIME NULL DEFAULT NULL");
}

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    $input = $_POST;
}

$token = sanitize_text_field($input['token'] ?? '');
$type  = sanitize_text_field($input['type'] ?? '');

// Also accept the authenticated application session as a fallback. This keeps
// the endpoint working if a stale/missing token is present in the frontend.
if ($token === '' && session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
if ($token === '' && !empty($_SESSION['pulsepoint_user']['token'])) {
    $token = sanitize_text_field($_SESSION['pulsepoint_user']['token']);
}

if ($token === '') {
    wp_send_json(['success' => false, 'message' => 'Authentication token is required'], 401);
}

if (!in_array($type, ['password', 'pin'], true)) {
    wp_send_json(['success' => false, 'message' => 'Invalid change type'], 400);
}

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, firstname, email, password, passcode, status, token,
                created_at, updated_at, password_updated_at, pin_updated_at
         FROM `{$table}` WHERE token = %s LIMIT 1",
        $token
    )
);

if (!$user) {
    wp_send_json(['success' => false, 'message' => 'Invalid or expired token'], 401);
}

if ((int) $user->status !== 1) {
    wp_send_json(['success' => false, 'message' => 'Account inactive'], 403);
}

// Independent 24-hour cooldowns. A missing timestamp means the user has never
// successfully changed that item, so the first change is allowed immediately.
$cooldown_seconds = 24 * 3600;
$cooldown_column  = $type === 'password' ? 'password_updated_at' : 'pin_updated_at';
$last_changed     = $user->{$cooldown_column};

if (!empty($last_changed)) {
    $elapsed = time() - strtotime($last_changed);
    if ($elapsed < $cooldown_seconds) {
        $remaining = $cooldown_seconds - max(0, $elapsed);
        $hours = (int) ceil($remaining / 3600);
        wp_send_json([
            'success' => false,
            'message' => "You can only change your {$type} once every 24 hours. Try again in {$hours} hour(s).",
            'cooldown' => true,
            'retry_after' => $remaining,
        ], 429);
    }
}

/** Verify both modern PHP hashes and any older WordPress-compatible hash. */
function pulsepoint_password_matches(string $plain, string $stored): bool {
    if ($stored === '') return false;
    if (password_verify($plain, $stored)) return true;
    if (function_exists('wp_check_password') && wp_check_password($plain, $stored)) return true;
    return false;
}

if ($type === 'password') {
    $passcode         = sanitize_text_field($input['passcode'] ?? '');
    $new_password     = (string) ($input['new_password'] ?? '');
    $confirm_password = (string) ($input['confirm_password'] ?? '');

    if ($passcode === '' || $new_password === '' || $confirm_password === '') {
        wp_send_json(['success' => false, 'message' => 'Passcode, new password and confirm password are required'], 400);
    }

    if (!preg_match('/^\d{4}$/', $passcode)) {
        wp_send_json(['success' => false, 'message' => 'Current PIN must be exactly 4 digits'], 400);
    }

    if (empty($user->passcode) || !hash_equals((string) $user->passcode, $passcode)) {
        wp_send_json(['success' => false, 'message' => 'Incorrect current transaction PIN'], 403);
    }

    if ($new_password !== $confirm_password) {
        wp_send_json(['success' => false, 'message' => 'New password and confirm password do not match'], 400);
    }

    if (strlen($new_password) < 8) {
        wp_send_json(['success' => false, 'message' => 'Password must be at least 8 characters'], 400);
    }

    if (pulsepoint_password_matches($new_password, (string) $user->password)) {
        wp_send_json(['success' => false, 'message' => 'New password must be different from your current password'], 400);
    }

    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    if (!$hashed) {
        wp_send_json(['success' => false, 'message' => 'Unable to secure the new password'], 500);
    }

    $now = current_time('mysql');
    $updated = $wpdb->update(
        $table,
        [
            'password'            => $hashed,
            'password_updated_at' => $now,
        ],
        ['id' => (int) $user->id],
        ['%s', '%s'],
        ['%d']
    );

    if ($updated === false) {
        wp_send_json(['success' => false, 'message' => 'Failed to update password: ' . ($wpdb->last_error ?: 'database error')], 500);
    }

    // Refresh the in-app session so the changed account state is immediately used.
    if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
    if (isset($_SESSION['pulsepoint_user'])) {
        $_SESSION['pulsepoint_user']['password_updated_at'] = $now;
    }

    if (function_exists('clean_user_cache')) {
        // This is a custom users table, so there is no WP user cache to clear.
        // Kept intentionally as a guarded no-op for compatibility.
    }

    if (function_exists('wp_mail') && !empty($user->email)) {
        @wp_mail(
            $user->email,
            'Password Changed Successfully',
            'Hello ' . esc_html($user->firstname) . ',<br><br>Your Pulsepoint account password was changed successfully. If you did not make this change, contact your administrator immediately.<br><br>Regards,<br>Pulsepoint Security Team',
            ['Content-Type: text/html; charset=UTF-8']
        );
    }

    wp_send_json([
        'success' => true,
        'message' => 'Password changed successfully.',
    ]);
}

// PIN change
$password    = (string) ($input['password'] ?? '');
$pin         = sanitize_text_field($input['pin'] ?? '');
$confirm_pin = sanitize_text_field($input['confirm_pin'] ?? '');

if ($password === '' || $pin === '' || $confirm_pin === '') {
    wp_send_json(['success' => false, 'message' => 'Current password, new PIN and confirm PIN are required'], 400);
}

if (!pulsepoint_password_matches($password, (string) $user->password)) {
    wp_send_json(['success' => false, 'message' => 'Incorrect current password'], 403);
}

if ($pin !== $confirm_pin) {
    wp_send_json(['success' => false, 'message' => 'PIN and confirm PIN do not match'], 400);
}

if (!preg_match('/^\d{4}$/', $pin)) {
    wp_send_json(['success' => false, 'message' => 'PIN must be exactly 4 digits'], 400);
}

if (!empty($user->passcode) && hash_equals((string) $user->passcode, $pin)) {
    wp_send_json(['success' => false, 'message' => 'New PIN must be different from your current PIN'], 400);
}

$now = current_time('mysql');
$updated = $wpdb->update(
    $table,
    [
        'passcode'       => $pin,
        'pin_updated_at' => $now,
    ],
    ['id' => (int) $user->id],
    ['%s', '%s'],
    ['%d']
);

if ($updated === false) {
    wp_send_json(['success' => false, 'message' => 'Failed to update PIN: ' . ($wpdb->last_error ?: 'database error')], 500);
}

if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
if (isset($_SESSION['pulsepoint_user'])) {
    $_SESSION['pulsepoint_user']['passcode'] = $pin;
    $_SESSION['pulsepoint_user']['pin_updated_at'] = $now;
}

wp_send_json([
    'success' => true,
    'message' => 'Transaction PIN changed successfully.',
    'passcode' => $pin,
]);
