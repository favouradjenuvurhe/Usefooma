<?php  
/**  
 * Pulsepoint API Login Endpoint (NO AUTO REGISTRATION)  
 * Path: /api/auth.php  
 * Author: Amaaavl  
 */  
  
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';  
global $wpdb;  
  
header('Content-Type: application/json; charset=utf-8');  
  
// Allow only POST  
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {  
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);  
    exit;  
}  
  
// Get JSON input  
$input = json_decode(file_get_contents('php://input'), true);  
  
// Fallback to form-data POST  
if (!$input) {  
    $input = $_POST;  
}  
  
$email_or_phone = sanitize_text_field($input['email'] ?? '');  
$password       = sanitize_text_field($input['password'] ?? '');  
  
if (empty($email_or_phone) || empty($password)) {  
    echo json_encode([  
        'success' => false,  
        'message' => 'Email/Phone and Password are required'  
    ]);  
    exit;  
}  
  
$table = $wpdb->prefix . 'pulsepoint_users';  
  
// Fetch user  
$user = $wpdb->get_row(  
    $wpdb->prepare(  
        "SELECT * FROM `$table` WHERE (`email` = %s OR `phone` = %s) LIMIT 1",  
        $email_or_phone,  
        $email_or_phone  
    )  
);  
  
// ================================  
// ❌ USER NOT FOUND → STOP  
// ================================  
if (!$user) {  
    echo json_encode([  
        'success' => false,  
        'message' => 'Account not found'  
    ]);  
    exit;  
}  
  
// ================================  
// ✔ USER FOUND → LOGIN  
// ================================  
  
// Check account status  
if ((int)$user->status !== 1) {  
    echo json_encode([  
        'success' => false,  
        'message' => 'Account inactive'  
    ]);  
    exit;  
}  
  
// Verify password  
if (!password_verify($password, $user->password)) {  
    echo json_encode([  
        'success' => false,  
        'message' => 'Incorrect password'  
    ]);  
    exit;  
}  
  
// Start session  
if (!session_id()) {  
    session_start();  
}  
  
$_SESSION['pulsepoint_user'] = [  
    'id'        => $user->id,  
    'firstname' => $user->firstname,  
    'lastname'  => $user->lastname,  
    'email'     => $user->email,  
    'phone'     => $user->phone,  
    'wallet'    => $user->wallet,  
    'token'     => $user->token  
];  
  
// SUCCESS RESPONSE  
echo json_encode([  
    'success'  => true,  
    'message'  => 'Login successful',  
    'new_user' => false,  
    'user' => [  
        'id'        => $user->id,  
        'firstname' => $user->firstname,  
        'lastname'  => $user->lastname,  
        'email'     => $user->email,  
        'phone'     => $user->phone,  
        'wallet'    => $user->wallet,  
        'token'     => $user->token, 
        'passcode'  => $user->passcode
    ]  
]);  
exit;  