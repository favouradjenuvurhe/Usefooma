<?php
/**
 * Pulsepoint API - Virtual Card Details
 * Path: /api/cards.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit;
}

// Read JSON body
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode([
        'success' => false,
        'message' => 'Token is required.'
    ]);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';

$users_table = $base_prefix . 'users';
$cards_table = $base_prefix . 'virtual_cards';

/*
|--------------------------------------------------------------------------
| Validate User
|--------------------------------------------------------------------------
*/

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status
        FROM {$users_table}
        WHERE token = %s
        LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token.'
    ]);
    exit;
}

if ((int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Account inactive.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Fetch Card
|--------------------------------------------------------------------------
*/

$card = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT
            id,
            card_holder_name,
            card_name,
            card_id,
            card_created_date,
            card_type,
            card_brand,
            card_user_id,
            reference,
            card_status,
            card_number,
            last4,
            cvv,
            expiry,
            customer_email,
            customer_id,
            balance,
            billing_address_city,
            billing_address_street,
            billing_address_country,
            billing_address_zipcode,
            billing_address_country_code,
            created_at,
            updated_at
        FROM {$cards_table}
        WHERE user_id = %d
        LIMIT 1",
        $user->id
    )
);

if (!$card) {
    echo json_encode([
        'success' => false,
        'message' => 'Virtual card not found.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Response
|--------------------------------------------------------------------------
*/

echo json_encode([
    'success' => true,
    'card' => [
        'id' => (int) $card->id,
        'card_holder_name' => $card->card_holder_name,
        'card_name' => $card->card_name,
        'card_id' => $card->card_id,
        'card_created_date' => $card->card_created_date,
        'card_type' => $card->card_type,
        'card_brand' => $card->card_brand,
        'card_user_id' => $card->card_user_id,
        'reference' => $card->reference,
        'status' => $card->card_status,
        'frozen' => strtolower($card->card_status) !== 'active',
        'card_number' => $card->card_number,
        'last4' => $card->last4,
        'cvv' => $card->cvv,
        'expiry' => $card->expiry,
        'customer_email' => $card->customer_email,
        'customer_id' => $card->customer_id,
        'balance' => (float) $card->balance,
        'billing_address_city' => $card->billing_address_city,
        'billing_address_street' => $card->billing_address_street,
        'billing_address_country' => $card->billing_address_country,
        'billing_address_zipcode' => $card->billing_address_zipcode,
        'billing_address_country_code' => $card->billing_address_country_code,
        'created_at' => $card->created_at,
        'updated_at' => $card->updated_at
    ]
]);

exit;