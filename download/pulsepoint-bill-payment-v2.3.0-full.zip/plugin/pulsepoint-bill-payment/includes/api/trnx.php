<?php
/**
 * Pulsepoint Transactions API Endpoint
 * Path: /api/trnx.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// ================================
// AUTHORIZATION
// ================================
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

$auth = trim($headers['Authorization']);
if (!preg_match('/Token\s+(\S+)/', $auth, $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

// ================================
// VALIDATE USER TOKEN
// ================================
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row(
    $wpdb->prepare("SELECT id, status FROM {$table_users} WHERE token = %s", $token)
);

if (!$user || (int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or inactive token'
    ]);
    exit;
}

// ================================
// INPUT FILTERS (OPTIONAL)
// ================================
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$category = sanitize_text_field($input['category'] ?? '');
$status   = sanitize_text_field($input['status'] ?? '');
$type     = sanitize_text_field($input['type'] ?? '');
$limit    = intval($input['limit'] ?? 50);
$page     = max(1, intval($input['page'] ?? 1));

$limit  = ($limit > 100) ? 100 : $limit; // hard limit
$offset = ($page - 1) * $limit;

// ================================
// BUILD QUERY
// ================================
$table_trnx = $wpdb->prefix . 'pulsepoint_trnx';

$where   = ["user_id = %d"];
$params  = [$user->id];

if (!empty($category)) {
    $where[]  = "category = %s";
    $params[] = $category;
}

if (!empty($status)) {
    $where[]  = "status = %s";
    $params[] = $status;
}

if (!empty($type)) {
    $where[]  = "type = %s";
    $params[] = $type;
}

$where_sql = 'WHERE ' . implode(' AND ', $where);

// ================================
// FETCH TRANSACTIONS
// ================================
$query = "
    SELECT 
        id,
        details,
        recipient,
        amount,
        reference,
        payment,
        category,
        status,
        type,
        description,
        date
    FROM {$table_trnx}
    {$where_sql}
    ORDER BY date DESC
    LIMIT %d OFFSET %d
";

$params[] = $limit;
$params[] = $offset;

$transactions = $wpdb->get_results(
    $wpdb->prepare($query, ...$params)
);

if (!$transactions) {
    echo json_encode([
        'success' => true,
        'message' => 'No transactions found',
        'data'    => [],
        'meta'    => [
            'page'  => $page,
            'limit' => $limit
        ]
    ]);
    exit;
}

// ================================
// FORMAT RESPONSE
// ================================
$data = [];

foreach ($transactions as $t) {
    $data[] = [
        'id'          => (int)$t->id,
        'reference'   => $t->reference,
        'category'    => $t->category,
        'type'        => $t->type,
        'status'      => $t->status,
        'payment'     => $t->payment,
        'recipient'   => $t->recipient,
        'amount'      => (float)$t->amount,
        'details'     => $t->details,
        'description' => $t->description,
        'date'        => $t->date
    ];
}

// ================================
// RESPONSE
// ================================
echo json_encode([
    'success' => true,
    'message' => 'Transactions fetched successfully',
    'data'    => $data,
    'meta'    => [
        'page'  => $page,
        'limit' => $limit
    ]
]);
exit;