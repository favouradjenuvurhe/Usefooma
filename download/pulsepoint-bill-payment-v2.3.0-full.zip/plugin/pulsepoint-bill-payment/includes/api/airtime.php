<?php
/**
 * Pulsepoint Airtime API Endpoint
 * Path: /api/airtime.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php'; // Load WordPress core
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// --- Authorization Header ---
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

$auth_header = trim($headers['Authorization']);
if (!preg_match('/Token\\s+(\\S+)/', $auth_header, $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

// --- Validate user token ---
$table_users = $wpdb->prefix . 'pulsepoint_users'; // ✅ Fixed table name
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE token = %s", $token));

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token',
        'hint'    => 'Ensure your token matches the stored token in pulsepoint_users table'
    ]);
    exit;
}

// --- Get and validate request body ---
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

$network        = sanitize_text_field($input['network'] ?? '');
$amount         = floatval($input['amount'] ?? 0);
$mobile_number  = sanitize_text_field($input['mobile_number'] ?? '');
$ported_number  = isset($input['Ported_number']) ? (bool)$input['Ported_number'] : false;
$airtime_type   = sanitize_text_field($input['airtime_type'] ?? 'VTU');

if (empty($network) || empty($amount) || empty($mobile_number)) {
    echo json_encode(['success' => false, 'message' => 'network, amount, and mobile_number are required']);
    exit;
}
if ($amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid amount']);
    exit;
}

// --- Include main airtime handler ---
$handler = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/airtime/pulsepoint.php';
if (!file_exists($handler)) {
    echo json_encode(['success' => false, 'message' => 'Airtime handler not found']);
    exit;
}
require_once $handler;

// --- Simulate user session for handler ---
if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

// --- Pass parameters to handler ---
$_POST['network'] = $network;
$_POST['amount']  = $amount;
$_POST['phone']   = $mobile_number;
$_POST['ported']  = $ported_number;
$_POST['type']    = $airtime_type;

// --- Call the existing purchase handler ---
if (function_exists('pulsepoint_airtime_purchase')) {
    pulsepoint_airtime_purchase(); // Outputs JSON directly
} else {
    echo json_encode(['success' => false, 'message' => 'Function pulsepoint_airtime_purchase() not found']);
}
exit;