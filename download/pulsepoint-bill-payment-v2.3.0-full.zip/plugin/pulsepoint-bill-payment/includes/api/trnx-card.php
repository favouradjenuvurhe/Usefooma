<?php
/**
 * Pulsepoint API - Virtual Card Transactions
 * Path: /api/transaction-card.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit;
}

// Read JSON body
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode([
        'success' => false,
        'message' => 'Token is required.'
    ]);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';

$users_table        = $base_prefix . 'users';
$cards_table        = $base_prefix . 'virtual_cards';
$transactions_table = $base_prefix . 'virtualcard_transactions';

/*
|--------------------------------------------------------------------------
| Validate User
|--------------------------------------------------------------------------
*/

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status
        FROM {$users_table}
        WHERE token = %s
        LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token.'
    ]);
    exit;
}

if ((int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Account inactive.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Get User Card
|--------------------------------------------------------------------------
*/

$card = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT card_id
        FROM {$cards_table}
        WHERE user_id = %d
        LIMIT 1",
        $user->id
    )
);

if (!$card) {
    echo json_encode([
        'success' => true,
        'data' => []
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Fetch Transactions
|--------------------------------------------------------------------------
*/

$transactions = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT
            transaction_id,
            amount,
            type,
            method,
            narrative,
            status,
            currency,
            created_at,
            reference
        FROM {$transactions_table}
        WHERE card_id = %s
        ORDER BY created_at DESC",
        $card->card_id
    )
);

$data = [];

foreach ($transactions as $trx) {

    $amount = (float)$trx->amount;

    // Debit = negative
    if (strtolower($trx->type) === 'debit') {
        $amount = -abs($amount);
    } else {
        $amount = abs($amount);
    }

    $title = 'Card Transaction';

    if (!empty($trx->method)) {
        $title = ucwords(str_replace(['_', '-'], ' ', $trx->method));
    }

    $subtitle = '';

    if (!empty($trx->narrative)) {
        $subtitle = $trx->narrative;
    } elseif (!empty($trx->created_at)) {
        $subtitle = date('M d, Y h:i A', strtotime($trx->created_at));
    }

    $data[] = [
        'title'  => $title,
        'date'   => $subtitle,
        'amount' => $amount,
        'icon'   => null
    ];
}

/*
|--------------------------------------------------------------------------
| Response
|--------------------------------------------------------------------------
*/

echo json_encode([
    'success' => true,
    'data' => $data
]);

exit;