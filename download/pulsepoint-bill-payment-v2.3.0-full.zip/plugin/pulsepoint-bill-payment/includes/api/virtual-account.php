<?php
/**
 * Pulsepoint Virtual Account API Endpoint
 * Path: /api/virtual-account.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// --- Authorization Header ---
$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

$auth_header = trim($headers['Authorization']);
if (!preg_match('/Token\s+(\S+)/', $auth_header, $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

// --- Validate user token ---
$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE token = %s", $token));

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token',
        'hint'    => 'Ensure your token matches the stored token in pulsepoint_users table'
    ]);
    exit;
}

// --- Simulate user session for AJAX hook ---
if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;

// --- Check existing virtual account ---
$table_accnt = $wpdb->prefix . 'pulsepoint_account';
$existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_accnt} WHERE user_id = %d LIMIT 1", $user->id));

if ($existing) {
    echo json_encode([
        'success' => true,
        'message' => 'Virtual account already exists',
        'account' => [
            'bank'     => $existing->bank,
            'name'     => $existing->name,
            'number'   => $existing->number,
            'provider' => $existing->provider
        ]
    ]);
    exit;
}

// --- Trigger virtual account generation ---
if (has_action('wp_ajax_nopriv_pulsepoint_virtual_account')) {
    do_action('wp_ajax_nopriv_pulsepoint_virtual_account');
} elseif (has_action('wp_ajax_pulsepoint_virtual_account')) {
    do_action('wp_ajax_pulsepoint_virtual_account');
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Virtual account generation not available'
    ]);
}
exit;