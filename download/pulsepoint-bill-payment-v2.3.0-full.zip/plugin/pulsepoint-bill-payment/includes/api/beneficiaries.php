<?php
/**
 * Pulsepoint API — Recent Beneficiaries
 * Path: /api/beneficiaries.php
 * Author: Amaaavl
 *
 * POST (token, category) -> the user's most recently used beneficiaries
 * for that category (transfer, airtime, data, cable, electricity, betting),
 * newest-used first. Populated automatically by pulsepoint_save_beneficiary()
 * after every successful transaction — nothing for the user to opt into.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$token    = sanitize_text_field($input['token'] ?? '');
$category = sanitize_text_field($input['category'] ?? '');

if (empty($token) || empty($category)) {
    echo json_encode(['success' => false, 'message' => 'token and category are required']);
    exit;
}

$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_var($wpdb->prepare(
    "SELECT id FROM `{$table_users}` WHERE token = %s LIMIT 1",
    $token
));

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$table_beneficiaries = $wpdb->prefix . 'pulsepoint_beneficiaries';

$rows = $wpdb->get_results($wpdb->prepare(
    "SELECT identifier, label, sub_label, meta, last_used
     FROM `{$table_beneficiaries}`
     WHERE user_id = %d AND category = %s
     ORDER BY last_used DESC
     LIMIT 8",
    $user,
    $category
));

$data = array_map(function ($row) {
    return [
        'identifier' => $row->identifier,
        'label'      => $row->label,
        'sub_label'  => $row->sub_label,
        'meta'       => $row->meta ? maybe_unserialize($row->meta) : [],
    ];
}, $rows);

echo json_encode([
    'success' => true,
    'data'    => $data,
]);
exit;
