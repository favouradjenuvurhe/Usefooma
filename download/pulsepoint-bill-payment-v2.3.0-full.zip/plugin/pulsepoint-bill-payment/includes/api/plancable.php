<?php
/**
 * Pulsepoint Cable Plan API Endpoint
 * Path: /api/plancable.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// ================================
// ALLOW ONLY POST
// ================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// ================================
// AUTHORIZATION
// ================================
$headers = getallheaders();

if (empty($headers['Authorization'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header'
    ]);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

// ================================
// VALIDATE USER TOKEN
// ================================
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status FROM {$table_users} WHERE token = %s",
        $token
    )
);

if (!$user || (int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or inactive token'
    ]);
    exit;
}

// ================================
// INPUT FILTERS (OPTIONAL)
// ================================
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$type = strtoupper(sanitize_text_field($input['type'] ?? ''));
// Allowed: DSTV, GOTV, STARTIMES

// ================================
// FETCH CABLE PLANS
// ================================
$table_cable = $wpdb->prefix . 'pulsepoint_cable';

$where  = [];
$params = [];

if (!empty($type)) {
    $where[]  = "type = %s";
    $params[] = $type;
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$query = "
    SELECT * FROM {$table_cable}
    {$where_sql}
    ORDER BY type, amount ASC
";

$plans = $params
    ? $wpdb->get_results($wpdb->prepare($query, ...$params))
    : $wpdb->get_results($query);

if (!$plans) {
    echo json_encode([
        'success' => false,
        'message' => 'No cable plans found'
    ]);
    exit;
}

// ================================
// GROUP PLANS BY TYPE
// ================================
$result = [];

foreach ($plans as $plan) {
    $typ = $plan->type ?? 'DSTV';

    $result[$typ][] = [
        'id'        => (int) $plan->id,
        'plan'      => $plan->plan,
        'details'   => $plan->details,
        'amount'    => (float) $plan->amount,
        'cashback'  => (float) $plan->cashback,
        'apiamount' => (float) $plan->apiamount,
        'provider'  => $plan->provider
    ];
}

// ================================
// RESPONSE
// ================================
echo json_encode([
    'success' => true,
    'message' => 'Cable plans fetched successfully',
    'data'    => $result
]);
exit;