<?php
/**
 * Pulsepoint Add/Edit Provider API Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-provider-api.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_provider = "{$base_prefix}provider";

// === Fetch Settings for Branding ===
$settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$set = [];
foreach ($settings as $row) $set[$row->opt_key] = maybe_unserialize($row->opt_value);
$platform_name = $set['platform_name'] ?? 'Pulsepoint';
$color_hex = $set['color_hex'] ?? '#356cf9';

// === Edit Mode ===
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$provider = null;
if ($id) $provider = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_provider} WHERE id = %d", $id));

// === Handle Save ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_provider_nonce']) && wp_verify_nonce($_POST['pulsepoint_provider_nonce'], 'save_pulsepoint_provider')) {
    $data = [
        'name' => sanitize_text_field($_POST['name']),
        'token' => sanitize_textarea_field($_POST['token']),
        'value' => sanitize_textarea_field($_POST['value']),
    ];

    if ($id) {
        $wpdb->update($table_provider, $data, ['id' => $id]);
        echo '<div class="updated notice"><p><strong>Provider updated successfully.</strong></p></div>';
    } else {
        $wpdb->insert($table_provider, $data);
        echo '<div class="updated notice"><p><strong>Provider added successfully.</strong></p></div>';
    }
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= $id ? 'Edit Provider' : 'Add New Provider' ?></h1>
  <p>Manage API provider credentials and tokens.</p>
  </br>
  <a href="?page=pulsepoint-provider" class="button">← Back to Providers</a>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
      max-width: 720px;
    }
    .pulse-input {
      width: 100%;
      border: 1px solid #ddd;
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 14px;
    }
    .pulse-label {
      font-weight: 600;
      font-size: 14px;
      margin-bottom: 6px;
      display: block;
    }
    .pulse-btn {
      background: var(--primary);
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
    }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_provider', 'pulsepoint_provider_nonce'); ?>

    <div class="pulse-section">
      <div class="mb-4">
        <label class="pulse-label">Provider Name</label>
        <input type="text" name="name" required value="<?= esc_attr($provider->name ?? '') ?>" class="pulse-input">
      </div>
      <div class="mb-4">
        <label class="pulse-label">Token</label>
        <textarea name="token" rows="3" class="pulse-input"><?= esc_textarea($provider->token ?? '') ?></textarea>
      </div>
      <div class="mb-4">
        <label class="pulse-label">Value / Description</label>
        <textarea name="value" rows="3" class="pulse-input"><?= esc_textarea($provider->value ?? '') ?></textarea>
      </div>
      <div class="text-right">
        <button type="submit" class="pulse-btn">
          <i class="bi bi-save"></i> <?= $id ? 'Update Provider' : 'Add Provider' ?>
        </button>
      </div>
    </div>
  </form>
</div>