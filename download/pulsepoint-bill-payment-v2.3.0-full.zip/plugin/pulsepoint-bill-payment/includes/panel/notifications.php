<?php
/**
 * Pulsepoint Notifications Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/notifications.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_users = "{$base_prefix}users";

// === Create users table if not exists ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_users}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `firstname` VARCHAR(100) NOT NULL,
    `lastname` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(30) DEFAULT NULL,
    `email` VARCHAR(200) NOT NULL,
    `wallet` DECIMAL(14,2) DEFAULT 0.00,
    PRIMARY KEY (`id`),
    UNIQUE KEY `email_unique` (`email`)
) {$charset};");

// === Fetch all users ===
$users = $wpdb->get_results("SELECT id, firstname, lastname, email FROM {$table_users} ORDER BY firstname ASC");

// === Handle Form Submission ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_notifications_nonce']) && wp_verify_nonce($_POST['pulsepoint_notifications_nonce'], 'send_pulsepoint_notifications')) {
    $selected_users = $_POST['users'] ?? [];
    $subject = sanitize_text_field($_POST['subject'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');
    
    if (!empty($selected_users) && !empty($subject) && !empty($message)) {
        $sent_count = 0;
        foreach ($selected_users as $user_id) {
            $user = $wpdb->get_row($wpdb->prepare("SELECT email, firstname FROM {$table_users} WHERE id=%d", $user_id));
            if ($user && is_email($user->email)) {
                $headers = ['Content-Type: text/html; charset=UTF-8'];
                $personal_message = "Hi " . esc_html($user->firstname) . ",<br><br>" . nl2br($message);
                if (wp_mail($user->email, $subject, $personal_message, $headers)) {
                    $sent_count++;
                }
            }
        }
        echo '<div class="updated notice"><p><strong>Emails sent: ' . intval($sent_count) . '/' . count($selected_users) . '</strong></p></div>';
    } else {
        echo '<div class="error notice"><p><strong>Please select users and fill in subject & message.</strong></p></div>';
    }
}

// === Get platform info for UI ===
$table_settings = "{$base_prefix}settings";
$settings = [];
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
foreach ($rows as $r) {
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#356cf9';
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Notifications</h1>
  <p>Send bulk emails to users. Select specific users or choose all.</p>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
    .pulse-users { max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 8px; }
    .pulse-user { display: flex; align-items: center; margin-bottom: 6px; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('send_pulsepoint_notifications', 'pulsepoint_notifications_nonce'); ?>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-envelope"></i> Select Users</h2>
      <div class="pulse-users">
        <div class="pulse-user">
          <input type="checkbox" id="select_all_users" /> <label for="select_all_users" class="ml-2 font-semibold">Select All</label>
        </div>
        <?php foreach ($users as $user): ?>
          <div class="pulse-user">
            <input type="checkbox" name="users[]" value="<?= esc_attr($user->id) ?>" class="user_checkbox" id="user_<?= $user->id ?>">
            <label for="user_<?= $user->id ?>" class="ml-2"><?= esc_html($user->firstname . ' ' . $user->lastname . ' (' . $user->email . ')') ?></label>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-card-text"></i> Compose Message</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Subject</label>
          <input type="text" name="subject" class="pulse-input" required>
        </div>
        <div>
          <label class="pulse-label">Message</label>
          <textarea name="message" class="pulse-input" rows="6" required></textarea>
        </div>
      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-send"></i> Send Email</button>
    </div>
  </form>
</div>

<script>
  // Select / Deselect all users
  document.getElementById('select_all_users').addEventListener('change', function() {
    let checkboxes = document.querySelectorAll('.user_checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
  });
</script>