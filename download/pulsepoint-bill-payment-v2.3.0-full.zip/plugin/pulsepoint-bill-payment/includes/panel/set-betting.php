<?php
/**
 * Pulsepoint Betting API Settings
 * URL: admin.php?page=pulsepoint-set-betting
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_settings = "{$base_prefix}settings";

/* === FETCH SETTINGS === */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}", OBJECT_K);

$betting_api   = $settings_rows['betting_api']->opt_value ?? 'https://ncwallet.africa/api/v1/betting';
$betting_token = $settings_rows['betting_token']->opt_value ?? '';
$betting_kyc   = $settings_rows['betting_kyc']->opt_value ?? '0';

/* === SAVE SETTINGS === */
if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_betting_settings_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_betting_settings_nonce'], 'save_pulsepoint_betting_settings')
) {

    $data = [
        'betting_api'   => sanitize_text_field($_POST['betting_api']),
        'betting_token' => sanitize_text_field($_POST['betting_token']),
        'betting_kyc'   => sanitize_text_field($_POST['betting_kyc']),
    ];

    foreach ($data as $key => $value) {

        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_settings} WHERE opt_key = %s",
            $key
        ));

        if ($exists) {
            $wpdb->update(
                $table_settings,
                ['opt_value' => $value],
                ['opt_key' => $key]
            );
        } else {
            $wpdb->insert(
                $table_settings,
                [
                    'opt_key'   => $key,
                    'opt_value' => $value,
                    'type'      => 'string',
                    'grouping'  => 'betting'
                ]
            );
        }
    }

    echo '<div class="updated notice"><p><strong>Betting API settings saved successfully.</strong></p></div>';

    // Refresh values
    $betting_api   = $data['betting_api'];
    $betting_token = $data['betting_token'];
    $betting_kyc   = $data['betting_kyc'];
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Betting API Settings</h1>
  <a href="?page=pulsepoint-betting" class="page-title-action"><i class="bi bi-arrow-left"></i> Back to Betting Platforms</a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }

    .pulse-section {
      background:#fff;
      border-radius:14px;
      padding:24px;
      box-shadow:0 3px 10px rgba(0,0,0,0.05);
      margin-top:24px;
    }

    .pulse-input {
      width:100%;
      border:1px solid #ddd;
      padding:10px 14px;
      border-radius:8px;
      font-size:14px;
    }

    .pulse-label {
      font-weight:600;
      font-size:14px;
      margin-bottom:6px;
      display:block;
    }

    .pulse-btn {
      background:var(--primary);
      color:#fff;
      padding:10px 20px;
      border:none;
      border-radius:8px;
      cursor:pointer;
      font-weight:600;
    }

    .pulse-grid {
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
      gap:16px;
    }
  </style>

  <p class="text-sm text-gray-500 mb-2">Token format is <code>trnx_pin:token</code> — e.g. <code>0987:sandbox_ncsk_90eff8a5e2250d553f297b703fb510dd46e3e5cc</code></p>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_betting_settings', 'pulsepoint_betting_settings_nonce'); ?>

    <div class="pulse-section">
      <div class="pulse-grid">

        <!-- API Endpoint -->
        <div>
          <label class="pulse-label">API Endpoint</label>
          <input type="text" name="betting_api"
                 value="<?= esc_attr($betting_api) ?>"
                 placeholder="https://ncwallet.africa/api/v1/betting"
                 class="pulse-input" required>
        </div>

        <!-- API Token -->
        <div>
          <label class="pulse-label">API Token (pin:token)</label>
          <input type="text" name="betting_token"
                 value="<?= esc_attr($betting_token) ?>"
                 placeholder="0987:sandbox_ncsk_..."
                 class="pulse-input">
        </div>

        <!-- KYC Toggle -->
        <div>
          <label class="pulse-label">Require KYC</label>
          <select name="betting_kyc" class="pulse-input">
            <option value="0" <?= $betting_kyc == '0' ? 'selected' : '' ?>>Disabled</option>
            <option value="1" <?= $betting_kyc == '1' ? 'selected' : '' ?>>Enabled</option>
          </select>
        </div>

      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn">
        Save Settings
      </button>
    </div>

  </form>
</div>
