<?php
/**
 * Pulsepoint Other Key Settings Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/other-key.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_settings = "{$base_prefix}settings";

// === Create settings table if not exists ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_settings}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `opt_key` VARCHAR(255) NOT NULL,
    `opt_value` TEXT,
    `type` VARCHAR(50) DEFAULT 'string',
    `grouping` VARCHAR(100) DEFAULT NULL,
    `autoload` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `opt_key_unique` (`opt_key`)
) {$charset};");

// === Default Settings ===
$defaults = [
    // 💳 Card Fee Configuration
    'card_creation_flat_fee'    => '2.50',   // Flat $2.50 charge
    'card_creation_percent_fee' => '1.5',    // 1.5% additional
    'card_funding_flat_fee'     => '1.90',   // Flat $1.90 charge
    'card_funding_percent_fee'  => '1.9',    // 1.9% additional
    'card_withdraw_flat_fee'    => '1.90',   // Flat $1.90 charge
    'card_withdraw_percent_fee' => '1.9',    // 1.9% additional

    // 💱 Currency & Conversion
    'rate_usd'   => '1560',
    'rate_naira' => '1460',

    // 🔑 Stropay / Strowallet Keys
    'stropay_pkey'        => 'public-key',
    'stropay_skey'        => 'secret-key',
    'strowallet_vip_key'  => 'vip-key',
];

// === Sync defaults with DB ===
foreach ($defaults as $key => $value) {
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s", $key));
    if (!$exists) {
        $wpdb->insert($table_settings, [
            'opt_key' => $key,
            'opt_value' => maybe_serialize($value),
            'type' => 'string',
            'autoload' => 1
        ]);
    }
}

// === Handle Save ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_otherkey_nonce']) && wp_verify_nonce($_POST['pulsepoint_otherkey_nonce'], 'save_pulsepoint_otherkey')) {
    foreach ($_POST as $key => $value) {
        if (array_key_exists($key, $defaults)) {
            $wpdb->update(
                $table_settings,
                ['opt_value' => maybe_serialize(sanitize_text_field($value))],
                ['opt_key' => $key]
            );
        }
    }
    echo '<div class="updated notice"><p><strong>Other Key settings saved successfully.</strong></p></div>';
}

// === Fetch all current settings ===
$settings = [];
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
foreach ($rows as $r) {
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);
}

// === Platform Info for Style ===
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#356cf9';
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Other Key Settings</h1>
  <p>Manage card fee configuration, conversion rates, and Stropay / Strowallet API keys here.</p>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 16px; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_otherkey', 'pulsepoint_otherkey_nonce'); ?>

    <!-- Card Fee Section -->
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-credit-card"></i> Card Fee Configuration</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Card Creation Flat Fee ($)</label>
          <input type="text" name="card_creation_flat_fee" value="<?= esc_attr($settings['card_creation_flat_fee']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Card Creation Percent Fee (%)</label>
          <input type="text" name="card_creation_percent_fee" value="<?= esc_attr($settings['card_creation_percent_fee']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Card Funding Flat Fee ($)</label>
          <input type="text" name="card_funding_flat_fee" value="<?= esc_attr($settings['card_funding_flat_fee']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Card Funding Percent Fee (%)</label>
          <input type="text" name="card_funding_percent_fee" value="<?= esc_attr($settings['card_funding_percent_fee']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Card Withdraw Flat Fee ($)</label>
          <input type="text" name="card_withdraw_flat_fee" value="<?= esc_attr($settings['card_withdraw_flat_fee']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Card Withdraw Percent Fee (%)</label>
          <input type="text" name="card_withdraw_percent_fee" value="<?= esc_attr($settings['card_withdraw_percent_fee']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    <!-- Conversion Rates -->
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-currency-exchange"></i> Conversion Rates</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">USD Rate</label>
          <input type="number" name="rate_usd" value="<?= esc_attr($settings['rate_usd']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Naira Rate</label>
          <input type="number" name="rate_naira" value="<?= esc_attr($settings['rate_naira']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    <!-- API Keys -->
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-key"></i> Stropay / Strowallet Keys</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Stropay Public Key</label>
          <input type="text" name="stropay_pkey" value="<?= esc_attr($settings['stropay_pkey']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Stropay Secret Key</label>
          <input type="text" name="stropay_skey" value="<?= esc_attr($settings['stropay_skey']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Strowallet VIP Key</label>
          <input type="text" name="strowallet_vip_key" value="<?= esc_attr($settings['strowallet_vip_key']) ?>" class="pulse-input">
        </div>
      </div>
    </div>

    <!-- Save Button -->
    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Settings</button>
    </div>
  </form>
</div>