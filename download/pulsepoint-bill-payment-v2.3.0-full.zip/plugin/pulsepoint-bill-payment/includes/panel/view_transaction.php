<?php  
/**  
 * Pulsepoint View Transaction Page  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/view_transaction.php  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// === Tables ===  
$table_users = "{$base_prefix}users";  
$table_trnx  = "{$base_prefix}trnx";  
  
// === Fetch transaction ID ===  
$transaction_id = isset($_GET['id']) ? intval($_GET['id']) : 0;  

// ==============================
// HANDLE STATUS UPDATE (NEW)
// ==============================
$message = '';

if (isset($_POST['update_status']) && $transaction_id > 0) {

    $new_status = sanitize_text_field($_POST['status']);

    // Get current transaction
    $current = $wpdb->get_row("SELECT * FROM {$table_trnx} WHERE id = {$transaction_id}");

    if ($current) {

        $wpdb->query('START TRANSACTION');

        try {

            // === Update transaction status ===
            $updated = $wpdb->update(
                $table_trnx,
                [
                    'status' => $new_status,
                    'updated_at' => current_time('mysql')
                ],
                ['id' => $transaction_id],
                ['%s', '%s'],
                ['%d']
            );

            // === OPTIONAL: Wallet Logic ===
            // Only refund if FAILED and was previously SUCCESS
            if ($new_status === 'failed' && $current->status === 'success') {

                $wpdb->query("UPDATE {$table_users} 
                    SET wallet = wallet + {$current->amount} 
                    WHERE id = {$current->user_id}");
            }

            // Prevent double deduction (IMPORTANT SAFETY)
            if ($new_status === 'success' && $current->status !== 'success') {

                $wpdb->query("UPDATE {$table_users} 
                    SET wallet = wallet - {$current->amount} 
                    WHERE id = {$current->user_id}");
            }

            $wpdb->query('COMMIT');

            $message = '<div class="notice notice-success"><p>Transaction status updated successfully.</p></div>';

        } catch (Exception $e) {

            $wpdb->query('ROLLBACK');
            $message = '<div class="notice notice-error"><p>Error updating transaction.</p></div>';
        }

    }
}
  
// === Fetch transaction ===  
$transaction = $wpdb->get_row("  
    SELECT t.*, u.firstname, u.lastname, u.phone, u.email, u.wallet   
    FROM {$table_trnx} t  
    LEFT JOIN {$table_users} u ON t.user_id = u.id  
    WHERE t.id = {$transaction_id}  
");  
  
if (!$transaction) {  
    echo '<div class="wrap"><h2>Transaction not found.</h2><p><a href="?page=pulsepoint-transactions" class="button button-primary">← Back to Transactions</a></p></div>';  
    return;  
}  
  
// === Platform Settings ===  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#6C63FF';  
  
// === Format Amount ===  
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }  
?>  

<div class="wrap">  
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — View Transaction</h1>  
  <p>Detailed transaction information below.</p>  

  <?= $message ?> <!-- SHOW MESSAGE -->

  <hr class="wp-header-end">  

  <!-- Tailwind -->  
  <script src="https://cdn.tailwindcss.com"></script>  
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">  

  <style>  
    :root { --primary: <?= $color_hex ?>; }  
    .pulse-box {  
      background: #fff;  
      border-radius: 14px;  
      padding: 24px;  
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);  
      margin-top: 20px;  
      max-width: 900px;  
    }  
    .pulse-grid {  
      display: grid;  
      grid-template-columns: 180px 1fr;  
      gap: 12px;  
      margin-bottom: 14px;  
    }  
    .label {  
      font-weight: 600;  
      color: #555;  
      font-size: 14px;  
    }  
    .value {  
      color: #222;  
      font-size: 15px;  
      word-break: break-word;  
    }  
    .section-title {  
      font-weight: 700;  
      color: var(--primary);  
      margin-top: 25px;  
      font-size: 18px;  
      border-bottom: 2px solid #eee;  
      padding-bottom: 6px;  
    }  
    .back-btn {  
      display: inline-flex;  
      align-items: center;  
      background: var(--primary);  
      color: #fff;  
      padding: 10px 16px;  
      border-radius: 8px;  
      text-decoration: none;  
      font-size: 14px;  
      margin-top: 16px;  
    }  
    .back-btn i { margin-right: 6px; }  
    pre {  
      background: #f8fafc;  
      padding: 10px;  
      border-radius: 8px;  
      font-size: 13px;  
      overflow-x: auto;  
      max-height: 300px;  
    }  
  </style>  

  <div class="pulse-box">  

    <!-- ===================== -->
    <!-- STATUS UPDATE FORM -->
    <!-- ===================== -->
    <div class="section-title">Update Status</div>

    <form method="POST">
      <div class="pulse-grid">
        <div class="label">Change Status:</div>
        <div class="value">
        </br>
          <select name="status" class="border px-3 py-2 rounded">
            <option value="pending" <?= $transaction->status == 'pending' ? 'selected' : '' ?>>Pending</option>
            <option value="success" <?= $transaction->status == 'success' ? 'selected' : '' ?>>Success</option>
            <option value="failed" <?= $transaction->status == 'failed' ? 'selected' : '' ?>>Failed</option>
          </select>
          </br>
          </br>
          <button type="submit" name="update_status" class="ml-2 px-4 py-2 bg-blue-600 text-white rounded">
            Update
          </button>
        </div>
      </div>
    </form>

    <div class="section-title">User Information</div>  
    <div class="pulse-grid"><div class="label">Full Name:</div><div class="value"><?= esc_html($transaction->firstname . ' ' . $transaction->lastname) ?></div></div>  
    <div class="pulse-grid"><div class="label">Phone:</div><div class="value"><?= esc_html($transaction->phone) ?></div></div>  
    <div class="pulse-grid"><div class="label">Email:</div><div class="value"><?= esc_html($transaction->email) ?></div></div>  
    <div class="pulse-grid"><div class="label">Wallet Balance:</div><div class="value"><?= fmt_amt($transaction->wallet) ?></div></div>  

    <div class="section-title">Transaction Details</div>  
    <div class="pulse-grid"><div class="label">Recipient:</div><div class="value"><?= esc_html($transaction->recipient ?: '-') ?></div></div>  
    <div class="pulse-grid"><div class="label">Amount:</div><div class="value font-semibold"><?= fmt_amt($transaction->amount) ?></div></div>  
    <div class="pulse-grid"><div class="label">Reference:</div><div class="value"><?= esc_html($transaction->reference) ?></div></div>  
    <div class="pulse-grid"><div class="label">Payment Method:</div><div class="value"><?= ucfirst($transaction->payment) ?></div></div>  
    <div class="pulse-grid"><div class="label">Category:</div><div class="value"><?= ucfirst($transaction->category) ?></div></div>  

    <div class="pulse-grid"><div class="label">Status:</div>  
      <div class="value">  
        <?php if ($transaction->status === 'success'): ?>  
          <span class="text-green-600 font-semibold">Success</span>  
        <?php elseif ($transaction->status === 'pending'): ?>  
          <span class="text-yellow-600 font-semibold">Pending</span>  
        <?php else: ?>  
          <span class="text-red-600 font-semibold">Failed</span>  
        <?php endif; ?>  
      </div>  
    </div>  

    <div class="pulse-grid"><div class="label">Type:</div><div class="value"><?= ucfirst($transaction->type) ?></div></div>  
    <div class="pulse-grid"><div class="label">Session:</div><div class="value"><?= esc_html($transaction->session) ?></div></div>  
    <div class="pulse-grid"><div class="label">Description:</div><div class="value"><?= esc_html($transaction->description) ?></div></div>  
    <div class="pulse-grid"><div class="label">Date:</div><div class="value"><?= esc_html($transaction->date) ?></div></div>  
    <div class="pulse-grid"><div class="label">Updated At:</div><div class="value"><?= esc_html($transaction->updated_at) ?></div></div>  

    <div class="section-title">Payload</div>  
    <pre><?= esc_html($transaction->details) ?></pre>  

    <div class="section-title">Api Response</div>  
    <pre><?= esc_html($transaction->gateway_response) ?></pre>  

    <a href="?page=pulsepoint-transactions" class="back-btn"><i class="bi bi-arrow-left"></i> Back to Transactions</a>

  </div>  
</div>