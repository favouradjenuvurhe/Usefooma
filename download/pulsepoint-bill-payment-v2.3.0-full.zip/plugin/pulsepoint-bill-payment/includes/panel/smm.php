<?php
/**
 * Pulsepoint SMM (Boost) Admin Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/smm.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_settings = "{$base_prefix}settings";
$table_smm = "{$base_prefix}smm_services";

$notice = '';

/* =========================================================
   SAVE PROVIDER SETTINGS
   ========================================================= */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_smm_settings_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_smm_settings_nonce'], 'save_pulsepoint_smm_settings')
) {
    $data = [
        'smm_api_provider' => sanitize_text_field($_POST['smm_api_provider'] ?? 'owlet'),
        'smm_api'          => esc_url_raw($_POST['smm_api'] ?? ''),
        'smm_token'        => sanitize_text_field($_POST['smm_token'] ?? ''),
        'smm_markup'       => floatval($_POST['smm_markup'] ?? 0),
    ];

    foreach ($data as $key => $value) {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_settings} WHERE opt_key=%s", $key));
        if ($exists) {
            $wpdb->update($table_settings, ['opt_value' => maybe_serialize($value)], ['opt_key' => $key]);
        } else {
            $wpdb->insert($table_settings, ['opt_key' => $key, 'opt_value' => maybe_serialize($value)]);
        }
    }

    $notice = 'SMM settings saved.';
}

/* =========================================================
   MANUAL SYNC
   ========================================================= */
if (isset($_GET['sync']) && check_admin_referer('pulsepoint_smm_sync_action')) {
    do_action('pulsepoint_cron_smm_sync');
    $notice = 'Service catalog sync triggered — refresh in a moment to see updates.';
}

/* =========================================================
   TOGGLE / DELETE SERVICE
   ========================================================= */
if (isset($_GET['toggle_service']) && is_numeric($_GET['toggle_service']) && check_admin_referer('pulsepoint_smm_service_action')) {
    $current = $wpdb->get_var($wpdb->prepare("SELECT status FROM {$table_smm} WHERE id=%d", intval($_GET['toggle_service'])));
    $next = $current === 'active' ? 'inactive' : 'active';
    $wpdb->update($table_smm, ['status' => $next], ['id' => intval($_GET['toggle_service'])]);
    $notice = 'Service marked ' . $next . '.';
}

/* =========================================================
   FETCH DATA
   ========================================================= */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings} WHERE opt_key IN ('smm_api_provider','smm_api','smm_token','smm_markup','smm_last_synced')", OBJECT_K);

$smm_provider     = $settings_rows['smm_api_provider']->opt_value ?? 'owlet';
$smm_provider     = maybe_unserialize($smm_provider) ?: 'owlet';
$smm_api          = maybe_unserialize($settings_rows['smm_api']->opt_value ?? '');
$smm_token        = maybe_unserialize($settings_rows['smm_token']->opt_value ?? '');
$smm_markup       = maybe_unserialize($settings_rows['smm_markup']->opt_value ?? '0');
$smm_last_synced  = maybe_unserialize($settings_rows['smm_last_synced']->opt_value ?? '');
$rate_label = ($smm_provider === 'ncwallet') ? 'Rate / Qty' : 'Rate /1000';

$category_filter = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$where = $category_filter ? $wpdb->prepare("WHERE category = %s", $category_filter) : '';

$services = $wpdb->get_results("SELECT * FROM {$table_smm} {$where} ORDER BY category ASC, name ASC LIMIT 300");
$categories = $wpdb->get_col("SELECT DISTINCT category FROM {$table_smm} ORDER BY category ASC");
$total_services = $wpdb->get_var("SELECT COUNT(*) FROM {$table_smm}");
?>
<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Boost (SMM)</h1>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; text-decoration: none; display: inline-block; font-size: 13px; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 8px; font-size: 13px; }
    th { text-align: left; background: #f9fafb; font-weight: 600; }
    .badge { padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .badge-active { background: #dcfce7; color: #166534; }
    .badge-inactive { background: #fee2e2; color: #991b1b; }
  </style>

  <?php if ($notice): ?>
    <div class="updated notice"><p><strong><?= esc_html($notice) ?></strong></p></div>
  <?php endif; ?>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-rocket"></i> Provider Settings</h2>

    <p class="text-xs text-gray-500 mb-4">
      NCWallet token format is <code>trnx_pin:token</code>. Owlet (and any other generic SMM panel using the standard action=services/add/status API) uses a plain API key.
    </p>

    <form method="POST" class="pulse-grid mb-4">
      <?php wp_nonce_field('save_pulsepoint_smm_settings', 'pulsepoint_smm_settings_nonce'); ?>

      <div>
        <label class="pulse-label">Provider</label>
        <select name="smm_api_provider" class="pulse-input">
          <option value="owlet" <?= $smm_provider === 'owlet' ? 'selected' : '' ?>>Owlet (generic SMM panel)</option>
          <option value="ncwallet" <?= $smm_provider === 'ncwallet' ? 'selected' : '' ?>>NCWallet</option>
        </select>
      </div>

      <div>
        <label class="pulse-label">API Endpoint</label>
        <input type="text" name="smm_api" value="<?= esc_attr($smm_api) ?>" placeholder="<?= $smm_provider === 'ncwallet' ? 'https://ncwallet.africa/api/v1' : 'https://theowlet.com/api/v2' ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">API Key / Token</label>
        <input type="text" name="smm_token" value="<?= esc_attr($smm_token) ?>" placeholder="Owlet: API key — NCWallet: pin:token" class="pulse-input">
        <?php if ($smm_provider === 'ncwallet'): ?><p class="text-xs text-gray-400 mt-1">NCWallet token format: <code>transaction_pin:api_key</code>. Services use NCWallet's per-quantity rate.</p><?php endif; ?>
      </div>

      <div>
        <label class="pulse-label">Markup (%)</label>
        <input type="number" step="0.01" name="smm_markup" value="<?= esc_attr($smm_markup) ?>" class="pulse-input">
      </div>

      <div class="flex items-end">
        <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Settings</button>
      </div>
    </form>

    <div class="flex items-center justify-between border-t border-gray-100 pt-4">
      <p class="text-xs text-gray-400">
        Last synced: <?= $smm_last_synced ? esc_html($smm_last_synced) : 'Never' ?> &middot; <?= (int) $total_services ?> services on file
      </p>
      <a href="<?= wp_nonce_url('?page=pulsepoint-smm&sync=1', 'pulsepoint_smm_sync_action') ?>" class="pulse-btn"><i class="bi bi-arrow-repeat"></i> Sync Services Now</a>
    </div>
  </div>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-list-ul"></i> Services</h2>

    <?php if ($categories): ?>
      <div class="flex gap-2 flex-wrap mb-4">
        <a href="?page=pulsepoint-smm" class="pulse-btn" style="background:<?= $category_filter === '' ? 'var(--primary)' : '#f3f4f6' ?>;color:<?= $category_filter === '' ? '#fff' : '#333' ?>;">All</a>
        <?php foreach ($categories as $cat): ?>
          <a href="?page=pulsepoint-smm&category=<?= urlencode($cat) ?>" class="pulse-btn" style="background:<?= $category_filter === $cat ? 'var(--primary)' : '#f3f4f6' ?>;color:<?= $category_filter === $cat ? '#fff' : '#333' ?>;"><?= esc_html($cat) ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (!$services): ?>
      <p>No services yet — click "Sync Services Now" above once your provider settings are saved.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr><th>Category</th><th>Name</th><th><?= esc_html($rate_label) ?></th><th>Min</th><th>Max</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($services as $s): $is_active = $s->status === 'active'; ?>
              <tr>
                <td><?= esc_html($s->category) ?></td>
                <td><?= esc_html($s->name) ?></td>
                <td>₦<?= number_format((float) $s->rate, 2) ?></td>
                <td><?= (int) $s->min ?></td>
                <td><?= (int) $s->max ?></td>
                <td><span class="badge <?= $is_active ? 'badge-active' : 'badge-inactive' ?>"><?= $is_active ? 'Active' : 'Inactive' ?></span></td>
                <td>
                  <a href="<?= wp_nonce_url('?page=pulsepoint-smm&toggle_service=' . $s->id . ($category_filter ? '&category=' . urlencode($category_filter) : ''), 'pulsepoint_smm_service_action') ?>" class="pulse-btn" style="background:<?= $is_active ? '#f59e0b' : '#22c55e' ?>;"><?= $is_active ? 'Turn Off' : 'Turn On' ?></a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
