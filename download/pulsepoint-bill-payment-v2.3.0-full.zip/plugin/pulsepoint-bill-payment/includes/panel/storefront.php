<?php
/** Pulsepoint Storefront admin configuration and store review. */
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) { wp_die('You do not have permission to manage Storefront.'); }

global $wpdb;
$table = function_exists('pulsepoint_storefront_table') ? pulsepoint_storefront_table() : $wpdb->prefix.'pulsepoint_stores';
if (function_exists('pulsepoint_storefront_install_table')) pulsepoint_storefront_install_table();

$notice = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_storefront_admin_action'])) {
    check_admin_referer('pulsepoint_storefront_admin');
    $action = sanitize_key($_POST['pulsepoint_storefront_admin_action']);
    if ($action === 'save_fees') {
        $percent = max(0, min(100, (float)($_POST['fee_percent'] ?? 0)));
        $flat = max(0, (float)($_POST['fee_flat'] ?? 0));
        update_option('pulsepoint_storefront_fee_percent', $percent, false);
        update_option('pulsepoint_storefront_fee_flat', $flat, false);
        $notice = 'Store fee settings saved successfully.';
    } elseif ($action === 'review_store') {
        $store_id = absint($_POST['store_id'] ?? 0);
        $decision = sanitize_key($_POST['decision'] ?? '');
        $note = sanitize_textarea_field(wp_unslash($_POST['review_note'] ?? ''));
        $store = function_exists('pulsepoint_storefront_get_store_by_id') ? pulsepoint_storefront_get_store_by_id($store_id) : null;
        if (!$store) {
            $error = 'Store request not found.';
        } elseif (!in_array($decision, ['active','declined'], true)) {
            $error = 'Invalid review decision.';
        } else {
            $wpdb->update($table, ['status'=>$decision,'review_note'=>$note,'reviewed_by'=>get_current_user_id(),'reviewed_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')], ['id'=>$store_id], ['%s','%s','%d','%s','%s'], ['%d']);
            $owner = function_exists('pulsepoint_storefront_get_user') ? pulsepoint_storefront_get_user($store->user_id) : null;
            $email = sanitize_email($store->owner_email ?: ($owner->email ?? ''));
            if (is_email($email)) {
                $subject = '['.get_bloginfo('name').'] Storefront '.($decision==='active'?'approved':'declined').' — '.$store->name;
                $body = '<div style="font-family:Arial,sans-serif"><h2>Storefront '.($decision==='active'?'Approved':'Declined').'</h2><p>Your store <strong>'.esc_html($store->name).'</strong> has been '.($decision==='active'?'approved and is now live.':'declined by the administrator.').'</p>'.($note!==''?'<p><strong>Admin note:</strong><br>'.nl2br(esc_html($note)).'</p>':'').($decision==='active'?'<p>Public URL: <a href="'.esc_url(pulsepoint_storefront_public_url($store->slug)).'">'.esc_html(pulsepoint_storefront_public_url($store->slug)).'</a></p>':'').'</div>';
                @wp_mail($email,$subject,$body,['Content-Type: text/html; charset=UTF-8']);
            }
            $notice = 'Store '.$decision.' successfully.';
        }
    }
}

$fee_percent = function_exists('pulsepoint_storefront_fee_percent') ? pulsepoint_storefront_fee_percent() : (float)get_option('pulsepoint_storefront_fee_percent',0);
$fee_flat = function_exists('pulsepoint_storefront_fee_flat') ? pulsepoint_storefront_fee_flat() : (float)get_option('pulsepoint_storefront_fee_flat',0);
$stores = $wpdb->get_results("SELECT * FROM {$table} ORDER BY CASE status WHEN 'pending' THEN 0 WHEN 'active' THEN 1 ELSE 2 END, created_at DESC");
$pending_count = 0; foreach((array)$stores as $s){ if($s->status==='pending')$pending_count++; }
$woo = function_exists('pulsepoint_storefront_woo_active') && pulsepoint_storefront_woo_active();
$addon = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('storefront');
?>
<div class="wrap">
<h1>Pulsepoint Storefront</h1>
<p>Manage storefront fees, WooCommerce requirements and vendor store approvals. Public stores use <code>/p/store-name</code>.</p>
<?php if($notice): ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
<?php if($error): ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html($error); ?></p></div><?php endif; ?>

<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px;max-width:1100px;margin-top:20px">
<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:22px"><div style="font-size:12px;color:#6b7280;text-transform:uppercase;font-weight:700">Add-on</div><h2 style="margin:8px 0;font-size:20px"><?php echo $addon?'Connected':'Not active'; ?></h2><p style="color:#6b7280;margin:0">pulsepoint-storefront-addon</p></div>
<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:22px"><div style="font-size:12px;color:#6b7280;text-transform:uppercase;font-weight:700">WooCommerce</div><h2 style="margin:8px 0;font-size:20px;color:<?php echo $woo?'#16a34a':'#dc2626'; ?>"><?php echo $woo?'Connected':'Not active'; ?></h2><p style="color:#6b7280;margin:0"><?php echo $woo?'Products, cart and orders are available.':'Activate WooCommerce to enable ecommerce features.'; ?></p></div>
<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:22px"><div style="font-size:12px;color:#6b7280;text-transform:uppercase;font-weight:700">Pending review</div><h2 style="margin:8px 0;font-size:20px"><?php echo (int)$pending_count; ?></h2><p style="color:#6b7280;margin:0">Store requests waiting for approval.</p></div>
</div>

<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:24px;max-width:1100px;margin-top:20px">
<h2 style="margin-top:0">Store fee</h2><p style="color:#6b7280">The fee is added to each product's base price for customers. The store owner receives the product base price when an order is completed; the configured fee remains with the platform.</p>
<form method="post"><input type="hidden" name="pulsepoint_storefront_admin_action" value="save_fees"><?php wp_nonce_field('pulsepoint_storefront_admin'); ?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px"><label><strong>Percentage fee (%)</strong><input type="number" min="0" max="100" step="0.01" name="fee_percent" value="<?php echo esc_attr($fee_percent); ?>" style="width:100%;margin-top:8px"></label><label><strong>Flat fee (₦)</strong><input type="number" min="0" step="0.01" name="fee_flat" value="<?php echo esc_attr($fee_flat); ?>" style="width:100%;margin-top:8px"></label></div>
<p><button class="button button-primary" type="submit">Save Store Fee</button></p></form>
</div>

<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:24px;max-width:1100px;margin-top:20px">
<h2 style="margin-top:0">Store review</h2><p style="color:#6b7280">New stores remain private until an administrator approves them. Declined stores are not available at their public URL.</p>
<div style="overflow:auto"><table class="widefat striped"><thead><tr><th>Store</th><th>Owner</th><th>Contact</th><th>Status</th><th>Submitted</th><th>Review</th></tr></thead><tbody>
<?php if(!$stores): ?><tr><td colspan="6">No stores have been submitted.</td></tr><?php endif; ?>
<?php foreach((array)$stores as $store): $owner=function_exists('pulsepoint_storefront_get_user')?pulsepoint_storefront_get_user($store->user_id):null; ?>
<tr><td><strong><?php echo esc_html($store->name); ?></strong><br><small>/p/<?php echo esc_html($store->slug); ?></small><br><small><?php echo esc_html(wp_trim_words($store->description,18)); ?></small></td><td><?php echo esc_html(trim(($owner->firstname??'').' '.($owner->lastname??'')) ?: 'User #'.$store->user_id); ?><br><small>#<?php echo (int)$store->user_id; ?></small></td><td><?php echo esc_html($store->owner_email ?: ($owner->email??'Not provided')); ?><br><?php echo esc_html($store->owner_phone ?: ($owner->phone??'Not provided')); ?><br><?php echo nl2br(esc_html($store->owner_address ?: '')); ?></td><td><span style="display:inline-block;padding:4px 10px;border-radius:999px;background:<?php echo $store->status==='active'?'#dcfce7':($store->status==='pending'?'#fef3c7':'#fee2e2'); ?>;color:#374151;font-size:11px;font-weight:700"><?php echo esc_html(ucfirst($store->status)); ?></span></td><td><?php echo esc_html($store->created_at); ?></td><td><?php if($store->status==='pending'): ?><form method="post" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><input type="hidden" name="pulsepoint_storefront_admin_action" value="review_store"><input type="hidden" name="store_id" value="<?php echo (int)$store->id; ?>"><?php wp_nonce_field('pulsepoint_storefront_admin'); ?><input name="review_note" placeholder="Optional review note" style="min-width:180px"><button class="button button-primary" name="decision" value="active">Approve & Live</button><button class="button" name="decision" value="declined">Decline</button></form><?php else: ?><small><?php echo esc_html($store->review_note ?: 'No review note.'); ?></small><?php if($store->status==='active'): ?><br><a target="_blank" href="<?php echo esc_url(pulsepoint_storefront_public_url($store->slug)); ?>">View store</a><?php endif; ?><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div>
</div>
</div>
