<?php
/**
 * Pulsepoint Add/Edit Data Plan Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-data.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_data = "{$base_prefix}data";
$table_provider = "{$base_prefix}provider";

$edit_id = isset($_GET['edit']) ? intval($_GET['edit']) : 0;
$plan_data = null;

if ($edit_id) {
  $plan_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_data} WHERE id = %d", $edit_id));
}

// === Fetch Providers ===
$providers = $wpdb->get_results("SELECT id, name FROM {$table_provider} ORDER BY name ASC");

// === Save Logic ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_data_nonce']) && wp_verify_nonce($_POST['pulsepoint_data_nonce'], 'save_pulsepoint_data')) {
  $data = [
    'plan' => sanitize_text_field($_POST['plan']),
    'details' => sanitize_text_field($_POST['details']),
    'value' => sanitize_text_field($_POST['value']),
    'network' => sanitize_text_field($_POST['network']),
    'amount' => floatval($_POST['amount']),
    'purchase' => floatval($_POST['purchase']),
    'cashback' => floatval($_POST['cashback']),
    'apiamount' => floatval($_POST['apiamount']),
    'type' => sanitize_text_field($_POST['type']),
    'provider' => intval($_POST['provider']),
    'status' => sanitize_text_field($_POST['status'] ?? 'active'),
  ];

  if ($edit_id) {
    $wpdb->update($table_data, $data, ['id' => $edit_id]);
    echo '<div class="updated notice"><p><strong>Data plan updated successfully.</strong></p></div>';
  } else {
    $wpdb->insert($table_data, $data);
    echo '<div class="updated notice"><p><strong>Data plan added successfully.</strong></p></div>';
  }
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= $edit_id ? 'Edit Data Plan' : 'Add Data Plan' ?></h1>
  <a href="?page=pulsepoint-data" class="page-title-action"><i class="bi bi-arrow-left"></i> Back to Plans</a>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    .pulse-input {
      width: 100%;
      border: 1px solid #ddd;
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 14px;
    }
    .pulse-label {
      font-weight: 600;
      font-size: 14px;
      margin-bottom: 6px;
      display: block;
    }
    .pulse-btn {
      background: var(--primary);
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
    }
    .pulse-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
    }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_data', 'pulsepoint_data_nonce'); ?>
    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-plus-circle"></i> <?= $edit_id ? 'Edit Plan' : 'Add New Plan' ?></h2>

      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Plan ID</label>
          <input type="text" name="plan" value="<?= esc_attr($plan_data->plan ?? '') ?>" class="pulse-input" required>
        </div>
        <div>
          <label class="pulse-label">Details</label>
          <input type="text" name="details" value="<?= esc_attr($plan_data->details ?? '') ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Value</label>
          <input type="text" name="value" value="<?= esc_attr($plan_data->value ?? '') ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Network</label>
          <select name="network" class="pulse-input" required>
            <?php
              $networks = ['MTN', 'GLO', 'AIRTEL', '9MOBILE'];
              foreach ($networks as $net) {
                $sel = ($plan_data && strtoupper($plan_data->network) === $net) ? 'selected' : '';
                echo "<option value='{$net}' {$sel}>{$net}</option>";
              }
            ?>
          </select>
        </div>      
        <div>
          <label class="pulse-label">Purchase (₦)</label>
          <input type="number" step="0.01" name="purchase" value="<?= esc_attr($plan_data->purchase ?? '') ?>" class="pulse-input" required>
        </div>
        <div>
          <label class="pulse-label">Amount (₦)</label>
          <input type="number" step="0.01" name="amount" value="<?= esc_attr($plan_data->amount ?? '') ?>" class="pulse-input" required>
        </div>
        <div>
          <label class="pulse-label">Cashback (₦)</label>
          <input type="number" step="0.01" name="cashback" value="<?= esc_attr($plan_data->cashback ?? '') ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">API Amount (₦)</label>
          <input type="number" step="0.01" name="apiamount" value="<?= esc_attr($plan_data->apiamount ?? '') ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Type</label>
          <input type="text" name="type" value="<?= esc_attr($plan_data->type ?? '') ?>" class="pulse-input" placeholder="SME, GIFTING, DIRECT">
        </div>
        <div>
          <label class="pulse-label">Provider</label>
          <select name="provider" class="pulse-input" required>
            <option value="">Select Provider</option>
            <?php foreach ($providers as $p): ?>
              <option value="<?= $p->id ?>" <?= ($plan_data && $plan_data->provider == $p->id) ? 'selected' : '' ?>><?= esc_html($p->name) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="pulse-label">Status</label>
          <select name="status" class="pulse-input">
            <option value="active" <?= (!$plan_data || ($plan_data->status ?? 'active') === 'active') ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= ($plan_data && ($plan_data->status ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive</option>
          </select>
        </div>
      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> <?= $edit_id ? 'Update Plan' : 'Add Plan' ?></button>
    </div>
  </form>
</div>