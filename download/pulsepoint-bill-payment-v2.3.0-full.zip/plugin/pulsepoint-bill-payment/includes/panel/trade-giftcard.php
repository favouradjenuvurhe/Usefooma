<?php
/**
 * Pulsepoint Admin Giftcard Trade Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/trade-giftcard.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

// === TABLES ===
$table_users = "{$base_prefix}users";
$table_giftcard_settings = "{$base_prefix}giftcard_settings";
$table_giftcard_listings = "{$base_prefix}giftcard_listings";
$table_giftcard_transactions = "{$base_prefix}giftcard_transactions";

// === Create tables if not exists (safety) ===
$wpdb->query($sql_giftcard_settings ?? "CREATE TABLE IF NOT EXISTS `{$table_giftcard_settings}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `category` VARCHAR(100) NOT NULL,
    `type` ENUM('digital','physical') DEFAULT 'digital',
    `rate` DECIMAL(14,2) NOT NULL,
    `min_amount` DECIMAL(14,2) DEFAULT 0.00,
    `max_amount` DECIMAL(14,2) DEFAULT 0.00,
    `status` ENUM('active','inactive') DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) $charset;");

$wpdb->query($sql_giftcard_listings ?? "CREATE TABLE IF NOT EXISTS `{$table_giftcard_listings}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `giftcard_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(14,2) NOT NULL,
    `selling_price` DECIMAL(14,2) NOT NULL,
    `type` ENUM('digital','physical') NOT NULL,
    `digital_code` VARCHAR(255) DEFAULT NULL,
    `physical_image` VARCHAR(255) DEFAULT NULL,
    `status` ENUM('pending','approved','rejected','sold') DEFAULT 'pending',
    `note` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `{$table_users}`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`giftcard_id`) REFERENCES `{$table_giftcard_settings}`(`id`) ON DELETE CASCADE
) $charset;");

// === Platform Settings ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// === Totals ===
$total_pending = (float) $wpdb->get_var("SELECT COUNT(*) FROM {$table_giftcard_listings} WHERE status='pending'");
$total_approved = (float) $wpdb->get_var("SELECT COUNT(*) FROM {$table_giftcard_listings} WHERE status='approved'");
$total_sold = (float) $wpdb->get_var("SELECT COUNT(*) FROM {$table_giftcard_listings} WHERE status='sold'");

// === Search Handling ===
$where = "1=1";
$search_value = '';
if (!empty($_GET['search'])) {
    $search_value = sanitize_text_field($_GET['search']);
    $where .= $wpdb->prepare(" AND (
        g.id LIKE %s OR
        u.firstname LIKE %s OR
        u.lastname LIKE %s OR
        u.phone LIKE %s OR
        u.email LIKE %s OR
        g.status LIKE %s OR
        s.category LIKE %s
    )", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%");
}

// === Giftcard Listings Query ===
$listings = $wpdb->get_results("
    SELECT g.*, u.firstname, u.lastname, u.phone, u.email, s.category AS giftcard_category
    FROM {$table_giftcard_listings} g
    LEFT JOIN {$table_users} u ON g.user_id = u.id
    LEFT JOIN {$table_giftcard_settings} s ON g.giftcard_id = s.id
    WHERE {$where}
    ORDER BY g.created_at DESC
    LIMIT 100
");

// === Helper ===
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }
function fmt_usd($num) { return '$' . number_format((float)$num, 2); }
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Giftcard Trade</h1>
  <p>Manage and review all user-submitted giftcards below.</p>
  <hr class="wp-header-end">

  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 18px; margin-top: 20px; }
    .pulse-card { background: #fff; border-radius: 14px; padding: 18px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); }
    .pulse-title { color: #666; font-size: 13px; text-transform: uppercase; font-weight: 600; }
    .pulse-value { font-weight: 800; font-size: 22px; color: var(--primary); margin-top: 6px; }
    .search-bar { margin-top: 24px; display: flex; gap: 12px; }
    .search-input { width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #ddd; font-size: 14px; }
    .search-btn { background: var(--primary); color: #fff; padding: 10px 18px; border-radius: 8px; cursor: pointer; border: none; }
    .pulse-table-container { margin-top: 28px; background: #fff; border-radius: 12px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); overflow-x: auto; width: 100%; }
    .pulse-table { width: 100%; border-collapse: collapse; min-width: 1200px; }
    .pulse-table th, .pulse-table td { padding: 12px 14px; border-bottom: 1px solid #eee; text-align: left; font-size: 14px; white-space: nowrap; }
    .pulse-table th { background: #f8fafc; font-weight: 700; text-transform: uppercase; font-size: 12px; }
    .view-btn { background: var(--primary); color: #fff; padding: 6px 12px; border-radius: 8px; text-decoration: none; font-size: 13px; white-space: nowrap; }
  </style>

  <!-- Summary Cards -->
  <div class="pulse-grid">
    <div class="pulse-card">
      <div class="pulse-title">Pending Listings</div>
      <div class="pulse-value text-yellow-600"><?= $total_pending ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Approved Listings</div>
      <div class="pulse-value text-green-600"><?= $total_approved ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Sold Listings</div>
      <div class="pulse-value text-blue-600"><?= $total_sold ?></div>
    </div>
  </div>

  <!-- Search -->
  <form method="get" class="search-bar">
    <input type="hidden" name="page" value="pulsepoint-trade-giftcard">
    <input type="text" name="search" value="<?= esc_attr($search_value) ?>" class="search-input" placeholder="Search by user, phone, email, status, category...">
    <button type="submit" class="search-btn"><i class="bi bi-search"></i> Search</button>
  </form>

  <!-- Giftcard Listings Table -->
  <div class="pulse-table-container">
    <table class="pulse-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Giftcard</th>
          <th>Type</th>
          <th>Face Value</th>
          <th>Selling Price</th>
          <th>Status</th>
          <th>Created At</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($listings): foreach ($listings as $g): ?>
          <tr>
            <td>#<?= $g->id ?></td>
            <td><?= esc_html($g->firstname . ' ' . $g->lastname) ?></td>
            <td><?= esc_html($g->phone) ?></td>
            <td><?= esc_html($g->email) ?></td>
            <td><?= esc_html($g->giftcard_category) ?></td>
            <td><?= ucfirst($g->type) ?></td>
            <td><?= fmt_usd($g->amount) ?></td>
            <td><?= fmt_amt($g->selling_price) ?></td>
            <td>
              <?php
              $status_color = [
                  'pending' => 'text-yellow-600',
                  'approved' => 'text-green-600',
                  'rejected' => 'text-red-600',
                  'sold' => 'text-blue-600'
              ][$g->status] ?? 'text-gray-600';
              ?>
              <span class="<?= $status_color ?> font-semibold"><?= ucfirst($g->status) ?></span>
            </td>
            <td><?= esc_html($g->created_at) ?></td>
            <td>
              <a href="?page=pulsepoint-view_giftcard&id=<?= $g->id ?>" class="view-btn">View</a>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="11" class="text-center py-4">No giftcard listings found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>