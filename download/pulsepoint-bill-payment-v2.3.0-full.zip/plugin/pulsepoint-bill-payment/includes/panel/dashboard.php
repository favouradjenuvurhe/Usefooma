<?php
/**
 * Pulsepoint Admin Dashboard
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/dashboard.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

// === Fetch Platform Settings ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// === Tables ===
$table_users = "{$base_prefix}users";
$table_trnx  = "{$base_prefix}trnx";

// === Data & Metrics ===
$total_users   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_users}");
$total_tx      = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_trnx}");
$failed_tx     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_trnx} WHERE status='failed'");
$pending_tx    = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_trnx} WHERE status='pending'");
$success_tx    = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_trnx} WHERE status='success'");
$total_wallet  = (float) $wpdb->get_var("SELECT SUM(wallet) FROM {$table_users}");
$total_usd  = (float) $wpdb->get_var("SELECT SUM(dollar) FROM {$table_users}");
$last_user     = $wpdb->get_var("SELECT CONCAT(firstname,' ',lastname) FROM {$table_users} ORDER BY id DESC LIMIT 1");
$last_reg_time = $wpdb->get_var("SELECT created_at FROM {$table_users} ORDER BY id DESC LIMIT 1");
$last_tx_time  = $wpdb->get_var("SELECT date FROM {$table_trnx} ORDER BY id DESC LIMIT 1");

// Format helper
function fmt($num) { return number_format((float)$num, 2); }

?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Admin</h1>
  <p>Welcome to your admin analytics center. Monitor real-time platform activity below.</p>
  <hr class="wp-header-end">

  <!-- Tailwind + Chart.js -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root {
      --primary: <?= $color_hex ?>;
      --bg: #f8fafc;
    }
    body, .wrap {
      font-family: 'Inter', sans-serif !important;
    }
    .pulse-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 18px;
      margin-top: 20px;
    }
    .pulse-card {
      background: #fff;
      border-radius: 14px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      padding: 20px;
      transition: all .3s;
    }
    .pulse-card:hover {
      transform: translateY(-2px);
    }
    .pulse-title {
      color: #666;
      font-size: 13px;
      text-transform: uppercase;
      font-weight: 600;
    }
    .pulse-value {
      font-weight: 800;
      font-size: 22px;
      color: var(--primary);
      margin-top: 6px;
    }
    .pulse-chart {
      background: #fff;
      border-radius: 16px;
      margin-top: 28px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.07);
      padding: 24px;
    }
    .pulse-info {
      margin-top: 30px;
      background: #fff;
      padding: 20px;
      border-radius: 14px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.07);
    }
    .pulse-row {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid #eee;
      font-size: 15px;
    }
    .pulse-label { color: #555; font-weight: 600; }
    .pulse-val { color: var(--primary); font-weight: 700; }
  </style>

  <!-- Stats Section -->
  <div class="pulse-grid">
    <div class="pulse-card">
      <div class="pulse-title">Available Balance</div>
      <div class="pulse-value">₦<?= fmt($total_wallet) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Dollar Balance</div>
      <div class="pulse-value">$<?= fmt($total_usd) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Current Users</div>
      <div class="pulse-value"><?= number_format($total_users) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Total Transactions</div>
      <div class="pulse-value"><?= number_format($total_tx) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Successful Transactions</div>
      <div class="pulse-value text-green-600"><?= number_format($success_tx) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Failed Transactions</div>
      <div class="pulse-value text-red-600"><?= number_format($failed_tx) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Pending Transactions</div>
      <div class="pulse-value text-yellow-600"><?= number_format($pending_tx) ?></div>
    </div>
  </div>

  <!-- Chart -->
  <div class="pulse-chart">
    <h2 class="text-lg font-bold mb-4 text-gray-800 flex items-center gap-2">
      <i class="bi bi-graph-up"></i> Transaction Activity
    </h2>
    <canvas id="txChart" height="120"></canvas>
  </div>

  <!-- Info Section -->
  <div class="pulse-info">
    <h3 class="text-lg font-semibold mb-3 text-gray-800 flex items-center gap-2">
      <i class="bi bi-info-circle"></i> System Insights
    </h3>
    <div class="pulse-row">
      <div class="pulse-label">Last Registered</div>
      <div class="pulse-val"><?= esc_html($last_user) ?> 
        <span class="text-gray-500 text-sm">(<?= esc_html($last_reg_time) ?>)</span>
      </div>
    </div>
    <div class="pulse-row">
      <div class="pulse-label">Last Transaction Time</div>
      <div class="pulse-val"><?= esc_html($last_tx_time) ?></div>
    </div>
    <div class="pulse-row">
      <div class="pulse-label">Failed Transactions</div>
      <div class="pulse-val"><?= number_format($failed_tx) ?></div>
    </div>
    <div class="pulse-row">
      <div class="pulse-label">Pending Transactions</div>
      <div class="pulse-val"><?= number_format($pending_tx) ?></div>
    </div>
  </div>
</div>

<script>
  // Chart.js Line Chart
  const ctx = document.getElementById('txChart');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      datasets: [{
        label: 'Transactions',
        data: [12, 19, 7, 15, 22, 30, 25],
        borderColor: '<?= $color_hex ?>',
        backgroundColor: '<?= $color_hex ?>33',
        fill: true,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: '#f1f1f1' } },
        x: { grid: { display: false } }
      }
    }
  });
</script>