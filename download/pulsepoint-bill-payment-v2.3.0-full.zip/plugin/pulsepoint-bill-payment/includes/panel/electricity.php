<?php
/**
 * Pulsepoint Electricity/Bill Plans Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/bill.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

$table_bill = "{$base_prefix}bill";

// === Create Table if not exists ===
$sql_bill = "CREATE TABLE IF NOT EXISTS `{$table_bill}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `plan` VARCHAR(255) DEFAULT NULL,
    `details` TEXT,
    `fee` DECIMAL(14,2) DEFAULT 0.00,
    `fee_api` DECIMAL(14,2) DEFAULT 0.00,
    `provider` VARCHAR(100) DEFAULT NULL,
    PRIMARY KEY (`id`)
) {$charset};";

$wpdb->query($sql_bill);

// === Delete Logic ===
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $wpdb->delete($table_bill, ['id' => $id]);
    echo '<div class="updated notice"><p><strong>Bill plan deleted successfully.</strong></p></div>';
}

// === Fetch All Bill Plans ===
$plans = $wpdb->get_results("SELECT * FROM {$table_bill} ORDER BY id DESC");
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Electricity/Bill Plans</h1>
  <a href="?page=pulsepoint-add-bill" class="page-title-action"><i class="bi bi-plus-circle"></i> Add New Plan</a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 10px 8px; font-size: 14px; }
    th { text-align: left; background: #f9fafb; font-weight: 600; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; }
    .pulse-btn-danger { background: #ef4444; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; }
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-lightning"></i> Electricity/Bill Plans</h2>

    <?php if (!$plans): ?>
      <p>No bill plans found. <a href="?page=pulsepoint-add-bill" class="text-blue-600">Add your first plan</a>.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Plan</th>
              <th>Details</th>
              <th>Fee (₦)</th>
              <th>API Fee (₦)</th>
              <th>Provider</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($plans as $p): ?>
              <tr>
                <td><?= esc_html($p->id) ?></td>
                <td><strong><?= esc_html($p->plan) ?></strong></td>
                <td><?= esc_html($p->details) ?: '—' ?></td>
                <td><?= number_format($p->fee, 2) ?></td>
                <td><?= number_format($p->fee_api, 2) ?></td>
                <td><?= esc_html($p->provider ?: '—') ?></td>
                <td>
                  <a href="?page=pulsepoint-add-bill&edit=<?= $p->id ?>" class="pulse-btn"><i class="bi bi-pencil-square"></i> Edit</a>
                  <a href="?page=pulsepoint-bill&delete=<?= $p->id ?>" onclick="return confirm('Delete this plan?')" class="pulse-btn-danger"><i class="bi bi-trash"></i> Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>