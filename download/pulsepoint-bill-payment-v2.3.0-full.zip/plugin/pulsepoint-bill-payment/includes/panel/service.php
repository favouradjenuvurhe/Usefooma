<?php
/**
 * Pulsepoint Service Management Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/service.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_services = "{$base_prefix}services";

// === Create services table if not exists ===
$sql_services = "CREATE TABLE IF NOT EXISTS `{$table_services}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `service_key` VARCHAR(100) NOT NULL,
    `service_name` VARCHAR(150) NOT NULL,
    `status` TINYINT(1) DEFAULT 1, -- 1 = enabled, 0 = disabled
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `service_key_unique` (`service_key`)
) {$charset};";
$wpdb->query($sql_services);

// === Default Services ===
$default_services = [
    ['airtime',       'Airtime',       1],
    ['data',          'Data',          1],
    ['electricity',   'Electricity',   1],
    ['flights',       'Flights',       0],
    ['internet',      'Internet',      1],
    ['esim',          'eSIM',          0],
    ['giftcard',      'Giftcard',      0],
    ['transport',     'Transport',     0],
    ['send',          'Transfer',      0],
    ['betting',       'Betting',       0],
    ['cable_tv',      'Cable TV',      1],
    ['virtual_card',  'Virtual Card',  0],
    ['education',     'Education',     1],
    ['saving',        'Saving',        0],
    ['event_ticket',  'Event Ticket',  0],
    ['currency',  'Convert',  0],
];

// === Insert default services if not exists ===
foreach ($default_services as $svc) {
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_services} WHERE service_key = %s", $svc[0]));
    if (!$exists) {
        $wpdb->insert($table_services, [
            'service_key' => $svc[0],
            'service_name' => $svc[1],
            'status' => $svc[2],
        ]);
    }
}

// === Handle POST Update ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_service_nonce']) && wp_verify_nonce($_POST['pulsepoint_service_nonce'], 'save_pulsepoint_service')) {
    if (isset($_POST['services']) && is_array($_POST['services'])) {
        foreach ($_POST['services'] as $id => $data) {
            $wpdb->update($table_services, [
                'service_name' => sanitize_text_field($data['service_name']),
                'status' => intval($data['status']),
            ], ['id' => intval($id)]);
        }
        echo '<div class="updated notice"><p><strong>Services updated successfully.</strong></p></div>';
    }
}

// === Fetch all services ===
$services = $wpdb->get_results("SELECT * FROM {$table_services} ORDER BY id ASC");

?>

<div class="wrap">
  <h1 class="wp-heading-inline">Service Management</h1>
  <p>Enable/disable services or edit service names below.</p>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #6C63FF; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 8px 12px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; display: block; margin-bottom: 4px; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    th, td { padding: 12px; border-bottom: 1px solid #eee; text-align: left; }
    th { background: #f3f4f6; font-weight: 600; }
    select { border-radius: 6px; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_service', 'pulsepoint_service_nonce'); ?>

    <div class="pulse-section">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Service Key</th>
            <th>Service Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($services as $svc): ?>
          <tr>
            <td><?= esc_html($svc->id) ?></td>
            <td><?= esc_html($svc->service_key) ?></td>
            <td>
              <input type="text" name="services[<?= esc_attr($svc->id) ?>][service_name]" value="<?= esc_attr($svc->service_name) ?>" class="pulse-input">
            </td>
            <td>
              <select name="services[<?= esc_attr($svc->id) ?>][status]" class="pulse-input">
                <option value="1" <?= selected($svc->status, 1, false) ?>>Active</option>
                <option value="0" <?= selected($svc->status, 0, false) ?>>Inactive</option>
              </select>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <div class="text-right mt-4">
        <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Services</button>
      </div>
    </div>
  </form>
</div>