<?php
/**
 * Pulsepoint Add/Edit Giftcard Page with Image URL & Subcategory
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-giftcard.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

$table_giftcard = "{$base_prefix}giftcard_settings";

/* =====================================================
 * CREATE TABLE (WITH image_url)
 * ===================================================== */
$sql_giftcard_settings = "CREATE TABLE IF NOT EXISTS {$table_giftcard} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    category VARCHAR(100) NOT NULL,
    sub_category VARCHAR(100) NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    type ENUM('digital','physical') DEFAULT 'digital',
    rate DECIMAL(14,2) NOT NULL,
    min_amount DECIMAL(14,2) DEFAULT 0.00,
    max_amount DECIMAL(14,2) DEFAULT 0.00,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) {$charset};";
$wpdb->query($sql_giftcard_settings);

/* =====================================================
 * EDIT MODE
 * ===================================================== */
$edit_id = isset($_GET['edit']) ? intval($_GET['edit']) : 0;
$giftcard = $edit_id
    ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_giftcard} WHERE id = %d", $edit_id))
    : null;

/* =====================================================
 * HANDLE FORM SUBMISSION
 * ===================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $category     = sanitize_text_field($_POST['category']);
    $sub_category = sanitize_text_field($_POST['sub_category']);
    $image_url    = esc_url_raw($_POST['image_url']);
    $type         = sanitize_text_field($_POST['type']);
    $rate         = floatval($_POST['rate']);
    $min_amount   = floatval($_POST['min_amount']);
    $max_amount   = floatval($_POST['max_amount']);
    $status       = sanitize_text_field($_POST['status']);

    $data = [
        'category'     => $category,
        'sub_category' => $sub_category,
        'image_url'    => $image_url,
        'type'         => $type,
        'rate'         => $rate,
        'min_amount'   => $min_amount,
        'max_amount'   => $max_amount,
        'status'       => $status
    ];

    if ($edit_id && $giftcard) {
        $wpdb->update($table_giftcard, $data, ['id' => $edit_id]);
        echo '<div class="updated notice"><p><strong>Giftcard updated successfully.</strong></p></div>';
        $giftcard = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_giftcard} WHERE id = %d", $edit_id));
    } else {
        $wpdb->insert($table_giftcard, $data);
        echo '<div class="updated notice"><p><strong>Giftcard added successfully.</strong></p></div>';
        $giftcard = null;
    }
}

/* =====================================================
 * PLATFORM SETTINGS
 * ===================================================== */
$settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings_map = [];
foreach ($settings as $s) {
    $settings_map[$s->opt_key] = maybe_unserialize($s->opt_value);
}

$platform_name = $settings_map['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings_map['color_hex'] ?? '#356cf9';
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — <?= $edit_id ? 'Edit' : 'Add' ?> Giftcard</h1>
  <a href="?page=pulsepoint-giftcard" class="page-title-action"><i class="bi bi-arrow-left-circle"></i> Back to Giftcards</a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    .pulse-input, select {
      width: 100%;
      border: 1px solid #ddd;
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 14px;
      margin-bottom: 12px;
    }
    .pulse-label {
      font-weight: 600;
      font-size: 14px;
      display: block;
      margin-bottom: 6px;
    }
    .pulse-btn {
      background: var(--primary);
      color: #fff;
      padding: 10px 20px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      border: none;
    }
  </style>

  <div class="pulse-section">
    <form method="POST">
      <div>
        <label class="pulse-label">Category</label>
        <input type="text" name="category" value="<?= esc_attr($giftcard->category ?? '') ?>" class="pulse-input" required>
      </div>

      <div>
        <label class="pulse-label">Sub Category</label>
        <input type="text" name="sub_category" value="<?= esc_attr($giftcard->sub_category ?? '') ?>" class="pulse-input" required>
      </div>

      <div>
        <label class="pulse-label">Image URL</label>
        <input type="url" name="image_url" value="<?= esc_attr($giftcard->image_url ?? '') ?>" class="pulse-input" required>
        <?php if (!empty($giftcard->image_url)): ?>
          <img src="<?= esc_url($giftcard->image_url) ?>" style="max-width:120px;margin-top:10px;">
        <?php endif; ?>
      </div>

      <div>
        <label class="pulse-label">Type</label>
        <select name="type" class="pulse-input" required>
          <option value="digital" <?= ($giftcard->type ?? '') === 'digital' ? 'selected' : '' ?>>Digital</option>
          <option value="physical" <?= ($giftcard->type ?? '') === 'physical' ? 'selected' : '' ?>>Physical</option>
        </select>
      </div>

      <div>
        <label class="pulse-label">Rate</label>
        <input type="number" step="0.01" name="rate" value="<?= esc_attr($giftcard->rate ?? '') ?>" class="pulse-input" required>
      </div>

      <div>
        <label class="pulse-label">Min Amount</label>
        <input type="number" step="0.01" name="min_amount" value="<?= esc_attr($giftcard->min_amount ?? 0) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Max Amount</label>
        <input type="number" step="0.01" name="max_amount" value="<?= esc_attr($giftcard->max_amount ?? 0) ?>" class="pulse-input">
      </div>

      <div>
        <label class="pulse-label">Status</label>
        <select name="status" class="pulse-input" required>
          <option value="active" <?= ($giftcard->status ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
          <option value="inactive" <?= ($giftcard->status ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
        </select>
      </div>

      <button type="submit" class="pulse-btn"><?= $edit_id ? 'Update' : 'Add' ?> Giftcard</button>
    </form>
  </div>
</div>