<?php
/**
 * Pulsepoint Provider API Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/provider-api.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_provider = "{$base_prefix}provider";

// === Create Provider Table if not exists ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_provider}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(150) NOT NULL,
    `token` TEXT,
    `value` TEXT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `provider_name_unique` (`name`)
) {$charset};");

// === Handle Delete ===
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $wpdb->delete($table_provider, ['id' => $id]);
    echo '<div class="updated notice"><p><strong>Provider deleted successfully.</strong></p></div>';
}

// === Fetch All Providers ===
$providers = $wpdb->get_results("SELECT * FROM {$table_provider} ORDER BY id DESC");

// === Fetch Settings for Branding ===
$settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$set = [];
foreach ($settings as $row) $set[$row->opt_key] = maybe_unserialize($row->opt_value);
$platform_name = $set['platform_name'] ?? 'Pulsepoint';
$color_hex = $set['color_hex'] ?? '#356cf9';
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Providers</h1>
  <p>Manage API provider integrations and credentials.</p>
  <a href="?page=pulsepoint-add-provider" class="button-primary" style="background: <?= esc_attr($color_hex) ?>; border:none;">+ Add Provider</a>
  <hr class="wp-header-end">

  <!-- Tailwind + Bootstrap Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-table-container {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
      overflow-x: auto;
    }
    .pulse-table {
      width: 100%;
      border-collapse: collapse;
    }
    .pulse-table th, .pulse-table td {
      padding: 12px 14px;
      border-bottom: 1px solid #eee;
      font-size: 14px;
      text-align: left;
      white-space: nowrap;
    }
    .pulse-table th {
      background: #f8fafc;
      font-weight: 700;
      text-transform: uppercase;
      font-size: 12px;
    }
    .action-btn {
      padding: 6px 12px;
      border-radius: 6px;
      color: #fff;
      font-size: 13px;
      text-decoration: none;
    }
    .edit-btn { background: var(--primary); }
    .delete-btn { background: #e3342f; }
  </style>

  <div class="pulse-table-container">
    <table class="pulse-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Provider Name</th>
          <th>Token</th>
          <th>Value</th>
          <th>Date Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($providers): foreach ($providers as $p): ?>
          <tr>
            <td>#<?= $p->id ?></td>
            <td><?= esc_html($p->name) ?></td>
            <td><?= esc_html(substr($p->token, 0, 30)) ?><?= strlen($p->token) > 30 ? '...' : '' ?></td>
            <td><?= esc_html(substr($p->value, 0, 30)) ?><?= strlen($p->value) > 30 ? '...' : '' ?></td>
            <td><?= esc_html($p->created_at) ?></td>
            <td>
              <a href="?page=pulsepoint-add-provider&id=<?= $p->id ?>" class="action-btn edit-btn"><i class="bi bi-pencil"></i></a>
              <a href="?page=pulsepoint-provider&delete=<?= $p->id ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this provider?');"><i class="bi bi-trash"></i></a>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="6" class="text-center py-4">No providers found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>