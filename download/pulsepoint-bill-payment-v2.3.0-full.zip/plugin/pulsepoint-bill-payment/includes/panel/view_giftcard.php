<?php
/**
 * Pulsepoint Admin View Giftcard Listing
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/view_giftcard.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

// === TABLES ===
$table_users = "{$base_prefix}users";
$table_giftcard_listings = "{$base_prefix}giftcard_listings";
$table_trnx = "{$base_prefix}trnx";

// === Platform Settings ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// === Helper ===
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }

// === Get Listing ID ===
$listing_id = intval($_GET['id'] ?? 0);
$listing = $wpdb->get_row($wpdb->prepare("
    SELECT g.*, u.firstname, u.lastname, u.phone, u.email, u.wallet
    FROM {$table_giftcard_listings} g
    LEFT JOIN {$table_users} u ON g.user_id = u.id
    WHERE g.id = %d
", $listing_id));

if (!$listing) {
    echo '<div class="notice notice-error"><p>Giftcard listing not found.</p></div>';
    return;
}

// === Handle Approve / Reject ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $note = sanitize_textarea_field($_POST['note'] ?? '');

    // Prevent multiple processing
    if ($listing->status !== 'pending') {
        echo '<div class="notice notice-warning"><p>This giftcard has already been processed.</p></div>';
    } else {
        if ($action === 'approve') {
            // Update listing status
            $wpdb->update($table_giftcard_listings, ['status' => 'approved', 'note' => $note], ['id' => $listing_id]);

            // Update user wallet
            $wpdb->query($wpdb->prepare(
                "UPDATE {$table_users} SET wallet = wallet + %f WHERE id = %d",
                $listing->selling_price,
                $listing->user_id
            ));

            // Record transaction
            $wpdb->insert($table_trnx, [
                'user_id' => $listing->user_id,
                'details' => "Giftcard Approved: {$listing->amount} {$listing->type} ({$listing->selling_price})",
                'amount' => $listing->selling_price,
                'reference' => 'GIFT-' . time() . '-' . $listing->id,
                'payment' => 'wallet',
                'category' => 'cards',
                'status' => 'success',
                'type' => 'credit',
                'description' => $note,
                'date' => current_time('mysql'),
            ]);

            echo '<div class="notice notice-success"><p>Giftcard approved and wallet updated successfully.</p></div>';

        } elseif ($action === 'reject') {
            // Update listing status
            $wpdb->update($table_giftcard_listings, ['status' => 'rejected', 'note' => $note], ['id' => $listing_id]);

            // Record transaction (failed) including rejection reason in details
            $details = "Giftcard Rejected: {$listing->amount} {$listing->type}";
            if (!empty($note)) {
                $details .= " | Reason: {$note}";
            }

            $wpdb->insert($table_trnx, [
                'user_id' => $listing->user_id,
                'details' => $details,
                'amount' => 0.00,
                'reference' => 'GIFT-' . time() . '-' . $listing->id,
                'payment' => 'wallet',
                'category' => 'cards',
                'status' => 'failed',
                'type' => 'debit',
                'description' => $note,
                'date' => current_time('mysql'),
            ]);

            echo '<div class="notice notice-warning"><p>Giftcard rejected.</p></div>';
        }
    }

    // Refresh listing data
    $listing = $wpdb->get_row($wpdb->prepare("
        SELECT g.*, u.firstname, u.lastname, u.phone, u.email, u.wallet
        FROM {$table_giftcard_listings} g
        LEFT JOIN {$table_users} u ON g.user_id = u.id
        WHERE g.id = %d
    ", $listing_id));
}

?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — View Giftcard</h1>
    <hr class="wp-header-end">

    <script src="https://cdn.tailwindcss.com"></script>

    <div class="pulse-table-container mt-6 p-4 bg-white rounded-xl shadow-md w-full max-w-3xl">
        <h2 class="font-semibold mb-4">Giftcard Details</h2>
        <table class="pulse-table w-full">
            <tr><th>ID</th><td>#<?= $listing->id ?></td></tr>
            <tr><th>User</th><td><?= esc_html($listing->firstname . ' ' . $listing->lastname) ?></td></tr>
            <tr><th>Phone</th><td><?= esc_html($listing->phone) ?></td></tr>
            <tr><th>Email</th><td><?= esc_html($listing->email) ?></td></tr>
            <tr><th>Type</th><td><?= ucfirst($listing->type) ?></td></tr>
            <tr><th>Face Value</th><td><?= fmt_amt($listing->amount) ?></td></tr>
            <tr><th>Selling Price</th><td><?= fmt_amt($listing->selling_price) ?></td></tr>
            <tr><th>Status</th><td><?= ucfirst($listing->status) ?></td></tr>
            <tr><th>Wallet Balance</th><td><?= fmt_amt($listing->wallet ?? 0) ?></td></tr>
            <tr><th>Note</th><td><?= esc_html($listing->note) ?></td></tr>
            <?php if ($listing->digital_code): ?>
            <tr><th>Digital Code</th><td><?= esc_html($listing->digital_code) ?></td></tr>
            <?php endif; ?>
            <?php if ($listing->physical_image): ?>
            <tr><th>Physical Image</th><td><img src="<?= esc_url($listing->physical_image) ?>" alt="Physical Card" class="w-32"></td></tr>
            <?php endif; ?>
            <tr><th>Created At</th><td><?= esc_html($listing->created_at) ?></td></tr>
        </table>

        <?php if ($listing->status === 'pending'): ?>
        <form method="post" class="mt-6 flex flex-col gap-4">
            <label for="note" class="font-semibold">Admin Note / Reason</label>
            <textarea name="note" id="note" rows="3" class="border p-2 rounded w-full"></textarea>
            <div class="flex gap-3">
                <button type="submit" name="action" value="approve" class="bg-green-600 text-white px-4 py-2 rounded">Approve</button>
                <button type="submit" name="action" value="reject" class="bg-red-600 text-white px-4 py-2 rounded">Reject</button>
            </div>
        </form>
        <?php else: ?>
        <p class="mt-4 font-semibold">This giftcard has already been <?= esc_html($listing->status) ?>.</p>
        <?php endif; ?>
    </div>
</div>