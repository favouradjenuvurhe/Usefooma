<?php
/**
 * Pulsepoint Logs & System Info
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/logs.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// Start timing
$start_time = microtime(true);

// === Get WordPress + Server Info ===
global $wpdb;

// Try to locate main plugin file dynamically
$plugin_main_file = plugin_dir_path(__DIR__) . 'pulsepoint-bill-payment.php';
if (!file_exists($plugin_main_file)) {
    // fallback to any file inside plugin root that has plugin headers
    $plugin_root = dirname(plugin_dir_path(__DIR__));
    $possible_files = glob($plugin_root . '/*.php');
    $plugin_main_file = $possible_files ? $possible_files[0] : '';
}

// Safely get plugin data
$plugin_data = [
    'Name'    => 'Pulsepoint',
    'Version' => '1.0.9',
    'Author'  => 'Favour Adjenuvurhe',
];
if ($plugin_main_file && file_exists($plugin_main_file)) {
    $data = get_file_data($plugin_main_file, [
        'Name'    => 'Plugin Name',
        'Version' => 'Version',
        'Author'  => 'Author',
    ]);
    $plugin_data = array_merge($plugin_data, array_filter($data));
}

// === System info ===
$system_info = [
    'Plugin Name' => $plugin_data['Name'],
    'Plugin Version' => $plugin_data['Version'],
    'Author' => $plugin_data['Author'],
    'WordPress Version' => get_bloginfo('version'),
    'Site URL' => get_site_url(),
    'Home URL' => get_home_url(),
    'PHP Version' => PHP_VERSION,
    'MySQL Version' => $wpdb->db_version(),
    'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'Active Theme' => wp_get_theme()->get('Name') . ' ' . wp_get_theme()->get('Version'),
    'Active Plugins' => count(get_option('active_plugins')),
    'Memory Limit' => ini_get('memory_limit'),
    'Max Upload Size' => size_format(wp_max_upload_size()),
    'Disk Space Free' => size_format(@disk_free_space(ABSPATH)),
    'Disk Space Total' => size_format(@disk_total_space(ABSPATH)),
];

// === Load PHP Error Log ===
$error_log_path = ini_get('error_log');
$error_entries = [];

if ($error_log_path && file_exists($error_log_path)) {
    $log_lines = @file($error_log_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $recent_logs = array_slice($log_lines, -50); // Last 50 entries

    foreach ($recent_logs as $line) {
        $timestamp = '';
        if (preg_match('/\[(.*?)\]/', $line, $match)) {
            $timestamp = $match[1];
        }

        $error_type = '';
        if (preg_match('/PHP\s+([A-Z_]+):/', $line, $match)) {
            $error_type = $match[1];
        }

        $error_entries[] = [
            'timestamp' => $timestamp ?: 'N/A',
            'type' => $error_type ?: 'Notice',
            'message' => trim(preg_replace('/.*PHP\s+[A-Z_]+:\s*/', '', $line)),
        ];
    }
}

// === Measure Load Speed ===
$load_time = round((microtime(true) - $start_time), 3);
$system_info['Load Time'] = $load_time . 's';
?>

<div class="wrap">
  <h1 class="wp-heading-inline">System & Error Logs</h1>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      border-bottom: 1px solid #eee;
      padding: 10px 8px;
      font-size: 14px;
    }
    th {
      text-align: left;
      background: #f9fafb;
      font-weight: 600;
    }
    .wp-logo {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      margin-bottom: 10px;
    }
    .error-type {
      font-weight: bold;
      text-transform: uppercase;
      color: #d14343;
    }
  </style>

  <!-- System Info -->
  <div class="pulse-section">
    <div class="flex items-center gap-4 mb-6">
      <img src="<?php echo esc_url(includes_url('images/w-logo-blue.png')); ?>" alt="WordPress Logo" class="wp-logo">
      <div>
        <h2 class="text-xl font-semibold text-gray-800">System & Hosting Information</h2>
        <p class="text-gray-500 text-sm">Overview of your WordPress hosting environment and plugin performance metrics.</p>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table>
        <thead>
          <tr>
            <th>Property</th>
            <th>Value</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($system_info as $label => $value): ?>
            <tr>
              <td><strong><?= esc_html($label) ?></strong></td>
              <td><?= esc_html($value) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- PHP Error Logs -->
  <div class="pulse-section">
    <h2 class="text-xl font-semibold text-gray-800 flex items-center gap-2 mb-4">
      <i class="bi bi-bug-fill text-red-500"></i> PHP Error Logs
    </h2>
    <?php if ($error_entries): ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Error Type</th>
              <th>Message</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($error_entries as $error): ?>
              <tr>
                <td><?= esc_html($error['timestamp']) ?></td>
                <td class="error-type"><?= esc_html($error['type']) ?></td>
                <td><?= esc_html($error['message']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p class="text-gray-500">No PHP errors found in the log file (<?php echo esc_html($error_log_path ?: 'Not configured'); ?>).</p>
    <?php endif; ?>
  </div>
</div>