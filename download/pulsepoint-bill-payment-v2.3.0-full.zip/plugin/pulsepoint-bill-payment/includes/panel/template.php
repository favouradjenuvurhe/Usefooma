<?php
/**
 * Pulsepoint Theme Manager
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/pages/template.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

// Ensure settings table exists
$sql_settings = "CREATE TABLE IF NOT EXISTS `{$base_prefix}settings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `opt_key` VARCHAR(255) NOT NULL,
    `opt_value` TEXT,
    `type` VARCHAR(50) DEFAULT 'string',
    `grouping` VARCHAR(100) DEFAULT NULL,
    `autoload` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `opt_key_unique` (`opt_key`)
) {$charset};";
$wpdb->query($sql_settings);

// Theme directory
$theme_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/includes/pages/theme/';
$theme_url = plugins_url('pulsepoint-bill-payment/includes/pages/theme/');

$message = '';

// Handle theme activation from button
if (!empty($_GET['activate_theme'])) {
    $theme_to_activate = sanitize_text_field($_GET['activate_theme']);
    if (is_dir($theme_dir . $theme_to_activate)) {
        $wpdb->replace(
            "{$base_prefix}settings",
            [
                'opt_key'   => 'theme',
                'opt_value' => $theme_to_activate,
                'type'      => 'string',
                'autoload'  => 1,
            ],
            ['%s', '%s', '%s', '%d']
        );
        $message = "Theme '{$theme_to_activate}' activated successfully!";
        $current_theme = $theme_to_activate;
    }
}

// Get list of allowed themes only
$allowed_themes = ['crypx', 'paypoint', 'default'];
$themes = [];
foreach ($allowed_themes as $theme) {
    if (is_dir($theme_dir . $theme)) {
        $themes[] = $theme;
    }
}

// Get current active theme
$current_theme = $current_theme ?? $wpdb->get_var("SELECT opt_value FROM {$base_prefix}settings WHERE opt_key = 'theme' LIMIT 1") ?: 'default';
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Theme Manager</h1>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      border-bottom: 1px solid #eee;
      padding: 10px 8px;
      font-size: 14px;
      vertical-align: middle;
    }
    th {
      text-align: left;
      background: #f9fafb;
      font-weight: 600;
    }
    .active-theme {
      color: #356cf9;
      font-weight: bold;
    }
    .theme-img {
      width: 50px;
      height: 50px;
      object-fit: cover;
      border-radius: 6px;
      margin-right: 10px;
    }
  </style>

  <?php if($message): ?>
    <div class="pulse-section text-green-600 font-semibold mb-4"><?= esc_html($message) ?></div>
  <?php endif; ?>

  <!-- Theme List -->
  <div class="pulse-section">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">Available Themes</h2>
    <div class="overflow-x-auto">
      <table>
        <thead>
          <tr>
            <th>Theme</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($themes as $theme): ?>
            <?php
              $img_file = $theme_dir . $theme . '/file.png';
              $img_url = file_exists($img_file) ? $theme_url . $theme . '/file.png' : 'https://via.placeholder.com/50';
            ?>
            <tr>
              <td class="flex items-center">
                <img src="<?= esc_url($img_url) ?>" class="theme-img" alt="<?= esc_attr($theme) ?>">
                <?= esc_html($theme) ?>
              </td>
              <td>
                <?php if($theme === $current_theme): ?>
                  <span class="active-theme">Active</span>
                <?php else: ?>
                  <span class="text-gray-500">Inactive</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if($theme !== $current_theme): ?>
                  <a href="<?= esc_url(add_query_arg('activate_theme', $theme)) ?>" class="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700">Activate</a>
                <?php else: ?>
                  <span class="text-gray-500">—</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if(empty($themes)): ?>
            <tr><td colspan="3" class="text-gray-500">No themes installed.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>