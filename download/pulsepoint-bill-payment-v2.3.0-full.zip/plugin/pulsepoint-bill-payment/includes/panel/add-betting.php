<?php
/**
 * Pulsepoint Add/Edit Betting Platform Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-betting.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_bet = "{$base_prefix}betting";

// === Fetch existing platform for edit ===
$edit_biller = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $biller_id = intval($_GET['edit']);
    $edit_biller = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_bet} WHERE id = %d", $biller_id)
    );
}

// === Handle Form Submission ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_bet_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_bet_nonce'], 'save_pulsepoint_bet')
) {

    $data = [
        'serviceid' => sanitize_text_field($_POST['serviceid']),
        'biller'    => sanitize_text_field($_POST['biller']),
        'cashback'  => floatval($_POST['cashback']),
        'fee'       => floatval($_POST['fee']),
        'fee_api'   => floatval($_POST['fee_api']),
        'provider'  => sanitize_text_field($_POST['provider']),
    ];

    if ($edit_biller) {
        $wpdb->update($table_bet, $data, ['id' => $edit_biller->id]);
        echo '<div class="updated notice"><p><strong>Betting platform updated successfully.</strong></p></div>';
    } else {
        $wpdb->insert($table_bet, $data);
        echo '<div class="updated notice"><p><strong>New betting platform added successfully.</strong></p></div>';
    }

    if (!$edit_biller) {
        $edit_biller = (object) $data;
    }
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline">
    <?= $edit_biller ? 'Edit Betting Platform' : 'Add New Betting Platform' ?>
  </h1>
  <a href="?page=pulsepoint-betting" class="page-title-action">
    <i class="bi bi-arrow-left"></i> Back to Betting Platforms
  </a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background:#fff; border-radius:14px; padding:24px; box-shadow:0 3px 10px rgba(0,0,0,0.05); margin-top:24px; }
    .pulse-input { width:100%; border:1px solid #ddd; padding:10px 14px; border-radius:8px; font-size:14px; }
    .pulse-label { font-weight:600; font-size:14px; margin-bottom:6px; display:block; }
    .pulse-btn { background:var(--primary); color:#fff; padding:10px 20px; border:none; border-radius:8px; cursor:pointer; font-weight:600; }
    .pulse-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:16px; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_bet', 'pulsepoint_bet_nonce'); ?>

    <div class="pulse-section">
      <div class="pulse-grid">

        <div>
          <label class="pulse-label">Service ID</label>
          <input type="text" name="serviceid"
                 value="<?= esc_attr($edit_biller->serviceid ?? '') ?>"
                 class="pulse-input" required>
        </div>

        <div>
          <label class="pulse-label">Platform Name (e.g. Bet9ja, SportyBet)</label>
          <input type="text" name="biller"
                 value="<?= esc_attr($edit_biller->biller ?? '') ?>"
                 class="pulse-input" required>
        </div>

        <div>
          <label class="pulse-label">Cashback (₦)</label>
          <input type="number" step="0.01" name="cashback"
                 value="<?= esc_attr($edit_biller->cashback ?? 0) ?>"
                 class="pulse-input">
        </div>

        <div>
          <label class="pulse-label">Fee (₦)</label>
          <input type="number" step="0.01" name="fee"
                 value="<?= esc_attr($edit_biller->fee ?? 0) ?>"
                 class="pulse-input" required>
        </div>

        <div>
          <label class="pulse-label">API Fee (₦)</label>
          <input type="number" step="0.01" name="fee_api"
                 value="<?= esc_attr($edit_biller->fee_api ?? 0) ?>"
                 class="pulse-input">
        </div>

        <div>
          <label class="pulse-label">Provider</label>
          <select name="provider" class="pulse-input">
            <?php
            $bet_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/betting/';
            $files = glob($bet_dir . '*.php');
            $has_providers = false;
            foreach ($files as $file) {
                $filename = basename($file, '.php');
                if ($filename === 'pulsepoint') continue;
                $has_providers = true;
                $selected = ($edit_biller->provider ?? '') === $filename ? 'selected' : '';
                echo "<option value='{$filename}' {$selected}>{$filename}</option>";
            }
            if (!$has_providers) {
                echo "<option value=''>No provider files yet — add core/betting/{provider}.php</option>";
            }
            ?>
          </select>
        </div>

      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn">
        <i class="bi bi-save"></i>
        <?= $edit_biller ? 'Update Platform' : 'Add Platform' ?>
      </button>
    </div>

  </form>
</div>
