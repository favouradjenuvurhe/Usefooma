<?php
/**
 * Pulsepoint Update Catalog — Clean View (No Webhooks)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/update-catalog.php
 * Author: Favour Adjenuvurhe
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) exit;

// CSV export is now handled by the standalone pulsepoint-export.php file
// (plugin root) instead of running inline here — see that file for why.

// === Determine server URL dynamically ===
$server_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['SERVER_NAME'];

// === Changelog Fetch ===
$changelog = [];
$latest_version = '';
$changelog_url = $server_url.'/wp-content/plugins/pulsepoint-bill-payment/changelog.txt';

$response = wp_remote_get($changelog_url);

if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
    $lines = array_filter(array_map('trim', explode("\n", wp_remote_retrieve_body($response))));
    if (!empty($lines)) {
        $latest_version = array_shift($lines);
        $changelog = array_slice($lines, 0, 5); // show up to 5 entries
    }
}

?>

<div class="wrap">
    <h1 class="wp-heading-inline">Pulsepoint — Updates</h1>
    <hr class="wp-header-end">

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        :root { --primary: #356cf9; }
        .pulse-section {
            background: #fff;
            border-radius: 14px;
            padding: 24px;
            box-shadow:0 3px 10px rgba(0,0,0,0.05);
            margin-top:24px;
        }
        .badge {
            display:inline-block;
            padding:4px 10px;
            border-radius:6px;
            font-size:12px;
            font-weight:600;
            background:#e5edff;
            color:var(--primary);
        }
    </style>

    <!-- ✅ Updates Section -->
    <div class="pulse-section">
        <h2 class="text-lg font-semibold text-gray-800 mb-3">
            <i class="bi bi-arrow-repeat"></i> System Updates
        </h2>

        <p class="text-gray-700">
            Latest Version:
            <span class="badge"><?= esc_html($latest_version ?: 'v1.0.0') ?></span>
        </p>

        <?php if (!empty($changelog)): ?>
            <ul class="list-disc list-inside text-gray-700 mt-4 space-y-1">
                <?php foreach ($changelog as $line): ?>
                    <li><?= esc_html($line) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-gray-500 mt-3">No changelog available.</p>
        <?php endif; ?>
    </div>

    <!-- ✅ Export Recipients Section -->
    <div class="pulse-section">
        <h2 class="text-lg font-semibold text-gray-800 mb-3">
            <i class="bi bi-download"></i> Export Recipients
        </h2>

        <p class="text-gray-700 mb-1">
            Download a CSV of <strong>active users only</strong> — one email or phone number per row.
        </p>
        <p class="text-gray-500 text-sm mb-4">
            Ready to use as a recipients list for email or SMS campaigns.
        </p>

        <?php $export_base = $server_url . '/wp-content/plugins/pulsepoint-bill-payment/pulsepoint-export.php'; ?>

        <div class="d-flex" style="gap:10px;">
            <a href="<?= esc_url(wp_nonce_url(add_query_arg('type', 'emails', $export_base), 'pulsepoint_export_csv')) ?>"
               class="badge" style="text-decoration:none; cursor:pointer;">
                <i class="bi bi-envelope"></i> Download Emails CSV
            </a>
            </br>
            <a href="<?= esc_url(wp_nonce_url(add_query_arg('type', 'phones', $export_base), 'pulsepoint_export_csv')) ?>"
               class="badge" style="text-decoration:none; cursor:pointer;">
                <i class="bi bi-telephone"></i> Download Phone CSV
            </a>
        </div>
    </div>

    <!-- ✅ Info Section -->
    <div class="pulse-section">
        <h2 class="text-lg font-semibold text-gray-800 mb-3">
            <i class="bi bi-info-circle"></i> Information
        </h2>

        <p class="text-gray-700">
            This page shows the latest updates and improvements to your Pulsepoint system.
        </p>

        <p class="text-gray-500 mt-2 text-sm">
            Webhook functionality has been completely removed from this panel.
        </p>
    </div>
</div>