<?php
/**
 * Pulsepoint Support Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/support.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

// === Handle AJAX Form Submission ===
add_action('wp_ajax_pulsepoint_support_form', 'pulsepoint_support_form');
add_action('wp_ajax_nopriv_pulsepoint_support_form', 'pulsepoint_support_form');

function pulsepoint_support_form() {
    $name    = sanitize_text_field($_POST['name']);
    $email   = sanitize_email($_POST['email']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);

    $to = 'favour-amaaavl@outlook.com';
    $headers = ['Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . $email];

    $body = "
        <h2>Pulsepoint Support Request</h2>
        <p><strong>Name:</strong> {$name}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Subject:</strong> {$subject}</p>
        <p><strong>Message:</strong><br>" . nl2br($message) . "</p>
    ";

    $sent = wp_mail($to, "Pulsepoint Support: {$subject}", $body, $headers);

    if ($sent) {
        wp_send_json_success("Thank you, {$name}! Your issue has been submitted successfully.");
    } else {
        wp_send_json_error("Error: Unable to send your message. Please try again or use WhatsApp support.");
    }
    wp_die();
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Support</h1>
  <hr class="wp-header-end">

  <!-- Tailwind + Icons -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section {
      background: #fff;
      border-radius: 14px;
      padding: 24px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 24px;
    }
    label { font-weight: 600; }
    input, textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 8px;
      font-size: 14px;
    }
    textarea { height: 100px; }
    .pulse-btn {
      background: var(--primary);
      color: #fff;
      padding: 10px 18px;
      border-radius: 8px;
      font-weight: 600;
      border: none;
      cursor: pointer;
    }
    .pulse-btn:hover { background: #2a57cc; }
    .whatsapp-btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: #25D366;
      color: #fff;
      padding: 10px 18px;
      border-radius: 8px;
      font-weight: 600;
      text-decoration: none;
    }
    .whatsapp-btn:hover { background: #1EBE5D; }
    .alert {
      padding: 10px 14px;
      border-radius: 6px;
      margin-top: 10px;
      display: none;
    }
    .alert-success { background: #d1fae5; color: #065f46; }
    .alert-error { background: #fee2e2; color: #991b1b; }
  </style>

  <div class="pulse-section">
    <div class="flex items-center gap-4 mb-6">
      <i class="bi bi-life-preserver text-3xl text-[--primary]"></i>
      <div>
        <h2 class="text-xl font-semibold text-gray-800">Need Help with Pulsepoint?</h2>
        <p class="text-gray-500 text-sm">Reach out for plugin support, bug reports, or feature suggestions.</p>
      </div>
    </div>

    <form id="pulsepointSupportForm">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label for="name">Your Name</label>
          <input type="text" name="name" id="name" placeholder="Enter your name" required>
        </div>
        <div>
          <label for="email">Your Email</label>
          <input type="email" name="email" id="email" placeholder="example@domain.com" required>
        </div>
      </div>

      <div class="mb-4">
        <label for="subject">Subject</label>
        <input type="text" name="subject" id="subject" placeholder="Enter subject" required>
      </div>

      <div class="mb-4">
        <label for="message">Message</label>
        <textarea name="message" id="message" placeholder="Describe your issue or suggestion..." required></textarea>
      </div>

      <button type="submit" class="pulse-btn">
        <i class="bi bi-send"></i> Submit Request
      </button>

      <div id="responseMsg" class="alert"></div>
    </form>
  </div>

  <!-- WhatsApp + Developer Section -->
  <div class="pulse-section">
    <h2 class="text-lg font-semibold text-gray-800 mb-3"><i class="bi bi-whatsapp text-green-500"></i> Quick Support via WhatsApp</h2>
    <p class="text-gray-600 mb-3">Need faster assistance? Chat directly with the developer on WhatsApp.</p>

    <a href="https://wa.me/2349064873505" target="_blank" class="whatsapp-btn">
      <i class="bi bi-whatsapp"></i> Chat on WhatsApp
    </a>

    <div class="mt-6 border-t pt-4 text-gray-500 text-sm">
      <p><strong>Developer:</strong> Favour Adjenuvurhe</p>
      <p><strong>Plugin:</strong> Pulsepoint — Bill Payment</p>
      <p><strong>Support Email:</strong> <a href="mailto:favour-amaaavl@outlook.com" class="text-blue-600">favour-amaaavl@outlook.com</a></p>
    </div>
  </div>
</div>

<script>
jQuery(document).ready(function($){
  $('#pulsepointSupportForm').on('submit', function(e){
    e.preventDefault();
    var form = $(this);
    var msg = $('#responseMsg');
    msg.hide();

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: form.serialize() + '&action=pulsepoint_support_form',
      success: function(response){
        msg.removeClass('alert-error').addClass('alert-success').text(response.data).fadeIn();
        form[0].reset();
      },
      error: function(xhr){
        msg.removeClass('alert-success').addClass('alert-error').text('Failed to send message. Please try again.').fadeIn();
      }
    });
  });
});
</script>