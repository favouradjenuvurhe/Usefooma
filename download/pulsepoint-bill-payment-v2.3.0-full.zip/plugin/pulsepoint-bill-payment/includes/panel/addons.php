<?php
/**
 * Pulsepoint Add-ons
 *
 * Add-on availability is determined entirely by local WordPress plugin
 * activation. License validity is handled separately by the license-check
 * cron and is never used here.
 */

if (!defined('ABSPATH')) exit;

$known_addons = [
    'transfer'    => ['label' => 'Bank Transfer',  'icon' => 'bi-bank2',              'plugin' => 'pulsepoint-transfer-addon'],
    'virtualcard' => ['label' => 'Virtual Cards',  'icon' => 'bi-credit-card',        'plugin' => 'pulsepoint-virtualcard-addon'],
    'tickets'     => ['label' => 'Event Tickets',  'icon' => 'bi-ticket-perforated',  'plugin' => 'pulsepoint-tickets-addon'],
    'esim'        => ['label' => 'eSIM',           'icon' => 'bi-sim',                'plugin' => 'pulsepoint-esim-addon'],
    'crypto'      => ['label' => 'Crypto Wallets', 'icon' => 'bi-currency-bitcoin',   'plugin' => 'pulsepoint-crypto-addon'],
    'giftcard'    => ['label' => 'Gift Cards',    'icon' => 'bi-gift',                 'plugin' => 'giftcard-addon'],
    'smm'         => ['label' => 'Boost (SMM)',   'icon' => 'bi-rocket',               'plugin' => 'smm-addon'],
    'storefront'  => ['label' => 'Storefront',    'icon' => 'bi-shop',                 'plugin' => 'pulsepoint-storefront-addon'],
];

if (!function_exists('pulsepoint_addon_active')) {
    $active_addons = [];
} else {
    $active_addons = pulsepoint_active_addons();
}
?>
<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Add-ons</h1>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background:#fff; border-radius:14px; padding:24px; box-shadow:0 3px 10px rgba(0,0,0,.05); margin-top:24px; }
    table { width:100%; border-collapse:collapse; }
    th, td { border-bottom:1px solid #eee; padding:12px 8px; font-size:14px; }
    th { text-align:left; background:#f9fafb; font-weight:600; }
    .badge { display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; text-transform:uppercase; }
    .badge-active { background:#dcfce7; color:#166534; }
    .badge-inactive { background:#f3f4f6; color:#6b7280; }
    .plugin-name { font-family:monospace; font-size:12px; color:#6b7280; }
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-1"><i class="bi bi-puzzle"></i> Add-on Plugins</h2>
    <p class="text-sm text-gray-500 mb-4">
      Add-ons are enabled by activating their WordPress plugin. Subscription/license data does not control add-on visibility.
    </p>

    <table>
      <thead>
        <tr>
          <th>Add-on</th>
          <th>Plugin</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($known_addons as $key => $info):
            $active = in_array($key, $active_addons, true);
        ?>
          <tr>
            <td><i class="bi <?= esc_attr($info['icon']) ?>"></i> <?= esc_html($info['label']) ?></td>
            <td class="plugin-name"><?= esc_html($info['plugin']) ?></td>
            <td>
              <span class="badge <?= $active ? 'badge-active' : 'badge-inactive' ?>">
                <?= $active ? 'Active' : 'Not Active' ?>
              </span>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</div>
