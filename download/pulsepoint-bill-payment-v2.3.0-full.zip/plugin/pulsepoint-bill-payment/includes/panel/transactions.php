<?php
/**
 * Pulsepoint Admin Transactions Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/transactions.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

// === TABLES ===
$table_users = "{$base_prefix}users";
$table_trnx  = "{$base_prefix}trnx";

// === Create table structure if not exists (for safety) ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_trnx}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `details` TEXT,
    `recipient` VARCHAR(255) DEFAULT NULL,
    `amount` DECIMAL(14,2) DEFAULT 0.00,
    `reference` VARCHAR(255) DEFAULT NULL,
    `payment` ENUM('wallet','api','app') DEFAULT 'wallet',
    `category` ENUM('airtime','data','cable','bill','virtual-account','funding','transfer','others') DEFAULT 'others',
    `status` ENUM('pending','success','failed') DEFAULT 'pending',
    `type` ENUM('debit','credit') DEFAULT 'debit',
    `gateway_response` TEXT,
    `session` VARCHAR(255) DEFAULT NULL,
    `description` TEXT,
    `date` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `reference_idx` (`reference`),
    KEY `user_id_idx` (`user_id`)
) $charset;");

// === Platform Settings ===
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings = [];
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#6C63FF';

// === Totals ===
$total_success = (float) $wpdb->get_var("SELECT SUM(amount) FROM {$table_trnx} WHERE status='success'");
$total_pending = (float) $wpdb->get_var("SELECT SUM(amount) FROM {$table_trnx} WHERE status='pending'");
$total_failed  = (float) $wpdb->get_var("SELECT SUM(amount) FROM {$table_trnx} WHERE status='failed'");

// === Search Handling ===
$where = "1=1";
$search_value = '';
if (!empty($_GET['search'])) {
    $search_value = sanitize_text_field($_GET['search']);
    $where .= $wpdb->prepare(" AND (
        t.reference LIKE %s OR 
        t.session LIKE %s OR 
        t.category LIKE %s OR 
        t.status LIKE %s OR 
        t.type LIKE %s OR 
        u.phone LIKE %s OR 
        u.email LIKE %s
    )", 
    "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%", "%$search_value%");
}

// === Transactions Query ===
$transactions = $wpdb->get_results("
    SELECT t.*, u.firstname, u.lastname, u.phone, u.email 
    FROM {$table_trnx} t
    LEFT JOIN {$table_users} u ON t.user_id = u.id
    WHERE {$where}
    ORDER BY t.date DESC
    LIMIT 10000
");

// === Number formatting ===
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Transactions</h1>
  <p>Manage and review all platform transactions below.</p>
  <hr class="wp-header-end">

  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 18px;
      margin-top: 20px;
    }
    .pulse-card {
      background: #fff;
      border-radius: 14px;
      padding: 18px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
    }
    .pulse-title {
      color: #666;
      font-size: 13px;
      text-transform: uppercase;
      font-weight: 600;
    }
    .pulse-value {
      font-weight: 800;
      font-size: 22px;
      color: var(--primary);
      margin-top: 6px;
    }
    .search-bar {
      margin-top: 24px;
      display: flex;
      gap: 12px;
    }
    .search-input {
      width: 100%;
      padding: 10px 14px;
      border-radius: 8px;
      border: 1px solid #ddd;
      font-size: 14px;
    }
    .search-btn {
      background: var(--primary);
      color: #fff;
      padding: 10px 18px;
      border-radius: 8px;
      cursor: pointer;
      border: none;
    }
    .pulse-table-container {
      margin-top: 28px;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      overflow-x: auto; /* ✅ Enable horizontal scrolling */
      width: 100%;
    }
    .pulse-table {
      width: 100%;
      border-collapse: collapse;
      min-width: 1100px; /* ✅ Prevent narrow squeeze */
    }
    .pulse-table th, .pulse-table td {
      padding: 12px 14px;
      border-bottom: 1px solid #eee;
      text-align: left;
      font-size: 14px;
      white-space: nowrap; /* ✅ Keep long text on one line */
    }
    .pulse-table th {
      background: #f8fafc;
      font-weight: 700;
      text-transform: uppercase;
      font-size: 12px;
    }
    .view-btn {
      background: var(--primary);
      color: #fff;
      padding: 6px 12px;
      border-radius: 8px;
      text-decoration: none;
      font-size: 13px;
      white-space: nowrap;
    }
  </style>

  <!-- Summary Cards -->
  <div class="pulse-grid">
    <div class="pulse-card">
      <div class="pulse-title">Total Successful Transactions</div>
      <div class="pulse-value text-green-600"><?= fmt_amt($total_success) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Total Pending Transactions</div>
      <div class="pulse-value text-yellow-600"><?= fmt_amt($total_pending) ?></div>
    </div>
    <div class="pulse-card">
      <div class="pulse-title">Total Lost (Failed)</div>
      <div class="pulse-value text-red-600"><?= fmt_amt($total_failed) ?></div>
    </div>
  </div>

  <!-- Search -->
  <form method="get" class="search-bar">
    <input type="hidden" name="page" value="pulsepoint-transactions">
    <input type="text" name="search" value="<?= esc_attr($search_value) ?>" class="search-input" placeholder="Search by phone, email, reference, session, status, type, or category...">
    <button type="submit" class="search-btn"><i class="bi bi-search"></i> Search</button>
  </form>

  <!-- Transactions Table -->
  <div class="pulse-table-container">
    <table class="pulse-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Amount</th>
          <th>Status</th>
          <th>Category</th>
          <th>Type</th>
          <th>Reference</th>
          <th>Session</th>
          <th>Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($transactions): foreach ($transactions as $t): ?>
          <tr>
            <td>#<?= $t->id ?></td>
            <td><?= esc_html($t->firstname . ' ' . $t->lastname) ?></td>
            <td><?= esc_html($t->phone) ?></td>
            <td><?= esc_html($t->email) ?></td>
            <td><?= fmt_amt($t->amount) ?></td>
            <td>
              <?php if ($t->status === 'success'): ?>
                <span class="text-green-600 font-semibold">Success</span>
              <?php elseif ($t->status === 'pending'): ?>
                <span class="text-yellow-600 font-semibold">Pending</span>
              <?php else: ?>
                <span class="text-red-600 font-semibold">Failed</span>
              <?php endif; ?>
            </td>
            <td><?= ucfirst($t->category) ?></td>
            <td><?= ucfirst($t->type) ?></td>
            <td><?= esc_html($t->reference) ?></td>
            <td><?= esc_html($t->session) ?></td>
            <td><?= esc_html($t->date) ?></td>
            <td>
              <a href="?page=pulsepoint-view_transaction&id=<?= $t->id ?>" class="view-btn">View</a>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="12" class="text-center py-4">No transactions found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>