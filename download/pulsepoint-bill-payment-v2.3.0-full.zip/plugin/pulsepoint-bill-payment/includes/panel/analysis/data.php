<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

$table = $wpdb->prefix . 'pulsepoint_trnx';

// ================= SAFE INPUT =================
$from = $_GET['from'] ?? '';
$to   = $_GET['to'] ?? '';

$where = "WHERE category = 'data' AND status = 'success'";

if (!empty($from) && !empty($to)) {
    $from = esc_sql($from);
    $to   = esc_sql($to);
    $where .= " AND date BETWEEN '{$from}' AND '{$to}'";
}

// ================= SUMMARY =================
$summary = $wpdb->get_row("
    SELECT 
        SUM(profit_amount) AS profit,
        SUM(amount) AS revenue,
        COUNT(*) AS total_transactions
    FROM $table
    $where
");

$profit  = $summary->profit ?? 0;
$revenue = $summary->revenue ?? 0;
$total   = $summary->total_transactions ?? 0;


// ================= DATA SOLD =================
$rows = $wpdb->get_results("
    SELECT value
    FROM $table
    $where
");

$total_mb = 0;

foreach ($rows as $r) {
    $val = strtoupper(trim($r->value));

    if (strpos($val, 'GB') !== false) {
        $total_mb += floatval($val) * 1000;
    } elseif (strpos($val, 'MB') !== false) {
        $total_mb += floatval($val);
    } elseif (is_numeric($val)) {
        $total_mb += floatval($val) * 1000;
    }
}

$total_gb = $total_mb / 1000;


// ================= NETWORK PERFORMANCE =================
$networks = $wpdb->get_results("
    SELECT 
        JSON_UNQUOTE(JSON_EXTRACT(details, '$.network')) AS network,
        SUM(amount) AS revenue,
        SUM(profit_amount) AS profit,
        COUNT(*) AS total
    FROM $table
    $where
    GROUP BY network
    ORDER BY profit DESC
");

function networkColor($net) {
    $net = strtoupper($net);

    return match ($net) {
        'MTN' => '#facc15',     // yellow
        'GLO' => '#22c55e',     // green
        'AIRTEL' => '#ef4444',  // red
        '9MOBILE' => '#000000', // black
        default => '#6b7280'
    };
}

// ================= LOSS CHECK =================
$loss_alert = ($profit < 0);
?>

<!-- ================= DASHBOARD ================= -->
<div id="dashboard">

<!-- FILTER -->
<div class="bg-white p-4 rounded-lg shadow mb-4">
    <form id="filterForm" class="flex gap-2 flex-wrap">
        <input type="date" name="from" value="<?= esc_attr($from) ?>" class="border p-2 rounded">
        <input type="date" name="to" value="<?= esc_attr($to) ?>" class="border p-2 rounded">

        <button class="bg-blue-600 text-white px-4 py-2 rounded">
            Filter
        </button>
    </form>
</div>

<!-- LOSS ALERT -->
<?php if ($loss_alert): ?>
<div class="bg-red-100 text-red-700 p-3 rounded mb-4">
    ⚠️ Loss Detected: ₦<?= number_format($profit, 2) ?>
</div>
<?php endif; ?>

<!-- ================= MAIN STATS ================= -->
<div class="grid grid-cols-2 gap-4">

    <div class="bg-blue-50 p-4 rounded-lg">
        <p>Total Data Profit</p>
        <h3 class="text-xl font-bold">₦<?= number_format($profit, 2) ?></h3>
    </div>

    <div class="bg-green-50 p-4 rounded-lg">
        <p>Total Data Sold</p>
        <h3 class="text-xl font-bold"><?= number_format($total_gb, 2) ?> GB</h3>
    </div>

</div>

<div class="grid grid-cols-2 gap-4 mt-4">

    <div class="bg-white border p-4 rounded-lg">
        <p>Total Revenue</p>
        <h3 class="text-xl font-bold">₦<?= number_format($revenue, 2) ?></h3>
    </div>

    <div class="bg-white border p-4 rounded-lg">
        <p>Total Transactions</p>
        <h3 class="text-xl font-bold"><?= number_format($total) ?></h3>
    </div>

</div>

<!-- ================= NETWORK RANKING ================= -->
<div class="bg-white p-4 mt-4 rounded-lg border">
    <p class="font-bold mb-3">🏆 Best Performing Network Ranking</p>

    <?php if (!empty($networks)): ?>
        <?php foreach ($networks as $n): 
            $net = strtoupper($n->network ?: 'UNKNOWN');
        ?>
            <div class="flex justify-between items-center p-2 border-b">

                <div class="flex items-center gap-2">
                    <span style="width:10px;height:10px;background:<?= networkColor($net) ?>;display:inline-block;border-radius:50%"></span>
                    <strong><?= $net ?></strong>
                </div>

                <div class="text-right">
                    <div>₦<?= number_format($n->profit ?? 0, 2) ?> Profit</div>
                    <small><?= $n->total ?> Transactions</small>
                </div>

            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-gray-500">No network data available</p>
    <?php endif; ?>
</div>

</div>

<!-- ================= FILTER AJAX ================= -->
<script>
document.getElementById('filterForm')?.addEventListener('submit', function(e) {
    e.preventDefault();

    const params = new URLSearchParams(new FormData(this)).toString();

    fetch(window.location.href + '&' + params)
        .then(res => res.text())
        .then(html => {
            const doc = new DOMParser().parseFromString(html, 'text/html');
            document.getElementById('dashboard').innerHTML =
                doc.getElementById('dashboard').innerHTML;
        });
});

// optional auto refresh
setInterval(() => {
    location.reload();
}, 20000);
</script>