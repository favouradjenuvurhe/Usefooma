<?php
/**
 * Pulsepoint Admin API Setup Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/api-setup.php
 * Author: Amaaavl
 *
 * Split out of the old settings.php "API Configuration" section — service
 * provider/API credentials only (airtime, cable, bill, bank transfer).
 * General/branding settings live in includes/panel/customization.php.
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_settings = "{$base_prefix}settings";

// === Create settings table if not exists ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_settings}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `opt_key` VARCHAR(255) NOT NULL,
    `opt_value` TEXT,
    `type` VARCHAR(50) DEFAULT 'string',
    `grouping` VARCHAR(100) DEFAULT NULL,
    `autoload` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `opt_key_unique` (`opt_key`)
) {$charset};");

// === Default Settings (API/provider credentials only) ===
$defaults = [
    'airtime_api'    => 'adex',
    'airtime_kyc'    => '1',
    'airtime_token'  => 'token',
    'cable_api'      => 'adex',
    'cable_kyc'      => '0',
    'cable_token'    => 'token',
    'bill_api'       => 'adex',
    'bill_kyc'       => '0',
    'bill_token'     => 'token',
    'bank_transfer'  => 'strowallet',
    'bank_kyc'       => '1',
    'bank_token'     => '',
];

// === Sync defaults with DB ===
foreach ($defaults as $key => $value) {
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s", $key));
    if (!$exists) {
        $wpdb->insert($table_settings, [
            'opt_key' => $key,
            'opt_value' => maybe_serialize($value),
            'type' => 'string',
            'autoload' => 1
        ]);
    }
}

// === Handle Save ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_api_setup_nonce']) && wp_verify_nonce($_POST['pulsepoint_api_setup_nonce'], 'save_pulsepoint_api_setup')) {
    foreach ($_POST as $key => $value) {
        if (array_key_exists($key, $defaults)) {
            $wpdb->update(
                $table_settings,
                ['opt_value' => maybe_serialize(sanitize_text_field($value))],
                ['opt_key' => $key]
            );
        }
    }
    echo '<div class="updated notice"><p><strong>API Setup saved successfully.</strong></p></div>';
}

// === Fetch all current settings ===
$settings = [];
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
foreach ($rows as $r) {
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);
}

// === Get platform info ===
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#356cf9';
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — API Setup</h1>
  <a href="?page=pulsepoint-configuration" class="page-title-action"><i class="bi bi-arrow-left"></i> Back to Configuration</a>
  <p>Manage service provider API credentials (airtime, cable, bill, bank transfer).</p>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_api_setup', 'pulsepoint_api_setup_nonce'); ?>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-cloud"></i> API Configuration</h2>
      <div class="pulse-grid">
      <div>
    <label class="pulse-label">Bank Transfer - Type</label>
    <select name="bank_transfer" class="pulse-input">
        <?php
        $transfer_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/transfer/';
        $files = glob($transfer_dir . '*.php'); // get all PHP files

        foreach ($files as $file) {
            $filename = basename($file, '.php'); // get file name without .php
            // Skip pulsepoint.php and verification.php
            if (in_array($filename, ['pulsepoint', 'verification', 'wallet2'])) continue;

            $selected = ($settings['bank_transfer'] ?? '') === $filename ? 'selected' : '';
            echo "<option value='{$filename}' {$selected}>{$filename}</option>";
        }
        ?>
    </select>
</div>

<div>
    <label class="pulse-label">Bank Token</label>
    <input type="text" 
           name="bank_token" 
           value="<?= esc_attr($settings['bank_token']) ?>" 
           class="pulse-input">
</div>
<div>
    <label class="pulse-label">Bank Transfer KYC</label>
    <select name="bank_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['bank_kyc']) && $settings['bank_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['bank_kyc']) && $settings['bank_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
    <label class="pulse-label">Airtime API - Type</label>
    <select name="airtime_api" class="pulse-input">
        <?php
        $airtime_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/airtime/';
        $files = glob($airtime_dir . '*.php'); // get all PHP files

        foreach ($files as $file) {
            $filename = basename($file, '.php'); // get file name without .php
            if ($filename === 'pulsepoint') continue; // skip pulsepoint.php

            $selected = ($settings['airtime_api'] ?? '') === $filename ? 'selected' : '';
            echo "<option value='{$filename}' {$selected}>{$filename}</option>";
        }
        ?>
    </select>
</div>
<div>
    <label class="pulse-label">Airtime KYC</label>
    <select name="airtime_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['airtime_kyc']) && $settings['airtime_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['airtime_kyc']) && $settings['airtime_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
          <label class="pulse-label">Airtime Token</label>
          <input type="text" name="airtime_token" value="<?= esc_attr($settings['airtime_token']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Cable API - Endpoint</label>
          <input type="text" name="cable_api" value="<?= esc_attr($settings['cable_api']) ?>" class="pulse-input">
        </div>
        <div>
    <label class="pulse-label">Cable KYC</label>
    <select name="cable_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['cable_kyc']) && $settings['cable_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['cable_kyc']) && $settings['cable_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
          <label class="pulse-label">Cable Token</label>
          <input type="text" name="cable_token" value="<?= esc_attr($settings['cable_token']) ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Bill API - Endpoint</label>
          <input type="text" name="bill_api" value="<?= esc_attr($settings['bill_api']) ?>" class="pulse-input">
        </div>
        <div>
    <label class="pulse-label">Bill KYC</label>
    <select name="bill_kyc" class="pulse-input">
        <option value="0" <?= (isset($settings['bill_kyc']) && $settings['bill_kyc'] == '0') ? 'selected' : '' ?>>
            Disable
        </option>
        <option value="1" <?= (isset($settings['bill_kyc']) && $settings['bill_kyc'] == '1') ? 'selected' : '' ?>>
            Enable
        </option>
    </select>
</div>
        <div>
          <label class="pulse-label">Bill Token</label>
          <input type="text" name="bill_token" value="<?= esc_attr($settings['bill_token']) ?>" class="pulse-input">
        </div>
      </div>
    </div>
    

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save API Setup</button>
    </div>

  </form>
</div>
