<?php
/**
 * Pulsepoint Airtime-to-Cash Admin Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/airtime-to-cash.php
 * Author: Amaaavl
 *
 * Two jobs on one page:
 *  1. Configure network rates (the `airtime_to_cash` table) — add/edit/delete
 *     the networks users can trade, their payout rate %, min/max, and the
 *     receiver number/name shown to users.
 *  2. Review submitted trades (the `airtime_to_cash_transactions` table) —
 *     approve (credits the user's wallet with `payable` and emails them) or
 *     decline (emails them with a remark), same as core/airtime/a2c/pulsepoint.php
 *     said this was intentionally left out of scope for the submission handler.
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_rates = "{$base_prefix}airtime_to_cash";
$table_trnx  = "{$base_prefix}airtime_to_cash_transactions";
$table_users = "{$base_prefix}users";
$table_ledger = "{$base_prefix}trnx";

// pulsepoint_send_a2c_email() is already available globally — it's
// defined in core/airtime/a2c/pulsepoint.php, which loader.php requires
// on every request (re-requiring it here would redeclare its functions).

$notice = '';

/* =========================================================
   RATE CONFIG: SAVE (ADD / EDIT)
   ========================================================= */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_a2c_rate_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_a2c_rate_nonce'], 'save_pulsepoint_a2c_rate')
) {
    $rate_id = isset($_POST['rate_id']) ? intval($_POST['rate_id']) : 0;

    $data = [
        'network'         => sanitize_text_field($_POST['network'] ?? ''),
        'receiver_number' => sanitize_text_field($_POST['receiver_number'] ?? ''),
        'receiver_name'   => sanitize_text_field($_POST['receiver_name'] ?? ''),
        'rate'            => floatval($_POST['rate'] ?? 0),
        'min_amount'      => floatval($_POST['min_amount'] ?? 0),
        'max_amount'      => floatval($_POST['max_amount'] ?? 0),
        'status'          => sanitize_text_field($_POST['status'] ?? 'active'),
        'instruction'     => sanitize_textarea_field($_POST['instruction'] ?? ''),
        'provider'        => sanitize_text_field($_POST['provider'] ?? ''),
    ];

    if ($rate_id) {
        $wpdb->update($table_rates, $data, ['id' => $rate_id]);
        $notice = 'Network rate updated.';
    } else {
        $wpdb->insert($table_rates, $data);
        $notice = 'Network rate added.';
    }
}

/* =========================================================
   RATE CONFIG: DELETE
   ========================================================= */
if (isset($_GET['delete_rate']) && is_numeric($_GET['delete_rate']) && check_admin_referer('pulsepoint_a2c_rate_action')) {
    $wpdb->delete($table_rates, ['id' => intval($_GET['delete_rate'])]);
    $notice = 'Network rate deleted.';
}

/* =========================================================
   TRADE REVIEW: APPROVE / DECLINE
   ========================================================= */
if (isset($_GET['action'], $_GET['trade_id']) && in_array($_GET['action'], ['approve', 'decline'], true) && check_admin_referer('pulsepoint_a2c_trade_action')) {

    $trade_id = intval($_GET['trade_id']);
    $action   = sanitize_text_field($_GET['action']);

    $trade = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_trnx} WHERE id=%d", $trade_id));

    if (!$trade) {
        $notice = 'Trade not found.';
    } elseif ($trade->status !== 'pending') {
        $notice = 'This trade has already been ' . $trade->status . '.';
    } else {

        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_users} WHERE id=%d", $trade->user_id));

        $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
        $settings = [];
        foreach ($settings_rows as $row) {
            $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
        }
        $branding = [
            'platform_name' => $settings['platform_name'] ?? 'Pulsepoint',
            'color_hex'     => $settings['color_hex'] ?? '#6C63FF',
        ];

        if ($action === 'approve') {

            $wpdb->query('START TRANSACTION');

            $updated = $wpdb->update(
                $table_trnx,
                ['status' => 'approved'],
                ['id' => $trade_id, 'status' => 'pending']
            );

            if ($updated) {

                $wpdb->query($wpdb->prepare(
                    "UPDATE {$table_users} SET wallet = wallet + %f WHERE id = %d",
                    (float) $trade->payable,
                    $trade->user_id
                ));

                $wpdb->insert($table_ledger, [
                    'user_id'     => $trade->user_id,
                    'details'     => json_encode(['network' => $trade->network, 'sender_number' => $trade->sender_number]),
                    'recipient'   => $trade->sender_number,
                    'amount'      => $trade->payable,
                    'reference'   => $trade->reference,
                    'payment'     => 'wallet',
                    'category'    => 'others',
                    'status'      => 'success',
                    'type'        => 'credit',
                    'description' => strtoupper($trade->network) . ' Airtime-to-Cash Trade Approved',
                ]);

                $wpdb->query('COMMIT');

                if ($user) {
                    pulsepoint_send_a2c_email($user, 'approved', $trade->network, $trade->sender_number, (float) $trade->amount, (float) $trade->payable, $trade->reference, $branding);
                }

                $notice = 'Trade approved and ₦' . number_format((float) $trade->payable, 2) . ' credited to the user\'s wallet.';
            } else {
                $wpdb->query('ROLLBACK');
                $notice = 'Could not approve — trade may have already been processed.';
            }

        } else { // decline

            $remark = sanitize_text_field($_GET['remark'] ?? 'Proof could not be verified.');

            $updated = $wpdb->update(
                $table_trnx,
                ['status' => 'declined', 'remark' => $remark],
                ['id' => $trade_id, 'status' => 'pending']
            );

            if ($updated && $user) {
                pulsepoint_send_a2c_email($user, 'declined', $trade->network, $trade->sender_number, (float) $trade->amount, (float) $trade->payable, $trade->reference, $branding);
            }

            $notice = $updated ? 'Trade declined and user notified.' : 'Could not decline — trade may have already been processed.';
        }
    }
}

/* =========================================================
   FETCH DATA
   ========================================================= */
$rates = $wpdb->get_results("SELECT * FROM {$table_rates} ORDER BY network ASC");

$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'pending';
$allowed_status = ['pending', 'approved', 'declined', 'all'];
if (!in_array($status_filter, $allowed_status, true)) $status_filter = 'pending';

$where = $status_filter === 'all' ? '' : $wpdb->prepare('WHERE t.status = %s', $status_filter);

$trades = $wpdb->get_results(
    "SELECT t.*, u.firstname, u.lastname, u.email
     FROM {$table_trnx} t
     LEFT JOIN {$table_users} u ON u.id = t.user_id
     {$where}
     ORDER BY t.created DESC
     LIMIT 100"
);

$edit_rate = null;
if (isset($_GET['edit_rate']) && is_numeric($_GET['edit_rate'])) {
    $edit_rate = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_rates} WHERE id=%d", intval($_GET['edit_rate'])));
}
?>
<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Airtime-to-Cash</h1>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 10px 8px; font-size: 13px; vertical-align: top; }
    th { text-align: left; background: #f9fafb; font-weight: 600; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 600; text-decoration: none; display:inline-block; }
    .pulse-btn-danger { background: #ef4444; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 600; text-decoration: none; display:inline-block; }
    .pulse-btn-outline { background: #fff; border: 1px solid #ddd; color: #333; padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 600; text-decoration: none; display:inline-block; }
    .badge { padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .badge-pending { background: #fef3c7; color: #92400e; }
    .badge-approved { background: #dcfce7; color: #166534; }
    .badge-declined { background: #fee2e2; color: #991b1b; }
    .filter-tab { padding: 6px 14px; border-radius: 999px; font-size: 12px; font-weight: 600; text-decoration: none; color: #555; background: #f3f4f6; }
    .filter-tab.active { background: var(--primary); color: #fff; }
    input, select, textarea { border: 1px solid #ddd; border-radius: 8px; padding: 8px 10px; font-size: 13px; width: 100%; }
  </style>

  <?php if ($notice): ?>
    <div class="updated notice"><p><strong><?= esc_html($notice) ?></strong></p></div>
  <?php endif; ?>

  <!-- ================= RATE CONFIG ================= -->
  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-sliders"></i> <?= $edit_rate ? 'Edit' : 'Add' ?> Network Rate</h2>

    <form method="post" class="grid grid-cols-2 md:grid-cols-3 gap-3">
      <?php wp_nonce_field('save_pulsepoint_a2c_rate', 'pulsepoint_a2c_rate_nonce'); ?>
      <input type="hidden" name="rate_id" value="<?= $edit_rate ? esc_attr($edit_rate->id) : '' ?>">

      <div>
        <label class="text-xs font-semibold">Network (e.g. MTN)</label>
        <input type="text" name="network" required value="<?= $edit_rate ? esc_attr($edit_rate->network) : '' ?>">
      </div>
      <div>
        <label class="text-xs font-semibold">Rate % (payout of amount sent)</label>
        <input type="number" step="0.01" name="rate" required value="<?= $edit_rate ? esc_attr($edit_rate->rate) : '' ?>">
      </div>
      <div>
        <label class="text-xs font-semibold">Status</label>
        <select name="status">
          <option value="active" <?= ($edit_rate && $edit_rate->status === 'active') ? 'selected' : '' ?>>Active</option>
          <option value="inactive" <?= ($edit_rate && $edit_rate->status === 'inactive') ? 'selected' : '' ?>>Inactive</option>
        </select>
      </div>
      <div>
        <label class="text-xs font-semibold">Min Amount (₦)</label>
        <input type="number" step="0.01" name="min_amount" value="<?= $edit_rate ? esc_attr($edit_rate->min_amount) : '' ?>">
      </div>
      <div>
        <label class="text-xs font-semibold">Max Amount (₦)</label>
        <input type="number" step="0.01" name="max_amount" value="<?= $edit_rate ? esc_attr($edit_rate->max_amount) : '' ?>">
      </div>
      <div>
        <label class="text-xs font-semibold">Provider (internal tag, optional)</label>
        <input type="text" name="provider" value="<?= $edit_rate ? esc_attr($edit_rate->provider) : '' ?>">
      </div>
      <div>
        <label class="text-xs font-semibold">Receiver Number</label>
        <input type="text" name="receiver_number" required value="<?= $edit_rate ? esc_attr($edit_rate->receiver_number) : '' ?>">
      </div>
      <div>
        <label class="text-xs font-semibold">Receiver Name</label>
        <input type="text" name="receiver_name" required value="<?= $edit_rate ? esc_attr($edit_rate->receiver_name) : '' ?>">
      </div>
      <div class="col-span-2 md:col-span-3">
        <label class="text-xs font-semibold">Instructions shown to the user</label>
        <textarea name="instruction" rows="2"><?= $edit_rate ? esc_textarea($edit_rate->instruction) : '' ?></textarea>
      </div>
      <div class="col-span-2 md:col-span-3">
        <button type="submit" class="pulse-btn"><i class="bi bi-check-circle"></i> <?= $edit_rate ? 'Update Rate' : 'Add Rate' ?></button>
        <?php if ($edit_rate): ?>
          <a href="?page=pulsepoint-airtime-to-cash" class="pulse-btn-outline">Cancel</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-broadcast"></i> Configured Networks</h2>

    <?php if (!$rates): ?>
      <p>No networks configured yet. Add one above.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Network</th><th>Rate</th><th>Min</th><th>Max</th><th>Receiver</th><th>Status</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rates as $r): ?>
            <tr>
              <td><strong><?= esc_html($r->network) ?></strong></td>
              <td><?= number_format((float) $r->rate, 2) ?>%</td>
              <td>₦<?= number_format((float) $r->min_amount, 2) ?></td>
              <td>₦<?= number_format((float) $r->max_amount, 2) ?></td>
              <td><?= esc_html($r->receiver_name) ?><br><span class="text-gray-400"><?= esc_html($r->receiver_number) ?></span></td>
              <td><span class="badge <?= $r->status === 'active' ? 'badge-approved' : 'badge-declined' ?>"><?= esc_html($r->status) ?></span></td>
              <td>
                <a href="?page=pulsepoint-airtime-to-cash&edit_rate=<?= $r->id ?>" class="pulse-btn"><i class="bi bi-pencil-square"></i></a>
                <a href="<?= wp_nonce_url('?page=pulsepoint-airtime-to-cash&delete_rate=' . $r->id, 'pulsepoint_a2c_rate_action') ?>" onclick="return confirm('Delete this network?')" class="pulse-btn-danger"><i class="bi bi-trash"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <!-- ================= TRADE REVIEW ================= -->
  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-inboxes"></i> Trade Submissions</h2>

    <div class="flex gap-2 mb-4">
      <a href="?page=pulsepoint-airtime-to-cash&status=pending" class="filter-tab <?= $status_filter === 'pending' ? 'active' : '' ?>">Pending</a>
      <a href="?page=pulsepoint-airtime-to-cash&status=approved" class="filter-tab <?= $status_filter === 'approved' ? 'active' : '' ?>">Approved</a>
      <a href="?page=pulsepoint-airtime-to-cash&status=declined" class="filter-tab <?= $status_filter === 'declined' ? 'active' : '' ?>">Declined</a>
      <a href="?page=pulsepoint-airtime-to-cash&status=all" class="filter-tab <?= $status_filter === 'all' ? 'active' : '' ?>">All</a>
    </div>

    <?php if (!$trades): ?>
      <p>No <?= $status_filter === 'all' ? '' : esc_html($status_filter) ?> trades found.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>User</th><th>Network</th><th>Sender #</th><th>Amount</th><th>Payable</th><th>Proof</th><th>Status</th><th>Date</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($trades as $t): ?>
              <tr>
                <td><?= esc_html(trim(($t->firstname ?? '') . ' ' . ($t->lastname ?? ''))) ?><br><span class="text-gray-400"><?= esc_html($t->email ?? '') ?></span></td>
                <td><?= esc_html($t->network) ?></td>
                <td><?= esc_html($t->sender_number) ?></td>
                <td>₦<?= number_format((float) $t->amount, 2) ?></td>
                <td>₦<?= number_format((float) $t->payable, 2) ?></td>
                <td><?php if ($t->proof): ?><a href="<?= esc_url($t->proof) ?>" target="_blank" class="pulse-btn-outline"><i class="bi bi-image"></i> View</a><?php else: ?>—<?php endif; ?></td>
                <td><span class="badge badge-<?= esc_attr($t->status) ?>"><?= esc_html($t->status) ?></span></td>
                <td><?= esc_html($t->created) ?></td>
                <td>
                  <?php if ($t->status === 'pending'): ?>
                    <a href="<?= wp_nonce_url('?page=pulsepoint-airtime-to-cash&action=approve&trade_id=' . $t->id . '&status=' . $status_filter, 'pulsepoint_a2c_trade_action') ?>" onclick="return confirm('Approve this trade and credit the wallet?')" class="pulse-btn"><i class="bi bi-check-lg"></i> Approve</a>
                    <a href="<?= wp_nonce_url('?page=pulsepoint-airtime-to-cash&action=decline&trade_id=' . $t->id . '&status=' . $status_filter, 'pulsepoint_a2c_trade_action') ?>" onclick="return confirm('Decline this trade?')" class="pulse-btn-danger"><i class="bi bi-x-lg"></i> Decline</a>
                  <?php else: ?>
                    <span class="text-gray-400"><?= esc_html($t->remark ?: '—') ?></span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
