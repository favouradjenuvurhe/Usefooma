<?php
/**
 * Pulsepoint Virtual Accounts Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/virtual-accounts.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();

$table_account = "{$base_prefix}account";
$table_trnx    = "{$base_prefix}trnx";

// === Create Accounts Table if not exists ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_account}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `bank` VARCHAR(150) DEFAULT NULL,
    `name` VARCHAR(200) DEFAULT NULL,
    `number` VARCHAR(100) DEFAULT NULL,
    `provider` VARCHAR(100) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_idx` (`user_id`)
) {$charset};");

// === Fetch all accounts ===
$accounts = $wpdb->get_results("
    SELECT a.*, u.firstname, u.lastname, u.email
    FROM {$table_account} a
    LEFT JOIN {$base_prefix}users u ON a.user_id = u.id
    ORDER BY a.id DESC
");

// === Handle Chatbox Query ===
$chat_response = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['yoma_query'])) {
    $query = sanitize_text_field($_POST['yoma_query']);

    // Check if query matches an account number
    $transaction = $wpdb->get_row($wpdb->prepare("
        SELECT t.*, u.firstname, u.lastname 
        FROM {$table_trnx} t
        LEFT JOIN {$base_prefix}users u ON t.user_id = u.id
        WHERE t.recipient = %s
        ORDER BY t.date DESC
        LIMIT 1
    ", $query));

    if ($transaction) {
        $chat_response = "Yoma 🤖: The account number <strong>{$transaction->recipient}</strong> was used to fund <strong>₦" . number_format($transaction->amount, 2) . "</strong> on <strong>{$transaction->date}</strong> by <strong>{$transaction->firstname} {$transaction->lastname}</strong>. Transaction reference: <strong>{$transaction->reference}</strong>. Status: <strong>{$transaction->status}</strong>.";
    } else {
        $chat_response = "Yoma 🤖: No transactions found for the account number <strong>{$query}</strong>.";
    }
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Virtual Accounts</h1>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 10px 8px; font-size: 14px; }
    th { text-align: left; background: #f9fafb; font-weight: 600; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; }
    .pulse-btn-danger { background: #ef4444; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; }
    .chat-box { border: 1px solid #ddd; border-radius: 14px; padding: 16px; max-height: 300px; overflow-y: auto; background: #f9fafb; margin-top: 16px; }
    .chat-input { width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #ddd; margin-top: 8px; }
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-bank"></i> Virtual Accounts</h2>

    <?php if (!$accounts): ?>
      <p>No virtual accounts found.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Bank</th>
              <th>Account Name</th>
              <th>Account Number</th>
              <th>Provider</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($accounts as $acc): ?>
              <tr>
                <td><?= esc_html($acc->id) ?></td>
                <td><?= esc_html($acc->firstname . ' ' . $acc->lastname) ?> <br><small><?= esc_html($acc->email) ?></small></td>
                <td><?= esc_html($acc->bank ?: '—') ?></td>
                <td><?= esc_html($acc->name ?: '—') ?></td>
                <td><?= esc_html($acc->number ?: '—') ?></td>
                <td><?= esc_html($acc->provider ?: '—') ?></td>
                <td><?= esc_html($acc->created_at) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <!-- Yoma Chatbox -->
    <div class="pulse-section mt-6">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-chat-dots"></i> Yoma Chat Assistant</h2>
      <form method="POST">
        <input type="text" name="yoma_query" class="chat-input" placeholder="Enter account number to check recent transaction..." required>
        <button type="submit" class="pulse-btn mt-2"><i class="bi bi-send"></i> Ask Yoma</button>
      </form>
      <?php if ($chat_response): ?>
        <div class="chat-box mt-4"><?= $chat_response ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>