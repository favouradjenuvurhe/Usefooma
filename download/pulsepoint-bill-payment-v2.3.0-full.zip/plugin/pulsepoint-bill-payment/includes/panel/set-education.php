<?php
/**
 * Pulsepoint Education API Settings
 * URL: admin.php?page=pulsepoint-set-education
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_settings = "{$base_prefix}settings";

/* === FETCH SETTINGS === */
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}", OBJECT_K);

$edu_api   = $settings_rows['edu_api']->opt_value ?? '';
$edu_token = $settings_rows['edu_token']->opt_value ?? '';
$edu_kyc   = $settings_rows['edu_kyc']->opt_value ?? '0';

/* === SAVE SETTINGS === */
if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['pulsepoint_edu_settings_nonce']) &&
    wp_verify_nonce($_POST['pulsepoint_edu_settings_nonce'], 'save_pulsepoint_edu_settings')
) {

    $data = [
        'edu_api'   => sanitize_text_field($_POST['edu_api']),
        'edu_token' => sanitize_text_field($_POST['edu_token']),
        'edu_kyc'   => sanitize_text_field($_POST['edu_kyc']),
    ];

    foreach ($data as $key => $value) {

        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_settings} WHERE opt_key = %s",
            $key
        ));

        if ($exists) {
            $wpdb->update(
                $table_settings,
                ['opt_value' => $value],
                ['opt_key' => $key]
            );
        } else {
            $wpdb->insert(
                $table_settings,
                [
                    'opt_key'   => $key,
                    'opt_value' => $value,
                    'type'      => 'string',
                    'grouping'  => 'education'
                ]
            );
        }
    }

    echo '<div class="updated notice"><p><strong>Education API settings saved successfully.</strong></p></div>';

    // Refresh values
    $edu_api   = $data['edu_api'];
    $edu_token = $data['edu_token'];
    $edu_kyc   = $data['edu_kyc'];
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Education API Settings</h1>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    :root { --primary: #356cf9; }

    .pulse-section {
      background:#fff;
      border-radius:14px;
      padding:24px;
      box-shadow:0 3px 10px rgba(0,0,0,0.05);
      margin-top:24px;
    }

    .pulse-input {
      width:100%;
      border:1px solid #ddd;
      padding:10px 14px;
      border-radius:8px;
      font-size:14px;
    }

    .pulse-label {
      font-weight:600;
      font-size:14px;
      margin-bottom:6px;
      display:block;
    }

    .pulse-btn {
      background:var(--primary);
      color:#fff;
      padding:10px 20px;
      border:none;
      border-radius:8px;
      cursor:pointer;
      font-weight:600;
    }

    .pulse-grid {
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
      gap:16px;
    }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_edu_settings', 'pulsepoint_edu_settings_nonce'); ?>

    <div class="pulse-section">
      <div class="pulse-grid">

        <!-- API Endpoint -->
        <div>
          <label class="pulse-label">API Endpoint</label>
          <input type="text" name="edu_api"
                 value="<?= esc_attr($edu_api) ?>"
                 placeholder="https://api.example.com"
                 class="pulse-input" required>
        </div>

        <!-- API Token -->
        <div>
          <label class="pulse-label">API Token</label>
          <input type="text" name="edu_token"
                 value="<?= esc_attr($edu_token) ?>"
                 placeholder="Enter API Token"
                 class="pulse-input">
        </div>

        <!-- KYC Toggle -->
        <div>
          <label class="pulse-label">Require KYC</label>
          <select name="edu_kyc" class="pulse-input">
            <option value="0" <?= $edu_kyc == '0' ? 'selected' : '' ?>>Disabled</option>
            <option value="1" <?= $edu_kyc == '1' ? 'selected' : '' ?>>Enabled</option>
          </select>
        </div>

      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn">
        Save Settings
      </button>
    </div>

  </form>
</div>