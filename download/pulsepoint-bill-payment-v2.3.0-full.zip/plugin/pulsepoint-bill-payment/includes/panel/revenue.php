<?php
/**
 * Pulsepoint Revenue — Profit Analysis Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/revenue.php
 * Author: Favour Adjenuvurhe
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

// === Base Directory ===
$analysis_dir = PULSEPOINT_DIR . 'includes/panel/analysis/';

// === List of analysis components to load ===
$components = [
    'data.php',
    'airtime.php',
    // add more here later
    // 'electricity.php',
    // 'cable.php',
];

?>

<div class="wrap">
    <h1 class="wp-heading-inline">Pulsepoint — Revenue</h1>
    <hr class="wp-header-end">

    <!-- UI Assets -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        :root { --primary: #356cf9; }

        .pulse-section {
            background: #fff;
            border-radius: 14px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            margin-top: 20px;
        }

        .pulse-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #1f2937;
        }
    </style>

    <!-- ✅ Revenue Overview -->
    <div class="pulse-section">
        <h2 class="pulse-title">
            <i class="bi bi-cash-stack"></i> Revenue Overview
        </h2>
        <p class="text-gray-600 text-sm">
            This page shows profit analysis, revenue breakdown, and performance from all services.
        </p>
    </div>

    <!-- ✅ Dynamic Component Loader -->
    <?php foreach ($components as $file): ?>

        <?php
        $path = $analysis_dir . $file;

        if (file_exists($path)) {
            echo '<div class="pulse-section">';
            
            // Optional Title (based on filename)
            $title = ucfirst(str_replace('.php', '', $file));
            echo '<h2 class="pulse-title"><i class="bi bi-graph-up"></i> ' . esc_html($title) . ' Analysis</h2>';

            include $path;

            echo '</div>';
        } else {
            echo '<div class="pulse-section">';
            echo '<p class="text-red-500">Missing component: ' . esc_html($file) . '</p>';
            echo '</div>';
        }
        ?>

    <?php endforeach; ?>

</div>