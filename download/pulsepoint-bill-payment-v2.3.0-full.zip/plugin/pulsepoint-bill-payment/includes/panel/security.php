<?php
/**
 * Pulsepoint Security & API Keys Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/security.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_users = "{$base_prefix}users";
$table_trnx  = "{$base_prefix}trnx";
$table_settings = "{$base_prefix}settings";

// === Create tables if not exist ===
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_users}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `firstname` VARCHAR(100) NOT NULL,
    `lastname` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(30) DEFAULT NULL,
    `email` VARCHAR(200) NOT NULL,
    `wallet` DECIMAL(14,2) DEFAULT 0.00,
    `referral_balance` DECIMAL(14,2) DEFAULT 0.00,
    `referby` BIGINT UNSIGNED DEFAULT NULL,
    `token` VARCHAR(255) DEFAULT NULL,
    `reset_token` VARCHAR(255) DEFAULT NULL,
    `passcode` VARCHAR(4) DEFAULT NULL,
    `password` VARCHAR(255) NOT NULL,
    `security_question1` VARCHAR(255) DEFAULT NULL,
    `security_question2` VARCHAR(255) DEFAULT NULL,
    `security_question3` VARCHAR(255) DEFAULT NULL,
    `account_limit` DECIMAL(14,2) DEFAULT 0.00,
    `auto_login` TINYINT(1) DEFAULT 0,
    `alert` TINYINT(1) DEFAULT 1,
    `close_account` TINYINT(1) DEFAULT 0,
    `gender` ENUM('Male','Female','Other') DEFAULT NULL,
    `dob` DATE DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `account_type` ENUM('Customer','Agent','API') DEFAULT 'Customer',
    `status` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `email_unique` (`email`),
    FOREIGN KEY (`referby`) REFERENCES `{$base_prefix}users`(`id`) ON DELETE SET NULL
) {$charset};");

$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_trnx}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `details` TEXT,
    `recipient` VARCHAR(255) DEFAULT NULL,
    `amount` DECIMAL(14,2) DEFAULT 0.00,
    `reference` VARCHAR(255) DEFAULT NULL,
    `payment` ENUM('wallet','api','app') DEFAULT 'wallet',
    `category` ENUM('airtime','data','cable','bill','virtual-account','funding','transfer','others') DEFAULT 'others',
    `status` ENUM('pending','success','failed') DEFAULT 'pending',
    `type` ENUM('debit','credit') DEFAULT 'debit',
    `gateway_response` TEXT,
    `session` VARCHAR(255) DEFAULT NULL,
    `description` TEXT,
    `date` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `reference_idx` (`reference`),
    KEY `user_id_idx` (`user_id`)
) {$charset};");

// === Fetch platform settings ===
$settings = [];
$rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
foreach ($rows as $r) {
    $settings[$r->opt_key] = maybe_unserialize($r->opt_value);
}
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex     = $settings['color_hex'] ?? '#356cf9';

// === Handle API key update ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_security_nonce']) && wp_verify_nonce($_POST['pulsepoint_security_nonce'], 'save_pulsepoint_security')) {
    $api_token = sanitize_text_field($_POST['api_token'] ?? '');
    $encryption_key = sanitize_text_field($_POST['encryption_key'] ?? '');
    
    $wpdb->update($table_settings, ['opt_value' => maybe_serialize($api_token)], ['opt_key' => 'api_token']);
    $wpdb->update($table_settings, ['opt_value' => maybe_serialize($encryption_key)], ['opt_key' => 'encryption_key']);

    echo '<div class="updated notice"><p><strong>Security keys updated successfully.</strong></p></div>';
}

// === Fetch suspended users ===
$suspended_users = $wpdb->get_results("SELECT * FROM {$table_users} WHERE close_account = 1 OR status = 0 ORDER BY created_at DESC");

// === Fetch last transactions for users ===
$user_trnx = [];
foreach ($suspended_users as $user) {
    $user_trnx[$user->id] = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_trnx} WHERE user_id = %d ORDER BY date DESC LIMIT 5",
        $user->id
    ));
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Security & API Keys</h1>
  <p>Manage API tokens, encryption keys, and monitor suspended users.</p>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= $color_hex ?>; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    table th, table td { padding: 10px; border: 1px solid #ddd; text-align: left; }
    table th { background: var(--primary); color: #fff; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_security', 'pulsepoint_security_nonce'); ?>

    <div class="pulse-section">
      <h2 class="text-lg font-semibold mb-4"><i class="bi bi-shield-lock"></i> API & Encryption Keys</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">API Token</label>
          <input type="text" name="api_token" value="<?= esc_attr($settings['api_token'] ?? '') ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">Encryption Key</label>
          <input type="text" name="encryption_key" value="<?= esc_attr($settings['encryption_key'] ?? '') ?>" class="pulse-input">
        </div>
      </div>
      <div class="text-right mt-4">
        <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> Save Keys</button>
      </div>
    </div>
  </form>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-person-x"></i> Suspended Users</h2>
    <?php if ($suspended_users): ?>
      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Email</th>
            <th>Account Type</th>
            <th>Status</th>
            <th>Last Transactions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($suspended_users as $user): ?>
            <tr>
              <td><?= esc_html($user->firstname . ' ' . $user->lastname) ?></td>
              <td><?= esc_html($user->email) ?></td>
              <td><?= esc_html($user->account_type) ?></td>
              <td><?= $user->status ? 'Suspended' : 'Inactive' ?></td>
              <td>
                <?php if (!empty($user_trnx[$user->id])): ?>
                  <ul>
                    <?php foreach ($user_trnx[$user->id] as $t): ?>
                      <li><?= esc_html($t->category . ': ' . $t->amount . ' (' . $t->status . ')') ?></li>
                    <?php endforeach; ?>
                  </ul>
                <?php else: ?>
                  <em>No recent transactions</em>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No suspended users found.</p>
    <?php endif; ?>
  </div>
</div>