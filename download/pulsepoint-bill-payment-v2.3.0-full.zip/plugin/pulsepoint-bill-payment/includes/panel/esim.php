<?php
if(!defined('ABSPATH'))exit;
global $wpdb; $prefix=$wpdb->prefix.'pulsepoint_'; $table=$prefix.'settings'; $notice='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pulsepoint_esim_nonce']) && wp_verify_nonce($_POST['pulsepoint_esim_nonce'],'save_pulsepoint_esim')){
 $data=['esim_api_key'=>sanitize_text_field($_POST['esim_api_key']??''),'esim_markup'=>(float)($_POST['esim_markup']??10),'esim_usd_rate'=>(float)($_POST['esim_usd_rate']??0)];
 foreach($data as $k=>$v){$id=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE opt_key=%s",$k));if($id)$wpdb->update($table,['opt_value'=>maybe_serialize($v)],['id'=>$id]);else$wpdb->insert($table,['opt_key'=>$k,'opt_value'=>maybe_serialize($v),'type'=>is_numeric($v)?'number':'string','grouping'=>'esim']);}
 $notice='eSIM settings saved.';
}
$rows=$wpdb->get_results("SELECT opt_key,opt_value FROM {$table} WHERE opt_key IN ('esim_api_key','esim_markup','esim_usd_rate','rate_usd')",OBJECT_K);
$key=maybe_unserialize($rows['esim_api_key']->opt_value??'');$markup=maybe_unserialize($rows['esim_markup']->opt_value??10);$rate=maybe_unserialize($rows['esim_usd_rate']->opt_value??'');$default_rate=maybe_unserialize($rows['rate_usd']->opt_value??'');
?>
<div class="wrap"><h1 class="wp-heading-inline">Pulsepoint — eSIM</h1><hr class="wp-header-end">
<?php if($notice):?><div class="updated notice"><p><strong><?=esc_html($notice)?></strong></p></div><?php endif;?>
<div style="background:#fff;border-radius:14px;padding:24px;margin-top:24px;max-width:900px;box-shadow:0 3px 10px rgba(0,0,0,.05)">
<h2>SMSPool eSIM Provider</h2><p style="color:#666">Configure the provider key and the Naira conversion/markup used for customer wallet pricing.</p>
<form method="post"><?php wp_nonce_field('save_pulsepoint_esim','pulsepoint_esim_nonce');?>
<p><label><strong>API Key</strong></label><input type="password" name="esim_api_key" value="<?=esc_attr($key)?>" class="regular-text" style="width:100%;max-width:650px"></p>
<p><label><strong>Markup (%)</strong></label><input type="number" step="0.01" name="esim_markup" value="<?=esc_attr($markup)?>" class="small-text"></p>
<p><label><strong>USD → NGN Rate</strong></label><input type="number" step="0.01" name="esim_usd_rate" value="<?=esc_attr($rate)?>" class="regular-text" placeholder="Uses platform rate if blank"></p>
<p class="description">Current platform rate: <?=esc_html($default_rate?:'Not set')?>. Provider plan prices are treated as USD for the Naira wallet conversion.</p>
<p><button class="button button-primary">Save eSIM Settings</button></p></form>
</div></div>
