<?php
/**
 * Pulsepoint Betting Billers Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/betting.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_bet = "{$base_prefix}betting";

// === Delete Logic ===
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $wpdb->delete($table_bet, ['id' => $id]);
    echo '<div class="updated notice"><p><strong>Betting platform deleted successfully.</strong></p></div>';
}

// === Fetch All Billers ===
$billers = $wpdb->get_results("SELECT * FROM {$table_bet} ORDER BY id DESC");
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Pulsepoint — Betting Platforms</h1>
  <a href="?page=pulsepoint-add-betting" class="page-title-action"><i class="bi bi-plus-circle"></i> Add New Platform</a>
  <a href="?page=pulsepoint-set-betting" class="page-title-action"><i class="bi bi-gear"></i> Provider Settings</a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 10px 8px; font-size: 14px; }
    th { text-align: left; background: #f9fafb; font-weight: 600; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; }
    .pulse-btn-danger { background: #ef4444; color: #fff; padding: 6px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; }
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-controller"></i> Betting Platforms</h2>

    <?php if (!$billers): ?>
      <p>No betting platforms found. <a href="?page=pulsepoint-add-betting" class="text-blue-600">Add your first platform</a>.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Service ID</th>
              <th>Platform</th>
              <th>Cashback (₦)</th>
              <th>Fee (₦)</th>
              <th>API Fee (₦)</th>
              <th>Provider</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($billers as $b): ?>
              <tr>
                <td><?= esc_html($b->id) ?></td>
                <td><strong><?= esc_html($b->serviceid) ?></strong></td>
                <td><?= esc_html($b->biller ?: '—') ?></td>
                <td><?= number_format($b->cashback, 2) ?></td>
                <td><?= number_format($b->fee, 2) ?></td>
                <td><?= number_format($b->fee_api, 2) ?></td>
                <td><?= esc_html($b->provider ?: '—') ?></td>
                <td>
                  <a href="?page=pulsepoint-add-betting&edit=<?= $b->id ?>" class="pulse-btn"><i class="bi bi-pencil-square"></i> Edit</a>
                  <a href="?page=pulsepoint-betting&delete=<?= $b->id ?>" onclick="return confirm('Delete this platform?')" class="pulse-btn-danger"><i class="bi bi-trash"></i> Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
