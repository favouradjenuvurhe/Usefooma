<?php
/**
 * Pulsepoint License Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/license.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_settings = "{$base_prefix}settings";

// === Ensure settings table exists ===
$wpdb->query("
CREATE TABLE IF NOT EXISTS `{$table_settings}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `opt_key` VARCHAR(255) NOT NULL,
    `opt_value` TEXT,
    `type` VARCHAR(50) DEFAULT 'string',
    `grouping` VARCHAR(100) DEFAULT NULL,
    `autoload` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `opt_key_unique` (`opt_key`)
) {$charset};
");

// === Default License ===
$defaults = [
    'license' => ''
];

// === Sync license default with DB ===
foreach ($defaults as $key => $value) {
    $exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s", $key));
    if (!$exists) {
        $wpdb->insert($table_settings, [
            'opt_key'   => $key,
            'opt_value' => maybe_serialize($value),
            'type'      => 'string',
            'autoload'  => 1
        ]);
    }
}

// === Handle Save ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_license_nonce']) 
    && wp_verify_nonce($_POST['pulsepoint_license_nonce'], 'save_pulsepoint_license')) {
    
    if (isset($_POST['license'])) {
        $wpdb->update(
            $table_settings,
            ['opt_value' => maybe_serialize(sanitize_text_field($_POST['license']))],
            ['opt_key' => 'license']
        );
        echo '<div class="updated notice"><p><strong>License saved successfully.</strong></p></div>';
    }
}

// === Fetch current license ===
$license = maybe_unserialize($wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$table_settings} WHERE opt_key = %s", 'license')));
?>

<div class="wrap">
    <h1 class="wp-heading-inline">Pulsepoint — License</h1>
    <p>Enter your plugin license key below.</p>
    <hr class="wp-header-end">

    <form method="POST">
        <?php wp_nonce_field('save_pulsepoint_license', 'pulsepoint_license_nonce'); ?>
        <div style="background:#fff;padding:20px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.05);max-width:400px;">
            <label style="display:block;margin-bottom:6px;font-weight:600;">License Key</label>
            <input type="text" name="license" value="<?= esc_attr($license) ?>" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:6px;">
            <div style="text-align:right;margin-top:12px;">
                <button type="submit" style="background:#356cf9;color:#fff;padding:10px 20px;border:none;border-radius:8px;font-weight:600;cursor:pointer;">
                    Save License
                </button>
            </div>
        </div>
    </form>
</div>