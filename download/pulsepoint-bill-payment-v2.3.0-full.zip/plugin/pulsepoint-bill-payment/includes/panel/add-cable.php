<?php
/**
 * Pulsepoint Add/Edit Cable Plan Page
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/add-cable.php
 * Author: Amaaavl
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_cable = "{$base_prefix}cable";

// === Fetch existing plan for edit ===
$edit_plan = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $plan_id = intval($_GET['edit']);
    $edit_plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_cable} WHERE id = %d", $plan_id));
}

// === Handle Form Submission ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pulsepoint_cable_nonce']) && wp_verify_nonce($_POST['pulsepoint_cable_nonce'], 'save_pulsepoint_cable')) {
    
    $data = [
        'plan'      => sanitize_text_field($_POST['plan']),
        'details'   => sanitize_textarea_field($_POST['details']),
        'type'      => sanitize_text_field($_POST['type']),
        'amount'    => floatval($_POST['amount']),
        'cashback'  => floatval($_POST['cashback']),
        'apiamount' => floatval($_POST['apiamount']),
        'provider'  => sanitize_text_field($_POST['provider']),
    ];

    if ($edit_plan) {
        $wpdb->update($table_cable, $data, ['id' => $edit_plan->id]);
        echo '<div class="updated notice"><p><strong>Cable plan updated successfully.</strong></p></div>';
    } else {
        $wpdb->insert($table_cable, $data);
        echo '<div class="updated notice"><p><strong>New cable plan added successfully.</strong></p></div>';
    }

    // Refresh edit_plan after save
    if (!$edit_plan) {
        $edit_plan = (object) $data;
    }
}
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= $edit_plan ? 'Edit Cable Plan' : 'Add New Cable Plan' ?></h1>
  <a href="?page=pulsepoint-cable" class="page-title-action"><i class="bi bi-arrow-left"></i> Back to Cable Plans</a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: #356cf9; }
    .pulse-section { background: #fff; border-radius: 14px; padding: 24px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); margin-top: 24px; }
    .pulse-input { width: 100%; border: 1px solid #ddd; padding: 10px 14px; border-radius: 8px; font-size: 14px; }
    .pulse-label { font-weight: 600; font-size: 14px; margin-bottom: 6px; display: block; }
    .pulse-btn { background: var(--primary); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; }
    .pulse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
  </style>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_cable', 'pulsepoint_cable_nonce'); ?>

    <div class="pulse-section">
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Plan ID</label>
          <input type="text" name="plan" value="<?= esc_attr($edit_plan->plan ?? '') ?>" class="pulse-input" required>
        </div>
        <div>
          <label class="pulse-label">Details / Description</label>
          <textarea name="details" class="pulse-input"><?= esc_textarea($edit_plan->details ?? '') ?></textarea>
        </div>
        <div>
          <label class="pulse-label">Type</label>
          <select name="type" class="pulse-input">
            <?php 
              $types = ['DSTV', 'GOTV', 'STARTIMES'];
              foreach ($types as $type): 
            ?>
              <option value="<?= esc_attr($type) ?>" <?= selected($edit_plan->type ?? '', $type, false) ?>><?= esc_html($type) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="pulse-label">Amount (₦)</label>
          <input type="number" step="0.01" name="amount" value="<?= esc_attr($edit_plan->amount ?? '') ?>" class="pulse-input" required>
        </div>
        <div>
          <label class="pulse-label">Cashback (₦)</label>
          <input type="number" step="0.01" name="cashback" value="<?= esc_attr($edit_plan->cashback ?? '') ?>" class="pulse-input">
        </div>
        <div>
          <label class="pulse-label">API Amount (₦)</label>
          <input type="number" step="0.01" name="apiamount" value="<?= esc_attr($edit_plan->apiamount ?? '') ?>" class="pulse-input">
        </div>
        <div>
    <label class="pulse-label">Provider</label>
    <select name="provider" class="pulse-input">
        <?php
        $cable_dir = WP_PLUGIN_DIR . '/pulsepoint-bill-payment/core/cable/';
        $files = glob($cable_dir . '*.php'); // get all PHP files

        foreach ($files as $file) {
            $filename = basename($file, '.php'); // filename without .php
            if ($filename === 'pulsepoint') continue; // skip pulsepoint.php

            $selected = ($edit_plan->provider ?? '') === $filename ? 'selected' : '';
            echo "<option value='{$filename}' {$selected}>{$filename}</option>";
        }
        ?>
    </select>
</div>
      </div>
    </div>

    <div class="pulse-section text-right">
      <button type="submit" class="pulse-btn"><i class="bi bi-save"></i> <?= $edit_plan ? 'Update Plan' : 'Add Plan' ?></button>
    </div>
  </form>
</div>