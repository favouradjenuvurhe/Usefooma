<?php
/**
 * Pulsepoint Shared Cashback Helper
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/cashback-helper.php
 * Author: Amaaavl
 *
 * Data, cable, education, and betting plans all have a per-plan `cashback`
 * column that admins can configure, but nothing ever actually credited it
 * to the user after a successful purchase — this closes that gap with one
 * shared function every purchase handler calls the same way.
 *
 * Cashback is credited straight to the wallet (not referral_balance) since
 * it's a reward on the user's own spend, not a referral bonus.
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_credit_cashback')) {
    function pulsepoint_credit_cashback(int $user_id, float $cashback_amount, string $category, string $reference, string $description = 'Cashback'): void {

        if ($cashback_amount <= 0) {
            return;
        }

        global $wpdb;

        $base_prefix = $wpdb->prefix . 'pulsepoint_';
        $table_users = "{$base_prefix}users";
        $table_trnx  = "{$base_prefix}trnx";

        $wpdb->query($wpdb->prepare(
            "UPDATE {$table_users} SET wallet = wallet + %f WHERE id = %d",
            $cashback_amount,
            $user_id
        ));

        $wpdb->insert($table_trnx, [
            'user_id'     => $user_id,
            'amount'      => $cashback_amount,
            'reference'   => $reference . '-CB',
            'payment'     => 'wallet',
            'category'    => $category,
            'status'      => 'success',
            'type'        => 'credit',
            'description' => $description,
        ]);
    }
}
