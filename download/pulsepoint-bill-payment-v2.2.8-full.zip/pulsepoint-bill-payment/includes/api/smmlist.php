<?php
/**
 * Pulsepoint SMM (Boost) List API Endpoint
 * Path: /api/smmlist.php
 * Author: Amaaavl
 *
 * POST (token) -> distinct categories
 * POST (token, category) -> services within that category, with unit_price
 * already marked up, ready to multiply by quantity on the frontend.
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$headers = getallheaders();
if (empty($headers['Authorization'])) {
    echo json_encode(['success' => false, 'message' => 'Missing Authorization header']);
    exit;
}

if (!preg_match('/Token\s+(\S+)/', $headers['Authorization'], $matches)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Authorization format']);
    exit;
}

$token = sanitize_text_field($matches[1]);

$table_users = $wpdb->prefix . 'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT id, status FROM {$table_users} WHERE token = %s", $token));

if (!$user || (int) $user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid or inactive token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;

$category = sanitize_text_field($input['category'] ?? '');
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_smm = "{$base_prefix}smm_services";

// No category given → return the distinct category list
if (empty($category)) {

    $categories = $wpdb->get_col("SELECT DISTINCT category FROM {$table_smm} WHERE status='active' ORDER BY category ASC");

    echo json_encode([
        'success'    => true,
        'categories' => $categories ?: [],
    ]);
    exit;
}

// Category given → return its services, with markup already applied
$rows = $wpdb->get_results($wpdb->prepare(
    "SELECT id, category, name, rate, min, max, refill, cancel FROM {$table_smm} WHERE status='active' AND category = %s ORDER BY name ASC",
    $category
));

if (!$rows) {
    echo json_encode(['success' => false, 'message' => 'No services found in this category']);
    exit;
}

$markup_raw = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$base_prefix}settings WHERE opt_key = %s", 'smm_markup'));
$markup = $markup_raw ? (float) maybe_unserialize($markup_raw) : 0;

$services = [];

foreach ($rows as $r) {
    $base_cost = (float) $r->rate / 1000;
    $unit_price = $base_cost + ($base_cost * ($markup / 100));

    $services[] = [
        'id'         => (int) $r->id,
        'category'   => $r->category,
        'name'       => $r->name,
        'unit_price' => round($unit_price, 4),
        'min'        => (int) $r->min,
        'max'        => (int) $r->max,
        'refill'     => (bool) $r->refill,
        'cancel'     => (bool) $r->cancel,
    ];
}

echo json_encode([
    'success' => true,
    'data'    => $services,
]);
exit;
