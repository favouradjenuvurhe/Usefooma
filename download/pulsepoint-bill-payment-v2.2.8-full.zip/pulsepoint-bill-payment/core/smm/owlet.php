<?php
/**
 * Owlet-style Generic SMM Panel Provider
 * File: core/smm/owlet.php
 * Author: Amaaavl
 *
 * This is the industry-standard "SMM panel API" shape used by Owlet and
 * most other SMM resellers (action=services / action=add / action=status,
 * single POST endpoint, plain "key" auth) — so this file works for any
 * provider using that same shape, not just Owlet specifically.
 *
 * Settings used: smm_api (POST endpoint, e.g. https://theowlet.com/api/v2)
 *                smm_token (API key)
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_smm_owlet_request')) {
    function pulsepoint_smm_owlet_request(string $api_url, array $payload): ?array {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            curl_close($ch);
            return null;
        }

        curl_close($ch);

        $decoded = json_decode($response, true);
        return is_array($decoded) ? $decoded : null;
    }
}

/**
 * Fetch the full service catalog — used by the admin "Sync Services"
 * action, not at purchase time.
 */
if (!function_exists('pulsepoint_smm_owlet_fetch_services')) {
    function pulsepoint_smm_owlet_fetch_services(string $api_url, string $key): array {

        $result = pulsepoint_smm_owlet_request($api_url, [
            'key'    => $key,
            'action' => 'services',
        ]);

        if (!is_array($result)) {
            return [];
        }

        $services = [];

        foreach ($result as $row) {
            if (empty($row['service'])) continue;

            $services[] = [
                'external_id' => (string) $row['service'],
                'category'    => $row['category'] ?? 'General',
                'name'        => $row['name'] ?? ('Service ' . $row['service']),
                'rate'        => (float) ($row['rate'] ?? 0),
                'min'         => (int) ($row['min'] ?? 1),
                'max'         => (int) ($row['max'] ?? 0),
                'refill'      => !empty($row['refill']),
                'cancel'      => !empty($row['cancel']),
            ];
        }

        return $services;
    }
}

/**
 * Place an order. Called by core/smm/pulsepoint.php.
 */
function send_smm(string $provider, string $external_service_id, string $link, int $quantity, string $reference, int $order_row_id) {

    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings WHERE opt_key IN ('smm_api','smm_token')", OBJECT_K);

    $api_url = $settings_rows['smm_api']->opt_value ?? 'https://theowlet.com/api/v2';
    $key     = $settings_rows['smm_token']->opt_value ?? '';

    if (!$key) {
        return ['success' => false, 'message' => 'SMM API key not configured'];
    }

    $result = pulsepoint_smm_owlet_request($api_url, [
        'key'      => $key,
        'action'   => 'add',
        'service'  => $external_service_id,
        'link'     => $link,
        'quantity' => $quantity,
    ]);

    if (!is_array($result)) {
        return ['success' => false, 'message' => 'No response from SMM provider'];
    }

    if (!empty($result['error'])) {
        return ['success' => false, 'message' => $result['error']];
    }

    if (empty($result['order'])) {
        return ['success' => false, 'message' => 'Unexpected response from SMM provider'];
    }

    return [
        'success'           => true,
        'message'           => 'Order placed successfully',
        'provider_order_id' => (string) $result['order'],
    ];
}

/**
 * Check order status. Called by cron/jobs/smm-status.php.
 */
if (!function_exists('pulsepoint_smm_owlet_check_status')) {
    function pulsepoint_smm_owlet_check_status(string $provider_order_id): ?array {

        global $wpdb;
        $base_prefix = $wpdb->prefix . 'pulsepoint_';

        $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings WHERE opt_key IN ('smm_api','smm_token')", OBJECT_K);

        $api_url = $settings_rows['smm_api']->opt_value ?? 'https://theowlet.com/api/v2';
        $key     = $settings_rows['smm_token']->opt_value ?? '';

        if (!$key) return null;

        $result = pulsepoint_smm_owlet_request($api_url, [
            'key'    => $key,
            'action' => 'status',
            'order'  => $provider_order_id,
        ]);

        if (!is_array($result) || empty($result['status'])) {
            return null;
        }

        return [
            'order_status' => $result['status'],
            'remains'      => isset($result['remains']) ? (int) $result['remains'] : null,
        ];
    }
}
