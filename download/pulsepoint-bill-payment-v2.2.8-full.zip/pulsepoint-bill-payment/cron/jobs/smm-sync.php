<?php
/**
 * Pulsepoint SMM Service Catalog Sync Cron
 * Path: cron/jobs/smm-sync.php
 * Author: Amaaavl
 *
 * Periodically re-syncs the SMM service catalog from the configured
 * provider (owlet or ncwallet) into `pulsepoint_smm_services`, so rates
 * and available services stay current without an admin manually curating
 * every single service — there can be hundreds. Same "keep it maintained
 * like data/airtime" idea, just synced instead of hand-entered.
 *
 * New services are inserted active by default; services no longer
 * present in the provider's feed are marked inactive (not deleted) so
 * order history keeps working.
 */

if (!defined('ABSPATH')) exit;

add_action('pulsepoint_cron_smm_sync', function () {

    global $wpdb;

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table_settings = "{$base_prefix}settings";
    $table_smm = "{$base_prefix}smm_services";

    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings} WHERE opt_key IN ('smm_api_provider')");
    $provider = 'owlet';
    foreach ($settings_rows as $row) {
        if ($row->opt_key === 'smm_api_provider') {
            $provider = strtolower(trim(maybe_unserialize($row->opt_value)) ?: 'owlet');
        }
    }

    $safe_provider = preg_replace('/[^a-z0-9]/i', '', $provider);
    $provider_file = dirname(__DIR__, 2) . "/core/smm/{$safe_provider}.php";

    if (!file_exists($provider_file)) {
        return;
    }

    require_once $provider_file;

    $services = [];

    if ($provider === 'owlet' && function_exists('pulsepoint_smm_owlet_fetch_services')) {

        $api_url = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$table_settings} WHERE opt_key=%s", 'smm_api'));
        $token   = $wpdb->get_var($wpdb->prepare("SELECT opt_value FROM {$table_settings} WHERE opt_key=%s", 'smm_token'));

        $services = pulsepoint_smm_owlet_fetch_services(
            $api_url ? maybe_unserialize($api_url) : 'https://theowlet.com/api/v2',
            $token ? maybe_unserialize($token) : ''
        );

    } elseif ($provider === 'ncwallet' && function_exists('pulsepoint_smm_ncwallet_fetch_services')) {

        $services = pulsepoint_smm_ncwallet_fetch_services();
    }

    if (empty($services)) {
        return;
    }

    $seen_ids = [];

    foreach ($services as $svc) {

        $seen_ids[] = $svc['external_id'];

        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_smm} WHERE provider = %s AND external_id = %s",
            $provider,
            $svc['external_id']
        ));

        $row = [
            'category' => $svc['category'],
            'name'     => $svc['name'],
            'rate'     => $svc['rate'],
            'min'      => $svc['min'],
            'max'      => $svc['max'],
            'refill'   => $svc['refill'] ? 1 : 0,
            'cancel'   => $svc['cancel'] ? 1 : 0,
        ];

        if ($exists) {
            $wpdb->update($table_smm, $row, ['id' => $exists]);
        } else {
            $row['external_id'] = $svc['external_id'];
            $row['provider']    = $provider;
            $row['status']      = 'active';
            $wpdb->insert($table_smm, $row);
        }
    }

    // Mark services no longer in the provider's feed as inactive
    // (never hard-delete — keeps historical order references intact).
    if ($seen_ids) {
        $placeholders = implode(',', array_fill(0, count($seen_ids), '%s'));
        $params = array_merge([$provider], $seen_ids);

        $wpdb->query($wpdb->prepare(
            "UPDATE {$table_smm} SET status = 'inactive' WHERE provider = %s AND external_id NOT IN ({$placeholders})",
            $params
        ));
    }

    $wpdb->query($wpdb->prepare(
        "INSERT INTO {$table_settings} (opt_key, opt_value) VALUES (%s, %s)
         ON DUPLICATE KEY UPDATE opt_value = VALUES(opt_value)",
        'smm_last_synced',
        maybe_serialize(current_time('mysql'))
    ));
});
