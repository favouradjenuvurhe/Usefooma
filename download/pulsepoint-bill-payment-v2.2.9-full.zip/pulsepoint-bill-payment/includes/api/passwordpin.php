<?php
/**
 * Pulsepoint API Change Password / Change PIN
 * Path: /api/passwordpin.php
 * Author: Amaaavl
 *
 * Two actions via `type`: "password" or "pin".
 *
 * Change password requires: token, passcode, new_password, confirm_password
 * Change pin requires:      token, password, pin, confirm_pin
 *
 * COOLDOWN NOTE: the `users` table has one shared `updated_at` column for
 * the whole row (ON UPDATE CURRENT_TIMESTAMP), not separate
 * password_updated_at / pin_updated_at columns. So this endpoint uses
 * `updated_at` as a proxy "last changed" timestamp for BOTH actions — e.g.
 * changing the PIN also resets the cooldown clock for the password, and
 * vice versa, since any UPDATE touches the same column. If you want the
 * two cooldowns tracked independently, add dedicated columns:
 *
 *   ALTER TABLE `{$base_prefix}users`
 *   ADD COLUMN `password_updated_at` DATETIME DEFAULT NULL,
 *   ADD COLUMN `pin_updated_at` DATETIME DEFAULT NULL;
 *
 * PASSCODE NOTE: `passcode` is VARCHAR(4), too short to hold a password_hash()
 * output, so it's compared in plain text below. That means a PIN is stored
 * in the clear in the DB — fine for a low-stakes PIN, but if you want it
 * hashed you'll need to widen the column (VARCHAR(255)) and switch the
 * comparison to password_verify().
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// How long a user must wait between changes (shared cooldown, see note above)
define('CHANGE_COOLDOWN_HOURS', 24);

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data POST
if (!$input) {
    $input = $_POST;
}

$token = sanitize_text_field($input['token'] ?? '');
$type  = sanitize_text_field($input['type'] ?? '');

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

if (!in_array($type, ['password', 'pin'], true)) {
    echo json_encode(['success' => false, 'message' => 'Invalid change type']);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table       = $base_prefix . 'users';

// Fetch user by token
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, password, passcode, status, created_at, updated_at
        FROM `{$table}` WHERE token = %s LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Check if account is active
if ((int)$user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Account inactive']);
    exit;
}

// Enforce the cooldown against the shared updated_at timestamp
$last_changed = $user->updated_at ?: $user->created_at;
$seconds_since_change = time() - strtotime($last_changed);
$cooldown_seconds = CHANGE_COOLDOWN_HOURS * 3600;

if ($seconds_since_change < $cooldown_seconds) {
    $seconds_remaining = $cooldown_seconds - $seconds_since_change;
    $hours_remaining = ceil($seconds_remaining / 3600);
    echo json_encode([
        'success' => false,
        'message' => "You can only change your password or PIN once every " . CHANGE_COOLDOWN_HOURS . " hours. Try again in {$hours_remaining} hour(s)."
    ]);
    exit;
}

if ($type === 'password') {
    $passcode         = sanitize_text_field($input['passcode'] ?? '');
    $new_password     = (string)($input['new_password'] ?? '');
    $confirm_password = (string)($input['confirm_password'] ?? '');

    if (empty($passcode) || empty($new_password) || empty($confirm_password)) {
        echo json_encode(['success' => false, 'message' => 'Passcode, new password and confirm password are required']);
        exit;
    }

    // Verify current passcode (plain comparison, see PASSCODE NOTE above)
    if (empty($user->passcode) || !hash_equals((string)$user->passcode, $passcode)) {
        echo json_encode(['success' => false, 'message' => 'Incorrect passcode']);
        exit;
    }

    if ($new_password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'New password and confirm password do not match']);
        exit;
    }

    if (strlen($new_password) < 8) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters']);
        exit;
    }

    // Don't allow reusing the same password
    if (password_verify($new_password, $user->password)) {
        echo json_encode(['success' => false, 'message' => 'New password must be different from your current password']);
        exit;
    }

    $hashed = password_hash($new_password, PASSWORD_DEFAULT);

    $updated = $wpdb->update(
        $table,
        ['password' => $hashed],
        ['id' => $user->id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        echo json_encode(['success' => false, 'message' => 'Failed to update password']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
    exit;
}

if ($type === 'pin') {
    $password     = (string)($input['password'] ?? '');
    $pin          = sanitize_text_field($input['pin'] ?? '');
    $confirm_pin  = sanitize_text_field($input['confirm_pin'] ?? '');

    if (empty($password) || empty($pin) || empty($confirm_pin)) {
        echo json_encode(['success' => false, 'message' => 'Password, pin and confirm pin are required']);
        exit;
    }

    // Verify current password
    if (!password_verify($password, $user->password)) {
        echo json_encode(['success' => false, 'message' => 'Incorrect password']);
        exit;
    }

    if ($pin !== $confirm_pin) {
        echo json_encode(['success' => false, 'message' => 'Pin and confirm pin do not match']);
        exit;
    }

    if (!preg_match('/^\d{4}$/', $pin)) {
        echo json_encode(['success' => false, 'message' => 'Pin must be exactly 4 digits']);
        exit;
    }

    // Don't allow reusing the same pin
    if (!empty($user->passcode) && hash_equals((string)$user->passcode, $pin)) {
        echo json_encode(['success' => false, 'message' => 'New pin must be different from your current pin']);
        exit;
    }

    $updated = $wpdb->update(
        $table,
        ['passcode' => $pin],
        ['id' => $user->id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        echo json_encode(['success' => false, 'message' => 'Failed to update pin']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'Pin changed successfully']);
    exit;
}
