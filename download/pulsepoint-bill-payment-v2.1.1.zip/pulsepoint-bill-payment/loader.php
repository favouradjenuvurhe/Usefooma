<?php
// loader.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define constants
define('PULSEPOINT_DIR', plugin_dir_path(__FILE__));
define('PULSEPOINT_URL', plugin_dir_url(__FILE__));

// Include all core files
require_once PULSEPOINT_DIR . 'includes/email-helper.php';
require_once PULSEPOINT_DIR . 'includes/cashback-helper.php';
require_once PULSEPOINT_DIR . 'includes/public.php';
require_once PULSEPOINT_DIR . 'includes/callback.php';
require_once PULSEPOINT_DIR . 'includes/woo-gateway.php';
require_once PULSEPOINT_DIR . 'includes/admin.php';
require_once PULSEPOINT_DIR . 'includes/api.php';
require_once PULSEPOINT_DIR . 'includes/theme-loader.php';
require_once PULSEPOINT_DIR . 'base/plugin.php';
require_once PULSEPOINT_DIR . 'base/core.php';
require_once PULSEPOINT_DIR . 'base/license.php';
require_once PULSEPOINT_DIR . 'base/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/index.php'; 
require_once PULSEPOINT_DIR . 'core/info.php'; 
require_once PULSEPOINT_DIR . 'core/login.php'; 
require_once PULSEPOINT_DIR . 'core/register.php';
require_once PULSEPOINT_DIR . 'core/change-password.php';
require_once PULSEPOINT_DIR . 'core/verify.php'; 
require_once PULSEPOINT_DIR . 'core/forgot-password.php';
require_once PULSEPOINT_DIR . 'core/reset-password.php'; 
require_once PULSEPOINT_DIR . 'core/logout.php';
require_once PULSEPOINT_DIR . 'core/ajax-handlers.php';
require_once PULSEPOINT_DIR . 'core/ajax-cable.php';
require_once PULSEPOINT_DIR . 'core/ajax-bill.php';
require_once PULSEPOINT_DIR . 'core/ajax-edu.php';
require_once PULSEPOINT_DIR . 'core/ajax-betting.php';
require_once PULSEPOINT_DIR . 'core/airtime/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/airtime/a2c/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/airtime/a2c/rates.php';
require_once PULSEPOINT_DIR . 'core/airtime/scheduling.php';
require_once PULSEPOINT_DIR . 'core/recharge/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/data/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/data/scheduling.php';
require_once PULSEPOINT_DIR . 'core/cable/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/electricity/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/education/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/betting/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/pocket/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/pocket/deposit.php';
require_once PULSEPOINT_DIR . 'core/pocket/savings.php';
require_once PULSEPOINT_DIR . 'core/transfer/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/transfer/wallet2.php';
require_once PULSEPOINT_DIR . 'core/transfer/verification.php';
require_once PULSEPOINT_DIR . 'core/customer/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/customer/status.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/details.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/fund.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/withdrawal.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/transaction.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/freeze.php';
require_once PULSEPOINT_DIR . 'core/virtualcard/convert.php';
require_once PULSEPOINT_DIR . 'core/crypto/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/giftcard/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/virtual-account/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/virtual-account/dynamic.php';
require_once PULSEPOINT_DIR . 'core/woo-commerce/pulsepoint.php';