<?php          
/**          
 * Pulsepoint Cable Purchase Function (Upgraded with Airtime Security)          
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/cable/pulsepoint.php          
 * Author: Amaaavl          
*/          
          
if (!defined('ABSPATH')) exit;          
          
// AJAX Hooks          
add_action('wp_ajax_nopriv_pulsepoint_cable_purchase', 'pulsepoint_cable_purchase');          
add_action('wp_ajax_pulsepoint_cable_purchase', 'pulsepoint_cable_purchase');          
          
function pulsepoint_cable_purchase() {          
    global $wpdb;          
          
    header('Content-Type: application/json; charset=utf-8');          
          
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {          
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);          
    }          
          
    if (!session_id()) session_start();          
          
    if (!isset($_SESSION['pulsepoint_user']['id'])) {          
        wp_send_json(['success' => false, 'message' => 'User not logged in.']);          
    }          
          
    $user_id      = $_SESSION['pulsepoint_user']['id'];          
    $table_users  = $wpdb->prefix . 'pulsepoint_users';          
    $table_trnx   = $wpdb->prefix . 'pulsepoint_trnx';          
    $base_prefix  = $wpdb->prefix . 'pulsepoint_';          
          
    // 15 Seconds Limit          
    $now = time();          
    if (isset($_SESSION['last_cable_request'][$user_id]) && ($now - $_SESSION['last_cable_request'][$user_id]) < 15) {          
        wp_send_json(['success' => false, 'message' => 'Please wait 15 seconds.']);          
    }          
    $_SESSION['last_cable_request'][$user_id] = $now;          
          
    // Fetch user          
    $user = $wpdb->get_row(          
        $wpdb->prepare("SELECT * FROM {$table_users} WHERE id = %d", $user_id)          
    );          
          
    if (!$user || $user->status != 1) {          
        wp_send_json(['success' => false, 'message' => 'User not active or found.']);          
    }          
          
    /** ---------------------------------------------          
     *  LOAD SETTINGS          
     * --------------------------------------------- */          
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");          
    $settings = [];          
    foreach ($settings_rows as $row) {          
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);          
    }          
          
    $maintenance_mode = $settings['maintenance_mode'] ?? '0';          
    $api_mode         = $settings['api_mode'] ?? 'live';          

    // ✅ NEW: KYC SETTING
    $require_kyc = isset($settings['cable_kyc']) && $settings['cable_kyc'] == 1;

    // ✅ NEW: KYC CHECK (LIKE BANK & AIRTIME)
    if ($require_kyc && $user->statuskyc != 1) {
        wp_send_json(['success' => false, 'message' => 'Kindly complete KYC before proceeding.']);
    }
          
    if ($maintenance_mode == '1') {          
        wp_send_json(['success' => false, 'message' => 'Under Maintenance']);          
    }          
          
    /** ---------------------------------------------          
     *  SANITIZE INPUTS          
     * --------------------------------------------- */          
    $plan_id   = intval($_POST['plan'] ?? 0);          
    $details   = sanitize_text_field($_POST['details'] ?? '');          
    $amount    = floatval($_POST['amount'] ?? 0);          
    $smartcard = sanitize_text_field($_POST['smartcard'] ?? '');          
    $reference = sanitize_text_field($_POST['reference'] ?? '');          
          
    if (!$plan_id || empty($smartcard)) {          
        wp_send_json(['success' => false, 'message' => 'Plan & Smartcard required.']);          
    }          
          
    /** ---------------------------------------------          
     *  GET CABLE PLAN          
     * --------------------------------------------- */          
    $cable_plan = $wpdb->get_row(          
        $wpdb->prepare("SELECT * FROM {$base_prefix}cable WHERE id = %d", $plan_id)          
    );          
          
    if (!$cable_plan) {          
        wp_send_json(['success' => false, 'message' => 'Invalid Cable Plan']);          
    }          
          
    $provider   = strtolower(trim($cable_plan->provider));          
    $plan_name  = trim($cable_plan->plan);          
    $cable_type = trim($cable_plan->type);          
          
    /** ---------------------------------------------          
     *  SMARTCARD VERIFICATION          
     * --------------------------------------------- */          
    $cable_map = ['dstv'=>2,'gotv'=>1,'startimes'=>3];          
    $cable_id  = $cable_map[strtolower($cable_type)] ?? 0;          
          
    $verify_url = "https://mansurdata.net/api/cable/cable-validation?iuc={$smartcard}&cable={$cable_id}";          
    $response = wp_remote_get($verify_url);          
    if (is_wp_error($response)) {          
        wp_send_json(['success' => false, 'message' => 'Verification failed']);          
    }          
          
    $data = json_decode(wp_remote_retrieve_body($response), true);          
    if (!isset($data['status']) || $data['status'] !== 'success') {          
        wp_send_json(['success' => false, 'message' => 'Smartcard verification failed']);          
    }          

    $verified_name = $data['name'] ?? '';        
          
    /** ---------------------------------------------          
     *  SHORT REFERENCE          
     * --------------------------------------------- */          
    if (empty($reference)) {          
        $reference = 'PSNG' . mt_rand(10000,99999) . 'C';          
    }          
          
    $description = "Cable - " . strtoupper($cable_type) . " " . strtoupper($plan_name);          
          
    /** ---------------------------------------------          
     *  ✅ UPDATED DAILY LIMIT (ONLY SUCCESS)          
     * --------------------------------------------- */          
    $today_start = date('Y-m-d 00:00:00');          
    $today_end   = date('Y-m-d 23:59:59');          
    $spent_today = $wpdb->get_var($wpdb->prepare(          
        "SELECT SUM(amount) FROM {$table_trnx}           
         WHERE user_id=%d 
         AND date BETWEEN %s AND %s           
         AND type='debit'
         AND category='cable'
         AND status='success'",          
        $user_id, $today_start, $today_end          
    ));          
    $spent_today = $spent_today ?: 0;          
    $limit = $user->account_limit ?: 5000;          
          
    if (($spent_today + $amount) > $limit) {          
        wp_send_json(['success' => false, 'message' => "Daily Max ₦{$limit} reached"]);          
    }          
          
    /** ---------------------------------------------          
     *  WALLET CHECK          
     * --------------------------------------------- */          
    if ($api_mode === 'live' && $user->wallet < $amount) {          
        wp_send_json(['success' => false, 'message' => 'Insufficient balance']);          
    }          
          
    /** ---------------------------------------------          
     *  API MODE CHECK          
     * --------------------------------------------- */          
    if ($api_mode === 'off') {          
        wp_send_json(['success' => false, 'message' => 'Stock not available']);          
    }          
    if ($api_mode === 'sandbox') {          
        wp_send_json(['success' => true, 'message' => 'Cable Success (Sandbox Mode)']);          
    }          
          
    /** ---------------------------------------------          
     *  LOAD PROVIDER FILE          
     * --------------------------------------------- */          
    $safe_provider = preg_replace('/[^a-z0-9]/i','', $provider);          
    $api_file = __DIR__ . "/{$safe_provider}.php";          
          
    if (!file_exists($api_file)) {          
        wp_send_json(['success' => false, 'message' => 'Provider file missing']);          
    }          
    require_once $api_file;          
          
    if (!function_exists('send_cable')) {          
        wp_send_json(['success' => false, 'message' => 'send_cable() missing']);          
    }          
          
    /** ---------------------------------------------          
     *  INSERT PENDING TRANSACTION          
     * --------------------------------------------- */          
    $wpdb->insert($table_trnx, [          
        'user_id'     => $user_id,          
        'details'     => json_encode(['provider'=>$provider,'plan'=>$plan_name,'smartcard'=>$smartcard]),          
        'recipient'   => $smartcard,          
        'amount'      => $amount,          
        'reference'   => $reference,          
        'payment'     => 'wallet',          
        'category'    => 'cable',          
        'status'      => 'pending',          
        'type'        => 'debit',          
        'session'     => session_id(),          
        'description' => $description          
    ]);          
          
    $trnx_id = $wpdb->insert_id;          
          
    /** ---------------------------------------------          
     *  CALL PROVIDER          
     * --------------------------------------------- */          
    try {          
        $api_response = send_cable($provider, $plan_name, $smartcard, $details, $amount, $reference, $trnx_id, $cable_type, $verified_name);          
    } catch (Exception $e) {          
        wp_send_json(['success' => false, 'message' => 'Provider Error']);          
    }          
          
    $status = (!empty($api_response['success'])) ? 'success' : 'failed';          
          
    /** ---------------------------------------------          
     *  UPDATE TRANSACTION          
     * --------------------------------------------- */          
    $wpdb->update($table_trnx, [          
        'status'           => $status,          
        'gateway_response' => json_encode($api_response),          
        'updated_at'       => current_time('mysql')          
    ], ['id' => $trnx_id]);          
          
    /** ---------------------------------------------          
     *  DEDUCT WALLET ONLY IF LIVE + SUCCESS          
     * --------------------------------------------- */          
    $new_wallet = $user->wallet;          
    if ($status === 'success' && $api_mode === 'live') {          
        $new_wallet -= $amount;          
        $wpdb->update($table_users, ['wallet' => $new_wallet], ['id' => $user_id]);          

        if ((float) $cable_plan->cashback > 0) {
            pulsepoint_credit_cashback(
                $user_id,
                (float) $cable_plan->cashback,
                'cable',
                $reference,
                'Cashback — ' . $plan_name
            );
        }
    }          
          
    wp_send_json([          
        'success'    => $status === 'success',          
        'message'    => $api_response['message'] ?? 'Cable Completed',          
        'new_wallet' => $new_wallet,          
        'reference'  => $reference,
        'name'       => $verified_name
    ]);          
}