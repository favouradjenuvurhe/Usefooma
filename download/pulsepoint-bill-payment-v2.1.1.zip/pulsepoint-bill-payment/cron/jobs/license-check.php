<?php
/**
 * Pulsepoint License Check Cron
 * Path: cron/jobs/license-check.php
 * Author: Amaaavl
 *
 * Runs on every cron tick and checks this domain's subscription status
 * against https://usefooma.site/api/license/check. The result is stored
 * as a plain 1/0 flag in the settings table (`license_valid`) instead of
 * calling the license API on every single page load — includes/public.php
 * just reads that stored flag to decide whether to shut the public app
 * down, so a slow/unreachable license server never blocks real requests.
 *
 * A license that has never been checked yet (fresh install, before the
 * first cron run) is treated as valid — this job only ever locks things
 * down once it has an explicit "inactive" answer from the API.
 */

if (!defined('ABSPATH')) exit;

add_action('pulsepoint_cron_license_check', function () {

    global $wpdb;

    $base_prefix    = $wpdb->prefix . 'pulsepoint_';
    $table_settings = "{$base_prefix}settings";

    $host = parse_url(get_site_url(), PHP_URL_HOST);
    $domain = $host ? strtolower(preg_replace('/^www\./', '', $host)) : '';

    $is_valid = true; // default: don't lock anyone out on a check failure

    if ($domain) {

        $response = wp_remote_post('https://usefooma.site/api/license/check', [
            'timeout' => 15,
            'body'    => ['domain' => $domain],
        ]);

        if (!is_wp_error($response)) {

            $code = wp_remote_retrieve_response_code($response);
            $data = json_decode(wp_remote_retrieve_body($response), true);

            if ($code === 200 && !empty($data['status'])) {

                $status     = $data['subscription'] ?? 'inactive';
                $expires_at = $data['expire_date'] ?? null;

                $is_valid = (
                    $status === 'active' &&
                    !empty($expires_at) &&
                    strtotime($expires_at) > time()
                );

            } elseif ($code === 200 && isset($data['status']) && $data['status'] === false) {
                // Explicit "no active license" response — lock it down.
                $is_valid = false;
            }
            // Any other unexpected response (rate limited, 500, etc.) →
            // keep $is_valid at its previous stored state rather than the
            // hardcoded default, so a flaky API call doesn't flip a
            // previously-valid site to locked, or vice versa.
            else {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT opt_value FROM {$table_settings} WHERE opt_key = %s",
                    'license_valid'
                ));
                if ($existing !== null) {
                    $is_valid = (maybe_unserialize($existing) == '1');
                }
            }
        } else {
            // Network-level failure — same reasoning: keep previous state.
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT opt_value FROM {$table_settings} WHERE opt_key = %s",
                'license_valid'
            ));
            if ($existing !== null) {
                $is_valid = (maybe_unserialize($existing) == '1');
            }
        }
    }

    $flag = $is_valid ? '1' : '0';

    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s",
        'license_valid'
    ));

    if ($exists) {
        $wpdb->update($table_settings, ['opt_value' => maybe_serialize($flag)], ['opt_key' => 'license_valid']);
    } else {
        $wpdb->insert($table_settings, ['opt_key' => 'license_valid', 'opt_value' => maybe_serialize($flag)]);
    }

    $now = current_time('mysql');
    $checked_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table_settings} WHERE opt_key = %s",
        'license_last_checked'
    ));

    if ($checked_exists) {
        $wpdb->update($table_settings, ['opt_value' => maybe_serialize($now)], ['opt_key' => 'license_last_checked']);
    } else {
        $wpdb->insert($table_settings, ['opt_key' => 'license_last_checked', 'opt_value' => maybe_serialize($now)]);
    }
});
