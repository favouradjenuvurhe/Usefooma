<?php
/**
 * /controller/labs.php
 * Universal READ-ONLY data loader for Pulsepoint Plugin
 * Loads settings, user, account, wallet, transactions, cards, giftcards,
 * savings, referrals, and services into plain variables/arrays for HTML use.
 *
 * IMPORTANT: This file only SELECTs data. It never inserts/updates/deletes.
 * Include it at the top of any page that needs to display data:
 *   require_once __DIR__ . '/../controller/labs.php';
 */

if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';

/* =========================================================
   TABLE NAMES (all read-only references)
========================================================= */
$table_users               = $base_prefix . 'users';
$table_referrals            = $base_prefix . 'referrals';
$table_trnx                = $base_prefix . 'trnx';
$table_airtime_jobs        = $base_prefix . 'airtime_jobs';
$table_data                = $base_prefix . 'data';
$table_data_jobs           = $base_prefix . 'data_jobs';
$table_cable               = $base_prefix . 'cable';
$table_bill                = $base_prefix . 'bill';
$table_betting             = $base_prefix . 'betting';
$table_education            = $base_prefix . 'education';
$table_account              = $base_prefix . 'account';
$table_wallet               = $base_prefix . 'wallet';
$table_provider             = $base_prefix . 'provider';
$table_savings_pocket       = $base_prefix . 'savings_pocket';
$table_savings_transactions = $base_prefix . 'savings_transactions';
$table_giftcard_settings    = $base_prefix . 'giftcard_settings';
$table_giftcard_listings    = $base_prefix . 'giftcard_listings';
$table_giftcard_transactions= $base_prefix . 'giftcard_transactions';
$table_giftcard_sales       = $base_prefix . 'giftcard_sales';
$table_giftcard_rate_history= $base_prefix . 'giftcard_rate_history';
$table_virtual_cards        = $base_prefix . 'virtual_cards';
$table_virtualcard_trnx     = $base_prefix . 'virtualcard_transactions';
$table_logs                 = $base_prefix . 'logs';
$table_services              = $base_prefix . 'services';
$table_settings              = $base_prefix . 'settings';

/* =========================================================
   SETTINGS  →  $settings['key'] and flattened $tag_* vars
========================================================= */
$settings = [];
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table_settings}");
foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}

// Commonly used ones pre-extracted for convenience in HTML
$platform_name   = $settings['platform_name'] ?? 'Pulsepoint';
$color_hex       = $settings['color_hex'] ?? '#2563eb';
$logo_url        = $settings['logo_url'] ?? '';
$favicon_url     = $settings['favicon_url'] ?? '';
$phone_number    = $settings['phone_number'] ?? '';
$email_number    = $settings['email_number'] ?? '';
$maintenance_mode= (int)($settings['maintenance_mode'] ?? 0);
$rate_usd        = $settings['rate_usd'] ?? '0';
$rate_naira      = $settings['rate_naira'] ?? '0';
$bank_transfer   = $settings['bank_transfer'] ?? 'disabled';
$banner_slides   = [
    $settings['ads1_url'] ?? null,
    $settings['ads2_url'] ?? null,
    $settings['ads3_url'] ?? null,
];

/* =========================================================
   SERVICES (enabled/disabled list for menu tags)
========================================================= */
$services = $wpdb->get_results("SELECT service_key, service_name, status FROM {$table_services}");

/* =========================================================
   CURRENT USER
========================================================= */
$user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;

$user = $user_id ? $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_users} WHERE id = %d",
    $user_id
)) : null;

$firstname        = $user ? esc_html($user->firstname) : 'Guest';
$lastname         = $user ? esc_html($user->lastname ?? '') : '';
$wallet_balance   = $user ? number_format((float)$user->wallet, 2) : '0.00';
$dollar_balance   = $user ? number_format((float)$user->dollar, 2) : '0.00';
$referral_balance = $user ? number_format((float)$user->referral_balance, 2) : '0.00';

$account_type = $user->account_type ?? 'Customer';
$status       = isset($user->status) ? (int)$user->status : 0;
$statuskyc    = isset($user->statuskyc) ? (int)$user->statuskyc : 0;

$status_label = $status === 1 ? 'Active' : 'Disabled';
$status_color = $status === 1 ? 'text-white' : 'text-red-500';

$kyc_label = $statuskyc == 1 ? 'Verified' : 'Unverified';
$kyc_color = $statuskyc == 1 ? 'bg-green-400' : 'bg-yellow-400';

$account_badge = match ($account_type) {
    'Agent' => 'bg-purple-100 text-purple-600',
    'API'   => 'bg-blue-100 text-blue-600',
    default => 'bg-gray-100 text-gray-600',
};

/* =========================================================
   BANK ACCOUNT (virtual account for funding)
========================================================= */
$account = $user_id ? $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_account} WHERE user_id = %d ORDER BY id DESC LIMIT 1",
    $user_id
)) : null;

$account_number = $account->number ?? '----------';
$account_name   = $account->name ?? $firstname;
$bank_name      = $account->bank ?? 'No Bank';

/* =========================================================
   RECENT WALLET TRANSACTIONS (last 10)
========================================================= */
$transactions = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_trnx} WHERE user_id = %d ORDER BY id DESC LIMIT 10",
    $user_id
)) : [];

/* =========================================================
   REFERRALS
========================================================= */
$referrals = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_referrals} WHERE referrer_id = %d ORDER BY id DESC",
    $user_id
)) : [];

/* =========================================================
   VIRTUAL CARDS + THEIR TRANSACTIONS
========================================================= */
$virtual_cards = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_virtual_cards} WHERE user_id = %d ORDER BY id DESC",
    $user_id
)) : [];

$virtualcard_transactions = [];
if (!empty($virtual_cards)) {
    $card_ids = array_map(fn($c) => $c->card_id, $virtual_cards);
    $placeholders = implode(',', array_fill(0, count($card_ids), '%s'));
    $virtualcard_transactions = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_virtualcard_trnx} WHERE card_id IN ($placeholders) ORDER BY id DESC LIMIT 20",
        ...$card_ids
    ));
}

/* =========================================================
   GIFTCARDS
========================================================= */
$giftcard_listings = $wpdb->get_results("SELECT * FROM {$table_giftcard_listings} ORDER BY id DESC");

$giftcard_transactions = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_giftcard_transactions} WHERE user_id = %d ORDER BY id DESC LIMIT 10",
    $user_id
)) : [];

$giftcard_sales = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_giftcard_sales} WHERE user_id = %d ORDER BY id DESC LIMIT 10",
    $user_id
)) : [];

/* =========================================================
   SAVINGS
========================================================= */
$savings_pockets = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_savings_pocket} WHERE user_id = %d ORDER BY id DESC",
    $user_id
)) : [];

$savings_transactions = $user_id ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$table_savings_transactions} WHERE user_id = %d ORDER BY id DESC LIMIT 10",
    $user_id
)) : [];

/* =========================================================
   HELPERS FOR HTML TEMPLATES
========================================================= */
if (!function_exists('truncate_description')) {
    function truncate_description($desc, $length = 22) {
        $desc = esc_html($desc);
        return strlen($desc) > $length ? substr($desc, 0, $length) . '...' : $desc;
    }
}