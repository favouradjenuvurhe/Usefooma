<?php
if (!defined('ABSPATH')) exit;

function pulsepoint_promo_tables(): array {
    global $wpdb;
    $b=$wpdb->prefix.'pulsepoint_';
    return ['codes'=>$b.'promo_codes','uses'=>$b.'promo_redemptions','users'=>$b.'users','trnx'=>$b.'trnx','settings'=>$b.'settings'];
}
function pulsepoint_promo_schema(): void {
    if (get_option('pulsepoint_promo_schema_version')==='2.3.4') return;
    global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=pulsepoint_promo_tables(); $c=$wpdb->get_charset_collate();
    $wpdb->query("ALTER TABLE `{$t['users']}` ADD COLUMN IF NOT EXISTS `promo_bonus_pending` DECIMAL(14,2) DEFAULT 0.00 AFTER `referral_balance`");
    $wpdb->query("ALTER TABLE `{$t['users']}` ADD COLUMN IF NOT EXISTS `promo_bonus_unlocked` TINYINT(1) DEFAULT 0 AFTER `promo_bonus_pending`");
    dbDelta("CREATE TABLE `{$t['codes']}` (`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,`code` VARCHAR(100) NOT NULL,`bonus_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,`used_count` BIGINT UNSIGNED NOT NULL DEFAULT 0,`status` VARCHAR(20) NOT NULL DEFAULT 'active',`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,`updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `code_unique` (`code`),KEY `status_idx` (`status`)) {$c};");
    dbDelta("CREATE TABLE `{$t['uses']}` (`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,`promo_code_id` BIGINT UNSIGNED NOT NULL,`user_id` BIGINT UNSIGNED NOT NULL,`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (`id`),UNIQUE KEY `user_unique` (`user_id`),UNIQUE KEY `code_user_unique` (`promo_code_id`,`user_id`),KEY `promo_code_idx` (`promo_code_id`)) {$c};");
    if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t['settings']}` WHERE opt_key=%s LIMIT 1",'promo_signup_threshold'))) $wpdb->insert($t['settings'],['opt_key'=>'promo_signup_threshold','opt_value'=>maybe_serialize('10000'),'type'=>'string','autoload'=>1]);
    update_option('pulsepoint_promo_schema_version','2.3.4',false);
}
add_action('init','pulsepoint_promo_schema',5);
function pulsepoint_promo_threshold(): float { global $wpdb; $t=pulsepoint_promo_tables(); $v=$wpdb->get_var($wpdb->prepare("SELECT opt_value FROM `{$t['settings']}` WHERE opt_key=%s LIMIT 1",'promo_signup_threshold')); return max(0,(float)maybe_unserialize($v)); }
function pulsepoint_promo_maybe_unlock(int $uid): bool {
    if($uid<=0)return false; global $wpdb; $t=pulsepoint_promo_tables();
    $u=$wpdb->get_row($wpdb->prepare("SELECT id,promo_bonus_pending,promo_bonus_unlocked FROM `{$t['users']}` WHERE id=%d LIMIT 1",$uid));
    if(!$u || (int)$u->promo_bonus_unlocked===1 || (float)$u->promo_bonus_pending<=0)return false;
    $threshold=pulsepoint_promo_threshold();
    $spent=$threshold<=0?$threshold:(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$t['trnx']}` WHERE user_id=%d AND type='debit' AND status='success' AND payment='wallet'",$uid));
    if($spent<$threshold)return false;
    return $wpdb->query($wpdb->prepare("UPDATE `{$t['users']}` SET wallet=wallet+%f,promo_bonus_pending=0,promo_bonus_unlocked=1 WHERE id=%d AND promo_bonus_unlocked=0 AND promo_bonus_pending>0",(float)$u->promo_bonus_pending,$uid))===1;
}
add_action('init',function(){ if(session_status()!==PHP_SESSION_ACTIVE) @session_start(); $uid=(int)($_SESSION['pulsepoint_user']['id']??0); if($uid)pulsepoint_promo_maybe_unlock($uid); },15);
function pulsepoint_resolve_signup_code(string $input): array {
    global $wpdb; $t=pulsepoint_promo_tables(); $v=strtoupper(trim($input)); if($v==='')return ['type'=>'none'];
    $p=$wpdb->get_row($wpdb->prepare("SELECT id,code,bonus_amount FROM `{$t['codes']}` WHERE code=%s AND status='active' LIMIT 1",$v));
    if($p)return ['type'=>'promo','id'=>(int)$p->id,'code'=>$p->code,'bonus'=>(float)$p->bonus_amount];
    $r=$wpdb->get_row($wpdb->prepare("SELECT id FROM `{$t['users']}` WHERE phone=%s OR uniqueid=%s LIMIT 1",$v,$v));
    return $r?['type'=>'referral','referrer_id'=>(int)$r->id]:['type'=>'invalid'];
}
function pulsepoint_apply_signup_promo(int $pid,int $uid,float $bonus): bool {
    if($pid<=0||$uid<=0||$bonus<=0)return false; global $wpdb; $t=pulsepoint_promo_tables();
    $wpdb->query('START TRANSACTION');
    try { if($wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t['uses']}` WHERE user_id=%d LIMIT 1 FOR UPDATE",$uid)))throw new Exception('already used');
        if(!$wpdb->insert($t['uses'],['promo_code_id'=>$pid,'user_id'=>$uid],['%d','%d']))throw new Exception('record failed');
        $wpdb->query($wpdb->prepare("UPDATE `{$t['codes']}` SET used_count=used_count+1 WHERE id=%d",$pid));
        $wpdb->query($wpdb->prepare("UPDATE `{$t['users']}` SET promo_bonus_pending=%f,promo_bonus_unlocked=0 WHERE id=%d",$bonus,$uid));
        $wpdb->query('COMMIT'); return true;
    } catch(Throwable $e){$wpdb->query('ROLLBACK');return false;}
}
function pulsepoint_promo_admin_actions(): void {
    if(!is_admin()||!current_user_can('manage_options')||$_SERVER['REQUEST_METHOD']!=='POST')return;
    if(empty($_POST['pulsepoint_promo_nonce'])||!wp_verify_nonce($_POST['pulsepoint_promo_nonce'],'pulsepoint_promo_manage'))return;
    global $wpdb; $t=pulsepoint_promo_tables(); $a=sanitize_key($_POST['promo_action']??'');
    if($a==='create'){
        $bonus=max(0,(float)($_POST['promo_bonus_amount']??0)); $raw=sanitize_text_field(wp_unslash($_POST['promo_code']??'')); $code=strtoupper(preg_replace('/[^A-Z0-9_-]/i','',$raw));
        if($code==='')$code='PROMO-'.strtoupper(wp_generate_password(10,false,false));
        if($bonus<=0){add_settings_error('pulsepoint_promo','bonus','Bonus amount must be greater than zero.','error');return;}
        if($wpdb->get_var($wpdb->prepare("SELECT id FROM `{$t['codes']}` WHERE code=%s LIMIT 1",$code))){add_settings_error('pulsepoint_promo','exists','Promo code already exists.','error');return;}
        $wpdb->insert($t['codes'],['code'=>$code,'bonus_amount'=>$bonus,'status'=>'active'],['%s','%f','%s']); add_settings_error('pulsepoint_promo','created','Promo code '.$code.' created.','updated');
    } elseif($a==='toggle') { $id=absint($_POST['promo_id']??0); $cur=$wpdb->get_var($wpdb->prepare("SELECT status FROM `{$t['codes']}` WHERE id=%d",$id)); if($cur)$wpdb->update($t['codes'],['status'=>$cur==='active'?'inactive':'active'],['id'=>$id],['%s'],['%d']); }
}
add_action('admin_init','pulsepoint_promo_admin_actions',20);
