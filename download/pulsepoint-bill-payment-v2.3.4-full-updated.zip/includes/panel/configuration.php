<?php    
/**    
 * Pulsepoint Configuration Page    
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/configuration.php    
 * Author: Amaaavl    
 */    
    
if (!defined('ABSPATH')) exit;    
    
global $wpdb;    
$base_prefix = $wpdb->prefix . 'pulsepoint_';    
    
// === Fetch Platform Settings ===    
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");    
$settings = [];    
foreach ($settings_rows as $row) {    
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);    
}    
    
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';    

// Giftcard and Boost are add-on plugins. Their configuration cards are shown
// only when the corresponding add-on plugin is active.
$giftcard_addon_active = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('giftcard');
$smm_addon_active      = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('smm');
$esim_addon_active     = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('esim');
$storefront_addon_active = function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('storefront');
$color_hex     = $settings['color_hex'] ?? '#6C63FF';    
?>  
<div class="wrap">      
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Configuration</h1>    
  <p>Manage your integration settings, providers, service APIs, and platform configurations here.</p>    
  <hr class="wp-header-end">    

  <div class="config-card" style="grid-column:1/-1;cursor:default;align-items:stretch;display:block;margin-top:20px;" onclick="">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;"><i class="bi bi-ticket-perforated config-icon"></i><div><div class="config-title">Signup Promo Codes</div><div class="config-desc">Create promo codes that share the signup referral field and unlock signup bonuses after a transaction threshold.</div></div></div>
    <?php settings_errors('pulsepoint_promo'); ?>
    <form method="POST" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-top:16px;">
      <?php wp_nonce_field('pulsepoint_promo_manage','pulsepoint_promo_nonce'); ?>
      <input type="hidden" name="promo_action" value="create">
      <div><label class="config-title" style="display:block;font-size:13px;margin-bottom:6px;">Promo Code</label><input type="text" name="promo_code" class="pulse-input" placeholder="Leave blank to generate randomly"></div>
      <div><label class="config-title" style="display:block;font-size:13px;margin-bottom:6px;">Signup Bonus (₦)</label><input type="number" min="0.01" step="0.01" name="promo_bonus_amount" class="pulse-input" required placeholder="e.g. 1000"></div>
      <div><label class="config-title" style="display:block;font-size:13px;margin-bottom:6px;">Bonus Unlock Threshold (₦)</label><input type="number" min="0" step="0.01" name="promo_signup_threshold" value="<?= esc_attr($settings['promo_signup_threshold'] ?? '10000') ?>" class="pulse-input"><div style="font-size:11px;color:#6b7280;margin-top:5px;">Successful wallet-paid transaction volume required before the bonus enters the normal wallet. Own funded money remains usable before the threshold.</div></div>
      <div style="display:flex;align-items:end;"><button type="submit" class="pulse-btn" style="width:100%;">Generate / Create Promo Code</button></div>
    </form>
    <?php
      if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pulsepoint_promo_nonce']) && wp_verify_nonce($_POST['pulsepoint_promo_nonce'],'pulsepoint_promo_manage') && isset($_POST['promo_signup_threshold'])) {
          $threshold=max(0,(float)$_POST['promo_signup_threshold']);
          $wpdb->update($base_prefix.'settings',['opt_value'=>maybe_serialize((string)$threshold)],['opt_key'=>'promo_signup_threshold']);
      }
      $promo_table=$base_prefix.'promo_codes';
      $promo_codes=$wpdb->get_results("SELECT * FROM `{$promo_table}` ORDER BY id DESC LIMIT 50");
    ?>
    <div style="overflow:auto;margin-top:18px;">
      <?php if($promo_codes): ?><table style="width:100%;border-collapse:collapse;"><thead><tr><th style="padding:8px;text-align:left;">Code</th><th style="padding:8px;text-align:left;">Bonus</th><th style="padding:8px;text-align:left;">Users Used</th><th style="padding:8px;text-align:left;">Status</th><th style="padding:8px;text-align:left;">Created</th><th></th></tr></thead><tbody>
      <?php foreach($promo_codes as $pc): ?><tr style="border-top:1px solid #eee;"><td style="padding:8px;"><strong><?= esc_html($pc->code) ?></strong></td><td style="padding:8px;">₦<?= number_format((float)$pc->bonus_amount,2) ?></td><td style="padding:8px;"><?= number_format((int)$pc->used_count) ?></td><td style="padding:8px;"><?= esc_html(ucfirst($pc->status)) ?></td><td style="padding:8px;"><?= esc_html($pc->created_at) ?></td><td style="padding:8px;"><form method="POST" style="margin:0;"><?php wp_nonce_field('pulsepoint_promo_manage','pulsepoint_promo_nonce'); ?><input type="hidden" name="promo_action" value="toggle"><input type="hidden" name="promo_id" value="<?= (int)$pc->id ?>"><button type="submit" class="pulse-btn" style="padding:6px 10px;font-size:12px;"><?= $pc->status==='active'?'Deactivate':'Activate' ?></button></form></td></tr><?php endforeach; ?></tbody></table>
      <?php else: ?><div style="padding:12px 0;color:#9ca3af;">No promo codes created yet.</div><?php endif; ?>
    </div>
  </div>


  <!-- Tailwind + Bootstrap Icons -->    
  <script src="https://cdn.tailwindcss.com"></script>    
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">    

  <style>    
    :root {    
      --primary: <?= $color_hex ?>;    
    }    
    body, .wrap {    
      font-family: 'Inter', sans-serif !important;    
      background: #f8fafc;    
    }    
    .config-grid {    
      display: grid;    
      grid-template-columns: repeat(3, minmax(0, 1fr));    
      gap: 24px;    
      margin-top: 30px;    
      max-width: 1200px;    
    }    
    @media (max-width: 1024px) {    
      .config-grid {    
        grid-template-columns: repeat(2, minmax(0, 1fr));    
      }    
    }    
    @media (max-width: 640px) {    
      .config-grid {    
        grid-template-columns: 1fr;    
      }    
    }    
    .config-card {    
      background: #fff;    
      border-radius: 16px;    
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);    
      padding: 28px;    
      text-align: center;    
      transition: all .3s ease;    
      cursor: pointer;    
      border: 2px solid transparent;    
    }    
    .config-card:hover {    
      transform: translateY(-4px);    
      border-color: var(--primary);    
    }    
    .config-icon {    
      font-size: 46px;    
      color: var(--primary);    
      margin-bottom: 12px;    
    }    
    .config-title {    
      font-weight: 700;    
      font-size: 18px;    
      color: #222;    
    }    
    .config-desc {    
      font-size: 14px;    
      color: #777;    
      margin-top: 6px;    
    }    
    .config-center {    
      grid-column: span 2;    
      display: flex;    
      justify-content: center;    
      gap: 24px;    
      flex-wrap: wrap;    
    }    
  </style>    

  <!-- Configuration Sections -->    
  <div class="config-grid">  

    <!-- Row 1 -->    
    <div class="config-card" onclick="openConfigPage('provider')">    
      <i class="bi bi-plug config-icon"></i>    
      <div class="config-title">Provider API</div>    
      <div class="config-desc">Setup your VTU & bill payment API providers.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('api-setup')">    
      <i class="bi bi-cloud config-icon"></i>    
      <div class="config-title">API Setup</div>    
      <div class="config-desc">Airtime, cable, bill & bank transfer API credentials.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('data')">    
      <i class="bi bi-sim config-icon"></i>    
      <div class="config-title">Data Plan</div>    
      <div class="config-desc">Configure mobile data bundles & pricing.</div>    
    </div>    

    <!-- Row 2 -->    
    <div class="config-card" onclick="openConfigPage('electricity')">    
      <i class="bi bi-lightning-charge config-icon"></i>    
      <div class="config-title">Electricity</div>    
      <div class="config-desc">Manage electricity bill payment integration.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('cable')">    
      <i class="bi bi-tv config-icon"></i>    
      <div class="config-title">Cable</div>    
      <div class="config-desc">Configure DSTV, GOTV, Startimes & other cable services.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('education')">    
      <i class="bi bi-mortarboard config-icon"></i>    
      <div class="config-title">Education</div>    
      <div class="config-desc">Integrate WAEC, NECO & exam pin services.</div>    
    </div>    

    <!-- Row 3 -->    
    <div class="config-card" onclick="openConfigPage('betting')">    
      <i class="bi bi-controller config-icon"></i>    
      <div class="config-title">Betting</div>    
      <div class="config-desc">Manage betting platforms for wallet funding.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('virtual-accounts')">    
      <i class="bi bi-bank config-icon"></i>    
      <div class="config-title">Virtual Accounts</div>    
      <div class="config-desc">Configure bank virtual account APIs.</div>    
    </div>    

    <div class="config-card" onclick="openConfigPage('other-key')">    
      <i class="bi bi-credit-card config-icon"></i>    
      <div class="config-title">Cards & Conversion</div>    
      <div class="config-desc">Virtual card fees, conversion rates & card provider keys.</div>    
    </div>    

    <!-- Row 4 -->
    <?php if ($giftcard_addon_active): ?>
    <div class="config-card" onclick="openConfigPage('giftcard')">
      <i class="bi bi-gift config-icon"></i>
      <div class="config-title">Giftcard</div>
      <div class="config-desc">Manage giftcard rates & trading settings.</div>
    </div>
    <?php endif; ?>
<div class="config-card" onclick="openConfigPage('airtime-to-cash')">    
      <i class="bi bi-arrow-left-right config-icon"></i>    
      <div class="config-title">Airtime to Cash</div>    
      <div class="config-desc">Network rates & trade submission reviews.</div>    
    </div>    


    <!-- Row 5 -->    
    <div class="config-card" onclick="openConfigPage('security')">    
      <i class="bi bi-shield-lock config-icon"></i>    
      <div class="config-title">Security & Keys</div>    
      <div class="config-desc">Encryption keys, API tokens & access controls.</div>    
    </div>    

    <?php if ($smm_addon_active): ?>
    <div class="config-card" onclick="openConfigPage('smm')">
      <i class="bi bi-rocket config-icon"></i>
      <div class="config-title">Boost (SMM)</div>
      <div class="config-desc">Provider setup, catalog sync & service management.</div>
    </div>
    <?php endif; ?>

    <?php if ($storefront_addon_active): ?>
    <div class="config-card" onclick="openConfigPage('storefront')">
      <i class="bi bi-shop config-icon"></i>
      <div class="config-title">Storefront</div>
      <div class="config-desc">Manage storefront settings and WooCommerce requirements.</div>
    </div>
    <?php endif; ?>

    <?php if ($esim_addon_active): ?>
    <div class="config-card" onclick="openConfigPage('esim')">
      <i class="bi bi-sim config-icon"></i>
      <div class="config-title">eSIM</div>
      <div class="config-desc">Configure eSIM provider API, pricing & conversion settings.</div>
    </div>
    <?php endif; ?>
</div>    
</div>  

<script>    
function openConfigPage(page) {    
  window.location.href = `admin.php?page=pulsepoint-${page}`;    
}    
</script>