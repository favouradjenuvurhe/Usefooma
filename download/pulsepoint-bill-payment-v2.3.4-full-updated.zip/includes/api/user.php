<?php
/**
 * Pulsepoint API Fetch User Details
 * Path: /api/users.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data POST
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode(['success' => false, 'message' => 'Token is required']);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table = $base_prefix . 'users';

// Fetch user by token
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, firstname, lastname, phone, email, wallet, dollar, referral_balance, promo_bonus_pending, promo_bonus_unlocked, token, account_type, status 
        FROM `{$table}` WHERE token = %s LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

// Check if account is active
if ((int)$user->status !== 1) {
    echo json_encode(['success' => false, 'message' => 'Account inactive']);
    exit;
}

// Format balances with Naira sign
$wallet = '₦' . number_format((float)$user->wallet, 2, '.', ',');
$dollar = '$' . number_format((float)$user->dollar, 2, '.', ',');
$referral_balance = '₦' . number_format((float)$user->referral_balance, 2, '.', ',');
$promo_bonus_amount = (float)$user->promo_bonus_pending;
$available_balance_amount = (float)$user->wallet + $promo_bonus_amount;
$promo_bonus = '₦' . number_format($promo_bonus_amount, 2, '.', ',');
$available_balance = '₦' . number_format($available_balance_amount, 2, '.', ',');
$promo_threshold = function_exists('pulsepoint_promo_threshold') ? pulsepoint_promo_threshold() : 0;
$promo_spend = 0;
if (function_exists('pulsepoint_promo_tables')) { $pt=pulsepoint_promo_tables(); $promo_spend=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM `{$pt['trnx']}` WHERE user_id=%d AND type='debit' AND status='success' AND payment='wallet'",(int)$user->id)); }

// Return user details
echo json_encode([
    'success' => true,
    'message' => 'User fetched successfully',
    'user' => [
        'id' => $user->id,
        'firstname' => $user->firstname,
        'lastname' => $user->lastname,
        'email' => $user->email,
        'phone' => $user->phone,
        'wallet' => $wallet,
        'available_balance' => $available_balance,
        'available_balance_includes_locked_bonus' => $promo_bonus_amount > 0,
        'dollar' => $dollar,
        'referral_balance' => $referral_balance,
        'promo_bonus_pending' => $promo_bonus,
        'promo_bonus_unlocked' => (int)$user->promo_bonus_unlocked === 1,
        'promo_threshold' => $promo_threshold,
        'promo_qualifying_amount' => $promo_spend,
        'promo_threshold_reached' => $promo_threshold <= 0 || $promo_spend >= $promo_threshold,
        'token' => $user->token,
        'account_type' => $user->account_type,
        'status' => $user->status
    ]
]);
exit;