<?php
// loader.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define constants
define('PULSEPOINT_DIR', plugin_dir_path(__FILE__));
define('PULSEPOINT_URL', plugin_dir_url(__FILE__));

// Include all core files
require_once PULSEPOINT_DIR . 'includes/email-helper.php';
require_once PULSEPOINT_DIR . 'includes/cashback-helper.php';
require_once PULSEPOINT_DIR . 'includes/beneficiary-helper.php';
require_once PULSEPOINT_DIR . 'core/persistent-login.php';
require_once PULSEPOINT_DIR . 'includes/promo-bonus.php';
require_once PULSEPOINT_DIR . 'includes/public.php';
require_once PULSEPOINT_DIR . 'includes/callback.php';
require_once PULSEPOINT_DIR . 'includes/woo-gateway.php';
require_once PULSEPOINT_DIR . 'includes/admin.php';
require_once PULSEPOINT_DIR . 'includes/api.php';
require_once PULSEPOINT_DIR . 'includes/theme-loader.php';
require_once PULSEPOINT_DIR . 'base/plugin.php';
require_once PULSEPOINT_DIR . 'base/core.php';
require_once PULSEPOINT_DIR . 'base/license.php';
require_once PULSEPOINT_DIR . 'base/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/index.php'; 
require_once PULSEPOINT_DIR . 'core/info.php'; 
require_once PULSEPOINT_DIR . 'core/login.php'; 
require_once PULSEPOINT_DIR . 'core/setup_2fa.php';
require_once PULSEPOINT_DIR . 'core/verify_2fa.php';
require_once PULSEPOINT_DIR . 'core/login_2fa_verify.php';
require_once PULSEPOINT_DIR . 'core/register.php';
require_once PULSEPOINT_DIR . 'core/change-password.php';
require_once PULSEPOINT_DIR . 'core/verify.php'; 
require_once PULSEPOINT_DIR . 'core/forgot-password.php';
require_once PULSEPOINT_DIR . 'core/reset-password.php'; 
require_once PULSEPOINT_DIR . 'core/logout.php';
require_once PULSEPOINT_DIR . 'core/ajax-handlers.php';
require_once PULSEPOINT_DIR . 'core/ajax-cable.php';
require_once PULSEPOINT_DIR . 'core/ajax-bill.php';
require_once PULSEPOINT_DIR . 'core/ajax-edu.php';
require_once PULSEPOINT_DIR . 'core/ajax-betting.php';
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('smm')) {
    require_once PULSEPOINT_DIR . 'core/ajax-smm.php';
}
require_once PULSEPOINT_DIR . 'core/airtime/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/airtime/a2c/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/airtime/a2c/rates.php';
require_once PULSEPOINT_DIR . 'core/airtime/scheduling.php';
require_once PULSEPOINT_DIR . 'core/recharge/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/data/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/data/scheduling.php';
require_once PULSEPOINT_DIR . 'core/cable/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/electricity/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/education/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/betting/pulsepoint.php';
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('smm')) {
    require_once PULSEPOINT_DIR . 'core/smm/pulsepoint.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('esim')) {
    require_once PULSEPOINT_DIR . 'core/esim/pulsepoint.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('transfer')) {
    require_once PULSEPOINT_DIR . 'core/transfer/pulsepoint.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('transfer')) {
    require_once PULSEPOINT_DIR . 'core/transfer/wallet2.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('transfer')) {
    require_once PULSEPOINT_DIR . 'core/transfer/verification.php';
}
require_once PULSEPOINT_DIR . 'core/customer/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/customer/status.php';
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/pulsepoint.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/details.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/fund.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/withdrawal.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/transaction.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/freeze.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('virtualcard')) {
    require_once PULSEPOINT_DIR . 'core/virtualcard/convert.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('crypto')) {
    require_once PULSEPOINT_DIR . 'core/crypto/pulsepoint.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('giftcard')) {
    require_once PULSEPOINT_DIR . 'core/giftcard/pulsepoint.php';
}
if (function_exists('pulsepoint_addon_active') && pulsepoint_addon_active('storefront')) {
    require_once PULSEPOINT_DIR . 'core/storefront/pulsepoint.php';
    require_once PULSEPOINT_DIR . 'core/storefront/api-handler.php';
}
require_once PULSEPOINT_DIR . 'core/virtual-account/pulsepoint.php';
require_once PULSEPOINT_DIR . 'core/virtual-account/dynamic.php';
require_once PULSEPOINT_DIR . 'core/woo-commerce/pulsepoint.php';

// Cron job hooks (pulsepoint_cron_*, master dispatcher pulsepoint_run_cron)
// are registered on every load now, not just when the external
// wp-json/pulsepoint/v1/cron endpoint is hit — this lets WP-Cron (and
// plugin activation) trigger the same jobs as a reliability fallback.
require_once PULSEPOINT_DIR . 'cron/cron-loader.php';

// Safety net for existing installs updating via auto-update, which never
// re-fires register_activation_hook — make sure the WP-Cron fallback
// schedule exists on every normal load too, not just fresh activations.
add_action('init', function () {
    if (!wp_next_scheduled('pulsepoint_run_cron')) {
        wp_schedule_event(time(), 'pulsepoint_15min', 'pulsepoint_run_cron');
    }
});