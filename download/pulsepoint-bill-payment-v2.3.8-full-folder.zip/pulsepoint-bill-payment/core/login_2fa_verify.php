<?php

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__DIR__) . 'libs/PHPGangsta/GoogleAuthenticator.php';

add_action(
    'wp_ajax_nopriv_pulsepoint_login_2fa_verify',
    'pulsepoint_login_2fa_verify'
);

add_action(
    'wp_ajax_pulsepoint_login_2fa_verify',
    'pulsepoint_login_2fa_verify'
);

function pulsepoint_login_2fa_verify() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if (!session_id()) {
        session_start();
    }

    if (!isset($_SESSION['pulsepoint_2fa_user'])) {

        wp_send_json([
            'success' => false,
            'message' => '2FA session expired.'
        ]);
    }

    $code = sanitize_text_field($_POST['code'] ?? '');

    if (empty($code)) {

        wp_send_json([
            'success' => false,
            'message' => 'Authentication code required.'
        ]);
    }

    $user_id = intval($_SESSION['pulsepoint_2fa_user']);

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user) {

        wp_send_json([
            'success' => false,
            'message' => 'User not found.'
        ]);
    }

    if (($user->twofa_method ?? 'app') === 'email') {

        if (empty($user->twofa_email_code) || empty($user->twofa_email_code_expires)) {
            wp_send_json(['success' => false, 'message' => 'No pending code. Please log in again.']);
        }

        if (strtotime($user->twofa_email_code_expires) < time()) {
            wp_send_json(['success' => false, 'message' => 'This code has expired. Please log in again.']);
        }

        if (!hash_equals((string) $user->twofa_email_code, $code)) {
            wp_send_json([
                'success' => false,
                'message' => 'Invalid verification code.'
            ]);
        }

        $wpdb->update($table, [
            'twofa_email_code'         => null,
            'twofa_email_code_expires' => null,
        ], ['id' => $user_id]);

    } else {

        $ga = new PHPGangsta_GoogleAuthenticator();

        $valid = $ga->verifyCode(
            $user->twofa_secret,
            $code,
            2
        );

        if (!$valid) {

            wp_send_json([
                'success' => false,
                'message' => 'Invalid authentication code.'
            ]);
        }
    }

    // FINAL LOGIN SESSION
    session_regenerate_id(true);

    $_SESSION['pulsepoint_user'] = [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode
    ];

    unset($_SESSION['pulsepoint_2fa_user']);

    setcookie('pulsepoint_user_session', session_id(), [
        'expires'  => time() + (defined('PULSEPOINT_SESSION_LIFETIME') ? PULSEPOINT_SESSION_LIFETIME : (90 * DAY_IN_SECONDS)),
        'path'     => '/',
        'domain'   => $_SERVER['SERVER_NAME'] ?? '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $branding = function_exists('pulsepoint_get_branding') ? pulsepoint_get_branding($wpdb, $base_prefix) : ['platform_name' => 'Pulsepoint', 'color_hex' => '#356cf9'];

    if ((int) $user->status_email === 1) {

        if (function_exists('pulsepoint_render_email_template')) {
            @wp_mail(
                $user->email,
                'New Login Activity on Your Account',
                pulsepoint_render_email_template([
                    'platform_name' => $branding['platform_name'],
                    'color_hex'     => $branding['color_hex'],
                    'heading'       => 'New Login Detected',
                    'firstname'     => $user->firstname,
                    'message'       => sprintf(
                        'A new login was detected on your account (verified with your authenticator app).<br><br><strong>Date:</strong> %s<br><strong>Device:</strong> %s<br><br>If this was not you, please secure your account immediately.',
                        htmlspecialchars(date('Y-m-d H:i:s'), ENT_QUOTES, 'UTF-8'),
                        htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Device', ENT_QUOTES, 'UTF-8')
                    ),
                ]),
                ['Content-Type: text/html; charset=UTF-8']
            );
        }

        wp_send_json([
            'success' => true,
            'message' => '2FA login successful.',
            'redirect' => site_url('/dashboard'),
            'user' => $_SESSION['pulsepoint_user']
        ]);
    }

    wp_send_json([
        'success' => true,
        'message' => '2FA login successful. Please verify your account.',
        'redirect' => site_url('/auth/verification'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}