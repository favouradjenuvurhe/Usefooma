<?php
/**
 * Pulsepoint persistent user session.
 * Keeps authenticated browser sessions alive for 90 days and restores the
 * Pulsepoint session from the existing pulsepoint_user_session cookie when
 * the browser no longer has the PHP session cookie.
 */
if (!defined('ABSPATH')) exit;

if (!defined('PULSEPOINT_SESSION_LIFETIME')) {
    define('PULSEPOINT_SESSION_LIFETIME', 90 * DAY_IN_SECONDS);
}

if (!function_exists('pulsepoint_prepare_long_session')) {
    function pulsepoint_prepare_long_session() {
        if (session_status() !== PHP_SESSION_NONE || headers_sent()) return;

        // Keep the server-side PHP session for the same period as the browser cookie.
        @ini_set('session.gc_maxlifetime', (string) PULSEPOINT_SESSION_LIFETIME);
        @ini_set('session.cookie_lifetime', (string) PULSEPOINT_SESSION_LIFETIME);
        @ini_set('session.use_strict_mode', '1');

        $params = session_get_cookie_params();
        $params['lifetime'] = PULSEPOINT_SESSION_LIFETIME;
        $params['path'] = '/';
        $params['secure'] = is_ssl();
        $params['httponly'] = true;
        $params['samesite'] = 'Lax';
        session_set_cookie_params($params);

        // The plugin has historically stored the PHP session ID in this cookie.
        // Re-use it when PHPSESSID is missing after a browser restart.
        if (empty($_COOKIE[session_name()]) && !empty($_COOKIE['pulsepoint_user_session'])) {
            $sid = preg_replace('/[^a-zA-Z0-9,-]/', '', (string) wp_unslash($_COOKIE['pulsepoint_user_session']));
            if ($sid !== '') {
                @session_id($sid);
            }
        }
    }
}

add_action('init', 'pulsepoint_prepare_long_session', 0);

if (!function_exists('pulsepoint_refresh_long_session_cookie')) {
    function pulsepoint_refresh_long_session_cookie() {
        if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['pulsepoint_user']['id']) || headers_sent()) return;
        setcookie('pulsepoint_user_session', session_id(), [
            'expires'  => time() + PULSEPOINT_SESSION_LIFETIME,
            'path'     => '/',
            'domain'   => $_SERVER['SERVER_NAME'] ?? '',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
}
add_action('init', 'pulsepoint_refresh_long_session_cookie', 2);
