<?php
/**
 * Pulsepoint eSIM Core - v2.3.2
 * Provider: KripiCard eSIM API
 *
 * Base URL: https://home.kripicard.com/api/esim
 * Provider authentication is sent as `api_key` in the JSON request body.
 */
if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_esim_settings')) {
function pulsepoint_esim_settings() {
    global $wpdb;
    $prefix = $wpdb->prefix . 'pulsepoint_';
    $rows = $wpdb->get_results(
        "SELECT opt_key,opt_value FROM {$prefix}settings
         WHERE opt_key IN ('esim_api_key','esim_markup','esim_usd_rate','rate_usd','api_mode','maintenance_mode')",
        OBJECT_K
    );
    $out = [];
    foreach ($rows as $row) {
        $out[$row->opt_key] = maybe_unserialize($row->opt_value);
    }
    return $out;
}
}

if (!function_exists('pulsepoint_esim_request')) {
function pulsepoint_esim_request($endpoint, $body = []) {
    $settings = pulsepoint_esim_settings();
    $key = trim((string)($settings['esim_api_key'] ?? ''));

    if ($key === '') {
        return ['success' => false, 'message' => 'eSIM API key is not configured.'];
    }

    $body['api_key'] = $key;
    $url = 'https://home.kripicard.com/api/esim/' . ltrim($endpoint, '/');

    $response = wp_remote_post($url, [
        'timeout' => 30,
        'headers' => [
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json',
        ],
        'body' => wp_json_encode($body),
    ]);

    if (is_wp_error($response)) {
        return ['success' => false, 'message' => $response->get_error_message()];
    }

    $code = wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return ['success' => false, 'message' => 'Invalid eSIM provider response.', '_http_code' => $code];
    }

    $json['_http_code'] = $code;
    return $json;
}
}

/**
 * Fetch packages from the new KripiCard endpoint.
 */
function pulsepoint_esim_packages($country = '', $data = '', $page = 1, $per_page = 20) {
    $payload = [
        'country'  => strtoupper(sanitize_text_field($country)),
        'data'     => sanitize_text_field((string)$data),
        'page'     => max(1, (int)$page),
        'per_page' => min(100, max(1, (int)$per_page)),
    ];

    return pulsepoint_esim_request('packages', $payload);
}

/**
 * Backwards-compatible wrapper used by the app. The new API has no
 * countries endpoint, so the caller supplies a country code and packages
 * are returned directly.
 */
function pulsepoint_esim_countries($start = '', $length = '', $search = '') {
    $country = sanitize_text_field($search);
    return pulsepoint_esim_packages($country, '', 1, $length !== '' ? (int)$length : 20);
}

function pulsepoint_esim_plans($country, $data = '', $page = 1, $per_page = 20) {
    return pulsepoint_esim_packages($country, $data, $page, $per_page);
}

/**
 * Local purchase history. KripiCard's supplied API does not expose a
 * history endpoint, so completed purchases are read from Pulsepoint's DB.
 */
function pulsepoint_esim_history($start = '', $length = '', $search = '') {
    global $wpdb;
    $table = $wpdb->prefix . 'pulsepoint_esim_orders';

    if (!session_id()) session_start();
    $user_id = (int)($_SESSION['pulsepoint_user']['id'] ?? 0);
    if (!$user_id) return ['success' => false, 'message' => 'Not authenticated.'];

    $limit = min(100, max(1, (int)($length !== '' ? $length : 20)));
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, transaction_id, reference, country_code, country_name, plan_id,
                data_gb, duration_days, amount, status, profile_json, provider_response, created_at
         FROM {$table}
         WHERE user_id=%d
         ORDER BY id DESC
         LIMIT %d",
        $user_id, $limit
    ), ARRAY_A);

    return ['success' => true, 'data' => $rows];
}

function pulsepoint_esim_profile($transaction_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'pulsepoint_esim_orders';

    if (!session_id()) session_start();
    $user_id = (int)($_SESSION['pulsepoint_user']['id'] ?? 0);

    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE transaction_id=%s AND user_id=%d LIMIT 1",
        sanitize_text_field($transaction_id), $user_id
    ), ARRAY_A);

    if (!$row) return ['success' => false, 'message' => 'eSIM purchase not found.'];

    $provider = json_decode((string)($row['provider_response'] ?? ''), true);
    $data = is_array($provider['data'] ?? null) ? $provider['data'] : [];

    return [
        'success' => true,
        'data' => $data,
        'transaction_id' => $row['transaction_id'],
        'country' => $row['country_name'] ?: $row['country_code'],
        'countryCode' => $row['country_code'],
        'status' => $row['status'],
        'created_at' => $row['created_at'],
        'esim_code' => $data['esim_code'] ?? null,
        'qr_code_url' => $data['qr_code_url'] ?? null,
        'activation_instructions' => $data['activation_instructions'] ?? null,
        'package_details' => $data['package_details'] ?? null,
    ];
}

function pulsepoint_esim_delete($transaction_id) {
    return ['success' => false, 'message' => 'eSIM deletion is not supported by the current provider API.'];
}

function pulsepoint_esim_topup_plans($plan_id) {
    return ['success' => false, 'message' => 'eSIM top-up is not supported by the current provider API.'];
}

function pulsepoint_esim_purchase($user_id, $product_id, $recipient_email = '', $country = '', $reference = '') {
    global $wpdb;

    $prefix = $wpdb->prefix . 'pulsepoint_';
    $users = $prefix . 'users';
    $orders = $prefix . 'esim_orders';
    $trnx = $prefix . 'trnx';

    $settings = pulsepoint_esim_settings();

    if (($settings['maintenance_mode'] ?? '0') == '1') {
        return ['success' => false, 'message' => 'Under Maintenance'];
    }

    if (($settings['api_mode'] ?? 'live') === 'off') {
        return ['success' => false, 'message' => 'eSIM service not available'];
    }

    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE id=%d", (int)$user_id));
    if (!$user || (int)$user->status !== 1) {
        return ['success' => false, 'message' => 'User not active'];
    }

    $product_id = sanitize_text_field($product_id);
    $country = strtoupper(sanitize_text_field($country));
    $recipient_email = sanitize_email($recipient_email ?: $user->email);

    if ($product_id === '') return ['success' => false, 'message' => 'product_id is required'];
    if (!is_email($recipient_email)) return ['success' => false, 'message' => 'A valid recipient email is required'];
    if ($country === '') return ['success' => false, 'message' => 'country is required to validate the package'];

    // Validate the selected product and obtain the provider's current USD price.
    $packages = pulsepoint_esim_packages($country, '', 1, 100);
    if (empty($packages['success'])) {
        return ['success' => false, 'message' => $packages['message'] ?? 'Unable to load eSIM packages', 'provider' => $packages];
    }

    $package_rows = $packages['data']['packages'] ?? [];
    $package = null;

    foreach ((array)$package_rows as $row) {
        if (is_array($row) && (string)($row['packageCode'] ?? '') === $product_id) {
            $package = $row;
            break;
        }
    }

    if (!$package) {
        return ['success' => false, 'message' => 'Selected eSIM package is no longer available'];
    }

    $usd = (float)($package['price'] ?? 0);
    if ($usd <= 0) return ['success' => false, 'message' => 'Invalid provider package price'];

    $rate = (float)($settings['esim_usd_rate'] ?? 0);
    if ($rate <= 0) $rate = (float)($settings['rate_usd'] ?? 0);
    if ($rate <= 0) $rate = 1600;

    $markup = (float)($settings['esim_markup'] ?? 0);
    $amount = round(($usd * $rate) * (1 + $markup / 100), 2);

    if (($settings['api_mode'] ?? 'live') === 'live' && (float)$user->wallet < $amount) {
        return ['success' => false, 'message' => 'Insufficient balance'];
    }

    if (!$reference) $reference = 'PESIM' . date('YmdHis') . wp_rand(100, 999);

    // Purchase from the new provider endpoint.
    $provider = pulsepoint_esim_request('purchase', [
        'recipient_email' => $recipient_email,
        'product_id'      => $product_id,
    ]);

    if (empty($provider['success']) || empty($provider['data']['transaction_id'])) {
        return [
            'success' => false,
            'message' => $provider['message'] ?? 'eSIM purchase failed',
            'provider' => $provider,
        ];
    }

    $data = is_array($provider['data'] ?? null) ? $provider['data'] : [];
    $tx = sanitize_text_field((string)($data['transaction_id'] ?? ''));

    $country_code = sanitize_text_field((string)($package['countryCode'] ?? $country));
    $country_name = sanitize_text_field((string)($package['country'] ?? $country));
    $data_gb = (float)preg_replace('/[^0-9.]/', '', (string)($package['data'] ?? '0'));
    $duration_days = (int)preg_replace('/[^0-9]/', '', (string)($package['duration'] ?? '0'));

    $wpdb->insert($orders, [
        'user_id'          => $user_id,
        'operation'        => 'purchase',
        'transaction_id'   => $tx,
        'reference'        => $reference,
        'country_code'     => $country_code,
        'country_name'     => $country_name,
        'plan_id'          => 0,
        'product_code'     => $product_id,
        'data_gb'          => $data_gb,
        'duration_days'    => $duration_days,
        'provider_cost_usd'=> $usd,
        'amount'           => $amount,
        'status'           => sanitize_text_field((string)($data['status'] ?? 'active')),
        'profile_json'     => wp_json_encode($data),
        'provider_response' => wp_json_encode($provider),
    ]);

    $order_id = $wpdb->insert_id;

    $wpdb->insert($trnx, [
        'user_id'     => $user_id,
        'details'     => wp_json_encode([
            'service' => 'eSIM',
            'country' => $country_name,
            'country_code' => $country_code,
            'product_id' => $product_id,
            'transaction_id' => $tx,
            'recipient_email' => $recipient_email,
        ]),
        'recipient'  => $recipient_email,
        'amount'     => $amount,
        'reference'  => $reference,
        'payment'    => 'wallet',
        'category'   => 'others',
        'status'     => 'pending',
        'type'       => 'debit',
        'session'    => session_id(),
        'description'=> 'eSIM - ' . $country_name . ' - ' . $package['data'] . ' - ' . $package['duration'],
    ]);

    $trnx_id = $wpdb->insert_id;
    $charged = true;
    $new_wallet = (float)$user->wallet;

    if (($settings['api_mode'] ?? 'live') === 'live') {
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE {$users} SET wallet = wallet - %f WHERE id=%d AND wallet >= %f",
            $amount, $user_id, $amount
        ));
        $charged = ($updated === 1);
        if ($charged) $new_wallet -= $amount;
    }

    if (!$charged) {
        $wpdb->update($orders, ['status' => 'wallet_failed'], ['id' => $order_id]);
        $wpdb->update($trnx, [
            'status' => 'failed',
            'gateway_response' => wp_json_encode(['message' => 'Wallet debit failed after provider purchase']),
        ], ['id' => $trnx_id]);

        return [
            'success' => false,
            'message' => 'Wallet debit failed. Contact support with reference ' . $reference,
            'reference' => $reference,
            'provider_transaction_id' => $tx,
        ];
    }

    $wpdb->update($trnx, [
        'status' => 'success',
        'gateway_response' => wp_json_encode($provider),
        'updated_at' => current_time('mysql'),
    ], ['id' => $trnx_id]);

    if (function_exists('pulsepoint_save_beneficiary')) {
        pulsepoint_save_beneficiary(
            $user_id,
            'esim',
            $recipient_email,
            $recipient_email,
            $country_name,
            ['product_id' => $product_id, 'country' => $country_code]
        );
    }

    return [
        'success' => true,
        'message' => $provider['message'] ?? 'eSIM purchased successfully',
        'reference' => $reference,
        'transaction_id' => $tx,
        'transactionId' => $tx,
        'amount' => $amount,
        'new_wallet' => $new_wallet,
        'package' => $package,
        'data' => $data,
        'qr_code_url' => $data['qr_code_url'] ?? null,
        'esim_code' => $data['esim_code'] ?? null,
        'activation_instructions' => $data['activation_instructions'] ?? null,
    ];
}
