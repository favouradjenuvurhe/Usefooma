<?php
/**
 * Pulsepoint Signup Promo + Bonus
 * Version 2.3.8
 *
 * Uses the existing users table columns promo_bonus_pending and
 * promo_bonus_unlocked. The normal wallet remains spendable while the
 * signup bonus is pending. Once the configured qualifying transaction
 * threshold is reached, the pending bonus is moved into wallet atomically.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('pulsepoint_promo_tables')) {
    function pulsepoint_promo_tables(): array {
        global $wpdb;
        $prefix = $wpdb->prefix . 'pulsepoint_';
        return [
            'users'  => $prefix . 'users',
            'trnx'   => $prefix . 'trnx',
            'codes'  => $prefix . 'promo_codes',
            'usage'  => $prefix . 'promo_code_usage',
        ];
    }
}

if (!function_exists('pulsepoint_promo_schema')) {
    function pulsepoint_promo_schema(): void {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $t = pulsepoint_promo_tables();
        $charset = $wpdb->get_charset_collate();

        // Create the promo tables first. This is intentionally idempotent so
        // an existing 2.3.5 installation can repair an incomplete schema.
        $sql_codes = "CREATE TABLE IF NOT EXISTS `{$t['codes']}` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `code` VARCHAR(80) NOT NULL,
            `bonus_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            `threshold_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            `status` VARCHAR(20) NOT NULL DEFAULT 'active',
            `created_by` BIGINT UNSIGNED DEFAULT NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `promo_code_unique` (`code`),
            KEY `promo_status_idx` (`status`)
        ) {$charset};";

        $sql_usage = "CREATE TABLE IF NOT EXISTS `{$t['usage']}` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `promo_code_id` BIGINT UNSIGNED NOT NULL,
            `user_id` BIGINT UNSIGNED NOT NULL,
            `bonus_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `promo_user_unique` (`promo_code_id`, `user_id`),
            KEY `promo_id_idx` (`promo_code_id`),
            KEY `promo_user_idx` (`user_id`)
        ) {$charset};";

        dbDelta($sql_codes);
        dbDelta($sql_usage);

        // Repair older/partially-created tables column-by-column. Do not rely
        // on ADD COLUMN IF NOT EXISTS because older MySQL/MariaDB versions may
        // reject that syntax.
        $ensure_column = static function(string $table, string $column, string $definition) use ($wpdb): void {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s",
                $table,
                $column
            ));
            if ((int)$exists === 0) {
                $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
            }
        };

        $ensure_column($t['codes'], 'code', "VARCHAR(80) NOT NULL");
        $ensure_column($t['codes'], 'bonus_amount', "DECIMAL(14,2) NOT NULL DEFAULT 0.00");
        $ensure_column($t['codes'], 'threshold_amount', "DECIMAL(14,2) NOT NULL DEFAULT 0.00");
        $ensure_column($t['codes'], 'status', "VARCHAR(20) NOT NULL DEFAULT 'active'");
        $ensure_column($t['codes'], 'created_by', "BIGINT UNSIGNED DEFAULT NULL");
        $ensure_column($t['codes'], 'created_at', "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP");
        $ensure_column($t['codes'], 'updated_at', "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

        $ensure_column($t['usage'], 'promo_code_id', "BIGINT UNSIGNED NOT NULL");
        $ensure_column($t['usage'], 'user_id', "BIGINT UNSIGNED NOT NULL");
        $ensure_column($t['usage'], 'bonus_amount', "DECIMAL(14,2) NOT NULL DEFAULT 0.00");
        $ensure_column($t['usage'], 'created_at', "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP");

        // Existing users table: only the two fields requested by the owner.
        $ensure_column($t['users'], 'promo_bonus_pending', "DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `wallet`");
        $ensure_column($t['users'], 'promo_bonus_unlocked', "TINYINT(1) NOT NULL DEFAULT 0 AFTER `promo_bonus_pending`");

        update_option('pulsepoint_promo_bonus_schema_version', '2.3.8', false);
    }
}
/**
 * Release a user's pending signup bonus when qualifying successful debit
 * transactions reach the threshold stored with the promo code.
 *
 * Existing wallet spending code is untouched: pending bonus is excluded
 * until this function atomically moves it into wallet.
 */
if (!function_exists('pulsepoint_maybe_release_signup_bonus')) {
    function pulsepoint_maybe_release_signup_bonus(int $user_id): bool {
        if ($user_id <= 0) {
            return false;
        }

        global $wpdb;
        $t = pulsepoint_promo_tables();

        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT id, wallet, promo_bonus_pending, promo_bonus_unlocked
             FROM `{$t['users']}`
             WHERE id = %d
             LIMIT 1",
            $user_id
        ));

        if (!$user || (float)$user->promo_bonus_pending <= 0 || (int)$user->promo_bonus_unlocked === 1) {
            return false;
        }

        // Threshold belongs to the promo code actually used by this user.
        $threshold = (float)$wpdb->get_var($wpdb->prepare(
            "SELECT pc.threshold_amount
             FROM `{$t['usage']}` pu
             INNER JOIN `{$t['codes']}` pc ON pc.id = pu.promo_code_id
             WHERE pu.user_id = %d
             ORDER BY pu.id DESC
             LIMIT 1",
            $user_id
        ));

        // Calculate qualifying service/trade spending from successful debit
        // transactions. Funding/deposits never count toward the threshold.
        $qualifying = (float)$wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0)
             FROM `{$t['trnx']}`
             WHERE user_id = %d
               AND status = 'success'
               AND type = 'debit'
               AND category <> 'funding'
               AND amount > 0",
            $user_id
        ));

        // Zero threshold means no qualifying spend is required.
        if ($threshold > 0 && $qualifying < $threshold) {
            return false;
        }

        // Atomic release prevents the same pending bonus from being credited
        // twice if two requests check the account at the same time.
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE `{$t['users']}`
             SET wallet = wallet + promo_bonus_pending,
                 promo_bonus_pending = 0,
                 promo_bonus_unlocked = 1,
                 updated_at = %s
             WHERE id = %d
               AND promo_bonus_pending > 0
               AND promo_bonus_unlocked = 0",
            current_time('mysql', 1),
            $user_id
        ));

        return $updated === 1;
    }
}

/**
 * Check eligible users during normal authenticated/session requests.
 * This does not alter the user balance API.
 */
add_action('init', function () {
    if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) {
        $session_user = $_SESSION['pulsepoint_user']['id'] ?? 0;
        if ($session_user) {
            pulsepoint_maybe_release_signup_bonus((int)$session_user);
        }
    }
}, 20);
