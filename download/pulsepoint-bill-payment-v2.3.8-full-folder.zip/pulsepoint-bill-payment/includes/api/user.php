<?php
/**
 * Pulsepoint API Fetch User Details
 * Path: /api/users.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data POST
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode([
        'success' => false,
        'message' => 'Token is required'
    ]);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table = $base_prefix . 'users';

// Fetch user by token
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, firstname, lastname, phone, email,
                wallet, promo_bonus_pending, dollar,
                referral_balance, token, account_type, status
        FROM `{$table}`
        WHERE token = %s
        LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
    exit;
}

// Check if account is active
if ((int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Account inactive'
    ]);
    exit;
}

// Get normal wallet
$wallet_balance = (float)$user->wallet;

// Get pending promo bonus
$promo_bonus_pending = (float)($user->promo_bonus_pending ?? 0);

// Combine wallet + promo bonus
$total_wallet = $wallet_balance + $promo_bonus_pending;

// Format balances
$wallet = '₦' . number_format($total_wallet, 2, '.', ',');
$dollar = '$' . number_format((float)$user->dollar, 2, '.', ',');
$referral_balance = '₦' . number_format(
    (float)$user->referral_balance,
    2,
    '.',
    ','
);

// Return user details
echo json_encode([
    'success' => true,
    'message' => 'User fetched successfully',
    'user' => [
        'id' => $user->id,
        'firstname' => $user->firstname,
        'lastname' => $user->lastname,
        'email' => $user->email,
        'phone' => $user->phone,

        // wallet + promo_bonus_pending
        'wallet' => $wallet,

        'dollar' => $dollar,
        'referral_balance' => $referral_balance,
        'token' => $user->token,
        'account_type' => $user->account_type,
        'status' => $user->status
    ]
]);

exit;
