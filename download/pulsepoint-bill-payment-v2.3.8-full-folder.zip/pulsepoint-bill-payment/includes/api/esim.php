<?php
/** Pulsepoint eSIM API adapter - /api/esim */
require_once $_SERVER['DOCUMENT_ROOT'].'/wp-load.php';

global $wpdb;
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json(['success'=>false,'message'=>'Invalid request method'],405);
}

$headers = getallheaders();
$auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
if (!preg_match('/Token\s+(\S+)/i', $auth, $m)) {
    wp_send_json(['success'=>false,'message'=>'Missing or invalid Authorization header'],401);
}

$token = sanitize_text_field($m[1]);
$users = $wpdb->prefix.'pulsepoint_users';
$user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$users} WHERE token=%s",$token));
if (!$user) {
    wp_send_json(['success'=>false,'message'=>'Invalid or expired token'],401);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = [];

$action = sanitize_key($input['action'] ?? 'packages');
$handler = WP_PLUGIN_DIR.'/pulsepoint-bill-payment/core/esim/pulsepoint.php';

if (!file_exists($handler)) {
    wp_send_json(['success'=>false,'message'=>'eSIM handler not found'],500);
}
require_once $handler;

if (!session_id()) session_start();
$_SESSION['pulsepoint_user']['id'] = $user->id;
$_SESSION['pulsepoint_user']['token'] = $token;

try {
    switch ($action) {
        case 'packages':
        case 'plans':
            $country = sanitize_text_field($input['country'] ?? '');
            if ($country === '') {
                wp_send_json(['success'=>false,'message'=>'country is required'],422);
            }
            $r = pulsepoint_esim_packages(
                $country,
                sanitize_text_field($input['data'] ?? ''),
                (int)($input['page'] ?? 1),
                (int)($input['per_page'] ?? 20)
            );
            break;

        case 'purchase':
            $product_id = sanitize_text_field($input['product_id'] ?? $input['packageCode'] ?? '');
            $country = sanitize_text_field($input['country'] ?? '');
            $recipient_email = sanitize_email($input['recipient_email'] ?? $user->email);

            if ($product_id === '' || $country === '') {
                wp_send_json(['success'=>false,'message'=>'product_id and country are required'],422);
            }

            $r = pulsepoint_esim_purchase(
                $user->id,
                $product_id,
                $recipient_email,
                $country,
                sanitize_text_field($input['reference'] ?? '')
            );
            break;

        case 'history':
            $r = pulsepoint_esim_history($input['start'] ?? '', $input['length'] ?? 20, $input['search'] ?? '');
            break;

        case 'profile':
            $r = pulsepoint_esim_profile($input['transaction_id'] ?? $input['transactionId'] ?? '');
            break;

        default:
            wp_send_json([
                'success'=>false,
                'message'=>'Unsupported eSIM action. Use packages, purchase, history, or profile.'
            ],422);
    }
} catch (Throwable $e) {
    wp_send_json([
        'success'=>false,
        'message'=>'eSIM service error',
        'error'=>WP_DEBUG ? $e->getMessage() : null
    ],500);
}

wp_send_json($r);
