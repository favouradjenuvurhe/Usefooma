<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']); exit; }
$headers=function_exists('getallheaders')?getallheaders():[]; $auth=$headers['Authorization']??($headers['authorization']??'');
if(!preg_match('/Token\s+(\S+)/',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]); $users=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT id,status FROM {$users} WHERE token=%s",$token));
if(!$user || (int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}
$mode=get_option('pulsepoint_giftcard_purchase_mode','manual');
if($mode==='api'){
  $base=untrailingslashit(get_option('pulsepoint_giftcard_api_base','https://appapi.kripicard.com/api/external/gifts')); $key=(string)get_option('pulsepoint_giftcard_api_key','');
  if($key===''){echo wp_json_encode(['success'=>false,'message'=>'Giftcard API is enabled but the API key is not configured.']);exit;}
  $country=strtoupper(sanitize_text_field($_POST['country']??'')); $search=sanitize_text_field($_POST['search']??'');
  $body=['api_key'=>$key]; if($country!=='')$body['country']=$country; if($search!=='')$body['search']=$search;
  $res=wp_remote_post($base.'/packages',['timeout'=>30,'headers'=>['Content-Type'=>'application/json','Accept'=>'application/json'],'body'=>wp_json_encode($body)]);
  if(is_wp_error($res)){echo wp_json_encode(['success'=>false,'message'=>'Unable to reach giftcard API: '.$res->get_error_message()]);exit;}
  $json=json_decode(wp_remote_retrieve_body($res),true); if(!is_array($json)||empty($json['success'])){echo wp_json_encode($json?:['success'=>false,'message'=>'Giftcard API returned an invalid response.']);exit;}
  $fx=(float)get_option('pulsepoint_giftcard_api_fx_rate',1); $markup=max(0,(float)get_option('pulsepoint_giftcard_api_markup',0));
  foreach(($json['data']['products']??[]) as &$x){$x['wallet_rate']=$fx;$x['wallet_markup_percent']=$markup;$x['wallet_price_basis']='local_amount × NGN rate × (1 + markup%)';$x['wallet_price_examples']=[]; foreach(($x['fixed_denominations']??[]) as $d){$x['wallet_price_examples'][]=['local_amount'=>(float)$d,'wallet_price'=>(float)$d*$fx*(1+$markup/100)];}}
  unset($x); echo wp_json_encode($json);exit;
}
$stock=$wpdb->prefix.'pulsepoint_giftcard_stock';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';
$rows=$wpdb->get_results("SELECT s.id,s.giftcard_id,s.face_value,s.sale_price,s.type,s.status,s.expires_at,g.category,g.sub_category,g.image_url,g.rate FROM {$stock} s INNER JOIN {$settings} g ON g.id=s.giftcard_id WHERE s.status='available' AND g.status='active' ORDER BY g.category,g.sub_category,s.face_value,s.id DESC");
$data=[];foreach($rows as $r){$data[]=['id'=>(int)$r->id,'giftcard_id'=>(int)$r->giftcard_id,'category'=>$r->category,'sub_category'=>$r->sub_category,'face_value'=>(float)$r->face_value,'sale_price'=>(float)$r->sale_price,'type'=>$r->type,'image_url'=>$r->image_url,'rate'=>(float)$r->rate,'expires_at'=>$r->expires_at];}
echo wp_json_encode(['success'=>true,'mode'=>'manual','data'=>$data]);exit;
