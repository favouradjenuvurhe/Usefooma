<?php
/**
 * Pulsepoint App Router (Full-screen, themeable views, fixed prefixes)
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/public.php
 * Author: Amaaavl
 *
 * Routing (no shortcode needed anywhere):
 *   /auth/login
 *   /auth/signup            (internally resolves to the "register" view)
 *   /auth/recovery
 *   /auth/verification
 *   /auth/reset-password
 *   /auth/logout
 *   /dashboard
 *   /dashboard/{page}       e.g. /dashboard/airtime, /dashboard/data
 *   /404                    directly visitable, for testing/QA
 *
 *   /app                    → forced redirect to /dashboard
 *   /app/{anything}         → forced redirect to /dashboard
 *     (e.g. /app/dashboard, /app/login, /app/whatever all land on
 *     /dashboard immediately — /app is not a real route, it's just
 *     an alias catch-all that bounces straight to /dashboard, which
 *     then applies its own normal auth checks)
 *
 * View resolution order for every route (including dashboard addons
 * and the 404 view):
 *   1. Active pulsepoint-*-theme plugin → {theme}/view/default/{route}.php
 *   2. Fallback → includes/app/view/default/{route}.php
 *
 * 404 behavior (SITE-WIDE):
 *   - Unknown /auth/{slug}            → our 404
 *   - Unknown /dashboard/{slug}       → our 404
 *   - Missing view file for any route → our 404
 *   - ANY other WordPress URL that resolves to WP's native is_404()
 *     (deleted post, bad permalink, random junk URL, etc.) → our 404,
 *     intercepted BEFORE the active theme's own 404.php can load.
 *   - The browser URL is left untouched (soft-404: real HTTP 404
 *     status, but no redirect to /404 — keeps bookmarks/SEO clean).
 *
 * pulsepoint_get_theme_path() and pulsepoint_theme_file() live ONLY in
 * theme-loader.php — this file just requires it.
 *
 * IMPORTANT: after deploying this file, visit WP Admin → Settings →
 * Permalinks → Save (once) to flush rewrite rules so /auth/*,
 * /dashboard/*, /app/*, and /404 start resolving.
 */

if (!defined('ABSPATH')) exit;

/* ======================================================
   LOAD THEME RESOLVER
   ====================================================== */
if (!function_exists('pulsepoint_theme_file')) {
    require_once __DIR__ . '/theme-loader.php';
}

/* ======================================================
   REWRITE RULES — /auth/{route}, /dashboard[/{page}], /app[/*], /404
   ====================================================== */
add_action('init', function () {
    add_rewrite_rule(
        '^auth/([^/]+)/?$',
        'index.php?pulsepoint_area=auth&pulsepoint_route=$matches[1]',
        'top'
    );
    add_rewrite_rule(
        '^dashboard/([^/]+)/?$',
        'index.php?pulsepoint_area=dashboard&pulsepoint_route=$matches[1]',
        'top'
    );
    add_rewrite_rule(
        '^dashboard/?$',
        'index.php?pulsepoint_area=dashboard&pulsepoint_route=dashboard',
        'top'
    );
    // Catch-all: /app, /app/dashboard, /app/login, /app/anything...
    // all get funneled through one query var and bounced to /dashboard.
    add_rewrite_rule(
        '^app(?:/.*)?/?$',
        'index.php?pulsepoint_area=app',
        'top'
    );
    add_rewrite_rule(
        '^p/([^/]+)/?$',
        'index.php?pulsepoint_area=storefront&pulsepoint_route=$matches[1]',
        'top'
    );
    add_rewrite_rule(
        '^404/?$',
        'index.php?pulsepoint_area=404',
        'top'
    );
});

add_filter('query_vars', function ($vars) {
    $vars[] = 'pulsepoint_area';
    $vars[] = 'pulsepoint_route';
    return $vars;
});

/* ======================================================
   START SESSION
   ====================================================== */
if (!function_exists('pulsepoint_start_session')) {
    function pulsepoint_start_session() {
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            if (function_exists('pulsepoint_prepare_long_session')) {
                pulsepoint_prepare_long_session();
            }
            session_start([
                'cookie_lifetime' => defined('PULSEPOINT_SESSION_LIFETIME') ? PULSEPOINT_SESSION_LIFETIME : (90 * DAY_IN_SECONDS),
                'cookie_httponly' => true,
                'cookie_samesite' => 'Lax',
                'use_strict_mode' => true,
            ]);
        }
    }
}
add_action('init', 'pulsepoint_start_session', 1);

/* ======================================================
   ROUTE TABLES
   ====================================================== */
if (!function_exists('pulsepoint_auth_routes')) {
    // public URL slug => internal view name
    function pulsepoint_auth_routes() {
        return [
            'login'          => 'login',
            'signup'         => 'register',
            'recovery'       => 'recovery',
            'verification'   => 'verification',
            'reset-password' => 'reset-password',
            'logout'         => 'logout',
        ];
    }
}

if (!function_exists('pulsepoint_auth_routes_open_when_logged_out')) {
    // routes reachable without being logged in
    function pulsepoint_auth_routes_open_when_logged_out() {
        return ['login', 'signup', 'recovery', 'verification', 'reset-password'];
    }
}

/* ======================================================
   FULL PAGE INTERCEPT
   ====================================================== */
add_action('template_redirect', function () {

    $area = get_query_var('pulsepoint_area');

    // License status does not block the public app.
    // Expired subscriptions only disable plugin updates; existing site
    // functionality remains available.

    // /app, /app/dashboard, /app/login, /app/whatever-else →
    // treated as /dashboard immediately. No auth logic here on
    // purpose — we just hand off to /dashboard, which already does
    // its own login/verification checks.
    if ($area === 'app') {
        wp_safe_redirect(home_url('/dashboard'));
        exit;
    }

    if ($area === 'storefront') {
        pulsepoint_render_storefront_route();
        exit;
    }

    if ($area === 'auth') {
        pulsepoint_render_auth_route();
        exit;
    }

    if ($area === 'dashboard') {
        pulsepoint_render_dashboard_route();
        exit;
    }

    if ($area === '404') {
        pulsepoint_render_404();
        exit;
    }

    // NOT a pulsepoint URL — but if WordPress itself couldn't resolve
    // the request to any post/page/archive/etc, it already flagged
    // is_404(). Hijack it here, BEFORE the active theme gets a chance
    // to load its own 404.php, so OUR 404 wins site-wide.
    if (is_404()) {
        pulsepoint_render_404();
        exit;
    }

    // a real, resolvable WP page — let WP handle it normally

}, 5); // priority 5: run early, well before template loading

/* ======================================================
   PUBLIC STOREFRONT ROUTE — /p/{storename}
   ====================================================== */
if (!function_exists('pulsepoint_render_storefront_route')) {
function pulsepoint_render_storefront_route() {
    $slug = sanitize_title((string) get_query_var('pulsepoint_route'));

    if (!function_exists('pulsepoint_addon_active') || !pulsepoint_addon_active('storefront')) {
        pulsepoint_render_404();
        return;
    }

    // The public storefront must never fatal if WooCommerce is missing or only partially loaded.
    // The management dashboard can still exist without WooCommerce; the public page simply
    // reports that checkout is unavailable.
    $woo_ready = function_exists('pulsepoint_storefront_woo_active')
        && pulsepoint_storefront_woo_active()
        && function_exists('wc_get_product')
        && function_exists('wc_get_cart_url')
        && function_exists('wc_price');

    if (!$woo_ready) {
        status_header(503);
        nocache_headers();
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Storefront unavailable</title></head><body style="font-family:Inter,Arial,sans-serif;background:#f8fafc;color:#111827;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px"><div style="max-width:520px;text-align:center;background:#fff;border-radius:20px;padding:32px;box-shadow:0 10px 30px rgba(0,0,0,.06)"><h1 style="margin:0 0 10px">Storefront unavailable</h1><p style="color:#6b7280;margin:0">This storefront is temporarily unavailable because WooCommerce is not fully active.</p></div></body></html>';
        return;
    }

    $store = function_exists('pulsepoint_storefront_get_store_by_slug') ? pulsepoint_storefront_get_store_by_slug($slug) : null;
    if (!$store || $store->status !== 'active') {
        pulsepoint_render_404();
        return;
    }

    status_header(200);
    nocache_headers();
    $file = pulsepoint_theme_file('view/storefront.php');
    if ($file && pulsepoint_safe_include_path($file)) {
        include $file;
        return;
    }
    pulsepoint_render_404();
}
}

/* ======================================================
   AUTH ROUTE RENDERER — /auth/{route}
   ====================================================== */
if (!function_exists('pulsepoint_render_auth_route')) {
function pulsepoint_render_auth_route() {

    $slug   = sanitize_file_name((string) get_query_var('pulsepoint_route'));
    $routes = pulsepoint_auth_routes();

    $view = $routes[$slug] ?? null;

    // unknown /auth/{slug} → true 404, not a silent redirect to login
    if ($view === null) {
        pulsepoint_render_404();
        return;
    }

    $is_logged_in = !empty($_SESSION['pulsepoint_user']);

    // logged-in users shouldn't see login/signup again
    if ($is_logged_in && in_array($slug, ['login', 'signup'], true)) {
        wp_safe_redirect(home_url('/dashboard'));
        exit;
    }

    // logout only makes sense when logged in; everything else in the
    // "open" list is fine whether logged in or not except forcing
    if ($slug === 'logout' && !$is_logged_in) {
        wp_safe_redirect(home_url('/auth/login'));
        exit;
    }

    // email verification force: if logged in & unverified, only
    // /auth/verification and /auth/logout stay reachable
    if ($is_logged_in && $slug !== 'verification' && $slug !== 'logout') {
        if (pulsepoint_user_needs_verification()) {
            wp_safe_redirect(home_url('/auth/verification'));
            exit;
        }
    }

    status_header(200);
    nocache_headers();

    pulsepoint_load_view($view);
}
}

/* ======================================================
   DASHBOARD ROUTE RENDERER — /dashboard or /dashboard/{page}
   ====================================================== */
if (!function_exists('pulsepoint_render_dashboard_route')) {
function pulsepoint_render_dashboard_route() {

    $slug = sanitize_file_name((string) get_query_var('pulsepoint_route'));
    $slug = $slug !== '' ? $slug : 'dashboard';

    $is_logged_in = !empty($_SESSION['pulsepoint_user']);

    if (!$is_logged_in) {
        wp_safe_redirect(home_url('/auth/login'));
        exit;
    }

    if (pulsepoint_user_needs_verification()) {
        wp_safe_redirect(home_url('/auth/verification'));
        exit;
    }

    $addon_routes  = apply_filters('pulsepoint_addon_routes', []);
    $is_addon      = in_array($slug, (array) $addon_routes, true);
    $is_dashboard  = ($slug === 'dashboard');

    // unknown /dashboard/{slug} → true 404 instead of bouncing to /dashboard
    if (!$is_dashboard && !$is_addon) {
        pulsepoint_render_404();
        return;
    }

    status_header(200);
    nocache_headers();

    pulsepoint_load_view($slug);
}
}

/* ======================================================
   VERIFICATION CHECK (shared by auth + dashboard renderers)
   ====================================================== */
if (!function_exists('pulsepoint_user_needs_verification')) {
function pulsepoint_user_needs_verification() {

    global $wpdb;

    $user_id = $_SESSION['pulsepoint_user']['id'] ?? 0;
    if (!$user_id) return false;

    $table = $wpdb->prefix . 'pulsepoint_users';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT status_email FROM `{$table}` WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    return $user && (int) $user->status_email === 0;
}
}

/* ======================================================
   VIEW LOADER — resolves via theme-loader.php and
   validates the resolved path before including it
   ====================================================== */
if (!function_exists('pulsepoint_load_view')) {
function pulsepoint_load_view($route) {

    $file = pulsepoint_theme_file('view/' . $route . '.php');

    // view genuinely missing (bad theme, deleted file, etc.) → 404,
    // never a hard wp_die crash
    if (!$file || !pulsepoint_safe_include_path($file)) {
        pulsepoint_render_404();
        return;
    }

    include $file;
}
}

/* ======================================================
   LICENSE GATE — reads the flag the license-check cron writes
   ====================================================== */
if (!function_exists('pulsepoint_license_blocked')) {
function pulsepoint_license_blocked() {

    global $wpdb;
    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table = "{$base_prefix}settings";

    $value = $wpdb->get_var($wpdb->prepare(
        "SELECT opt_value FROM {$table} WHERE opt_key = %s",
        'license_valid'
    ));

    // Never checked yet (fresh install, cron hasn't run) → don't block.
    if ($value === null) return false;

    return maybe_unserialize($value) == '0';
}
}

if (!function_exists('pulsepoint_render_unauthorized')) {
function pulsepoint_render_unauthorized() {

    nocache_headers();

    $file = pulsepoint_theme_file('view/usefooma.php');

    if ($file && pulsepoint_safe_include_path($file)) {
        include $file;
        return;
    }

    status_header(503);
    echo '<!DOCTYPE html><html><head><title>Unauthorized Access</title></head><body style="font-family:sans-serif;text-align:center;padding:80px 20px;">'
        . '<h1>Unauthorized Access</h1>'
        . '<p>This site\'s license or subscription is not active.</p>'
        . '</body></html>';
}
}

/* ======================================================
   404 RENDERER — themeable, with a safe last-resort fallback
   ====================================================== */
if (!function_exists('pulsepoint_render_404')) {
function pulsepoint_render_404() {

    status_header(404);
    nocache_headers();

    $file = pulsepoint_theme_file('view/404.php');

    if ($file && pulsepoint_safe_include_path($file)) {
        include $file;
        return;
    }

    // last-resort inline fallback so a missing 404.php never
    // turns into a blank page or a fatal error
    pulsepoint_render_404_fallback();
}
}

if (!function_exists('pulsepoint_render_404_fallback')) {
function pulsepoint_render_404_fallback() {
    $home = esc_url(home_url('/'));
    $dashboard = esc_url(home_url('/dashboard'));
    ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, follow">
    <title>404 — Page Not Found</title>
    <style>
    html,body{
        height:100%;
        margin:0;
    }

    body{
        display:flex;
        align-items:center;
        justify-content:center;
        font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
        background:#ffffff;
        color:#111827;
        text-align:center;
        padding:24px;
        box-sizing:border-box;
    }

    .pp-404{
        max-width:420px;
    }

    .pp-404 h1{
        font-size:88px;
        margin:0;
        line-height:1;
        letter-spacing:-2px;
        color:#111827;
    }

    .pp-404 p{
        font-size:16px;
        color:#6b7280;
        margin:16px 0 28px;
    }

    .pp-404 a{
        display:inline-block;
        margin:0 6px;
        padding:12px 22px;
        border-radius:8px;
        text-decoration:none;
        font-weight:600;
        font-size:14px;
        transition:.2s ease;
    }

    .pp-404 .primary{
        background:#000000;
        color:#ffffff;
    }

    .pp-404 .primary:hover{
        background:#1d4ed8;
    }

    .pp-404 .secondary{
        border:1px solid #d1d5db;
        color:#111827;
        background:#ffffff;
    }

    .pp-404 .secondary:hover{
        background:#f9fafb;
    }
</style>
</head>
<body>
    <div class="pp-404">
        <h1>404</h1>
        <p>The page you're looking for doesn't exist or may have been moved.</p>
        <a class="primary" href="<?php echo $dashboard; ?>">Go to Dashboard</a>
        <a class="secondary" href="<?php echo $home; ?>">Home</a>
    </div>
</body>
</html>
    <?php
}
}

/* ======================================================
   SECURITY: block path traversal
   ====================================================== */
if (!function_exists('pulsepoint_safe_include_path')) {
function pulsepoint_safe_include_path($file) {

    $real_file = realpath($file);
    if (!$real_file) return false;

    $theme_path = function_exists('pulsepoint_get_theme_path') ? pulsepoint_get_theme_path() : false;

    $allowed_bases = array_filter([
        defined('PULSEPOINT_DIR') ? realpath(PULSEPOINT_DIR) : realpath(__DIR__),
        $theme_path ? realpath($theme_path) : false,
    ]);

    foreach ($allowed_bases as $base) {
        if ($base && strpos($real_file, $base) === 0) {
            return true;
        }
    }

    return false;
}
}
