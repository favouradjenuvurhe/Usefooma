<?php
if (!defined('ABSPATH')) {
    require_once __DIR__ . '/wp-load.php';
}

global $wpdb;

session_start();

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table       = $base_prefix . 'users';

/**
 * ============================
 * GOOGLE OAUTH CONFIG
 * ============================
 */
$client_id     = '963442018052-3d7k7b3omdu7p39h9snn1018ep4mp92r.apps.googleusercontent.com';
$client_secret = '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';
$redirect_uri  = site_url('/callback/google-auth/');

/**
 * ============================
 * GET AUTH CODE
 * ============================
 */
if (!isset($_GET['code'])) {
    wp_redirect(site_url('/app/login?error=missing_code'));
    exit;
}

$code = sanitize_text_field($_GET['code']);

/**
 * ============================
 * EXCHANGE CODE FOR TOKEN
 * ============================
 */
$response = wp_remote_post('https://oauth2.googleapis.com/token', [
    'body' => [
        'code'          => $code,
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
        'redirect_uri'  => $redirect_uri,
        'grant_type'    => 'authorization_code'
    ],
    'headers' => [
        'Content-Type' => 'application/x-www-form-urlencoded'
    ]
]);

if (is_wp_error($response)) {
    wp_die('Google token request failed.');
}

$token_body = json_decode(wp_remote_retrieve_body($response), true);

if (empty($token_body['id_token'])) {
    wp_die('Invalid Google token response.');
}

$id_token = $token_body['id_token'];

/**
 * ============================
 * VERIFY ID TOKEN
 * ============================
 */
$verify = wp_remote_get('https://oauth2.googleapis.com/tokeninfo?id_token=' . $id_token);

if (is_wp_error($verify)) {
    wp_die('Failed to verify Google token.');
}

$user_data = json_decode(wp_remote_retrieve_body($verify), true);

if (empty($user_data['email_verified']) || $user_data['email_verified'] !== 'true') {
    wp_die('Google email not verified.');
}

$email     = sanitize_email($user_data['email']);
$firstname = sanitize_text_field($user_data['given_name'] ?? '');
$lastname  = sanitize_text_field($user_data['family_name'] ?? '');

/**
 * ============================
 * CHECK IF USER EXISTS
 * ============================
 */
$user = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM {$table} WHERE email = %s LIMIT 1", $email)
);

/**
 * ============================
 * AUTO-CREATE USER (MATCHES REGISTER)
 * ============================
 */
if (!$user) {

    /** Load settings */
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $account_limit = isset($settings['account_limit']) ? floatval($settings['account_limit']) : 5000.00;
    $auth_email    = isset($settings['auth_email']) ? intval($settings['auth_email']) : 0;

    /** Email verification logic */
    $status        = 1;
    $security_code = null;

    if ($auth_email === 1) {
        $status        = 0;
        $security_code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    /** Token generation (SAME AS REGISTER) */
    $prefix = 'PS-NG';
    $random_len = 30 - strlen($prefix);
    $pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $rand = '';

    for ($i = 0; $i < $random_len; $i++) {
        $rand .= $pool[random_int(0, strlen($pool) - 1)];
    }

    $token = $prefix . $rand;

    /** Defaults */
    $password_hash = password_hash(bin2hex(random_bytes(12)), PASSWORD_DEFAULT);
    $passcode      = '1234';

    /** Insert user */
    $inserted = $wpdb->insert(
        $table,
        [
            'firstname'        => $firstname,
            'lastname'         => $lastname,
            'phone'            => null,
            'email'            => $email,
            'wallet'           => 0.00,
            'referral_balance' => 0.00,
            'referby'          => null,
            'token'            => $token,
            'passcode'         => $passcode,
            'password'         => $password_hash,
            'security_code'    => $security_code,
            'account_limit'    => $account_limit,
            'status'           => $status,
            'created_at'       => current_time('mysql', 1),
            'updated_at'       => current_time('mysql', 1),
        ],
        [
            '%s','%s','%s','%s','%f','%f','%d','%s','%s','%s','%s','%f','%d','%s','%s'
        ]
    );

    if ($inserted === false) {
        wp_die('Google registration failed.');
    }

    $user_id = $wpdb->insert_id;

    /** Send OTP email if enabled */
    if ($auth_email === 1) {
        $platform_name = $settings['platform_name'] ?? 'Pulsepoint';

        pulsepoint_send_transaction_email(
            $email,
            "Verify your {$platform_name} account",
            [
                'status_label' => 'VERIFY EMAIL',
                'status_color' => '#356cf9',
                'heading'      => 'Verify Your Account',
                'firstname'    => $firstname,
                'message'      => 'Use the verification code below to confirm your account.',
                'details'      => [
                    'Verification Code' => $security_code,
                ],
            ]
        );
    }

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d LIMIT 1", $user_id)
    );
}

/**
 * ============================
 * START SESSION (SAME STRUCTURE)
 * ============================
 */
$_SESSION['pulsepoint_user'] = [
    'id'            => $user->id,
    'firstname'     => $user->firstname,
    'lastname'      => $user->lastname,
    'email'         => $user->email,
    'phone'         => $user->phone,
    'wallet'        => $user->wallet,
    'token'         => $user->token,
    'account_limit' => $user->account_limit,
];

/** Cookie */
setcookie(
    'pulsepoint_user_session',
    session_id(),
    time() + (defined('PULSEPOINT_SESSION_LIFETIME') ? PULSEPOINT_SESSION_LIFETIME : (90 * DAY_IN_SECONDS)),
    '/',
    $_SERVER['SERVER_NAME'],
    is_ssl(),
    true
);

/**
 * ============================
 * REDIRECT
 * ============================
 */
wp_redirect(
    ($user->status == 0)
        ? site_url('/app/verification')
        : site_url('/app/dashboard')
);
exit;