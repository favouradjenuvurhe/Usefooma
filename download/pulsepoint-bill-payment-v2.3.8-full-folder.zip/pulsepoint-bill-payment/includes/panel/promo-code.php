<?php
/**
 * Pulsepoint Promo Code Management
 * Path: /includes/panel/promo-code.php
 */
if (!defined('ABSPATH')) exit;

if (!current_user_can('manage_options')) {
    wp_die('You do not have permission to access this page.');
}

global $wpdb;

// Ensure promo tables/columns exist before any promo-code query or insert.
// This is required on upgrades because WordPress plugin activation hooks do not
// necessarily run again when an existing plugin is replaced by a ZIP update.
if (!function_exists('pulsepoint_promo_schema')) {
    $promo_bonus_file = dirname(__DIR__) . '/promo-bonus.php';
    if (file_exists($promo_bonus_file)) {
        require_once $promo_bonus_file;
    }
}
if (function_exists('pulsepoint_promo_schema')) {
    pulsepoint_promo_schema();
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$codes_table = $base_prefix . 'promo_codes';
$usage_table = $base_prefix . 'promo_code_usage';
$settings_table = $base_prefix . 'settings';

$notice = '';
$error = '';

$settings_get = function($key, $default = '') use ($wpdb, $settings_table) {
    $value = $wpdb->get_var($wpdb->prepare(
        "SELECT opt_value FROM `{$settings_table}` WHERE opt_key = %s LIMIT 1",
        $key
    ));
    return $value === null ? $default : maybe_unserialize($value);
};

$save_setting = function($key, $value) use ($wpdb, $settings_table) {
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM `{$settings_table}` WHERE opt_key = %s LIMIT 1",
        $key
    ));
    if ($exists) {
        return $wpdb->update(
            $settings_table,
            ['opt_value' => maybe_serialize($value)],
            ['opt_key' => $key],
            ['%s'],
            ['%s']
        );
    }
    return $wpdb->insert(
        $settings_table,
        ['opt_key' => $key, 'opt_value' => maybe_serialize($value), 'type' => 'number', 'grouping' => 'promo'],
        ['%s','%s','%s','%s']
    );
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['pulsepoint_promo_nonce']) || !wp_verify_nonce($_POST['pulsepoint_promo_nonce'], 'pulsepoint_promo_action')) {
        $error = 'Security check failed. Please refresh and try again.';
    } else {
        $action = sanitize_key($_POST['promo_action'] ?? '');

        if ($action === 'save_settings') {
            $bonus = max(0, (float)($_POST['bonus_amount'] ?? 0));
            $threshold = max(0, (float)($_POST['threshold_amount'] ?? 0));
            $save_setting('promo_bonus_amount', number_format($bonus, 2, '.', ''));
            $save_setting('promo_threshold_amount', number_format($threshold, 2, '.', ''));
            $notice = 'Promo settings saved successfully.';
        }

        if ($action === 'create_code') {
            $requested = strtoupper(trim(sanitize_text_field(wp_unslash($_POST['promo_code'] ?? ''))));
            $bonus = max(0, (float)($_POST['bonus_amount'] ?? $settings_get('promo_bonus_amount', 0)));
            $threshold = max(0, (float)($_POST['threshold_amount'] ?? $settings_get('promo_threshold_amount', 0)));

            if ($requested === '') {
                $requested = 'PP' . strtoupper(wp_generate_password(10, false, false));
            }

            $requested = preg_replace('/[^A-Z0-9_-]/', '', $requested);

            if ($requested === '' || strlen($requested) < 3 || strlen($requested) > 80) {
                $error = 'Promo code must contain 3–80 letters/numbers, hyphens or underscores.';
            } elseif ($bonus <= 0) {
                $error = 'Signup bonus amount must be greater than zero.';
            } elseif ($wpdb->get_var($wpdb->prepare("SELECT id FROM `{$codes_table}` WHERE code = %s LIMIT 1", $requested))) {
                $error = 'That promo code already exists.';
            } else {
                // Build the insert from columns that actually exist. This keeps
                // promo creation compatible with older installations whose promo
                // table was created before all metadata columns were introduced.
                $insert_data = [
                    'code' => $requested,
                    'bonus_amount' => $bonus,
                    'threshold_amount' => $threshold,
                    'status' => 'active',
                ];
                $insert_formats = ['%s','%f','%f','%s'];

                $has_created_by = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = 'created_by'",
                    $codes_table
                ));
                if ((int)$has_created_by > 0) {
                    $insert_data['created_by'] = get_current_user_id();
                    $insert_formats[] = '%d';
                }

                $created = $wpdb->insert($codes_table, $insert_data, $insert_formats);

                if ($created === false) {
                    // Keep the public/admin message generic, but log the real DB error
                    // so server logs reveal any installation-specific SQL problem.
                    if (!empty($wpdb->last_error)) {
                        error_log('[Pulsepoint Promo] Promo code creation failed: ' . $wpdb->last_error);
                    }
                    $error = 'Unable to create the promo code.';
                } else {
                    $notice = 'Promo code created: ' . $requested;
                }
            }
        }

        if ($action === 'toggle_code') {
            $id = absint($_POST['promo_id'] ?? 0);
            $current = $wpdb->get_var($wpdb->prepare("SELECT status FROM `{$codes_table}` WHERE id = %d", $id));
            if ($current !== null) {
                $new_status = $current === 'active' ? 'disabled' : 'active';
                $wpdb->update($codes_table, ['status' => $new_status], ['id' => $id], ['%s'], ['%d']);
                $notice = 'Promo code status updated.';
            }
        }
    }
}

$bonus_amount = (float)$settings_get('promo_bonus_amount', 0);
$threshold_amount = (float)$settings_get('promo_threshold_amount', 0);

$codes = $wpdb->get_results(
    "SELECT pc.*,
            (SELECT COUNT(*) FROM `{$usage_table}` pu WHERE pu.promo_code_id = pc.id) AS usage_count
     FROM `{$codes_table}` pc
     ORDER BY pc.id DESC"
);
?>
<div class="wrap">
    <h1>Promo Code</h1>
    <p>Signup promo codes use the existing referral field on registration. A successful promo signup receives its bonus in the separate Sign Bonus Wallet until the transaction threshold is reached.</p>

    <?php if ($notice): ?>
        <div class="notice notice-success is-dismissible"><p><?= esc_html($notice) ?></p></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="notice notice-error is-dismissible"><p><?= esc_html($error) ?></p></div>
    <?php endif; ?>

    <div style="max-width:1000px;background:#fff;padding:24px;border:1px solid #dcdcde;border-radius:8px;margin-top:20px;">
        <h2>Promo Settings</h2>
        <form method="post">
            <?php wp_nonce_field('pulsepoint_promo_action', 'pulsepoint_promo_nonce'); ?>
            <input type="hidden" name="promo_action" value="save_settings">
            <table class="form-table">
                <tr>
                    <th><label for="bonus_amount">Signup Bonus Amount</label></th>
                    <td><input name="bonus_amount" id="bonus_amount" type="number" min="0" step="0.01" value="<?= esc_attr(number_format($bonus_amount,2,'.','')) ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="threshold_amount">Transaction Threshold</label></th>
                    <td>
                        <input name="threshold_amount" id="threshold_amount" type="number" min="0" step="0.01" value="<?= esc_attr(number_format($threshold_amount,2,'.','')) ?>" class="regular-text">
                        <p class="description">Successful debit transaction volume required before the signup bonus is released to the normal wallet. Enter 0 to make the bonus immediately eligible.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Promo Settings'); ?>
        </form>
    </div>

    <div style="max-width:1000px;background:#fff;padding:24px;border:1px solid #dcdcde;border-radius:8px;margin-top:20px;">
        <h2>Generate Promo Code</h2>
        <form method="post">
            <?php wp_nonce_field('pulsepoint_promo_action', 'pulsepoint_promo_nonce'); ?>
            <input type="hidden" name="promo_action" value="create_code">
            <table class="form-table">
                <tr>
                    <th><label for="promo_code">Promo Code</label></th>
                    <td>
                        <input name="promo_code" id="promo_code" type="text" maxlength="80" placeholder="Leave blank for random code" class="regular-text">
                        <p class="description">Leave blank to generate a secure random code, or enter your own code.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="create_bonus_amount">Bonus Amount</label></th>
                    <td><input name="bonus_amount" id="create_bonus_amount" type="number" min="0" step="0.01" value="<?= esc_attr(number_format($bonus_amount,2,'.','')) ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="create_threshold_amount">Threshold Amount</label></th>
                    <td><input name="threshold_amount" id="create_threshold_amount" type="number" min="0" step="0.01" value="<?= esc_attr(number_format($threshold_amount,2,'.','')) ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button('Generate Promo Code'); ?>
        </form>
    </div>

    <div style="max-width:1000px;background:#fff;padding:24px;border:1px solid #dcdcde;border-radius:8px;margin-top:20px;">
        <h2>Promo Codes</h2>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Bonus</th>
                    <th>Threshold</th>
                    <th>Users Used</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$codes): ?>
                <tr><td colspan="7">No promo codes have been created yet.</td></tr>
            <?php else: foreach ($codes as $code): ?>
                <tr>
                    <td><strong><?= esc_html($code->code) ?></strong></td>
                    <td>₦<?= esc_html(number_format((float)$code->bonus_amount, 2)) ?></td>
                    <td>₦<?= esc_html(number_format((float)$code->threshold_amount, 2)) ?></td>
                    <td><?= esc_html((string)$code->usage_count) ?></td>
                    <td><?= esc_html(ucfirst($code->status)) ?></td>
                    <td><?= esc_html($code->created_at) ?></td>
                    <td>
                        <form method="post" style="display:inline">
                            <?php wp_nonce_field('pulsepoint_promo_action', 'pulsepoint_promo_nonce'); ?>
                            <input type="hidden" name="promo_action" value="toggle_code">
                            <input type="hidden" name="promo_id" value="<?= (int)$code->id ?>">
                            <button type="submit" class="button"><?= $code->status === 'active' ? 'Disable' : 'Enable' ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
