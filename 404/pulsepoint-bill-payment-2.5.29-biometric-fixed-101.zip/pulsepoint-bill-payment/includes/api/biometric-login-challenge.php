<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/wp-load.php';
require_once PULSEPOINT_DIR.'includes/api/biometric.php';
global $wpdb; header('Content-Type: application/json; charset=utf-8');
$in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
$email=sanitize_email($in['email']??'');
if(!$email) wp_send_json(['success'=>false,'message'=>'Email is required'],400);
$table=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT id,status,email,biometric_enabled,biometric_public_key,twofa_enabled FROM `{$table}` WHERE email=%s LIMIT 1",$email));
if(!$user || (int)$user->status!==1 || (int)$user->biometric_enabled!==1 || empty($user->biometric_public_key)) wp_send_json(['success'=>false,'message'=>'Biometric login is not enabled for this account'],403);
$challenge=pulsepoint_biometric_issue_challenge($user->id,'login','');
set_transient('pulsepoint_bio_login_'.$challenge,['user_id'=>(int)$user->id],120);
wp_send_json(['success'=>true,'challenge'=>$challenge,'expires_in'=>120,'requires_2fa'=>(int)$user->twofa_enabled===1]);
