<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/wp-load.php';
require_once PULSEPOINT_DIR.'includes/api/biometric.php';
global $wpdb; header('Content-Type: application/json; charset=utf-8');
$in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
$email=sanitize_email($in['email']??''); $challenge=sanitize_text_field($in['challenge']??''); $signature=sanitize_text_field($in['signature']??'');
if(!$email||!$challenge||!$signature) wp_send_json(['success'=>false,'message'=>'Biometric login data is incomplete'],400);
$key='pulsepoint_bio_login_'. $challenge; $pending=get_transient($key); if(!is_array($pending)){wp_send_json(['success'=>false,'message'=>'Biometric login challenge expired'],403);} delete_transient($key);
$table=$wpdb->prefix.'pulsepoint_users'; $user=$wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE id=%d AND email=%s LIMIT 1",(int)$pending['user_id'],$email));
if(!$user || (int)$user->status!==1 || (int)$user->biometric_enabled!==1 || empty($user->biometric_public_key)) wp_send_json(['success'=>false,'message'=>'Biometric login is unavailable'],403);
$pub=base64_decode($user->biometric_public_key,true); $sig=base64_decode($signature,true); if($pub===false||$sig===false) wp_send_json(['success'=>false,'message'=>'Invalid biometric signature'],403);
$pem="-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($pub),64,"\n")."-----END PUBLIC KEY-----\n";
if(openssl_verify($challenge,$sig,$pem,OPENSSL_ALGO_SHA256)!==1) wp_send_json(['success'=>false,'message'=>'Biometric verification failed'],403);
if((int)$user->twofa_enabled===1){
 if(session_status()!==PHP_SESSION_ACTIVE) @session_start();
 $_SESSION['pulsepoint_login_biometric_user_id']=(int)$user->id;
 wp_send_json(['success'=>true,'requires_2fa'=>true,'token'=>$user->token,'message'=>'Biometric verified. Enter your 2FA code to continue.']);
}
if(session_status()!==PHP_SESSION_ACTIVE) @session_start();
$_SESSION['pulsepoint_user']=[ 'id'=>(int)$user->id,'firstname'=>$user->firstname,'lastname'=>$user->lastname,'email'=>$user->email,'phone'=>$user->phone,'token'=>$user->token,'passcode'=>$user->passcode,'status'=>(int)$user->status ];
wp_send_json(['success'=>true,'requires_2fa'=>false,'redirect'=>home_url('/dashboard/'),'user'=>['id'=>(int)$user->id,'firstname'=>$user->firstname,'lastname'=>$user->lastname,'email'=>$user->email,'phone'=>$user->phone,'token'=>$user->token]]);
