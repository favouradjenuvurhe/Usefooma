<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
require_once PULSEPOINT_DIR . 'includes/api/biometric.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') wp_send_json(['success'=>false,'message'=>'Invalid request method'],405);
$in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
$token=sanitize_text_field($in['token']??''); $purpose=sanitize_key($in['purpose']??'transaction'); $payload=is_array($in['payload']??null)?$in['payload']:null; $payload_hash=sanitize_text_field($in['payload_hash']??''); if($payload!==null){$payload_hash=pulsepoint_biometric_payload_hash($payload);}
$user=pulsepoint_biometric_get_user_by_token($token);
if(!pulsepoint_biometric_is_enabled($user)) wp_send_json(['success'=>false,'message'=>'Biometric authentication is not enabled'],403);
if($payload_hash==='' || !preg_match('/^[a-f0-9]{64}$/',$payload_hash)) wp_send_json(['success'=>false,'message'=>'Invalid transaction challenge'],400);
wp_send_json(['success'=>true,'challenge'=>pulsepoint_biometric_issue_challenge($user->id,$purpose,$payload_hash),'expires_in'=>120]);
