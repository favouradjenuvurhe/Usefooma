# Changes in this build
**Card error "Invalid Authorization format."** – empty API token. Fixed in dashboard.php (token/PIN read from DB), create-card.php/fund-card.php (tolerant parsing, clear empty-token message), create-card/add-card/topup.html (guards).
**Hardening** – gift card upload images-only; card numbers/CVV/PIN masked in logs; logs deleted + .htaccess deny rules; DeepSeek key moved to wp-config constant PULSEPOINT_DEEPSEEK_API_KEY; customers.php needs PULSEPOINT_CUSTOMERS_API_SECRET; save_license admin-only; PIN kept in session for Telegram/email-verify logins.
## wp-config.php additions
define('PULSEPOINT_DEEPSEEK_API_KEY','<new key>');  // AI feature is off until set
define('PULSEPOINT_CUSTOMERS_API_SECRET','<long random>'); // customers.php is off until set
## NOT fixed (needs provider docs / behaviour change)
Unsigned webhooks: whogopay, cashwyre, cashwyre-crypto, strowallet, strocard. Server-side PIN check for card create/fund. Secret key in withdraw.html. Rotate all exposed keys.
Not executed: no PHP interpreter was available; test on staging.

# Build 2 additions
## Biometric stays working (data / airtime / cable PIN sheets)
- Server: biometric endpoints fall back to the logged-in session user when the page holds an old/empty token (app resumed from background).
- Server: biometric-challenge/verify now return an error `code`.
- App: shows the REAL reason instead of always "Biometric cancelled"; "Try biometric again" button; auto-retries when the user comes back to the app (only while the PIN sheet is open); "Set up biometric again" one-tap re-enroll if the phone key no longer matches.
- NOTE: the Android app's own code (Keystore key) is not in this plugin. If a key is destroyed on the phone (reinstall, clear data, fingerprint changes) the user must re-enroll - now one tap.
## Admin > View Transaction
- Failed => automatic refund of exactly what the user was charged (wallet/referral split aware, includes fee).
- Success => never double-charges (queued data was already debited).
- Pending rows with no record of a charge ask once: "Was the user already charged?"
- Final: first update locks the transaction forever (DB columns admin_locked, admin_updated_by, refunded_amount are added automatically; needs ALTER TABLE permission).
- Nonce + capability check, row-locked DB transaction (no double refund on double click).

# Build 3: biometric self-heal
If the phone's biometric key stops matching the server, the app fetches the phone's current key; after the user enters their PIN (verified on the SERVER) the key is re-linked automatically (biometric.php: pulsepoint_biometric_rebind_after_pin). Only for users who already enabled biometric.
Android developer notes for a truly permanent key: create the Keystore key once (if !containsAlias), setInvalidatedByBiometricEnrollment(false), never delete the key on logout/onPause, keep android:allowBackup irrelevant (keys never leave the device).

# Build 4: biometric LOGIN icon
- login.php: fingerprint button under "Continue" (only inside the app when the phone has biometrics). One tap -> challenge -> fingerprint -> signed -> logged in. Last email is remembered in the app so users don't retype it.
- biometric-login-verify.php: now identical to password login (session_regenerate_id + 90-day session cookie) - before it created a short session.
- biometric-login-challenge.php: per-IP throttle (15/min) + clearer "not set up" message.
- Users must first turn biometric ON in Profile (while logged in). 2FA accounts still need their 2FA code after biometric.
