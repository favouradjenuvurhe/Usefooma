<?php
/**
 * Fincra NGN Permanent Virtual Account Provider
 * Version 2.5.29
 *
 * Credentials are resolved through the virtual-account credential slot:
 *   Provider 1 -> pay_token / pay_secret / pay_biz
 *   Provider 2 -> pay_token_2 / pay_secret_2 / pay_biz_2
 *
 * Fincra uses the secret API key in the `api-key` header. The secondary
 * Secret field is used for the Fincra webhook encryption secret.
 */

if (!defined('ABSPATH')) exit;

function pulsepoint_create_virtual_account_fincra($user_id = 0, $name = '', $email = '', $phone = '') {
    global $wpdb;

    $name  = trim($name ?: 'Customer');
    $email = trim($email ?: 'unknown@example.com');
    $phone = trim($phone ?: '');

    if (empty($user_id) || empty($email)) {
        return [
            'success' => false,
            'message' => 'Invalid parameters for Fincra virtual account creation.',
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'fincra']
        ];
    }

    $slot = (int) ($GLOBALS['pulsepoint_va_credential_slot'] ?? 1);
    $apiKey = pulsepoint_get_virtual_account_setting('pay_token', $slot);

    if ($apiKey === '') {
        return [
            'success' => false,
            'message' => 'Fincra API secret key is not configured for this provider.',
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'fincra']
        ];
    }

    // Fincra requires a BVN for NGN individual permanent virtual accounts.
    $users_table = $wpdb->prefix . 'pulsepoint_users';
    $bvn = '';

    $column_exists = $wpdb->get_var(
        $wpdb->prepare("SHOW COLUMNS FROM `{$users_table}` LIKE %s", 'bvn')
    );

    if ($column_exists) {
        $bvn = preg_replace('/\D+/', '', (string) $wpdb->get_var(
            $wpdb->prepare("SELECT bvn FROM `{$users_table}` WHERE id=%d LIMIT 1", $user_id)
        ));
    }

    if (strlen($bvn) !== 11) {
        return [
            'success' => false,
            'message' => 'Fincra requires a verified 11-digit BVN before an NGN virtual account can be created.',
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'fincra']
        ];
    }

    $parts = preg_split('/\s+/', $name, 2);
    $firstName = trim($parts[0] ?? $name);
    $lastName  = trim($parts[1] ?? $firstName);

    $payload = [
        'currency' => 'NGN',
        'accountType' => 'individual',
        'channel' => 'wema',
        'merchantReference' => 'PP-' . $user_id . '-' . wp_generate_password(10, false, false),
        'KYCInformation' => [
            'firstName' => $firstName,
            'lastName'  => $lastName,
            'email'     => $email,
            'bvn'       => $bvn,
        ],
    ];

    $response = wp_remote_post(
        'https://api.fincra.com/profile/virtual-accounts/requests',
        [
            'timeout' => 45,
            'headers' => [
                'api-key' => $apiKey,
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ]
    );

    if (is_wp_error($response)) {
        return [
            'success' => false,
            'message' => 'Fincra request failed: ' . $response->get_error_message(),
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'fincra']
        ];
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $raw  = wp_remote_retrieve_body($response);
    $data = json_decode($raw, true);

    if (!is_array($data)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response from Fincra.',
            'account' => ['bank'=>'','name'=>$name,'number'=>'','provider'=>'fincra'],
            'http_code' => $code,
        ];
    }

    $info = $data['data']['accountInformation'] ?? [];
    $number = sanitize_text_field($info['accountNumber'] ?? '');
    $accountName = sanitize_text_field($info['accountName'] ?? $name);
    $bank = sanitize_text_field($info['bankName'] ?? '');

    if ($number !== '' && !empty($data['success'])) {
        return [
            'success' => true,
            'message' => $data['message'] ?? 'Fincra virtual account created successfully.',
            'account' => [
                'bank' => $bank,
                'name' => $accountName,
                'number' => $number,
                'provider' => 'fincra'
            ],
            'provider_reference' => sanitize_text_field($data['data']['id'] ?? ''),
        ];
    }

    return [
        'success' => false,
        'message' => $data['message'] ?? 'Fincra virtual account creation failed.',
        'account' => [
            'bank' => $bank,
            'name' => $accountName,
            'number' => $number,
            'provider' => 'fincra'
        ],
        'provider_response' => $data,
        'http_code' => $code,
    ];
}
