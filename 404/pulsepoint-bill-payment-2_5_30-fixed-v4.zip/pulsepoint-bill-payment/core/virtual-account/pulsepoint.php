<?php
/**
 * Pulsepoint Virtual Account Creation / Provider Dispatcher
 * Path: /core/virtual-account/pulsepoint.php
 *
 * Version 2.5.29
 *
 * Supports:
 * - legacy single-provider virtual accounts
 * - two configured virtual-account providers
 * - one account per configured provider/user
 * - backwards-compatible `account` response containing the primary account
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_nopriv_pulsepoint_virtual_account', 'pulsepoint_virtual_account');
add_action('wp_ajax_pulsepoint_virtual_account', 'pulsepoint_virtual_account');


/**
 * Supported static virtual-account provider handlers.
 */
function pulsepoint_virtual_account_provider_map(): array {
    return [
        'xixapay'       => 'pulsepoint_create_virtual_account_xixapay',
        'stropay'       => 'pulsepoint_create_virtual_account_stropay',
        'whogopay'      => 'pulsepoint_create_virtual_account_whogopay',
        'paymentpoint'  => 'pulsepoint_create_virtual_account_paymentpoint',
        'dotmfb-wa'     => 'pulsepoint_create_virtual_account_dotmfb_wa',
        'dotmfb_wa'     => 'pulsepoint_create_virtual_account_dotmfb_wa',
        'ncwallet'      => 'pulsepoint_create_virtual_account_ncwallet',
        'fincra'        => 'pulsepoint_create_virtual_account_fincra',
        'billstack'     => 'pulsepoint_create_virtual_account_billstack',
    ];
}


/**
 * Load one virtual-account provider without creating a global
 * `create_virtual_account()` collision.
 */
function pulsepoint_load_virtual_account_provider(string $provider): bool {

    $provider = strtolower(trim($provider));
    $map = pulsepoint_virtual_account_provider_map();

    if (!isset($map[$provider])) {
        return false;
    }

    $file = __DIR__ . '/' . $provider . '.php';

    /*
     * dotmfb-wa uses a hyphen in the filename while the normalized key
     * may also arrive as dotmfb_wa.
     */
    if (!file_exists($file) && $provider === 'dotmfb_wa') {
        $file = __DIR__ . '/dotmfb-wa.php';
    }

    if (!file_exists($file)) {
        return false;
    }

    require_once $file;

    return function_exists($map[$provider]);
}


/**
 * Create a virtual account through one configured provider.
 */
function pulsepoint_get_virtual_account_setting(string $key, int $slot = 0): string {
    global $wpdb;

    $base = $wpdb->prefix . 'pulsepoint_';
    $settings_table = $base . 'settings';
    $slot = $slot === 2 ? 2 : 1;
    $setting_key = $slot === 2 ? $key . '_2' : $key;

    $value = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
            $setting_key
        )
    );

    if ($value === null && $slot === 2) {
        $value = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT opt_value FROM {$settings_table} WHERE opt_key = %s LIMIT 1",
                $key
            )
        );
    }

    return trim((string) maybe_unserialize($value ?? ''));
}


function pulsepoint_create_virtual_account_with_provider(
    string $provider,
    int $user_id,
    string $name,
    string $email,
    string $phone,
    string $token = ''
): array {

    $provider = strtolower(trim($provider));
    $map = pulsepoint_virtual_account_provider_map();

    if (!isset($map[$provider])) {
        return [
            'success' => false,
            'message' => "Unsupported virtual account provider: {$provider}"
        ];
    }

    if (!pulsepoint_load_virtual_account_provider($provider)) {
        return [
            'success' => false,
            'message' => "Virtual account provider handler not found for '{$provider}'"
        ];
    }

    $function = $map[$provider];

    try {

        /*
         * Provider #1 uses the existing pay_token/pay_secret/pay_biz keys.
         * Provider #2 uses pay_token_2/pay_secret_2/pay_biz_2.
         */
        $settings_slot = 1;
        $configured_primary = function_exists('pulsepoint_get_virtual_account_providers') ? '' : '';
        $secondary_provider = '';
        if (isset($GLOBALS['pulsepoint_va_secondary_provider'])) {
            $secondary_provider = strtolower(trim((string) $GLOBALS['pulsepoint_va_secondary_provider']));
        }
        if ($secondary_provider !== '' && $secondary_provider === $provider) {
            $settings_slot = 2;
        }

        $provider_token = pulsepoint_get_virtual_account_setting('pay_token', $settings_slot);
        $GLOBALS['pulsepoint_va_credential_slot'] = $settings_slot;

        /*
         * Existing providers have slightly different function signatures.
         * PHP accepts the first four arguments for all current handlers;
         * providers that support the token can use it through their existing
         * optional fifth parameter below.
         */
        $reflection = new ReflectionFunction($function);
        $count = $reflection->getNumberOfParameters();

        if ($count >= 5) {
            $response = $function(
                $user_id,
                $name,
                $email,
                $phone,
                $provider_token
            );
        } else {
            $response = $function(
                $user_id,
                $name,
                $email,
                $phone
            );
        }

        unset($GLOBALS['pulsepoint_va_credential_slot']);

    } catch (Throwable $e) {

        unset($GLOBALS['pulsepoint_va_credential_slot']);

        return [
            'success' => false,
            'message' => 'Provider error: ' . $e->getMessage()
        ];
    }

    if (!is_array($response)) {
        return [
            'success' => false,
            'message' => 'Invalid provider response format'
        ];
    }

    return $response;
}


/**
 * Read the current two-provider configuration.
 *
 * `payment_gateway` remains the legacy fallback so existing installations
 * continue working without configuration changes.
 */
function pulsepoint_get_virtual_account_providers(array $settings): array {

    $providers = [];

    $legacy = strtolower(
        trim((string) ($settings['payment_gateway'] ?? ''))
    );

    $primary = strtolower(
        trim((string) ($settings['virtual_account_provider_1'] ?? ''))
    );

    $secondary = strtolower(
        trim((string) ($settings['virtual_account_provider_2'] ?? ''))
    );

    if ($primary === '') {
        $primary = $legacy;
    }

    if ($primary !== '') {
        $providers[] = $primary;
    }

    if (
        !empty($settings['virtual_account_provider_2_enabled'])
        && $secondary !== ''
    ) {
        $providers[] = $secondary;
    }

    /*
     * Only supported providers are returned, and duplicates are removed.
     */
    $map = pulsepoint_virtual_account_provider_map();

    $providers = array_values(
        array_unique(
            array_filter(
                $providers,
                static function ($provider) use ($map) {
                    return isset($map[$provider]);
                }
            )
        )
    );

    return $providers;
}


/**
 * Return accounts already created for a user.
 */
function pulsepoint_get_user_virtual_accounts(
    int $user_id
): array {

    global $wpdb;

    $table = $wpdb->prefix . 'pulsepoint_account';

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT id, bank, name, number, provider, created_at
             FROM `{$table}`
             WHERE user_id = %d
             ORDER BY id ASC",
            $user_id
        )
    );

    $accounts = [];

    foreach ($rows as $row) {
        if (empty($row->number)) {
            continue;
        }

        $accounts[] = [
            'id'        => (int) $row->id,
            'bank'      => (string) $row->bank,
            'name'      => (string) $row->name,
            'number'    => (string) $row->number,
            'provider'  => (string) $row->provider,
            'created_at'=> (string) $row->created_at,
        ];
    }

    return $accounts;
}


/**
 * Create any missing configured accounts for a user.
 *
 * If one provider is down, the other provider is still attempted.
 * Existing accounts are never recreated.
 */
function pulsepoint_ensure_virtual_accounts(
    int $user_id,
    object $user,
    array $settings
): array {

    global $wpdb;

    $table = $wpdb->prefix . 'pulsepoint_account';

    $providers = pulsepoint_get_virtual_account_providers($settings);

    if (empty($providers)) {
        return [
            'accounts' => [],
            'errors'   => ['No valid virtual account provider is configured.']
        ];
    }

    $existing = pulsepoint_get_user_virtual_accounts($user_id);

    $existing_providers = [];

    foreach ($existing as $account) {
        $existing_providers[
            strtolower(trim((string) $account['provider']))
        ] = true;
    }

    $errors = [];

    foreach ($providers as $provider) {

        if (isset($existing_providers[$provider])) {
            continue;
        }

        $GLOBALS['pulsepoint_va_secondary_provider'] = strtolower(
            trim((string) ($settings['virtual_account_provider_2'] ?? ''))
        );

        $response = pulsepoint_create_virtual_account_with_provider(
            $provider,
            $user_id,
            (string) ($user->firstname ?? 'Unknown User'),
            (string) ($user->email ?? 'noemail@example.com'),
            (string) ($user->phone ?? ''),
            (string) ($settings['virtual_token'] ?? '')
        );

        unset($GLOBALS['pulsepoint_va_secondary_provider']);

        if (empty($response['success'])) {

            $errors[] = [
                'provider' => $provider,
                'message'  => $response['message'] ?? 'Account creation failed.'
            ];

            continue;
        }

        $account = $response['account'] ?? [];

        $bank = sanitize_text_field(
            $account['bank']
            ?? $account['bankName']
            ?? ''
        );

        $name = sanitize_text_field(
            $account['name']
            ?? $account['account_name']
            ?? $user->firstname
        );

        $number = sanitize_text_field(
            $account['number']
            ?? $account['accountNumber']
            ?? ''
        );

        if ($number === '') {

            $errors[] = [
                'provider' => $provider,
                'message'  => 'Provider returned no account number.'
            ];

            continue;
        }

        /*
         * Prevent the same account number from being inserted twice.
         */
        $duplicate = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM `{$table}`
                 WHERE number = %s
                 LIMIT 1",
                $number
            )
        );

        if ($duplicate) {
            $existing_providers[$provider] = true;
            continue;
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'user_id'  => $user_id,
                'bank'     => $bank,
                'name'     => $name,
                'number'   => $number,
                'provider' => $provider,
            ],
            ['%d','%s','%s','%s','%s']
        );

        if ($inserted === false) {

            $errors[] = [
                'provider' => $provider,
                'message'  => 'Failed to save virtual account.'
            ];

            continue;
        }

        $existing_providers[$provider] = true;
    }

    return [
        'accounts' => pulsepoint_get_user_virtual_accounts($user_id),
        'errors'   => $errors
    ];
}


/**
 * Legacy AJAX endpoint.
 *
 * It now creates the configured accounts, but still returns the primary
 * account in `account` so existing frontend code remains compatible.
 */
function pulsepoint_virtual_account() {

    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (empty($_SESSION['pulsepoint_user']['id'])) {
        wp_send_json([
            'success' => false,
            'message' => 'User not logged in.'
        ]);
    }

    $user_id = (int) $_SESSION['pulsepoint_user']['id'];

    $table_users = $wpdb->prefix . 'pulsepoint_users';
    $base_prefix = $wpdb->prefix . 'pulsepoint_';

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM `{$table_users}` WHERE id = %d LIMIT 1",
            $user_id
        )
    );

    if (!$user || (int) $user->status !== 1) {
        wp_send_json([
            'success' => false,
            'message' => 'User not active or found.'
        ]);
    }

    $settings_rows = $wpdb->get_results(
        "SELECT opt_key, opt_value FROM {$base_prefix}settings"
    );

    $settings = [];

    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    if (($settings['maintenance_mode'] ?? '0') === '1') {
        wp_send_json([
            'success' => false,
            'message' => 'Under Maintenance'
        ]);
    }

    $accounts_result = pulsepoint_ensure_virtual_accounts(
        $user_id,
        $user,
        $settings
    );

    $accounts = $accounts_result['accounts'];

    if (empty($accounts)) {
        wp_send_json([
            'success' => false,
            'message' => $accounts_result['errors'][0]['message']
                ?? 'Unable to create a virtual account.',
            'accounts' => [],
            'errors' => $accounts_result['errors']
        ]);
    }

    wp_send_json([
        'success' => true,
        'message' => 'Virtual account(s) ready.',
        'account' => $accounts[0],
        'accounts' => $accounts,
        'partial' => !empty($accounts_result['errors']),
        'errors' => $accounts_result['errors']
    ]);
}
