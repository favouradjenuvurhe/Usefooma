<?php
/**
 * Reloadly Gift Card integration for Pulsepoint.
 *
 * The original file name is intentionally kept for backwards compatibility
 * with the existing plugin includes. Provider calls are now made to Reloadly.
 */
if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_reloadly_mode')) {
    function pulsepoint_reloadly_mode(): string {
        $mode = get_option('pulsepoint_giftcard_reloadly_mode', 'sandbox');
        return $mode === 'live' ? 'live' : 'sandbox';
    }
}

if (!function_exists('pulsepoint_reloadly_base_url')) {
    function pulsepoint_reloadly_base_url(): string {
        return pulsepoint_reloadly_mode() === 'live'
            ? 'https://giftcards.reloadly.com'
            : 'https://giftcards-sandbox.reloadly.com';
    }
}

if (!function_exists('pulsepoint_reloadly_audience')) {
    function pulsepoint_reloadly_audience(): string {
        return pulsepoint_reloadly_base_url();
    }
}

if (!function_exists('pulsepoint_reloadly_client_id')) {
    function pulsepoint_reloadly_client_id(): string {
        $key = pulsepoint_reloadly_mode() === 'live'
            ? 'pulsepoint_giftcard_reloadly_live_client_id'
            : 'pulsepoint_giftcard_reloadly_sandbox_client_id';
        return trim((string) get_option($key, ''));
    }
}

if (!function_exists('pulsepoint_reloadly_client_secret')) {
    function pulsepoint_reloadly_client_secret(): string {
        $key = pulsepoint_reloadly_mode() === 'live'
            ? 'pulsepoint_giftcard_reloadly_live_client_secret'
            : 'pulsepoint_giftcard_reloadly_sandbox_client_secret';
        return trim((string) get_option($key, ''));
    }
}

if (!function_exists('pulsepoint_reloadly_credentials_configured')) {
    function pulsepoint_reloadly_credentials_configured(): bool {
        return pulsepoint_reloadly_client_id() !== '' && pulsepoint_reloadly_client_secret() !== '';
    }
}

if (!function_exists('pulsepoint_reloadly_get_token')) {
    function pulsepoint_reloadly_get_token(bool $force = false): array {
        $mode = pulsepoint_reloadly_mode();
        $transient = 'pulsepoint_reloadly_gc_token_' . $mode;
        if (!$force) {
            $cached = get_transient($transient);
            if (is_string($cached) && $cached !== '') {
                return ['ok' => true, 'token' => $cached, 'code' => 200, 'message' => ''];
            }
        }

        $client_id = pulsepoint_reloadly_client_id();
        $client_secret = pulsepoint_reloadly_client_secret();
        if ($client_id === '' || $client_secret === '') {
            return ['ok' => false, 'token' => '', 'code' => 0, 'message' => 'Reloadly ' . ucfirst($mode) . ' Client ID and Client Secret are not configured.'];
        }

        $res = wp_remote_post('https://auth.reloadly.com/oauth/token', [
            'timeout' => 30,
            'redirection' => 2,
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body' => wp_json_encode([
                'client_id' => $client_id,
                'client_secret' => $client_secret,
                'grant_type' => 'client_credentials',
                'audience' => pulsepoint_reloadly_audience(),
            ]),
        ]);

        if (is_wp_error($res)) {
            return ['ok' => false, 'token' => '', 'code' => 0, 'message' => $res->get_error_message()];
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $json = json_decode(wp_remote_retrieve_body($res), true);
        $token = is_array($json) ? (string) ($json['access_token'] ?? '') : '';
        if ($code < 200 || $code >= 300 || $token === '') {
            $message = is_array($json) ? ($json['message'] ?? $json['error_description'] ?? $json['error'] ?? '') : '';
            return ['ok' => false, 'token' => '', 'code' => $code, 'message' => is_string($message) && $message !== '' ? $message : 'Reloadly authentication failed.'];
        }

        $expires = max(300, min((int) ($json['expires_in'] ?? 86400) - 300, 5184000));
        set_transient($transient, $token, $expires);
        return ['ok' => true, 'token' => $token, 'code' => $code, 'message' => ''];
    }
}

if (!function_exists('pulsepoint_reloadly_request')) {
    function pulsepoint_reloadly_request(string $method, string $path = '', array $query = [], ?array $body = null, string $accept = 'application/com.reloadly.giftcards-v1+json', bool $retry_auth = true): array {
        $auth = pulsepoint_reloadly_get_token(false);
        if (!$auth['ok']) return ['ok' => false, 'code' => $auth['code'], 'data' => null, 'message' => $auth['message']];

        $url = untrailingslashit(pulsepoint_reloadly_base_url()) . '/' . ltrim($path, '/');
        if ($query) $url = add_query_arg($query, $url);
        $args = [
            'timeout' => 45,
            'redirection' => 2,
            'headers' => [
                'Authorization' => 'Bearer ' . $auth['token'],
                'Accept' => $accept,
            ],
        ];

        $method = strtoupper($method);
        if ($method === 'POST') {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body ?: []);
            $res = wp_remote_post($url, $args);
        } else {
            $res = wp_remote_get($url, $args);
        }

        if (is_wp_error($res)) {
            return ['ok' => false, 'code' => 0, 'data' => null, 'message' => $res->get_error_message()];
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $raw = wp_remote_retrieve_body($res);
        $json = json_decode($raw, true);
        if (!is_array($json)) {
            return ['ok' => false, 'code' => $code, 'data' => null, 'message' => 'Reloadly returned an invalid JSON response.'];
        }

        if (($code === 401 || $code === 403) && $retry_auth) {
            delete_transient('pulsepoint_reloadly_gc_token_' . pulsepoint_reloadly_mode());
            return pulsepoint_reloadly_request($method, $path, $query, $body, $accept, false);
        }

        $ok = $code >= 200 && $code < 300;
        if ($code === 403) {
            $message = $json['message'] ?? $json['error_description'] ?? $json['error'] ?? 'Access Denied';
            if (is_string($message) && strtolower(trim($message)) === 'access denied') {
                $message = 'Access Denied. Check that the selected Reloadly environment uses its matching Gift Card Client ID/Secret and that the credentials have Gift Card API access.';
            }
        } else {
            $message = $json['message'] ?? $json['error_description'] ?? $json['error'] ?? 'Reloadly request failed.';
        }
        if (is_array($message)) $message = $message['message'] ?? 'Reloadly request failed.';

        return [
            'ok' => $ok,
            'code' => $code,
            'data' => $json,
            'message' => is_string($message) ? $message : 'Reloadly request failed.',
        ];
    }
}

/* Backwards-compatible wrappers: existing plugin files keep working. */
if (!function_exists('usefooma_topupmate_api_key')) {
    function usefooma_topupmate_api_key(): string {
        return pulsepoint_reloadly_credentials_configured() ? 'configured' : '';
    }
}
if (!function_exists('usefooma_topupmate_base_url')) {
    function usefooma_topupmate_base_url(): string { return pulsepoint_reloadly_base_url(); }
}
if (!function_exists('usefooma_topupmate_request')) {
    function usefooma_topupmate_request(string $method, string $path = '', array $query = [], ?array $body = null): array {
        return pulsepoint_reloadly_request($method, $path, $query, $body);
    }
}

if (!function_exists('pulsepoint_reloadly_products_from_response')) {
    function pulsepoint_reloadly_products_from_response(array $json): array {
        if (isset($json['data']) && is_array($json['data']) && array_is_list($json['data'])) return $json['data'];
        if (array_is_list($json)) return $json;
        return [];
    }
}

if (!function_exists('usefooma_topupmate_products_from_response')) {
    function usefooma_topupmate_products_from_response(array $json): array {
        return pulsepoint_reloadly_products_from_response($json);
    }
}

if (!function_exists('usefooma_topupmate_find_product')) {
    function usefooma_topupmate_find_product(int $product_id): ?array {
        $res = pulsepoint_reloadly_request('GET', 'products/' . $product_id);
        if ($res['ok'] && is_array($res['data'])) return $res['data'];
        /* Some accounts/API versions expose country catalog as the primary lookup. */
        $res = pulsepoint_reloadly_request('GET', 'countries/US/products');
        if (!$res['ok']) return null;
        foreach (pulsepoint_reloadly_products_from_response($res['data']) as $product) {
            if ((int) ($product['productId'] ?? 0) === $product_id) return $product;
        }
        return null;
    }
}

if (!function_exists('pulsepoint_reloadly_sender_amount')) {
    function pulsepoint_reloadly_sender_amount(array $product, float $recipient_amount): float {
        $map = $product['fixedRecipientToSenderDenominationsMap'] ?? [];
        foreach ($map as $recipient => $sender) {
            /* Reloadly returns this as either an object/map or an array of
             * one-key objects depending on API version. */
            if (is_array($sender)) {
                foreach ($sender as $map_recipient => $map_sender) {
                    if (abs((float) $map_recipient - $recipient_amount) < 0.00001) return round((float) $map_sender, 4);
                }
            } else {
                if (abs((float) $recipient - $recipient_amount) < 0.00001) return round((float) $sender, 4);
            }
        }

        $rate = (float) ($product['recipientCurrencyToSenderCurrencyExchangeRate'] ?? 0);
        if ($rate > 0) return round($recipient_amount * $rate, 4);

        return $recipient_amount;
    }
}

if (!function_exists('pulsepoint_reloadly_ngn_rate')) {
    function pulsepoint_reloadly_ngn_rate(): float {
        return max(0, (float) get_option('pulsepoint_giftcard_api_fx_rate', 1));
    }
}

if (!function_exists('pulsepoint_reloadly_wallet_charge')) {
    function pulsepoint_reloadly_wallet_charge(array $product, float $recipient_amount): float {
        $sender_amount = pulsepoint_reloadly_sender_amount($product, $recipient_amount);
        $sender_currency = strtoupper((string) ($product['senderCurrencyCode'] ?? ''));
        $rate = pulsepoint_reloadly_ngn_rate();

        /* Reloadly's fixedSenderDenominations represent the converted card
         * value. senderFee/senderFeePercentage are additional provider fees. */
        $fee = (float) ($product['senderFee'] ?? 0);
        $fee_pct = (float) ($product['senderFeePercentage'] ?? 0);
        $provider_cost = $sender_amount + $fee + ($sender_amount * $fee_pct / 100);

        /* If Reloadly's account is already funded in NGN, no FX conversion is needed. */
        if ($sender_currency === 'NGN') $rate = 1;
        $markup = max(0, (float) get_option('pulsepoint_giftcard_api_markup', 0));
        return round($provider_cost * max(0, $rate) * (1 + $markup / 100), 2);
    }
}

if (!function_exists('usefooma_topupmate_sender_amount')) {
    function usefooma_topupmate_sender_amount(array $product, float $recipient_amount): float {
        return pulsepoint_reloadly_sender_amount($product, $recipient_amount);
    }
}
if (!function_exists('usefooma_topupmate_wallet_charge')) {
    function usefooma_topupmate_wallet_charge(array $product, float $recipient_amount): float {
        return pulsepoint_reloadly_wallet_charge($product, $recipient_amount);
    }
}

if (!function_exists('usefooma_topupmate_normalize_product')) {
    function usefooma_topupmate_normalize_product(array $p): array {
        $recipient = array_values(array_map('floatval', $p['fixedRecipientDenominations'] ?? []));
        $map = $p['fixedRecipientToSenderDenominationsMap'] ?? [];
        $prices = [];
        foreach ($recipient as $amount) {
            $sender_amount = pulsepoint_reloadly_sender_amount($p, $amount);
            $prices[] = [
                'recipient_amount' => $amount,
                'sender_amount' => $sender_amount,
                'wallet_charge' => pulsepoint_reloadly_wallet_charge($p, $amount),
            ];
        }
        return [
            'product_id' => (int) ($p['productId'] ?? 0),
            'name' => (string) ($p['productName'] ?? ''),
            'brand' => (string) ($p['brand']['brandName'] ?? ''),
            'brand_id' => (int) ($p['brand']['brandId'] ?? 0),
            'country_iso' => (string) ($p['countryCode'] ?? $p['country']['isoName'] ?? ''),
            'country_name' => (string) ($p['country']['name'] ?? ''),
            'currency' => (string) ($p['currencyCode'] ?? $p['recipientCurrencyCode'] ?? ''),
            'sender_currency' => (string) ($p['senderCurrencyCode'] ?? ''),
            'denomination_type' => (string) ($p['denominationType'] ?? ''),
            'fixed_denominations' => $recipient,
            'fixed_sender_denominations' => array_values(array_map('floatval', $p['fixedSenderDenominations'] ?? [])),
            'fixed_recipient_to_sender_map' => $map,
            'min_amount' => isset($p['minRecipientDenomination']) ? (float) $p['minRecipientDenomination'] : null,
            'max_amount' => isset($p['maxRecipientDenomination']) ? (float) $p['maxRecipientDenomination'] : null,
            'sender_fee' => (float) ($p['senderFee'] ?? 0),
            'sender_fee_percentage' => (float) ($p['senderFeePercentage'] ?? 0),
            'exchange_rate' => (float) ($p['recipientCurrencyToSenderCurrencyExchangeRate'] ?? 0),
            'wallet_rate' => (strtoupper((string) ($p['senderCurrencyCode'] ?? '')) === 'NGN') ? 1 : pulsepoint_reloadly_ngn_rate(),
            'wallet_markup_percent' => max(0, (float) get_option('pulsepoint_giftcard_api_markup', 0)),
            'denomination_prices' => $prices,
            'logo_url' => (string) ($p['brand']['logoUrl'] ?? ($p['logoUrls'][0] ?? '')),
            'logo_urls' => array_values($p['logoUrls'] ?? []),
            'redeem_instruction' => $p['redeemInstruction'] ?? [],
            'additional_requirements' => $p['additionalRequirements'] ?? [],
            'raw_product' => $p,
        ];
    }
}

if (!function_exists('usefooma_topupmate_catalog')) {
    function usefooma_topupmate_catalog(array $query = []): array {
        $country = strtoupper((string) ($query['countryCode'] ?? ''));
        if ($country === '') $country = 'US';
        $res = pulsepoint_reloadly_request('GET', 'countries/' . rawurlencode($country) . '/products');
        if (!$res['ok']) return $res;
        $products = [];
        foreach (pulsepoint_reloadly_products_from_response($res['data']) as $p) {
            if (!is_array($p)) continue;
            if (!empty($query['productId']) && (int) ($p['productId'] ?? 0) !== (int) $query['productId']) continue;
            if (!empty($query['productName']) && stripos((string) ($p['productName'] ?? ''), (string) $query['productName']) === false) continue;
            $products[] = usefooma_topupmate_normalize_product($p);
        }
        return ['ok' => true, 'code' => $res['code'], 'data' => $products, 'message' => ''];
    }
}

if (!function_exists('pulsepoint_reloadly_get_account_balance')) {
    function pulsepoint_reloadly_get_account_balance(): array {
        return pulsepoint_reloadly_request('GET', 'accounts/balance', [], null, 'application/json');
    }
}

if (!function_exists('pulsepoint_reloadly_purchase')) {
    function pulsepoint_reloadly_purchase(int $product_id, string $country, float $amount, string $email, string $sender, string $ref): array {
        $body = [
            'productId' => $product_id,
            'countryCode' => strtoupper($country),
            'quantity' => 1,
            'unitPrice' => $amount,
            'customIdentifier' => $ref,
            'senderName' => $sender,
            'recipientEmail' => $email,
            'preOrder' => false,
        ];
        return pulsepoint_reloadly_request('POST', 'orders', [], $body);
    }
}

if (!function_exists('usefooma_topupmate_purchase')) {
    function usefooma_topupmate_purchase(int $product_id, float $amount, string $email, string $sender, string $ref): array {
        return pulsepoint_reloadly_purchase($product_id, '', $amount, $email, $sender, $ref);
    }
}

if (!function_exists('pulsepoint_reloadly_get_cards')) {
    function pulsepoint_reloadly_get_cards(int $transaction_id): array {
        return pulsepoint_reloadly_request(
            'GET',
            'orders/transactions/' . $transaction_id . '/cards',
            [],
            null,
            'application/com.reloadly.giftcards-v2+json'
        );
    }
}

if (!function_exists('usefooma_topupmate_redeem')) {
    function usefooma_topupmate_redeem(string $ref = ''): array {
        if ($ref === '') return ['ok' => false, 'code' => 0, 'data' => null, 'message' => 'Transaction reference is required.'];
        $tx = pulsepoint_reloadly_request('GET', 'orders/transactions/' . rawurlencode($ref) . '/cards', [], null, 'application/com.reloadly.giftcards-v2+json');
        return $tx;
    }
}

if (!function_exists('pulsepoint_reloadly_extract_card')) {
    function pulsepoint_reloadly_extract_card(array $json): array {
        $d = $json;
        if (isset($json['data']) && is_array($json['data'])) $d = array_merge($json, $json['data']);
        $card = $d['cardNumber'] ?? $d['card_number'] ?? '';
        $pin = $d['pinCode'] ?? $d['pin_code'] ?? '';
        $url = $d['redemptionUrl'] ?? $d['redemption_url'] ?? '';
        return [
            'status' => strtolower((string) ($d['status'] ?? 'successful')),
            'transaction_id' => (int) ($d['transactionId'] ?? 0),
            'card_number' => (string) $card,
            'pin_code' => (string) $pin,
            'redeem' => (string) ($card ?: ''),
            'redeem_details' => (string) ($d['redeemInstructions'] ?? $d['redeem_details'] ?? ''),
            'redemption_url' => (string) $url,
            'raw' => $json,
        ];
    }
}

/* Legacy extraction name retained for existing API/status/cron files. */
if (!function_exists('usefooma_topupmate_extract_redeem')) {
    function usefooma_topupmate_extract_redeem(array $json): array {
        $d = pulsepoint_reloadly_extract_card($json);
        return [
            'status' => $d['status'],
            'redeem_id' => (string) $d['transaction_id'],
            'card_name' => '',
            'card_amount' => 0,
            'card_currency' => '',
            'redeem' => $d['redeem'],
            'redeem_details' => $d['redeem_details'],
            'card_number' => $d['card_number'],
            'pin_code' => $d['pin_code'],
            'redemption_url' => $d['redemption_url'],
            'raw' => $d['raw'],
        ];
    }
}
