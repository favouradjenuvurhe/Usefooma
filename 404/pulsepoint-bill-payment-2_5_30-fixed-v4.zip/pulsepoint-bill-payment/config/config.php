<?php
if (!defined('ABSPATH')) { exit; }

return [
    'version' => defined('PULSEPOINT_VERSION') ? PULSEPOINT_VERSION : '2.5.29',
    'ai' => [
        'endpoint' => 'https://api.deepseek.com/chat/completions',
        'model' => 'deepseek-v4-flash',
        'timeout' => 20,
        // Define PULSEPOINT_DEEPSEEK_API_KEY in wp-config.php (never commit keys to this file).
        'api_key' => defined('PULSEPOINT_DEEPSEEK_API_KEY') ? PULSEPOINT_DEEPSEEK_API_KEY : '',
    ],
];
