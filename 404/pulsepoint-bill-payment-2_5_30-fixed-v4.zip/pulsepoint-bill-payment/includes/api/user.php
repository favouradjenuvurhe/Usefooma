<?php
/**
 * Pulsepoint API — User / Wallet
 * Path: /api/user.php
 *
 * Compatibility endpoint for mobile clients using:
 *   POST /api/user
 *   {"token":"..."}
 *
 * Also accepts GET ?token=... and Authorization: Token <token>.
 *
 * IMPORTANT:
 * The native Android app reads:
 *   u.optString("wallet")
 *
 * Therefore `user.wallet` is returned as a formatted NGN string:
 *   ₦11,711.60
 */

if (!defined('ABSPATH')) {
    $wp_load = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

    if (is_file($wp_load)) {
        require_once $wp_load;
    }
}

global $wpdb;

header('Content-Type: application/json; charset=utf-8');


/**
 * Return JSON response and stop this endpoint.
 */
if (!function_exists('pulsepoint_user_api_response')) {

    function pulsepoint_user_api_response(array $payload) {

        echo function_exists('wp_json_encode')
            ? wp_json_encode($payload)
            : json_encode($payload);

        exit;
    }
}


/**
 * Check request method.
 */
$method = strtoupper(
    (string) ($_SERVER['REQUEST_METHOD'] ?? '')
);

if (!in_array($method, ['GET', 'POST'], true)) {

    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}


/**
 * Read JSON request body first.
 *
 * Example:
 * {
 *     "token": "xxxxxxxx"
 * }
 */
$raw = file_get_contents('php://input');

$input = json_decode(
    $raw ?: '',
    true
);


/**
 * If JSON was not supplied,
 * fall back to normal POST data.
 */
if (!is_array($input)) {
    $input = $_POST;
}

if (!is_array($input)) {
    $input = [];
}


/**
 * Get token from JSON/POST.
 */
$token = isset($input['token'])
    ? trim((string) $input['token'])
    : '';


/**
 * Also support:
 *
 * /api/user.php?token=xxxxx
 */
if ($token === '' && isset($_GET['token'])) {

    $token = trim(
        (string) $_GET['token']
    );
}


/**
 * Also support:
 *
 * Authorization: Token xxxxx
 */
$headers = function_exists('getallheaders')
    ? getallheaders()
    : [];

$authorization = '';

if (is_array($headers)) {

    $authorization =
        $headers['Authorization']
        ?? ($headers['authorization'] ?? '');
}


/**
 * Some servers expose Authorization
 * through HTTP_AUTHORIZATION.
 */
if ($authorization === '') {

    $authorization =
        $_SERVER['HTTP_AUTHORIZATION'] ?? '';
}


/**
 * Extract token from:
 *
 * Authorization: Token xxxxx
 */
if (
    $token === ''
    &&
    preg_match(
        '/^Token\s+(.+)$/i',
        trim((string) $authorization),
        $matches
    )
) {

    $token = trim($matches[1]);
}


/**
 * Sanitize token.
 */
$token = sanitize_text_field($token);


/**
 * Token is required.
 */
if ($token === '') {

    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Token is required'
    ]);
}


/**
 * Make sure WordPress database is available.
 */
if (!isset($wpdb) || !is_object($wpdb)) {

    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Database connection unavailable'
    ]);
}


/**
 * Pulsepoint users table.
 */
$table = $wpdb->prefix . 'pulsepoint_users';


/**
 * Find user by token.
 */
$user = $wpdb->get_row(

    $wpdb->prepare(

        "SELECT *
         FROM `{$table}`
         WHERE `token` = %s
         LIMIT 1",

        $token
    )
);


/**
 * Invalid token.
 */
if (!$user) {

    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
}


/**
 * Account status.
 */
$status = isset($user->status)
    ? (int) $user->status
    : 0;


/**
 * Account must be active.
 */
if ($status !== 1) {

    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Account inactive',
        'status' => $status
    ]);
}


/**
 * User information.
 */
$lastname = isset($user->lastname)
    ? (string) $user->lastname
    : '';

$firstname = isset($user->firstname)
    ? (string) $user->firstname
    : '';

$email = isset($user->email)
    ? (string) $user->email
    : '';

$phone = isset($user->phone)
    ? (string) $user->phone
    : '';


/**
 * Wallet.
 */
$wallet = isset($user->wallet)
    ? (float) $user->wallet
    : 0.0;


/**
 * Pending promotional bonus.
 *
 * This is still included in the displayed wallet.
 */
$promo = isset($user->promo_bonus_pending)
    ? (float) $user->promo_bonus_pending
    : 0.0;


/**
 * Other balances.
 */
$dollar = isset($user->dollar)
    ? (float) $user->dollar
    : 0.0;

$referral = isset($user->referral_balance)
    ? (float) $user->referral_balance
    : 0.0;


/**
 * Account type.
 */
$accountType = isset($user->account_type)
    ? (string) $user->account_type
    : '';


/**
 * User token.
 */
$userToken = isset($user->token)
    ? (string) $user->token
    : $token;


/**
 * User ID.
 */
$userId = isset($user->id)
    ? (int) $user->id
    : 0;


/**
 * Total wallet.
 *
 * Pending promo balance is included.
 *
 * Example:
 *
 * wallet = 10,000.00
 * promo  = 1,711.60
 *
 * total = 11,711.60
 */
$totalWallet = round(
    $wallet + $promo,
    2
);


/**
 * Format wallet for the existing Android application.
 *
 * Android reads:
 *
 * String wallet = u.optString("wallet");
 *
 * Therefore this returns:
 *
 * ₦11,711.60
 */
$walletFormatted =
    '₦' . number_format(
        $totalWallet,
        2,
        '.',
        ','
    );


/**
 * Format dollar balance.
 */
$dollarFormatted =
    '$' . number_format(
        $dollar,
        2,
        '.',
        ','
    );


/**
 * Format referral balance.
 */
$referralFormatted =
    '₦' . number_format(
        $referral,
        2,
        '.',
        ','
    );


/**
 * Return API response.
 *
 * NOTE:
 *
 * Only `wallet` is returned for the combined
 * wallet + pending bonus amount.
 *
 * These fields have intentionally been removed:
 *
 * - wallet_balance
 * - promo_bonus_pending
 * - wallet_formatted
 */
pulsepoint_user_api_response([

    'success' => true,

    'message' => 'User fetched successfully',

    'user' => [

        'id' => $userId,

        'firstname' => $firstname,

        'lastname' => $lastname,

        'email' => $email,

        'phone' => $phone,

        /**
         * Combined wallet + pending bonus.
         *
         * Example:
         * ₦11,711.60
         */
        'wallet' => $walletFormatted,

        /**
         * Dollar balance.
         */
        'dollar' => $dollarFormatted,

        /**
         * Referral balance.
         */
        'referral_balance' => $referralFormatted,

        /**
         * User token.
         */
        'token' => $userToken,

        /**
         * Account type.
         */
        'account_type' => $accountType,

        /**
         * Account status.
         */
        'status' => $status,

    ]

]);