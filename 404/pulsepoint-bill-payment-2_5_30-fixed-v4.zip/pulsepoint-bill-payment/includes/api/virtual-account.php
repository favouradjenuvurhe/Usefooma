<?php
/**
 * Pulsepoint Virtual Account API Endpoint
 * Path: /api/virtual-account.php
 *
 * Version 2.5.29
 *
 * Returns up to two virtual accounts — one from each configured provider.
 * The first account remains available in `account` for backwards
 * compatibility with existing clients.
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid request method'
    ], 405);
}


/**
 * Authorization Header
 */
$headers = function_exists('getallheaders')
    ? getallheaders()
    : [];

$authorization = '';

if (is_array($headers)) {
    $authorization =
        $headers['Authorization']
        ?? ($headers['authorization'] ?? '');
}

if ($authorization === '') {
    $authorization =
        $_SERVER['HTTP_AUTHORIZATION'] ?? '';
}

if (
    !preg_match(
        '/^Token\s+(\S+)$/i',
        trim((string) $authorization),
        $matches
    )
) {
    wp_send_json([
        'success' => false,
        'message' => 'Missing or invalid Authorization header'
    ], 401);
}

$token = sanitize_text_field($matches[1]);


/**
 * Validate user token.
 */
$table_users = $wpdb->prefix . 'pulsepoint_users';

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT *
         FROM `{$table_users}`
         WHERE token = %s
         LIMIT 1",
        $token
    )
);

if (!$user) {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid or expired token'
    ], 401);
}

if ((int) $user->status !== 1) {
    wp_send_json([
        'success' => false,
        'message' => 'Account inactive'
    ], 403);
}


/**
 * Load the 2.5.29 provider dispatcher.
 */
$dispatcher = PULSEPOINT_DIR . 'core/virtual-account/pulsepoint.php';

if (!file_exists($dispatcher)) {
    wp_send_json([
        'success' => false,
        'message' => 'Virtual account dispatcher not found'
    ], 500);
}

require_once $dispatcher;


/**
 * Read settings.
 */
$base_prefix = $wpdb->prefix . 'pulsepoint_';

$settings_rows = $wpdb->get_results(
    "SELECT opt_key, opt_value FROM {$base_prefix}settings"
);

$settings = [];

foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}


/**
 * Maintenance mode.
 */
if (($settings['maintenance_mode'] ?? '0') === '1') {
    wp_send_json([
        'success' => false,
        'message' => 'Under Maintenance'
    ]);
}


/**
 * Rate limit account creation/check requests.
 *
 * Existing accounts are still returned immediately; the limit only prevents
 * repeatedly calling external providers when accounts are missing.
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$user_id = (int) $user->id;
$now = time();

$existing_accounts = pulsepoint_get_user_virtual_accounts($user_id);

$providers = pulsepoint_get_virtual_account_providers($settings);

$missing_provider = false;

foreach ($providers as $provider) {
    $found = false;

    foreach ($existing_accounts as $account) {
        if (strtolower((string) $account['provider']) === $provider) {
            $found = true;
            break;
        }
    }

    if (!$found) {
        $missing_provider = true;
        break;
    }
}

if (
    $missing_provider
    &&
    !empty($_SESSION['pulsepoint_virtual_api_last_request'][$user_id])
    &&
    ($now - $_SESSION['pulsepoint_virtual_api_last_request'][$user_id]) < 15
) {
    wp_send_json([
        'success' => !empty($existing_accounts),
        'message' => 'Please wait 15 seconds before retrying virtual account creation.',
        'account' => $existing_accounts[0] ?? null,
        'accounts' => $existing_accounts
    ], 429);
}


/**
 * Create missing accounts.
 *
 * If provider 1 is unavailable, provider 2 is still attempted.
 */
if ($missing_provider) {
    $_SESSION['pulsepoint_virtual_api_last_request'][$user_id] = $now;

    $result = pulsepoint_ensure_virtual_accounts(
        $user_id,
        $user,
        $settings
    );

    $accounts = $result['accounts'];
    $errors   = $result['errors'];
} else {
    $accounts = $existing_accounts;
    $errors = [];
}


/**
 * No account at all.
 */
if (empty($accounts)) {
    wp_send_json([
        'success' => false,
        'message' => $errors[0]['message']
            ?? 'No virtual account is available.',
        'account' => null,
        'accounts' => [],
        'errors' => $errors
    ], 503);
}


/**
 * The first account is kept in `account` for the existing wallet.html and
 * older native clients. New clients can use `accounts`.
 */
wp_send_json([
    'success' => true,
    'message' => 'Virtual account(s) ready.',
    'account' => $accounts[0],
    'accounts' => $accounts,
    'partial' => !empty($errors),
    'errors' => $errors
]);
exit;
