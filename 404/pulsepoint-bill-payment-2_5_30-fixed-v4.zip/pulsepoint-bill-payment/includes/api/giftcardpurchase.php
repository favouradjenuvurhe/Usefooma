<?php
if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-load.php';
require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo wp_json_encode(['success'=>false,'message'=>'Invalid request method']); exit; }
$headers=function_exists('getallheaders')?getallheaders():[]; $auth=$headers['Authorization']??($headers['authorization']??($_SERVER['HTTP_AUTHORIZATION']??''));
if(!preg_match('/Token\s+(\S+)/i',trim($auth),$m)){echo wp_json_encode(['success'=>false,'message'=>'Missing Authorization header']);exit;}
$token=sanitize_text_field($m[1]); $users=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT id,wallet,passcode,status,email,firstname,lastname FROM {$users} WHERE token=%s LIMIT 1",$token));
if(!$user||(int)$user->status!==1){echo wp_json_encode(['success'=>false,'message'=>'Invalid or inactive token']);exit;}

$pin=sanitize_text_field($_POST['passcode']??'');
if(!preg_match('/^\d{4}$/',$pin)||empty($user->passcode)||!hash_equals((string)$user->passcode,$pin)){echo wp_json_encode(['success'=>false,'message'=>'Incorrect transaction PIN']);exit;}

$mode=get_option('pulsepoint_giftcard_purchase_mode','manual');
if($mode!=='api'){
    // Keep the existing manual inventory flow intact.
    $stock_id=absint($_POST['stock_id']??0); if(!$stock_id){echo wp_json_encode(['success'=>false,'message'=>'Stock item is required']);exit;}
    $stock=$wpdb->prefix.'pulsepoint_giftcard_stock';$settings=$wpdb->prefix.'pulsepoint_giftcard_settings';$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';
    $wpdb->query('START TRANSACTION');
    try{
        $item=$wpdb->get_row($wpdb->prepare("SELECT s.*,g.category,g.sub_category FROM {$stock} s INNER JOIN {$settings} g ON g.id=s.giftcard_id WHERE s.id=%d AND s.status='available' AND g.status='active' FOR UPDATE",$stock_id));
        if(!$item)throw new Exception('This giftcard is no longer available.');
        if(!empty($item->expires_at)&&strtotime($item->expires_at)!==false&&strtotime($item->expires_at)<current_time('timestamp')){$wpdb->update($stock,['status'=>'expired'],['id'=>$stock_id]);throw new Exception('This giftcard has expired.');}
        $price=(float)$item->sale_price;$balance=(float)$user->wallet;if($balance<$price)throw new Exception('Insufficient wallet balance.');
        $ref='PGB'.strtoupper(wp_generate_password(12,false,false));$new=$balance-$price;
        $ok=$wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=%f WHERE id=%d AND wallet >= %f",$new,$user->id,$price));if($ok!==1)throw new Exception('Unable to debit wallet.');
        $wpdb->update($stock,['status'=>'sold','sold_to'=>$user->id,'sold_at'=>current_time('mysql')],['id'=>$stock_id],['%s','%d','%s'],['%d']);
        $ok=$wpdb->insert($tx,['listing_id'=>null,'user_id'=>$user->id,'amount'=>$item->face_value,'selling_price'=>$price,'fee'=>0,'status'=>'completed','payment_method'=>'wallet','reference'=>$ref,'note'=>'Giftcard purchase: '.$item->category.' '.$item->sub_category,'transaction_type'=>'purchase','inventory_id'=>$stock_id,'delivered_code'=>$item->digital_code,'delivered_pin'=>$item->digital_pin],['%d','%d','%f','%f','%f','%s','%s','%s','%s','%d','%s','%s']);
        if(!$ok)throw new Exception('Failed to record purchase.');
        $wpdb->query('COMMIT');
        echo wp_json_encode(['success'=>true,'message'=>'Giftcard purchased successfully.','data'=>['reference'=>$ref,'category'=>$item->category,'sub_category'=>$item->sub_category,'face_value'=>(float)$item->face_value,'sale_price'=>$price,'code'=>$item->digital_code,'pin'=>$item->digital_pin,'new_balance'=>$new,'status'=>'completed']]);exit;
    }catch(Throwable $e){$wpdb->query('ROLLBACK');echo wp_json_encode(['success'=>false,'message'=>$e->getMessage()]);exit;}
}

$product_id=absint($_POST['product_id']??0);
$amount=(float)($_POST['amount']??$_POST['local_amount']??0);
$country=sanitize_text_field($_POST['country_iso']??($_POST['country']??''));
$recipient=sanitize_email($_POST['recipient_email']??($_POST['email']??''));
if(!$recipient)$recipient=sanitize_email($user->email??'');
$sender=sanitize_text_field($_POST['sender']??trim(($user->firstname??'').' '.($user->lastname??'')));
if(!$product_id||$amount<=0){echo wp_json_encode(['success'=>false,'message'=>'product_id and amount are required']);exit;}
if(!$recipient){echo wp_json_encode(['success'=>false,'message'=>'A valid recipient email is required']);exit;}
if($sender==='')$sender='Pulsepoint Customer';

if(!pulsepoint_reloadly_credentials_configured()){
    echo wp_json_encode(['success'=>false,'message'=>'Reloadly credentials are not configured for the selected environment.']);exit;
}

/* Re-fetch the product server-side. Never trust price/product data supplied by the browser. */
$product=usefooma_topupmate_find_product($product_id);
if(!$product){
    echo wp_json_encode(['success'=>false,'message'=>'Giftcard product is no longer available.']);exit;
}
$normalized=usefooma_topupmate_normalize_product($product);
$provider_country=strtoupper((string)($normalized['country_iso']??$country));
if($country!=='' && $provider_country!==strtoupper($country)){
    echo wp_json_encode(['success'=>false,'message'=>'Giftcard country does not match the selected product.']);exit;
}

/* Validate the denomination against Reloadly's current catalog. */
$fixed=$normalized['fixed_denominations'];
$valid=false;
foreach($fixed as $d){if(abs((float)$d-$amount)<0.00001){$valid=true;break;}}
if(!$valid && strtoupper($normalized['denomination_type'])!=='FIXED'){
    $min=$normalized['min_amount'];$max=$normalized['max_amount'];
    $valid=($min===null||$amount>=(float)$min)&&($max===null||$amount<=(float)$max);
}
if(!$valid){
    echo wp_json_encode(['success'=>false,'message'=>'Invalid giftcard denomination for this product.']);exit;
}

$charge=usefooma_topupmate_wallet_charge($product,$amount);
$sender_amount=usefooma_topupmate_sender_amount($product,$amount);
if($charge<=0){
    echo wp_json_encode(['success'=>false,'message'=>'Unable to calculate the NGN giftcard price. Configure the NGN conversion rate in Giftcard Settings.']);exit;
}

$balance=(float)$user->wallet;
if($balance<$charge){
    echo wp_json_encode(['success'=>false,'message'=>'Insufficient wallet balance.','required'=>$charge,'wallet'=>$balance]);exit;
}

$ref='GC_'.strtoupper(wp_generate_password(16,false,false));
$tx=$wpdb->prefix.'pulsepoint_giftcard_transactions';
$note_meta=[
    'source'=>'reloadly',
    'mode'=>pulsepoint_reloadly_mode(),
    'product_id'=>$product_id,
    'product_name'=>$normalized['name'],
    'brand'=>$normalized['brand'],
    'country_iso'=>$provider_country,
    'recipient_currency'=>$normalized['currency'],
    'sender_currency'=>$normalized['sender_currency'],
    'recipient_amount'=>$amount,
    'sender_amount'=>$sender_amount,
    'wallet_charge'=>$charge,
    'recipient_email'=>$recipient,
    'sender'=>$sender,
    'provider_ref'=>$ref,
    'status'=>'pending'
];

/* Debit first. The provider is only called after the wallet transaction is created. */
$debited=$wpdb->query($wpdb->prepare(
    "UPDATE {$users} SET wallet=wallet-%f WHERE id=%d AND wallet >= %f",
    $charge,$user->id,$charge
));
if($debited!==1){
    echo wp_json_encode(['success'=>false,'message'=>'Wallet balance changed. Please try again.']);exit;
}
$new_balance=round($balance-$charge,2);

$inserted=$wpdb->insert($tx,[
    'listing_id'=>null,'user_id'=>$user->id,'amount'=>$amount,'selling_price'=>$charge,'fee'=>0,
    'status'=>'pending','payment_method'=>'wallet','reference'=>$ref,'note'=>wp_json_encode($note_meta),
    'transaction_type'=>'purchase'
],['%d','%d','%f','%f','%f','%s','%s','%s','%s','%s']);
$txid=(int)$wpdb->insert_id;
if(!$inserted||!$txid){
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Failed to create giftcard transaction. Your wallet was not charged.']);exit;
}

/* Keep the purchase in the plugin's normal transaction history. */
$trnx=$wpdb->prefix.'pulsepoint_trnx';
$provider_cost_estimate=round($sender_amount * ((strtoupper((string)$normalized['sender_currency'])==='NGN') ? 1 : pulsepoint_reloadly_ngn_rate()),2);
$profit_estimate=round($charge-$provider_cost_estimate,2);
$main_insert=$wpdb->insert($trnx,[
    'user_id'=>$user->id,
    'details'=>wp_json_encode([
        'provider'=>'reloadly','mode'=>pulsepoint_reloadly_mode(),'product_id'=>$product_id,
        'product_name'=>$normalized['name'],'brand'=>$normalized['brand'],'country_iso'=>$provider_country,
        'recipient_amount'=>$amount,'sender_amount'=>$sender_amount,'provider_cost'=>$provider_cost_estimate
    ]),
    'value'=>(string)$amount,'recipient'=>$recipient,'amount'=>$charge,'profit_amount'=>$profit_estimate,
    'reference'=>$ref,'payment'=>'wallet','category'=>'others','status'=>'pending','type'=>'debit',
    'session'=>session_id(),'description'=>pulsepoint_transaction_description('Giftcard ' . $normalized['name'])
],['%d','%s','%s','%s','%f','%f','%s','%s','%s','%s','%s','%s']);
$main_trnx_id=(int)$wpdb->insert_id;
if(!$main_insert||!$main_trnx_id){
    $wpdb->update($tx,['status'=>'failed','note'=>wp_json_encode(array_merge($note_meta,['status'=>'failed','message'=>'Platform transaction record could not be created.']))],['id'=>$txid]);
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Failed to initialize the wallet transaction. Your wallet was not charged.']);exit;
}
$note_meta['main_trnx_id']=$main_trnx_id;
$wpdb->update($tx,['note'=>wp_json_encode($note_meta)],['id'=>$txid],['%s'],['%d']);

/* Place the real Reloadly order. */
$provider=pulsepoint_reloadly_purchase($product_id,$provider_country,$amount,$recipient,$sender,$ref);
if(!$provider['ok']){
    $note_meta['status']='failed';
    $note_meta['provider_message']=$provider['message'];
    $note_meta['provider_http_code']=$provider['code'];
    $wpdb->update($tx,['status'=>'failed','note'=>wp_json_encode($note_meta)],['id'=>$txid],['%s','%s'],['%d']);
    $wpdb->update($trnx,['status'=>'failed','gateway_response'=>$provider['message']],['id'=>$main_trnx_id],['%s','%s'],['%d']);
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Reloadly rejected the giftcard purchase. Your wallet has been refunded.','provider_message'=>$provider['message']]);exit;
}

$provider_data=$provider['data'];
$provider_txid=(int)($provider_data['transactionId']??0);
$provider_status=strtolower((string)($provider_data['status']??''));
$note_meta['provider_transaction_id']=$provider_txid;
$note_meta['provider_response']=$provider_data;

if(in_array($provider_status,['failed','failure','declined','rejected','cancelled','canceled'],true)){
    $note_meta['status']='failed';
    $wpdb->update($tx,['status'=>'failed','note'=>wp_json_encode($note_meta)],['id'=>$txid],['%s','%s'],['%d']);
    $wpdb->update($trnx,['status'=>'failed','gateway_response'=>wp_json_encode($provider_data)],['id'=>$main_trnx_id],['%s','%s'],['%d']);
    $wpdb->query($wpdb->prepare("UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",$charge,$user->id));
    echo wp_json_encode(['success'=>false,'message'=>'Reloadly did not complete the giftcard order. Your wallet has been refunded.']);exit;
}

/* Reloadly returns the transaction ID from the order call. Fetch the actual
 * redeem code from the versioned cards endpoint. */
$card_res=$provider_txid ? pulsepoint_reloadly_get_cards($provider_txid) : ['ok'=>false,'code'=>0,'data'=>null,'message'=>'Reloadly did not return a transaction ID.'];
$card=[];
if($card_res['ok'] && is_array($card_res['data'])){
    $card=pulsepoint_reloadly_extract_card($card_res['data']);
}

$has_code=!empty($card['card_number'])||!empty($card['pin_code'])||!empty($card['redeem']);
$note_meta['status']=$has_code?'successful':'pending';
$note_meta['redeem_id']=(string)$provider_txid;
$note_meta['redeem_instructions']=$card['redeem_details']??'';
$note_meta['redeem_response']=$card['raw']??($card_res['data']??null);

$updates=['status'=>$has_code?'completed':'pending','note'=>wp_json_encode($note_meta)];
if(!empty($card['card_number']))$updates['delivered_code']=sanitize_textarea_field($card['card_number']);
if(!empty($card['pin_code']))$updates['delivered_pin']=sanitize_text_field($card['pin_code']);
$wpdb->update($tx,$updates,['id'=>$txid],['%s','%s'],['%d']);

/* Use Reloadly's actual balance cost when it is available. */
$actual_cost=(float)($provider_data['balanceInfo']['cost']??0);
$actual_cost_ngn=$actual_cost;
if(strtoupper((string)($provider_data['balanceInfo']['currencyCode']??$normalized['sender_currency']))!=='NGN'){
    $actual_cost_ngn=$actual_cost*pulsepoint_reloadly_ngn_rate();
}
$actual_cost_ngn=round($actual_cost_ngn,2);
$actual_profit=round($charge-($actual_cost_ngn>0?$actual_cost_ngn:$provider_cost_estimate),2);

if($main_trnx_id){
    $wpdb->update($trnx,[
        'status'=>$has_code?'success':'pending',
        'profit_amount'=>$actual_profit,
        'gateway_response'=>wp_json_encode($provider_data)
    ],['id'=>$main_trnx_id],['%s','%f','%s'],['%d']);
}

$data=[
    'reference'=>$ref,
    'transaction_id'=>$txid,
    'provider_transaction_id'=>$provider_txid,
    'product_id'=>$product_id,
    'product_name'=>$normalized['name'],
    'brand'=>$normalized['brand'],
    'country_iso'=>$provider_country,
    'amount'=>$amount,
    'recipient_amount'=>$amount,
    'sender_amount'=>$sender_amount,
    'currency'=>$normalized['currency'],
    'sender_currency'=>$normalized['sender_currency'],
    'wallet_charge'=>$charge,
    'new_balance'=>$new_balance,
    'status'=>$has_code?'completed':'pending',
    'redeemId'=>(string)$provider_txid,
    'redeem'=>$card['redeem']??'',
    'redeem_details'=>$card['redeem_details']??'',
    'cardNumber'=>$card['card_number']??'',
    'pinCode'=>$card['pin_code']??'',
    'redemptionUrl'=>$card['redemption_url']??''
];
echo wp_json_encode([
    'success'=>true,
    'message'=>$has_code?'Giftcard purchased successfully.': 'Giftcard order submitted. Your giftcard code is being prepared.',
    'data'=>$data
]);exit;
