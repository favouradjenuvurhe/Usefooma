<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
require_once PULSEPOINT_DIR . 'includes/api/biometric.php';
global $wpdb;
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') wp_send_json(['success'=>false,'message'=>'Invalid request method'],405);
$in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
$token=sanitize_text_field($in['token']??''); $public=sanitize_text_field($in['public_key']??''); $key_id=sanitize_text_field($in['key_id']??'');
$user=pulsepoint_biometric_get_user_by_token($token);
if(!$user || (int)$user->status!==1) wp_send_json(['success'=>false,'message'=>'Invalid or expired token'],401);
if (!empty($in['disable'])) { $wpdb->update($wpdb->prefix.'pulsepoint_users',['biometric_enabled'=>0],['id'=>(int)$user->id],['%d'],['%d']); wp_send_json(['success'=>true,'enabled'=>false]); }
if($public==='') wp_send_json(['success'=>false,'message'=>'Public key is required'],400);
$raw=base64_decode($public,true); if($raw===false || strlen($raw)<32) wp_send_json(['success'=>false,'message'=>'Invalid public key'],400);
$table=$wpdb->prefix.'pulsepoint_users';
$ok=$wpdb->update($table,['biometric_public_key'=>$public,'biometric_key_id'=>$key_id,'biometric_enabled'=>1],['id'=>(int)$user->id],['%s','%s','%d'],['%d']);
if($ok===false) wp_send_json(['success'=>false,'message'=>'Could not register biometric device'],500);
wp_send_json(['success'=>true,'enabled'=>true]);
