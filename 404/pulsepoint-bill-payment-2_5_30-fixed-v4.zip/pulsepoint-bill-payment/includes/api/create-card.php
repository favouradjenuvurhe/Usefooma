<?php
/**
 * Pulsepoint Virtual Card API
 * Path: /api/create-card.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$users_table = $base_prefix . 'users';
$settings_table = $base_prefix . 'settings';

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
*/

$headers = function_exists('getallheaders') ? getallheaders() : [];

// Header names are case-insensitive (HTTP/2, LiteSpeed and nginx often send them
// lower-case) and some hosts only expose the value through $_SERVER.
$authorization = '';
foreach ((array) $headers as $header_name => $header_value) {
    if (strtolower((string) $header_name) === 'authorization') {
        $authorization = trim((string) $header_value);
        break;
    }
}
if ($authorization === '') {
    $authorization = trim((string) (
        $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? ''
    ));
}

if ($authorization === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Missing Authorization header.'
    ]);
    exit;
}

// "Token" / "Bearer" with nothing after it means the client had no token to send.
if (preg_match('/^(?:Token|Bearer)$/i', $authorization)) {
    echo json_encode([
        'success' => false,
        'message' => 'Your session token is empty. Please log out and log in again.'
    ]);
    exit;
}

if (!preg_match('/(?:Token|Bearer)\s+(\S+)/i', $authorization, $matches)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid Authorization format. Use: Authorization: Token <your_token>'
    ]);
    exit;
}

$token = sanitize_text_field($matches[1]);

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM {$users_table} WHERE token=%s LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token.'
    ]);
    exit;
}

if ((int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Account inactive.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| GET - Card Configuration
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $provider = $wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='virtualcard_type'
        LIMIT 1"
    );

    $minimum_amount = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='card_creation_minimum'
        LIMIT 1"
    );

    if (!$minimum_amount) {
        $minimum_amount = 3;
    }

    $flat_fee = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='card_creation_flat_fee'
        LIMIT 1"
    );

    $percent_fee = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='card_creation_percent_fee'
        LIMIT 1"
    );

    $rate = (float)$wpdb->get_var(
        "SELECT opt_value
        FROM {$settings_table}
        WHERE opt_key='rate_usd'
        LIMIT 1"
    );

    $multiple_enabled = $wpdb->get_var(
        "SELECT opt_value FROM {$settings_table} WHERE opt_key='virtualcard_multiple_enabled' LIMIT 1"
    );
    $multiple_enabled = maybe_unserialize($multiple_enabled);
    $multiple_enabled = !in_array(strtolower((string) $multiple_enabled), ['0', 'false', 'no', 'off'], true);
    $card_count = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$base_prefix}virtual_cards WHERE user_id = %d", $user->id)
    );

    echo json_encode([

        'success' => true,

        'message' => 'Virtual card configuration fetched successfully.',

        'data' => [

            'provider' => $provider,

            'minimum_amount' => $minimum_amount,

            'flat_fee' => $flat_fee,

            'percent_fee' => $percent_fee,

            'rate_usd' => $rate,

            'wallet_balance' => (float)$user->wallet,

            'currency' => 'NGN'

        ]

    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| POST ONLY
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);

    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $input = $_POST;
}

$card_type = sanitize_text_field($input['card_type'] ?? '');
$amount = floatval($input['amount'] ?? 0);

if (empty($card_type)) {

    echo json_encode([
        'success' => false,
        'message' => 'card_type is required.'
    ]);

    exit;
}

if ($amount <= 0) {

    echo json_encode([
        'success' => false,
        'message' => 'Invalid amount.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Create Virtual Card
|--------------------------------------------------------------------------
*/

// Start session
if (!session_id()) {
    session_start();
}

// Simulate logged-in user for the main handler
$_SESSION['pulsepoint_user']['id'] = (int) $user->id;

// Pass values to the existing handler
$_POST['card_type'] = $card_type;
$_POST['amount']    = $amount;

// Main Virtual Card Handler
$handler = PULSEPOINT_DIR . 'core/virtualcard/pulsepoint.php';

if (!file_exists($handler)) {

    echo json_encode([
        'success' => false,
        'message' => 'Virtual card handler not found.'
    ]);

    exit;
}

require_once $handler;

// Ensure the function exists
if (!function_exists('pulsepoint_create_card')) {

    echo json_encode([
        'success' => false,
        'message' => 'Function pulsepoint_create_card() not found.'
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Execute
|--------------------------------------------------------------------------
|
| The handler will:
| - Validate the amount
| - Get the provider
| - Calculate fees
| - Convert USD to NGN
| - Deduct wallet balance
| - Call the provider API
| - Save the card
| - Save the transaction
| - Return JSON via wp_send_json()
|
*/

pulsepoint_create_card();

exit;