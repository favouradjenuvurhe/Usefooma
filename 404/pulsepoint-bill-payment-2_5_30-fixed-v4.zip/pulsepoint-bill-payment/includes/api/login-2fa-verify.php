<?php
/**
 * Pulsepoint API — Login 2FA Verification
 * Path: /api/login-2fa-verify.php
 *
 * Completes the 2FA challenge returned by /api/auth.php.
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json(['success' => false, 'message' => 'Invalid request method'], 405);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);

if (!is_array($input)) {
    $input = $_POST;
}

$challenge = sanitize_text_field($input['challenge_token'] ?? '');
$token     = sanitize_text_field($input['token'] ?? '');
$code      = sanitize_text_field($input['code'] ?? '');

if (($challenge === '' && $token === '') || $code === '') {
    wp_send_json([
        'success' => false,
        'message' => '2FA challenge and authentication code are required'
    ], 400);
}

$table = $wpdb->prefix . 'pulsepoint_users';
$user = false;

/* Preferred API flow: short-lived challenge returned by /api/auth. */
if ($challenge !== '') {
    $challenge_key = 'pulsepoint_login_2fa_' . hash('sha256', $challenge);
    $challenge_user_id = get_transient($challenge_key);

    if ($challenge_user_id) {
        $user = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM `{$table}` WHERE id = %d LIMIT 1",
                (int) $challenge_user_id
            )
        );
    }
}

/* Backwards-compatible flow for an already authenticated API token. */
if (!$user && $token !== '') {
    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE token = %s LIMIT 1",
            $token
        )
    );
}

if (!$user || (int) $user->status !== 1) {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid or expired 2FA challenge'
    ], 401);
}

if ((int) ($user->twofa_enabled ?? 0) !== 1) {
    wp_send_json([
        'success' => false,
        'message' => 'Two-factor authentication is not enabled'
    ], 400);
}

/*
 * /api/auth.php stores the pending 2FA user in the normal session.
 * If a mobile client starts a fresh PHP session, restore that pending
 * identity only after validating the supplied token against the database.
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$_SESSION['pulsepoint_2fa_user'] = (int) $user->id;
$_POST['code'] = $code;

if ($challenge !== '') {
    $_SESSION['pulsepoint_login_2fa_challenge_key'] =
        'pulsepoint_login_2fa_' . hash('sha256', $challenge);
}

/* Load the same completion handler used by the web application. */
$handler = PULSEPOINT_DIR . 'core/login_2fa_verify.php';

if (!file_exists($handler)) {
    wp_send_json([
        'success' => false,
        'message' => '2FA verification handler not found'
    ], 500);
}

if (!function_exists('pulsepoint_login_2fa_verify')) {
    require_once $handler;
}

if (!function_exists('pulsepoint_login_2fa_verify')) {
    wp_send_json([
        'success' => false,
        'message' => '2FA verification handler unavailable'
    ], 500);
}

pulsepoint_login_2fa_verify();
exit;
