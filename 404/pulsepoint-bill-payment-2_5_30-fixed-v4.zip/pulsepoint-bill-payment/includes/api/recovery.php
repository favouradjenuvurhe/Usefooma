<?php
/**
 * Pulsepoint API — Password Recovery
 * Path: /api/recovery.php
 *
 * Uses the same password-recovery handler as the web application.
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid request method'
    ], 405);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);

if (!is_array($input)) {
    $input = $_POST;
}

if (!is_array($input)) {
    $input = [];
}

$email = sanitize_email($input['email'] ?? '');

if ($email === '') {
    wp_send_json([
        'success' => false,
        'message' => 'Email is required'
    ], 400);
}

$handler = PULSEPOINT_DIR . 'core/forgot-password.php';

if (!file_exists($handler)) {
    wp_send_json([
        'success' => false,
        'message' => 'Forgot password handler not found'
    ], 500);
}

if (!function_exists('pulsepoint_forgot_password')) {
    require_once $handler;
}

$_POST['email'] = $email;
$_SERVER['REQUEST_METHOD'] = 'POST';

if (!function_exists('pulsepoint_forgot_password')) {
    wp_send_json([
        'success' => false,
        'message' => 'Forgot password handler unavailable'
    ], 500);
}

pulsepoint_forgot_password();
exit;
