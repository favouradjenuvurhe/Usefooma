<?php
/**
 * Pulsepoint biometric authorization helpers.
 *
 * Android registers an ECDSA public key after a successful native biometric
 * check. For each protected transaction the server issues a short-lived,
 * one-time challenge. Android signs that challenge with the Keystore private
 * key only after BiometricPrompt succeeds. The server verifies the signature
 * and returns a one-time authorization token.
 */
if (!defined('ABSPATH')) { require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php'; }

function pulsepoint_biometric_get_user_by_token($token) {
    global $wpdb;
    $token = sanitize_text_field((string)$token);
    $table = $wpdb->prefix . 'pulsepoint_users';
    $cols  = 'id, token, status, biometric_enabled, biometric_public_key, biometric_key_id';
    if ($token !== '') {
        $user = $wpdb->get_row($wpdb->prepare("SELECT {$cols} FROM `{$table}` WHERE token = %s LIMIT 1", $token));
        if ($user) return $user;
    }
    // FIX: after the app is backgrounded/resumed the page can still hold an old
    // or empty token. Fall back to the logged-in session user so biometric keeps
    // working instead of failing with "not enabled".
    if (session_status() !== PHP_SESSION_ACTIVE && !headers_sent()) { @session_start(); }
    $sid = (int)($_SESSION['pulsepoint_user']['id'] ?? 0);
    if ($sid > 0) {
        $user = $wpdb->get_row($wpdb->prepare("SELECT {$cols} FROM `{$table}` WHERE id = %d LIMIT 1", $sid));
        if ($user) return $user;
    }
    return false;
}

function pulsepoint_biometric_is_enabled($user) {
    return $user && (int)($user->status ?? 0) === 1 && (int)($user->biometric_enabled ?? 0) === 1 && !empty($user->biometric_public_key);
}

function pulsepoint_biometric_issue_challenge($user_id, $purpose = 'transaction', $payload_hash = '') {
    $challenge = bin2hex(random_bytes(32));
    $key = 'pulsepoint_bio_ch_' . hash('sha256', $challenge);
    set_transient($key, [
        'user_id' => (int)$user_id,
        'purpose' => sanitize_key($purpose),
        'payload_hash' => sanitize_text_field($payload_hash),
        'created' => time(),
    ], 120);
    return $challenge;
}

function pulsepoint_biometric_verify_challenge($token, $challenge, $signature_b64, $purpose = 'transaction', $payload_hash = '') {
    global $wpdb;
    $user = pulsepoint_biometric_get_user_by_token($token);
    if (!pulsepoint_biometric_is_enabled($user)) return new WP_Error('bio_disabled', 'Biometric authentication is not enabled.');
    $challenge = sanitize_text_field((string)$challenge);
    if ($challenge === '') return new WP_Error('bio_challenge', 'Biometric challenge is required.');
    $key = 'pulsepoint_bio_ch_' . hash('sha256', $challenge);
    $data = get_transient($key);
    if (!is_array($data) || (int)($data['user_id'] ?? 0) !== (int)$user->id) return new WP_Error('bio_expired', 'Biometric challenge expired.');
    if (($data['purpose'] ?? '') !== sanitize_key($purpose)) return new WP_Error('bio_purpose', 'Invalid biometric purpose.');
    if ((string)($data['payload_hash'] ?? '') !== (string)$payload_hash) return new WP_Error('bio_payload', 'Biometric transaction data does not match.');
    delete_transient($key);

    $public = base64_decode((string)$user->biometric_public_key, true);
    $signature = base64_decode((string)$signature_b64, true);
    if ($public === false || $signature === false) return new WP_Error('bio_encoding', 'Invalid biometric signature.');
    $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($public), 64, "\n") . "-----END PUBLIC KEY-----\n";
    $ok = openssl_verify($challenge, $signature, $pem, OPENSSL_ALGO_SHA256);
    if ($ok !== 1) return new WP_Error('bio_signature', 'Biometric verification failed.');

    $auth = bin2hex(random_bytes(32));
    $auth_key = 'pulsepoint_bio_auth_' . hash('sha256', $auth);
    set_transient($auth_key, [
        'user_id' => (int)$user->id,
        'purpose' => sanitize_key($purpose),
        'payload_hash' => sanitize_text_field($payload_hash),
    ], 90);
    return $auth;
}

function pulsepoint_biometric_consume_authorization($token, $authorization, $purpose = 'transaction', $payload_hash = '') {
    $user = pulsepoint_biometric_get_user_by_token($token);
    if (!$user || !pulsepoint_biometric_is_enabled($user)) return false;
    $authorization = sanitize_text_field((string)$authorization);
    if ($authorization === '') return false;
    $key = 'pulsepoint_bio_auth_' . hash('sha256', $authorization);
    $data = get_transient($key);
    if (!is_array($data) || (int)($data['user_id'] ?? 0) !== (int)$user->id) return false;
    if (($data['purpose'] ?? '') !== sanitize_key($purpose)) return false;
    if ((string)($data['payload_hash'] ?? '') !== (string)$payload_hash) return false;
    delete_transient($key);
    return true;
}

function pulsepoint_biometric_payload_hash($payload) {
    if (!is_array($payload)) $payload = [];
    unset($payload['passcode'], $payload['biometric_token'], $payload['biometric_signature'], $payload['biometric_rebind_public_key'], $payload['biometric_rebind_key_id']);
    ksort($payload);
    return hash('sha256', wp_json_encode($payload, JSON_UNESCAPED_SLASHES));
}

function pulsepoint_require_transaction_authorization($user, $payload, $purpose = 'transaction') {
    $payload_hash = pulsepoint_biometric_payload_hash($payload);
    $bio_token = sanitize_text_field($payload['biometric_token'] ?? '');
    if ($bio_token !== '' && pulsepoint_biometric_consume_authorization($user->token, $bio_token, $purpose, $payload_hash)) return true;
    $pin = sanitize_text_field($payload['passcode'] ?? '');
    if (preg_match('/^\d{4}$/', $pin) && !empty($user->passcode) && hash_equals((string)$user->passcode, $pin)) {
        pulsepoint_biometric_rebind_after_pin($user, $payload);
        return true;
    }
    return false;
}

/**
 * Self-heal: biometric was already turned on for this user, but this phone's key
 * no longer matches the one on the server (key regenerated / app data cleared).
 * Once the user has proven themselves with the server-verified PIN, store the
 * phone's current key so biometric keeps working without manual setup.
 */
function pulsepoint_biometric_rebind_after_pin($user, $payload) {
    global $wpdb;
    $pub = sanitize_text_field((string)($payload['biometric_rebind_public_key'] ?? ''));
    $kid = sanitize_text_field((string)($payload['biometric_rebind_key_id'] ?? ''));
    if ($pub === '' || empty($user->id)) return;
    $raw = base64_decode($pub, true);
    if ($raw === false || strlen($raw) < 32) return;
    $table = $wpdb->prefix . 'pulsepoint_users';
    $row = $wpdb->get_row($wpdb->prepare("SELECT biometric_enabled, biometric_public_key FROM `{$table}` WHERE id = %d LIMIT 1", (int)$user->id));
    if (!$row || (int)$row->biometric_enabled !== 1) return;          // only users who turned it on
    if (hash_equals((string)$row->biometric_public_key, $pub)) return; // already in sync
    $wpdb->update($table, ['biometric_public_key' => $pub, 'biometric_key_id' => $kid, 'biometric_enabled' => 1],
        ['id' => (int)$user->id], ['%s', '%s', '%d'], ['%d']);
}
