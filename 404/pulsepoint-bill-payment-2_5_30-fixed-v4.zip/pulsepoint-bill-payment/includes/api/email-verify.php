<?php
/**
 * Pulsepoint API — Email Verification
 * Path: /api/email-verify.php
 *
 * Uses the same core verification handler as the web application.
 * Token may be supplied in the JSON body when the mobile client has
 * not yet established a browser session.
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json(['success' => false, 'message' => 'Invalid request method'], 405);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);

if (!is_array($input)) {
    $input = $_POST;
}

$token = sanitize_text_field($input['token'] ?? '');
$verification_token = sanitize_text_field(
    $input['verification_token'] ?? ''
);
$code = sanitize_text_field($input['code'] ?? '');

if (($token === '' && $verification_token === '') || $code === '') {
    wp_send_json([
        'success' => false,
        'message' => 'Verification token and code are required'
    ], 400);
}

$table = $wpdb->prefix . 'pulsepoint_users';
$user = false;

/* Preferred API flow: short-lived verification challenge returned by create. */
if ($verification_token !== '') {

    $challenge_key =
        'pulsepoint_email_verify_' .
        hash('sha256', $verification_token);

    $challenge_user_id = get_transient($challenge_key);

    if ($challenge_user_id) {
        $user = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM `{$table}` WHERE id = %d LIMIT 1",
                (int) $challenge_user_id
            )
        );
    }
}

/* Backwards-compatible flow using the account token. */
if (!$user && $token !== '') {

    $user = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM `{$table}` WHERE token = %s LIMIT 1",
            $token
        )
    );
}

if (!$user) {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid or expired verification token'
    ], 401);
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* The core handler identifies the pending account from this session. */
$_SESSION['pulsepoint_user']['id'] = (int) $user->id;
$_SESSION['pulsepoint_user']['token'] = (string) ($user->token ?? $token);
$_POST['code'] = $code;

if ($verification_token !== '') {
    $_SESSION['pulsepoint_email_verify_challenge_key'] =
        'pulsepoint_email_verify_' . hash('sha256', $verification_token);
}

$handler = PULSEPOINT_DIR . 'core/verify.php';

if (!file_exists($handler)) {
    wp_send_json([
        'success' => false,
        'message' => 'Email verification handler not found'
    ], 500);
}

if (!function_exists('pulsepoint_email_verify')) {
    require_once $handler;
}

if (!function_exists('pulsepoint_email_verify')) {
    wp_send_json([
        'success' => false,
        'message' => 'Email verification handler unavailable'
    ], 500);
}

pulsepoint_email_verify();
exit;
