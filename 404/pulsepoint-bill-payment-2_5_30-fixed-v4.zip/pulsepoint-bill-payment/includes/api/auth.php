<?php
/**
 * Pulsepoint API — Login
 * Path: /api/auth.php
 *
 * API compatibility wrapper around the current core login handler.
 * This keeps the API login path in sync with the web login features:
 * - brute-force protection
 * - account status / close-account checks
 * - password rehashing
 * - token/passcode generation
 * - 2FA gate
 * - hardened sessions
 * - verification redirect/email behaviour
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid request method'
    ], 405);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);

if (!is_array($input)) {
    $input = $_POST;
}

if (!is_array($input)) {
    $input = [];
}

$email_or_phone = sanitize_text_field(
    $input['email_or_phone']
    ?? $input['email']
    ?? $input['phone']
    ?? ''
);

$password = isset($input['password'])
    ? (string) $input['password']
    : '';

if ($email_or_phone === '' || $password === '') {
    wp_send_json([
        'success' => false,
        'message' => 'Email or Phone Number and Password are required.'
    ], 400);
}

/*
 * The current web login handler is the single source of truth.
 * It reads email/password from $_POST and sends the final JSON response.
 */
if (!function_exists('pulsepoint_user_login')) {
    $handler = PULSEPOINT_DIR . 'core/login.php';

    if (!file_exists($handler)) {
        wp_send_json([
            'success' => false,
            'message' => 'Login handler not found'
        ], 500);
    }

    require_once $handler;
}

$_POST['email'] = $email_or_phone;
$_POST['password'] = $password;
$_SERVER['REQUEST_METHOD'] = 'POST';

if (!function_exists('pulsepoint_user_login')) {
    wp_send_json([
        'success' => false,
        'message' => 'Login handler unavailable'
    ], 500);
}

pulsepoint_user_login();
exit;
