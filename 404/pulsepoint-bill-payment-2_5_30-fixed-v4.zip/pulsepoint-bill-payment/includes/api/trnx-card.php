<?php
/**
 * Pulsepoint API - Virtual Card Transactions
 * Path: /api/transaction-card.php
 * Author: Amaaavl
 */

require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

// Allow only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit;
}

// Read JSON body
$input = json_decode(file_get_contents('php://input'), true);

// Fallback to form-data
if (!$input) {
    $input = $_POST;
}

// Get token
$token = sanitize_text_field($input['token'] ?? '');

if (empty($token)) {
    echo json_encode([
        'success' => false,
        'message' => 'Token is required.'
    ]);
    exit;
}

$base_prefix = $wpdb->prefix . 'pulsepoint_';

$users_table        = $base_prefix . 'users';
$cards_table        = $base_prefix . 'virtual_cards';
$transactions_table = $base_prefix . 'virtualcard_transactions';

/*
|--------------------------------------------------------------------------
| Validate User
|--------------------------------------------------------------------------
*/

$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT id, status
        FROM {$users_table}
        WHERE token = %s
        LIMIT 1",
        $token
    )
);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid or expired token.'
    ]);
    exit;
}

if ((int)$user->status !== 1) {
    echo json_encode([
        'success' => false,
        'message' => 'Account inactive.'
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| Get User Cards
|--------------------------------------------------------------------------
*/

$requested_card_id = sanitize_text_field($input['card_id'] ?? '');

if ($requested_card_id !== '') {
    $card_ids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT card_id FROM {$cards_table} WHERE user_id = %d AND card_id = %s LIMIT 1",
            $user->id,
            $requested_card_id
        )
    );
} else {
    $card_ids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT card_id FROM {$cards_table} WHERE user_id = %d ORDER BY id DESC",
            $user->id
        )
    );
}

if (empty($card_ids)) {
    echo json_encode([
        'success' => true,
        'data' => [],
        'cards' => []
    ]);
    exit;
}

$placeholders = implode(',', array_fill(0, count($card_ids), '%s'));
$transactions = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT
            transaction_id, card_id, amount, type, method, narrative,
            status, currency, created_at, reference
         FROM {$transactions_table}
         WHERE card_id IN ($placeholders)
         ORDER BY created_at DESC, id DESC",
        ...$card_ids
    )
);

$data = [];
foreach ($transactions as $trx) {
    $amount = (float) $trx->amount;
    if (strtolower((string) $trx->type) === 'debit') {
        $amount = -abs($amount);
    } else {
        $amount = abs($amount);
    }

    $title = 'Card Transaction';
    if (!empty($trx->method)) {
        $title = ucwords(str_replace(['_', '-'], ' ', $trx->method));
    }

    $subtitle = !empty($trx->narrative)
        ? $trx->narrative
        : (!empty($trx->created_at) ? date('M d, Y h:i A', strtotime($trx->created_at)) : '');

    $data[] = [
        'title' => $title,
        'date' => $subtitle,
        'amount' => $amount,
        'icon' => null,
        'card_id' => $trx->card_id,
        'transaction_id' => $trx->transaction_id,
        'status' => $trx->status,
        'currency' => $trx->currency,
        'reference' => $trx->reference
    ];
}

/*
|--------------------------------------------------------------------------
| Response
|--------------------------------------------------------------------------
*/

echo json_encode([
    'success' => true,
    'data' => $data
]);

exit;