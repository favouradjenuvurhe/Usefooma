<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
require_once PULSEPOINT_DIR . 'includes/api/biometric.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') wp_send_json(['success'=>false,'message'=>'Invalid request method'],405);
$in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
$token=sanitize_text_field($in['token']??''); $challenge=sanitize_text_field($in['challenge']??''); $signature=sanitize_text_field($in['signature']??''); $purpose=sanitize_key($in['purpose']??'transaction'); $payload=is_array($in['payload']??null)?$in['payload']:null; $payload_hash=sanitize_text_field($in['payload_hash']??''); if($payload!==null){$payload_hash=pulsepoint_biometric_payload_hash($payload);}
$result=pulsepoint_biometric_verify_challenge($token,$challenge,$signature,$purpose,$payload_hash);
if(is_wp_error($result)) wp_send_json(['success'=>false,'code'=>$result->get_error_code(),'message'=>$result->get_error_message()],403);
wp_send_json(['success'=>true,'authorization_token'=>$result]);
