<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
global $wpdb; header('Content-Type: application/json; charset=utf-8');
$in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) $in=$_POST;
$token=sanitize_text_field($in['token']??($_GET['token']??''));
if(!$token) wp_send_json(['success'=>false,'message'=>'Token is required'],400);
$table=$wpdb->prefix.'pulsepoint_users';
$user=$wpdb->get_row($wpdb->prepare("SELECT id, biometric_enabled FROM `{$table}` WHERE token=%s AND status=1 LIMIT 1",$token));
if(!$user) wp_send_json(['success'=>false,'message'=>'Invalid or expired token'],401);
if(!empty($in['disable'])) { $wpdb->update($table,['biometric_enabled'=>0],['id'=>(int)$user->id],['%d'],['%d']); $user->biometric_enabled=0; }
wp_send_json(['success'=>true,'enabled'=>(int)$user->biometric_enabled===1]);
