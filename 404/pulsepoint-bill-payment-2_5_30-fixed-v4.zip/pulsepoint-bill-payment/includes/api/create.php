<?php
/**
 * Pulsepoint API — Registration
 * Path: /api/create.php
 *
 * API compatibility wrapper around the current core registration handler.
 * The API accepts both the old mobile payload and the current web fields.
 *
 * Old:
 *   fullname, phone, email, password, confirm_password, passcode, referby
 *
 * Current core:
 *   firstname, lastname, phone, email, password, passcode, refer
 */

if (!defined('ABSPATH')) {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json([
        'success' => false,
        'message' => 'Invalid request method'
    ], 405);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);

if (!is_array($input)) {
    $input = $_POST;
}

if (!is_array($input)) {
    $input = [];
}

/*
 * Accept the existing API's fullname field, while also supporting
 * firstname/lastname used by the updated web registration.
 */
$firstname = sanitize_text_field(
    $input['firstname'] ?? ''
);

$lastname = sanitize_text_field(
    $input['lastname'] ?? ''
);

$fullname = sanitize_text_field(
    $input['fullname'] ?? ''
);

if ($firstname === '' && $fullname !== '') {
    $parts = preg_split('/\s+/', trim($fullname), 2);
    $firstname = $parts[0] ?? '';
    $lastname  = $parts[1] ?? '';
}

$phone = sanitize_text_field(
    $input['phone'] ?? ''
);

$email = sanitize_email(
    $input['email'] ?? ''
);

$password = isset($input['password'])
    ? (string) $input['password']
    : '';

$confirm_password = isset($input['confirm_password'])
    ? (string) $input['confirm_password']
    : '';

$passcode = sanitize_text_field(
    $input['passcode'] ?? ''
);

$refer = sanitize_text_field(
    $input['refer']
    ?? $input['referby']
    ?? ''
);

/*
 * Preserve the old API contract: if confirm_password is supplied,
 * it must match. If omitted, the core handler remains responsible for
 * the rest of registration validation.
 */
if (
    $confirm_password !== ''
    && !hash_equals($password, $confirm_password)
) {
    wp_send_json([
        'success' => false,
        'message' => 'Passwords do not match'
    ], 400);
}

if ($firstname === '' || $lastname === '' || $phone === '' || $password === '' || $passcode === '') {
    wp_send_json([
        'success' => false,
        'message' => 'Firstname, lastname, phone, password and passcode are required.'
    ], 400);
}

if (!function_exists('pulsepoint_user_register')) {
    $handler = PULSEPOINT_DIR . 'core/register.php';

    if (!file_exists($handler)) {
        wp_send_json([
            'success' => false,
            'message' => 'Registration handler not found'
        ], 500);
    }

    require_once $handler;
}

$_POST['firstname'] = $firstname;
$_POST['lastname']  = $lastname;
$_POST['phone']     = $phone;
$_POST['email']     = $email;
$_POST['password']  = $password;
$_POST['passcode']  = $passcode;
$_POST['refer']     = $refer;

$_SERVER['REQUEST_METHOD'] = 'POST';

if (!function_exists('pulsepoint_user_register')) {
    wp_send_json([
        'success' => false,
        'message' => 'Registration handler unavailable'
    ], 500);
}

pulsepoint_user_register();
exit;
