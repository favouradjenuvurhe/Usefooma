<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 🔹 Guard against any stray output before headers are sent
 *    (whitespace, BOM, notices from other plugins, etc.) so
 *    session_start() below never fires after headers have gone out.
 */
if (!ob_get_level()) {
    ob_start();
}

/**
 * 🔹 Add query var for callback
 */
add_filter('query_vars', function ($vars) {
    $vars[] = 'pulsepoint_callback';
    return $vars;
});

/**
 * 🔹 Add rewrite rules for callback URLs
 *    e.g. /callback/whogopay → includes/callback/whogopay.php
 */
add_action('init', function () {
    add_rewrite_rule('^callback/?$', 'index.php?pulsepoint_callback=index', 'top');
    add_rewrite_rule('^callback/([^/]*)/?', 'index.php?pulsepoint_callback=$matches[1]', 'top');
});

/**
 * 🔹 Start session (if needed) — safe against "headers already sent"
 *    Reuses the shared starter if public.php already defined one,
 *    so we never have two different session_start() call sites
 *    racing each other.
 */

/**
 * Resolve the credential slot for a virtual-account provider.
 *
 * Slot 1 = pay_token / pay_secret / pay_biz
 * Slot 2 = pay_token_2 / pay_secret_2 / pay_biz_2
 *
 * The provider itself is never hard-coded to a slot. Whatever provider the
 * admin selects as primary uses slot 1; whatever provider is selected as the
 * enabled secondary uses slot 2.
 */
if (!function_exists('pulsepoint_get_virtual_account_provider_slot')) {
    function pulsepoint_get_virtual_account_provider_slot($provider): int {
        global $wpdb;

        $provider = strtolower(trim((string) $provider));
        if ($provider === '') {
            return 1;
        }

        $table = $wpdb->prefix . 'pulsepoint_settings';
        $rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$table}");
        $settings = [];

        foreach ($rows as $row) {
            $settings[(string) $row->opt_key] = maybe_unserialize($row->opt_value);
        }

        $primary = strtolower(trim((string) (
            $settings['virtual_account_provider_1']
            ?? $settings['payment_gateway']
            ?? ''
        )));

        $secondary = strtolower(trim((string) (
            $settings['virtual_account_provider_2'] ?? ''
        )));

        $secondary_enabled = !empty($settings['virtual_account_provider_2_enabled']);

        if ($secondary_enabled && $secondary !== '' && $provider === $secondary) {
            return 2;
        }

        if ($primary !== '' && $provider === $primary) {
            return 1;
        }

        // Legacy installations may not have virtual_account_provider_1 yet.
        // Keep the old primary credential set as the safe fallback.
        return 1;
    }
}

if (!function_exists('pulsepoint_get_virtual_account_callback_setting')) {
    function pulsepoint_get_virtual_account_callback_setting($key, $provider): string {
        global $wpdb;

        $slot = pulsepoint_get_virtual_account_provider_slot($provider);
        $setting_key = $slot === 2 ? $key . '_2' : $key;
        $table = $wpdb->prefix . 'pulsepoint_settings';

        $value = $wpdb->get_var($wpdb->prepare(
            "SELECT opt_value FROM {$table} WHERE opt_key = %s LIMIT 1",
            $setting_key
        ));

        return trim((string) maybe_unserialize($value ?? ''));
    }
}

if (!function_exists('pulsepoint_start_session')) {
    function pulsepoint_start_session() {
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            session_start([
                'cookie_httponly' => true,
                'cookie_samesite' => 'Lax',
                'use_strict_mode' => true,
            ]);
        }
    }
}
add_action('init', 'pulsepoint_start_session', 1);

/**
 * 🔹 Template redirect handler for /callback/*
 */
add_action('template_redirect', function () {
    $cb = get_query_var('pulsepoint_callback');
    if ($cb) {

        status_header(200);
        nocache_headers();

        // ✅ Define the callback directory
        $callback_dir = PULSEPOINT_DIR . 'includes/callback/';

        // Sanitize and find target file
        $callback_file = sanitize_file_name($cb);
        $file_path = $callback_dir . $callback_file . '.php';

        // Default to index.php if no file found
        if (!file_exists($file_path)) {
            $file_path = $callback_dir . 'index.php';
        }

        // ✅ Include the callback file
        include $file_path;
        exit;
    }
});
