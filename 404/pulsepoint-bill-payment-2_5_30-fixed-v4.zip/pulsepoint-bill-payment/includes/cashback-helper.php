<?php
/**
 * Pulsepoint Shared Cashback Helper
 * Cashback is credited to referral_balance and is intentionally NOT recorded
 * as a separate transaction. The purchase transaction remains the only
 * transaction-history entry for the purchase.
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('pulsepoint_transaction_description')) {
    /**
     * Keep transaction descriptions compact and consistent in history/API.
     * 23 characters is the maximum; no ellipsis is added so every description
     * stays within the same visible character budget.
     */
    function pulsepoint_transaction_description($description, int $max_length = 23): string {
        $description = trim(wp_strip_all_tags((string) $description));
        if ($description === '') return '';
        if (function_exists('mb_substr')) {
            return mb_substr($description, 0, $max_length, 'UTF-8');
        }
        return substr($description, 0, $max_length);
    }
}

if (!function_exists('pulsepoint_credit_cashback')) {
    function pulsepoint_credit_cashback(int $user_id, float $cashback_amount, string $category = '', string $reference = '', string $description = 'Cashback'): void {
        if ($cashback_amount <= 0) return;

        global $wpdb;
        $table_users = $wpdb->prefix . 'pulsepoint_users';

        // Cashback is reward balance, so it belongs in referral_balance.
        // Do not create a transaction row for cashback.
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table_users} SET referral_balance = referral_balance + %f WHERE id = %d",
            $cashback_amount,
            $user_id
        ));
    }
}
