<?php
/**
 * Fincra Collection Webhook
 * Pulsepoint 2.5.29
 *
 * Configure this URL in the Fincra dashboard:
 *   /callback/fincra
 *
 * Credentials are resolved dynamically from the provider slot selected in Payment Gateway.
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    status_header(403);
    header('Content-Type: application/json; charset=utf-8');
    echo wp_json_encode(['success' => false, 'message' => 'POST requests only.']);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

$raw = file_get_contents('php://input');
$data = json_decode($raw ?: '', true);

if (!is_array($data)) {
    status_header(400);
    echo wp_json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

$signature = '';
$headers = function_exists('getallheaders') ? getallheaders() : [];
if (is_array($headers)) {
    $signature = $headers['signature'] ?? ($headers['Signature'] ?? '');
}
if ($signature === '') {
    $signature = $_SERVER['HTTP_SIGNATURE'] ?? '';
}

$base = $wpdb->prefix . 'pulsepoint_';
$settings = $base . 'settings';
$accounts = $base . 'account';
$users = $base . 'users';
$trnx = $base . 'trnx';

// Fincra uses whichever credential slot the admin assigned to Fincra.
$webhookSecret = pulsepoint_get_virtual_account_callback_setting('pay_secret', 'fincra');

if ($webhookSecret === '' || $signature === '') {
    status_header(401);
    echo wp_json_encode(['success' => false, 'message' => 'Fincra webhook secret/signature missing.']);
    exit;
}

$calculated = hash_hmac('sha512', $raw, $webhookSecret);

if (!hash_equals($calculated, trim((string) $signature))) {
    status_header(401);
    echo wp_json_encode(['success' => false, 'message' => 'Invalid Fincra webhook signature.']);
    exit;
}

$event = sanitize_text_field($data['event'] ?? '');
$payload = $data['data'] ?? [];

if ($event !== 'collection.successful') {
    echo wp_json_encode(['success' => true, 'message' => 'Event received.', 'event' => $event]);
    exit;
}

$reference = sanitize_text_field($payload['reference'] ?? '');
$virtualAccountId = sanitize_text_field($payload['virtualAccount'] ?? '');
$amountReceived = (float) ($payload['amountReceived'] ?? 0);
$sourceAmount = (float) ($payload['sourceAmount'] ?? 0);
$senderName = sanitize_text_field($payload['senderAccountName'] ?? $payload['customerName'] ?? '');
$senderAccount = sanitize_text_field($payload['senderAccountNumber'] ?? '');
$status = sanitize_text_field($payload['status'] ?? 'successful');

if ($reference === '' || $virtualAccountId === '' || $amountReceived <= 0) {
    status_header(400);
    echo wp_json_encode(['success' => false, 'message' => 'Incomplete Fincra collection payload.']);
    exit;
}

// Fincra collection webhooks identify the virtual account by ID, not always by number.
// Resolve the ID to its account number before mapping it to our local account table.
$apiKey = pulsepoint_get_virtual_account_callback_setting('pay_token', 'fincra');

if ($apiKey === '') {
    status_header(500);
    echo wp_json_encode(['success' => false, 'message' => 'Fincra API key is not configured for its selected provider slot.']);
    exit;
}

$lookup = wp_remote_get(
    'https://api.fincra.com/profile/virtual-accounts/' . rawurlencode($virtualAccountId),
    [
        'timeout' => 30,
        'headers' => [
            'api-key' => $apiKey,
            'Accept' => 'application/json',
        ],
    ]
);

if (is_wp_error($lookup)) {
    status_header(502);
    echo wp_json_encode(['success' => false, 'message' => 'Unable to verify Fincra virtual account.']);
    exit;
}

$lookupData = json_decode(wp_remote_retrieve_body($lookup), true);
$accountInfo = $lookupData['data']['accountInformation'] ?? [];
$accountNumber = sanitize_text_field($accountInfo['accountNumber'] ?? '');

if ($accountNumber === '') {
    status_header(404);
    echo wp_json_encode(['success' => false, 'message' => 'Fincra virtual account could not be resolved.']);
    exit;
}

$account = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$accounts} WHERE number=%s AND LOWER(provider)=LOWER(%s) LIMIT 1",
    $accountNumber,
    'fincra'
));

if (!$account) {
    echo wp_json_encode(['success' => false, 'message' => 'Fincra account not found in Pulsepoint.']);
    exit;
}

$userId = (int) $account->user_id;

// Idempotency: reference is the provider's unique collection reference.
$exists = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$trnx} WHERE reference=%s LIMIT 1",
    $reference
));

if ((int) $exists > 0) {
    echo wp_json_encode(['success' => true, 'message' => 'Duplicate webhook ignored.']);
    exit;
}

$fundingFeeVal = (float) $wpdb->get_var($wpdb->prepare(
    "SELECT opt_value FROM {$settings} WHERE opt_key=%s LIMIT 1",
    'pay_fee'
));

$feeBase = $amountReceived > 0 ? $amountReceived : $sourceAmount;
$fee = ($fundingFeeVal >= 30)
    ? $fundingFeeVal
    : (($fundingFeeVal > 0) ? ($fundingFeeVal / 100) * $feeBase : 0);

$credited = max($feeBase - $fee, 0);

$wpdb->insert($trnx, [
    'user_id' => $userId,
    'details' => 'Wallet funding via Fincra',
    'recipient' => $accountInfo['accountName'] ?? $account->name,
    'amount' => $feeBase,
    'reference' => $reference,
    'payment' => 'wallet',
    'category' => 'funding',
    'status' => $status,
    'type' => 'credit',
    'gateway_response' => maybe_serialize($data),
    'description' => pulsepoint_transaction_description(
        "Wallet funding ₦{$feeBase} from {$senderName} ({$senderAccount}) via Fincra. fee: ₦{$fee}"
    )
]);

if ($wpdb->last_error) {
    status_header(500);
    echo wp_json_encode(['success' => false, 'message' => 'Unable to record Fincra transaction.']);
    exit;
}

$wpdb->query($wpdb->prepare(
    "UPDATE {$users} SET wallet=wallet+%f WHERE id=%d",
    $credited,
    $userId
));

file_put_contents(
    __DIR__ . '/fincra-webhook-log.txt',
    date('Y-m-d H:i:s') . ' | ' . $raw . PHP_EOL,
    FILE_APPEND
);

echo wp_json_encode([
    'success' => true,
    'message' => 'Fincra collection processed successfully.',
    'reference' => $reference,
    'account_number' => $accountNumber,
    'credited' => round($credited, 2),
]);
exit;
