<?php
/**
 * Pulsepoint Virtual Accounts Admin
 * Path: /includes/panel/virtual-accounts.php
 *
 * Version 2.5.29
 *
 * Adds two virtual-account provider slots while preserving existing
 * accounts and the legacy payment_gateway setting.
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

$base_prefix = $wpdb->prefix . 'pulsepoint_';
$table_account = "{$base_prefix}account";
$table_trnx    = "{$base_prefix}trnx";
$table_users   = "{$base_prefix}users";
$table_settings = "{$base_prefix}settings";

$charset = $wpdb->get_charset_collate();


/**
 * Ensure the account table exists.
 *
 * There is intentionally no UNIQUE(user_id) constraint because a user may
 * now have one account from provider 1 and another from provider 2.
 */
$wpdb->query("CREATE TABLE IF NOT EXISTS `{$table_account}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `bank` VARCHAR(150) DEFAULT NULL,
    `name` VARCHAR(200) DEFAULT NULL,
    `number` VARCHAR(100) DEFAULT NULL,
    `provider` VARCHAR(100) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_idx` (`user_id`),
    KEY `number_idx` (`number`),
    KEY `provider_idx` (`provider`)
) {$charset};");


/**
 * Provider list.
 *
 * These are the static virtual-account handlers present in this build.
 */
$providers = [
    'xixapay'      => 'XIXAPAY',
    'stropay'      => 'StroPay / Strowallet',
    'whogopay'     => 'WhogoPay',
    'paymentpoint' => 'PaymentPoint',
    'dotmfb-wa'    => 'Dot MFB / WhogoPay',
    'ncwallet'     => 'NCWallet',
    'billstack'    => 'BillStack',
];


/**
 * Load settings.
 */
$settings_rows = $wpdb->get_results(
    "SELECT opt_key, opt_value FROM {$table_settings}"
);

$settings = [];

foreach ($settings_rows as $row) {
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
}


/**
 * Existing installation compatibility:
 * If provider 1 has not been configured yet, display the current
 * payment_gateway as the primary selection when it is supported.
 */
$provider1 = strtolower(
    trim((string) ($settings['virtual_account_provider_1'] ?? ''))
);

if ($provider1 === '') {
    $legacy_gateway = strtolower(
        trim((string) ($settings['payment_gateway'] ?? ''))
    );

    if (isset($providers[$legacy_gateway])) {
        $provider1 = $legacy_gateway;
    }
}

$provider2 = strtolower(
    trim((string) ($settings['virtual_account_provider_2'] ?? ''))
);

$provider2_enabled = !empty(
    $settings['virtual_account_provider_2_enabled']
);


/**
 * Save provider settings.
 */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['pulsepoint_save_va_providers'])
) {

    if (!current_user_can('manage_options')) {
        wp_die('You do not have permission to manage virtual account settings.');
    }

    check_admin_referer('pulsepoint_virtual_account_providers');

    $new_provider1 = sanitize_key(
        wp_unslash($_POST['virtual_account_provider_1'] ?? '')
    );

    $new_provider2 = sanitize_key(
        wp_unslash($_POST['virtual_account_provider_2'] ?? '')
    );

    $new_enabled = !empty(
        $_POST['virtual_account_provider_2_enabled']
    ) ? '1' : '0';


    if ($new_provider1 === '' || !isset($providers[$new_provider1])) {
        echo '<div class="notice notice-error is-dismissible"><p>Please select a valid primary virtual account provider.</p></div>';
    } elseif (
        $new_enabled === '1'
        && (
            $new_provider2 === ''
            || !isset($providers[$new_provider2])
        )
    ) {
        echo '<div class="notice notice-error is-dismissible"><p>Please select a valid secondary virtual account provider or disable the secondary provider.</p></div>';
    } elseif (
        $new_enabled === '1'
        && $new_provider1 === $new_provider2
    ) {
        echo '<div class="notice notice-error is-dismissible"><p>The primary and secondary providers must be different.</p></div>';
    } else {

        /*
         * Save the new primary provider.
         *
         * Also update payment_gateway for older code paths that still read
         * the legacy setting.
         */
        $wpdb->replace(
            $table_settings,
            [
                'opt_key'   => 'virtual_account_provider_1',
                'opt_value' => maybe_serialize($new_provider1),
                'type'      => 'string',
                'grouping'  => 'vtu',
                'autoload'  => 0
            ],
            ['%s','%s','%s','%s','%d']
        );

        $wpdb->replace(
            $table_settings,
            [
                'opt_key'   => 'virtual_account_provider_2',
                'opt_value' => maybe_serialize($new_provider2),
                'type'      => 'string',
                'grouping'  => 'vtu',
                'autoload'  => 0
            ],
            ['%s','%s','%s','%s','%d']
        );

        $wpdb->replace(
            $table_settings,
            [
                'opt_key'   => 'virtual_account_provider_2_enabled',
                'opt_value' => $new_enabled,
                'type'      => 'number',
                'grouping'  => 'vtu',
                'autoload'  => 0
            ],
            ['%s','%s','%s','%s','%d']
        );

        $wpdb->replace(
            $table_settings,
            [
                'opt_key'   => 'payment_gateway',
                'opt_value' => maybe_serialize($new_provider1),
                'type'      => 'string',
                'grouping'  => 'vtu',
                'autoload'  => 0
            ],
            ['%s','%s','%s','%s','%d']
        );

        $provider1 = $new_provider1;
        $provider2 = $new_provider2;
        $provider2_enabled = ($new_enabled === '1');

        echo '<div class="notice notice-success is-dismissible"><p>Virtual account provider settings saved successfully.</p></div>';
    }
}


/**
 * Fetch all accounts.
 */
$accounts = $wpdb->get_results("
    SELECT a.*, u.firstname, u.lastname, u.email
    FROM {$table_account} a
    LEFT JOIN {$table_users} u ON a.user_id = u.id
    ORDER BY a.id DESC
");


/**
 * Yoma chat query.
 */
$chat_response = '';

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['yoma_query'])
) {

    $query = sanitize_text_field(
        wp_unslash($_POST['yoma_query'])
    );

    $transaction = $wpdb->get_row(
        $wpdb->prepare(
            "
            SELECT t.*, u.firstname, u.lastname
            FROM {$table_trnx} t
            LEFT JOIN {$table_users} u
                ON t.user_id = u.id
            WHERE t.recipient = %s
            ORDER BY t.date DESC
            LIMIT 1
            ",
            $query
        )
    );

    if ($transaction) {

        $chat_response =
            "Yoma 🤖: The account number <strong>"
            . esc_html($transaction->recipient)
            . "</strong> was used to fund <strong>₦"
            . number_format((float) $transaction->amount, 2)
            . "</strong> on <strong>"
            . esc_html($transaction->date)
            . "</strong> by <strong>"
            . esc_html($transaction->firstname . ' ' . $transaction->lastname)
            . "</strong>. Transaction reference: <strong>"
            . esc_html($transaction->reference)
            . "</strong>. Status: <strong>"
            . esc_html($transaction->status)
            . "</strong>.";

    } else {

        $chat_response =
            "Yoma 🤖: No transactions found for the account number <strong>"
            . esc_html($query)
            . "</strong>.";
    }
}

?>

<div class="wrap">

    <h1 class="wp-heading-inline">
        Pulsepoint — Virtual Accounts
    </h1>

    <hr class="wp-header-end">


    <script src="https://cdn.tailwindcss.com"></script>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"
    >


    <style>

        :root {
            --primary: #356cf9;
        }

        .pulse-section {
            background: #fff;
            border-radius: 14px;
            padding: 24px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            margin-top: 24px;
        }

        .pulse-input {
            width: 100%;
            min-height: 42px;
            padding: 8px 12px;
            border: 1px solid #dcdcde;
            border-radius: 8px;
            background: #fff;
        }

        .pulse-btn {
            background: var(--primary);
            color: #fff;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            border: 0;
            cursor: pointer;
        }

        .pulse-btn-danger {
            background: #ef4444;
            color: #fff;
            padding: 6px 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border-bottom: 1px solid #eee;
            padding: 10px 8px;
            font-size: 14px;
        }

        th {
            text-align: left;
            background: #f9fafb;
            font-weight: 600;
        }

        .chat-box {
            border: 1px solid #ddd;
            border-radius: 14px;
            padding: 16px;
            max-height: 300px;
            overflow-y: auto;
            background: #f9fafb;
            margin-top: 16px;
        }

        .chat-input {
            width: 100%;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-top: 8px;
        }

        .provider-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .provider-card {
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            padding: 18px;
            background: #fff;
        }

        .provider-card label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 7px;
        }

        .provider-description {
            color: #646970;
            font-size: 12px;
            line-height: 1.5;
            margin-top: 6px;
        }

        .provider-status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 10px;
        }

        @media(max-width: 782px) {
            .provider-grid {
                grid-template-columns: 1fr;
            }
        }

    </style>


    <!-- Provider Configuration -->
    <div class="pulse-section">

        <h2 class="text-lg font-semibold mb-2">
            <i class="bi bi-bank"></i>
            Virtual Account Providers
        </h2>

        <p class="text-sm text-gray-500 mb-5">
            Configure two different virtual account providers. Users can have
            an account from each enabled provider, so either bank can be used
            when one provider has an outage.
        </p>


        <form method="POST">

            <?php wp_nonce_field('pulsepoint_virtual_account_providers'); ?>

            <input
                type="hidden"
                name="pulsepoint_save_va_providers"
                value="1"
            >


            <div class="provider-grid">

                <!-- Primary -->
                <div class="provider-card">

                    <label for="virtual_account_provider_1">
                        Primary Provider
                    </label>

                    <select
                        id="virtual_account_provider_1"
                        name="virtual_account_provider_1"
                        class="pulse-input"
                    >

                        <option value="">
                            Select provider
                        </option>

                        <?php foreach ($providers as $key => $label): ?>

                            <option
                                value="<?= esc_attr($key) ?>"
                                <?= selected($provider1, $key, false) ?>
                            >
                                <?= esc_html($label) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <p class="provider-description">
                        The first account shown to users and the fallback
                        returned in the legacy <code>account</code> API field.
                    </p>

                    <div class="provider-status">
                        <span>●</span>
                        Primary account
                    </div>

                </div>


                <!-- Secondary -->
                <div class="provider-card">

                    <label for="virtual_account_provider_2">
                        Secondary Provider
                    </label>

                    <select
                        id="virtual_account_provider_2"
                        name="virtual_account_provider_2"
                        class="pulse-input"
                    >

                        <option value="">
                            Select provider
                        </option>

                        <?php foreach ($providers as $key => $label): ?>

                            <option
                                value="<?= esc_attr($key) ?>"
                                <?= selected($provider2, $key, false) ?>
                            >
                                <?= esc_html($label) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>


                    <label style="margin-top:14px;">

                        <input
                            type="checkbox"
                            name="virtual_account_provider_2_enabled"
                            value="1"
                            <?= checked($provider2_enabled, true, false) ?>
                        >

                        Enable secondary provider

                    </label>

                    <p class="provider-description">
                        When enabled, users receive a second virtual account
                        from this provider. The two providers must be different.
                    </p>

                </div>

            </div>


            <div style="margin-top:18px;">

                <button
                    type="submit"
                    class="pulse-btn"
                >
                    <i class="bi bi-check2"></i>
                    Save Provider Settings
                </button>

            </div>

        </form>

    </div>


    <!-- Accounts -->
    <div class="pulse-section">

        <h2 class="text-lg font-semibold mb-4">
            <i class="bi bi-bank"></i>
            User Virtual Accounts
        </h2>

        <?php if (!$accounts): ?>

            <p>No virtual accounts found.</p>

        <?php else: ?>

            <div class="overflow-x-auto">

                <table>

                    <thead>

                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Bank</th>
                            <th>Account Name</th>
                            <th>Account Number</th>
                            <th>Provider</th>
                            <th>Created At</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php foreach ($accounts as $acc): ?>

                            <tr>

                                <td>
                                    <?= esc_html($acc->id) ?>
                                </td>

                                <td>
                                    <?= esc_html(
                                        $acc->firstname . ' ' . $acc->lastname
                                    ) ?>

                                    <br>

                                    <small>
                                        <?= esc_html($acc->email) ?>
                                    </small>
                                </td>

                                <td>
                                    <?= esc_html($acc->bank ?: '—') ?>
                                </td>

                                <td>
                                    <?= esc_html($acc->name ?: '—') ?>
                                </td>

                                <td>
                                    <?= esc_html($acc->number ?: '—') ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= esc_html(
                                            $providers[$acc->provider]
                                            ?? $acc->provider
                                            ?? '—'
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= esc_html($acc->created_at) ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>


    <!-- Yoma Chatbox -->
    <div class="pulse-section">

        <h2 class="text-lg font-semibold mb-4">
            <i class="bi bi-chat-dots"></i>
            Yoma Chat Assistant
        </h2>

        <form method="POST">

            <input
                type="text"
                name="yoma_query"
                class="chat-input"
                placeholder="Enter account number to check recent transaction..."
                required
            >

            <button
                type="submit"
                class="pulse-btn"
                style="margin-top:8px;"
            >
                <i class="bi bi-send"></i>
                Ask Yoma
            </button>

        </form>

        <?php if ($chat_response): ?>

            <div class="chat-box">
                <?= $chat_response ?>
            </div>

        <?php endif; ?>

    </div>

</div>
