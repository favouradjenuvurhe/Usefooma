<?php  
/**  
 * Pulsepoint View Transaction Page  
 * Path: /wp-content/plugins/pulsepoint-bill-payment/includes/panel/view_transaction.php  
 * Author: Amaaavl  
 */  
  
if (!defined('ABSPATH')) exit;  
  
global $wpdb;  
$base_prefix = $wpdb->prefix . 'pulsepoint_';  
  
// === Tables ===  
$table_users = "{$base_prefix}users";  
$table_trnx  = "{$base_prefix}trnx";  
  
// === Fetch transaction ID ===  
$transaction_id = isset($_GET['id']) ? intval($_GET['id']) : 0;  

// ==============================
// STATUS UPDATE  (final, one-time, wallet-safe)
// ==============================
$message = '';

/**
 * What did this transaction record about how the user was charged?
 * airtime / queued-data store wallet_used + referral_used in `details`
 * at the moment they debit the user. Returns [wallet, referral] or null.
 */
if (!function_exists('pulsepoint_trnx_recorded_split')) {
    function pulsepoint_trnx_recorded_split($details) {
        $d = json_decode((string) $details, true);
        if (is_array($d) && (isset($d['wallet_used']) || isset($d['referral_used']))) {
            $w = (float) ($d['wallet_used'] ?? 0);
            $r = (float) ($d['referral_used'] ?? 0);
            if (($w + $r) > 0) {
                return [$w, $r];
            }
        }
        return null;
    }
}

/**
 * Finalise a transaction from the admin panel.
 *  - Allowed once only (pending|success -> success|failed), then it is closed.
 *  - failed  => refunds exactly what the user was charged (split-aware).
 *  - success => charges the wallet ONLY if the user was not charged yet.
 * Everything runs in one DB transaction under a row lock, so a double click
 * or two admins can never refund twice.
 */
if (!function_exists('pulsepoint_admin_finalize_transaction')) {
    function pulsepoint_admin_finalize_transaction($trnx_id, $new_status, $charged_answer, $admin_id) {
        global $wpdb;
        $users = $wpdb->prefix . 'pulsepoint_users';
        $trnx  = $wpdb->prefix . 'pulsepoint_trnx';

        if (!in_array($new_status, ['success', 'failed'], true)) {
            return ['ok' => false, 'msg' => 'Choose Success or Failed.'];
        }

        $wpdb->query('START TRANSACTION');

        $t = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$trnx}` WHERE id = %d LIMIT 1 FOR UPDATE", $trnx_id));
        if (!$t) {
            $wpdb->query('ROLLBACK');
            return ['ok' => false, 'msg' => 'Transaction not found.'];
        }
        if ((int) ($t->admin_locked ?? 0) === 1 || !in_array($t->status, ['pending', 'success'], true)) {
            $wpdb->query('ROLLBACK');
            return ['ok' => false, 'msg' => 'This transaction is closed and cannot be changed again.'];
        }
        if ($t->status === $new_status) {
            $wpdb->query('ROLLBACK');
            return ['ok' => false, 'msg' => 'Transaction is already marked as ' . $new_status . '.'];
        }

        $total           = round((float) $t->amount + (float) ($t->fee ?? 0), 2);
        $is_wallet_debit = ($t->payment === 'wallet' && $t->type === 'debit');
        $split           = pulsepoint_trnx_recorded_split($t->details);

        // Was the user's wallet already debited for this transaction?
        $already_charged = false;
        if ($is_wallet_debit) {
            if ($split !== null || $t->status === 'success') {
                $already_charged = true;            // recorded split, or success => debited
            } elseif ($charged_answer === 'yes') {
                $already_charged = true;
            } elseif ($charged_answer !== 'no') {
                $wpdb->query('ROLLBACK');
                return ['ok' => false, 'msg' => 'Please answer "Was the user already charged?" for this pending transaction.'];
            }
        }

        $refund_w = 0.0; $refund_r = 0.0; $charge_w = 0.0;
        if ($is_wallet_debit) {
            if ($new_status === 'failed' && $already_charged) {
                if ($split !== null) { $refund_w = $split[0]; $refund_r = $split[1]; }
                else                 { $refund_w = $total; }
            } elseif ($new_status === 'success' && !$already_charged) {
                $charge_w = $total;
            }
        }

        if ($refund_w > 0 || $refund_r > 0) {
            $wpdb->query($wpdb->prepare(
                "UPDATE `{$users}` SET wallet = wallet + %f, referral_balance = referral_balance + %f WHERE id = %d",
                $refund_w, $refund_r, (int) $t->user_id
            ));
            if ($wpdb->rows_affected !== 1) {
                $wpdb->query('ROLLBACK');
                return ['ok' => false, 'msg' => 'Refund failed (user not found). Nothing was changed.'];
            }
        }
        if ($charge_w > 0) {
            $wpdb->query($wpdb->prepare(
                "UPDATE `{$users}` SET wallet = wallet - %f WHERE id = %d AND wallet >= %f",
                $charge_w, (int) $t->user_id, $charge_w
            ));
            if ($wpdb->rows_affected !== 1) {
                $wpdb->query('ROLLBACK');
                return ['ok' => false, 'msg' => 'Cannot mark as success: the user does not have enough wallet balance to be charged ₦' . number_format($charge_w, 2) . '. Nothing was changed.'];
            }
        }

        $refunded_total = round($refund_w + $refund_r, 2);
        $wpdb->query($wpdb->prepare(
            "UPDATE `{$trnx}` SET status = %s, admin_locked = 1, admin_updated_by = %d, refunded_amount = %f, updated_at = %s WHERE id = %d AND admin_locked = 0",
            $new_status, (int) $admin_id, $refunded_total, current_time('mysql'), (int) $trnx_id
        ));
        if ($wpdb->rows_affected !== 1) {
            $wpdb->query('ROLLBACK');
            return ['ok' => false, 'msg' => 'Could not save the status. Nothing was changed.'];
        }

        $wpdb->query('COMMIT');

        $msg = 'Transaction marked as ' . $new_status . '.';
        if ($refunded_total > 0) {
            $msg .= ' ₦' . number_format($refunded_total, 2) . ' was refunded to the user.';
        } elseif ($charge_w > 0) {
            $msg .= ' ₦' . number_format($charge_w, 2) . ' was charged to the user\'s wallet.';
        }
        $msg .= ' This transaction is now closed.';
        return ['ok' => true, 'msg' => $msg];
    }
}

// One-time schema upgrade: lock + refund audit columns
$pp_cols = $wpdb->get_col("SHOW COLUMNS FROM `{$table_trnx}`", 0);
$pp_cols = is_array($pp_cols) ? $pp_cols : [];
$pp_add  = [];
if (!in_array('admin_locked', $pp_cols, true))     { $pp_add[] = 'ADD COLUMN `admin_locked` TINYINT(1) NOT NULL DEFAULT 0'; }
if (!in_array('admin_updated_by', $pp_cols, true)) { $pp_add[] = 'ADD COLUMN `admin_updated_by` BIGINT UNSIGNED NULL'; }
if (!in_array('refunded_amount', $pp_cols, true))  { $pp_add[] = 'ADD COLUMN `refunded_amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00'; }
if ($pp_add) {
    $wpdb->query("ALTER TABLE `{$table_trnx}` " . implode(', ', $pp_add));
    $pp_cols = $wpdb->get_col("SHOW COLUMNS FROM `{$table_trnx}`", 0);
    $pp_cols = is_array($pp_cols) ? $pp_cols : [];
}
$pp_ready = in_array('admin_locked', $pp_cols, true)
    && in_array('admin_updated_by', $pp_cols, true)
    && in_array('refunded_amount', $pp_cols, true);

if (isset($_POST['update_status']) && $transaction_id > 0) {

    if (!current_user_can('manage_options')) {
        $message = '<div class="notice notice-error"><p>Permission denied.</p></div>';
    } elseif (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'pulsepoint_update_trnx_' . $transaction_id)) {
        $message = '<div class="notice notice-error"><p>Security check failed. Reload the page and try again.</p></div>';
    } elseif (!$pp_ready) {
        $message = '<div class="notice notice-error"><p>Could not prepare the database to lock this update, so nothing was changed. Ask your host to allow ALTER TABLE for the WordPress database user.</p></div>';
    } else {
        $pp_res = pulsepoint_admin_finalize_transaction(
            $transaction_id,
            sanitize_key($_POST['status'] ?? ''),
            sanitize_key($_POST['charged'] ?? ''),
            get_current_user_id()
        );
        $message = '<div class="notice notice-' . ($pp_res['ok'] ? 'success' : 'error') . '"><p>' . esc_html($pp_res['msg']) . '</p></div>';
    }
}

// === Fetch transaction ===  
$transaction = $wpdb->get_row("  
    SELECT t.*, u.firstname, u.lastname, u.phone, u.email, u.wallet   
    FROM {$table_trnx} t  
    LEFT JOIN {$table_users} u ON t.user_id = u.id  
    WHERE t.id = {$transaction_id}  
");  
  
if (!$transaction) {  
    echo '<div class="wrap"><h2>Transaction not found.</h2><p><a href="?page=pulsepoint-transactions" class="button button-primary">← Back to Transactions</a></p></div>';  
    return;  
}  
  
// === Platform Settings ===  
$settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");  
$settings = [];  
foreach ($settings_rows as $row) {  
    $settings[$row->opt_key] = maybe_unserialize($row->opt_value);  
}  
$platform_name = $settings['platform_name'] ?? 'Pulsepoint';  
$color_hex     = $settings['color_hex'] ?? '#6C63FF';  
  
// === Format Amount ===  
function fmt_amt($num) { return '₦' . number_format((float)$num, 2); }  
?>  

<div class="wrap">  
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — View Transaction</h1>  
  <p>Detailed transaction information below.</p>  

  <?= $message ?> <!-- SHOW MESSAGE -->

  <hr class="wp-header-end">  

  <!-- Tailwind -->  
  <script src="https://cdn.tailwindcss.com"></script>  
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">  

  <style>  
    :root { --primary: <?= $color_hex ?>; }  
    .pulse-box {  
      background: #fff;  
      border-radius: 14px;  
      padding: 24px;  
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);  
      margin-top: 20px;  
      max-width: 900px;  
    }  
    .pulse-grid {  
      display: grid;  
      grid-template-columns: 180px 1fr;  
      gap: 12px;  
      margin-bottom: 14px;  
    }  
    .label {  
      font-weight: 600;  
      color: #555;  
      font-size: 14px;  
    }  
    .value {  
      color: #222;  
      font-size: 15px;  
      word-break: break-word;  
    }  
    .section-title {  
      font-weight: 700;  
      color: var(--primary);  
      margin-top: 25px;  
      font-size: 18px;  
      border-bottom: 2px solid #eee;  
      padding-bottom: 6px;  
    }  
    .back-btn {  
      display: inline-flex;  
      align-items: center;  
      background: var(--primary);  
      color: #fff;  
      padding: 10px 16px;  
      border-radius: 8px;  
      text-decoration: none;  
      font-size: 14px;  
      margin-top: 16px;  
    }  
    .back-btn i { margin-right: 6px; }  
    pre {  
      background: #f8fafc;  
      padding: 10px;  
      border-radius: 8px;  
      font-size: 13px;  
      overflow-x: auto;  
      max-height: 300px;  
    }  
  </style>  

  <div class="pulse-box">  

    <!-- ===================== -->
    <!-- STATUS UPDATE FORM -->
    <!-- ===================== -->
    <div class="section-title">Update Status</div>

    <?php
      $pp_is_closed   = ((int) ($transaction->admin_locked ?? 0) === 1) || $transaction->status === 'failed';
      $pp_split       = pulsepoint_trnx_recorded_split($transaction->details);
      $pp_wallet_debit = ($transaction->payment === 'wallet' && $transaction->type === 'debit');
      $pp_ask_charged = (!$pp_is_closed && $pp_wallet_debit && $transaction->status === 'pending' && $pp_split === null);
      $pp_total       = (float) $transaction->amount + (float) ($transaction->fee ?? 0);
    ?>

    <?php if ($pp_is_closed): ?>
      <div class="pulse-grid">
        <div class="label">Status update:</div>
        <div class="value">
          <strong>Closed.</strong> This transaction is <?= esc_html($transaction->status) ?> and can't be changed again.
          <?php if ((float) ($transaction->refunded_amount ?? 0) > 0): ?>
            <br>Refunded to user: <strong><?= fmt_amt($transaction->refunded_amount) ?></strong>
          <?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <form method="POST" onsubmit="return confirm('This is final and cannot be undone or redone. Continue?');">
        <?php wp_nonce_field('pulsepoint_update_trnx_' . $transaction_id); ?>
        <div class="pulse-grid">
          <div class="label">Change Status:</div>
          <div class="value">
            <br>
            <select name="status" class="border px-3 py-2 rounded" required>
              <option value="">— Choose —</option>
              <option value="success">Success</option>
              <option value="failed">Failed<?= $pp_wallet_debit ? ' (refunds the user automatically)' : '' ?></option>
            </select>
            <br><br>
            <?php if ($pp_ask_charged): ?>
              <div style="margin-bottom:10px">
                <label><strong>Was the user already charged <?= fmt_amt($pp_total) ?> for this?</strong></label><br>
                <select name="charged" class="border px-3 py-2 rounded" required>
                  <option value="">— Choose —</option>
                  <option value="yes">Yes, already charged (Failed = refund, Success = no extra charge)</option>
                  <option value="no">No, not charged yet (Failed = nothing to refund, Success = charge now)</option>
                </select>
              </div>
            <?php endif; ?>
            <button type="submit" name="update_status" class="ml-2 px-4 py-2 bg-blue-600 text-white rounded">
              Update (final)
            </button>
          </div>
        </div>
      </form>
    <?php endif; ?>

    <div class="section-title">User Information</div>  
    <div class="pulse-grid"><div class="label">Full Name:</div><div class="value"><?= esc_html($transaction->firstname . ' ' . $transaction->lastname) ?></div></div>  
    <div class="pulse-grid"><div class="label">Phone:</div><div class="value"><?= esc_html($transaction->phone) ?></div></div>  
    <div class="pulse-grid"><div class="label">Email:</div><div class="value"><?= esc_html($transaction->email) ?></div></div>  
    <div class="pulse-grid"><div class="label">Wallet Balance:</div><div class="value"><?= fmt_amt($transaction->wallet) ?></div></div>  

    <div class="section-title">Transaction Details</div>  
    <div class="pulse-grid"><div class="label">Recipient:</div><div class="value"><?= esc_html($transaction->recipient ?: '-') ?></div></div>  
    <div class="pulse-grid"><div class="label">Amount:</div><div class="value font-semibold"><?= fmt_amt($transaction->amount) ?></div></div>  
    <div class="pulse-grid"><div class="label">Reference:</div><div class="value"><?= esc_html($transaction->reference) ?></div></div>  
    <div class="pulse-grid"><div class="label">Payment Method:</div><div class="value"><?= ucfirst($transaction->payment) ?></div></div>  
    <div class="pulse-grid"><div class="label">Category:</div><div class="value"><?= ucfirst($transaction->category) ?></div></div>  

    <div class="pulse-grid"><div class="label">Status:</div>  
      <div class="value">  
        <?php if ($transaction->status === 'success'): ?>  
          <span class="text-green-600 font-semibold">Success</span>  
        <?php elseif ($transaction->status === 'pending'): ?>  
          <span class="text-yellow-600 font-semibold">Pending</span>  
        <?php else: ?>  
          <span class="text-red-600 font-semibold">Failed</span>  
        <?php endif; ?>  
      </div>  
    </div>  

    <div class="pulse-grid"><div class="label">Type:</div><div class="value"><?= ucfirst($transaction->type) ?></div></div>  
    <div class="pulse-grid"><div class="label">Session:</div><div class="value"><?= esc_html($transaction->session) ?></div></div>  
    <div class="pulse-grid"><div class="label">Description:</div><div class="value"><?= esc_html($transaction->description) ?></div></div>  
    <div class="pulse-grid"><div class="label">Date:</div><div class="value"><?= esc_html($transaction->date) ?></div></div>  
    <div class="pulse-grid"><div class="label">Updated At:</div><div class="value"><?= esc_html($transaction->updated_at) ?></div></div>  

    <div class="section-title">Payload</div>  
    <pre><?= esc_html($transaction->details) ?></pre>  

    <div class="section-title">Api Response</div>  
    <pre><?= esc_html($transaction->gateway_response) ?></pre>  

    <a href="?page=pulsepoint-transactions" class="back-btn"><i class="bi bi-arrow-left"></i> Back to Transactions</a>

  </div>  
</div>