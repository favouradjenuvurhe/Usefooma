<?php
/**
 * Pulsepoint Giftcard Settings Page
 * Reloadly Gift Cards integration.
 */
if (!defined('ABSPATH')) exit;

global $wpdb;
$base_prefix = $wpdb->prefix . 'pulsepoint_';
$charset = $wpdb->get_charset_collate();
$table_giftcard = "{$base_prefix}giftcard_settings";

require_once PULSEPOINT_DIR . 'core/giftcard/topupmate.php';

/* === Reloadly settings === */
$reloadly_mode = get_option('pulsepoint_giftcard_reloadly_mode', 'sandbox');
if (!in_array($reloadly_mode, ['sandbox','live'], true)) $reloadly_mode = 'sandbox';

$sandbox_client_id = (string)get_option('pulsepoint_giftcard_reloadly_sandbox_client_id', '');
$sandbox_secret    = (string)get_option('pulsepoint_giftcard_reloadly_sandbox_client_secret', '');
$live_client_id    = (string)get_option('pulsepoint_giftcard_reloadly_live_client_id', '');
$live_secret       = (string)get_option('pulsepoint_giftcard_reloadly_live_client_secret', '');
$gift_api_fx       = (float)get_option('pulsepoint_giftcard_api_fx_rate', 1);
$gift_api_markup   = (float)get_option('pulsepoint_giftcard_api_markup', 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_giftcard_purchase_settings'])) {
    check_admin_referer('pulsepoint_giftcard_purchase_settings');

    $reloadly_mode = in_array($_POST['reloadly_mode'] ?? 'sandbox', ['sandbox','live'], true) ? $_POST['reloadly_mode'] : 'sandbox';

    /* Blank secret fields intentionally keep the existing secret. */
    $sandbox_client_id = sanitize_text_field($_POST['sandbox_client_id'] ?? '');
    $live_client_id    = sanitize_text_field($_POST['live_client_id'] ?? '');
    $new_sandbox_secret = trim((string)($_POST['sandbox_client_secret'] ?? ''));
    $new_live_secret    = trim((string)($_POST['live_client_secret'] ?? ''));

    if ($sandbox_client_id !== '') update_option('pulsepoint_giftcard_reloadly_sandbox_client_id', $sandbox_client_id, false);
    if ($live_client_id !== '') update_option('pulsepoint_giftcard_reloadly_live_client_id', $live_client_id, false);
    if ($new_sandbox_secret !== '') update_option('pulsepoint_giftcard_reloadly_sandbox_client_secret', sanitize_text_field($new_sandbox_secret), false);
    if ($new_live_secret !== '') update_option('pulsepoint_giftcard_reloadly_live_client_secret', sanitize_text_field($new_live_secret), false);

    update_option('pulsepoint_giftcard_purchase_mode', 'api', false);
    update_option('pulsepoint_giftcard_reloadly_mode', $reloadly_mode, false);
    update_option('pulsepoint_giftcard_api_fx_rate', max(0, (float)($_POST['gift_api_fx_rate'] ?? 1)), false);
    update_option('pulsepoint_giftcard_api_markup', max(0, (float)($_POST['gift_api_markup'] ?? 0)), false);

    /* Reload settings after save. */
    $sandbox_client_id = (string)get_option('pulsepoint_giftcard_reloadly_sandbox_client_id', '');
    $live_client_id    = (string)get_option('pulsepoint_giftcard_reloadly_live_client_id', '');
    $gift_api_fx       = (float)get_option('pulsepoint_giftcard_api_fx_rate', 1);
    $gift_api_markup   = (float)get_option('pulsepoint_giftcard_api_markup', 0);

    delete_transient('pulsepoint_reloadly_gc_token_sandbox');
    delete_transient('pulsepoint_reloadly_gc_token_live');

    echo '<div class="updated notice"><p><strong>Reloadly Gift Card settings saved.</strong></p></div>';
}

/* === Connection test === */
$connection_result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_reloadly_connection'])) {
    check_admin_referer('pulsepoint_giftcard_purchase_settings');
    $connection_result = pulsepoint_reloadly_get_account_balance();
}

/* === Create Giftcard Settings Table if not exists === */
$sql_giftcard_settings = "CREATE TABLE IF NOT EXISTS `{$table_giftcard}` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `category` VARCHAR(100) NOT NULL,
    `type` ENUM('digital','physical') DEFAULT 'digital',
    `rate` DECIMAL(14,2) NOT NULL,
    `min_amount` DECIMAL(14,2) DEFAULT 0.00,
    `max_amount` DECIMAL(14,2) DEFAULT 0.00,
    `status` ENUM('active','inactive') DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) {$charset};";
$wpdb->query($sql_giftcard_settings);

/* === Delete / toggle existing manual giftcards: retained for backwards compatibility === */
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $wpdb->delete($table_giftcard, ['id' => $id]);
    echo '<div class="updated notice"><p><strong>Giftcard deleted successfully.</strong></p></div>';
}
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = intval($_GET['toggle']);
    $gift = $wpdb->get_row($wpdb->prepare("SELECT status FROM {$table_giftcard} WHERE id = %d", $id));
    if ($gift) {
        $new_status = ($gift->status === 'active') ? 'inactive' : 'active';
        $wpdb->update($table_giftcard, ['status' => $new_status], ['id' => $id]);
        echo '<div class="updated notice"><p><strong>Status changed to '.esc_html(ucfirst($new_status)).'.</strong></p></div>';
    }
}
$giftcards = $wpdb->get_results("SELECT * FROM {$table_giftcard} ORDER BY id DESC");

$settings = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
$settings_map = [];
foreach ($settings as $s) $settings_map[$s->opt_key] = maybe_unserialize($s->opt_value);
$platform_name = $settings_map['platform_name'] ?? 'Pulsepoint';
$color_hex = $settings_map['color_hex'] ?? '#356cf9';

$has_sandbox = $sandbox_client_id !== '' && (string)get_option('pulsepoint_giftcard_reloadly_sandbox_client_secret', '') !== '';
$has_live = $live_client_id !== '' && (string)get_option('pulsepoint_giftcard_reloadly_live_client_secret', '') !== '';
$current_base = pulsepoint_reloadly_base_url();
?>

<div class="wrap">
  <h1 class="wp-heading-inline"><?= esc_html($platform_name) ?> — Giftcard Settings</h1>
  <a href="?page=pulsepoint-add-giftcard" class="page-title-action"><i class="bi bi-plus-circle"></i> Add New Giftcard</a>
  <a href="?page=pulsepoint-trade-giftcard" class="page-title-action"><i class="bi bi-history"></i> View Trades</a>
  <a href="?page=pulsepoint-giftcard-inventory" class="page-title-action"><i class="bi bi-box-seam"></i> Manage Stock</a>
  <hr class="wp-header-end">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

  <style>
    :root { --primary: <?= esc_attr($color_hex) ?>; }
    .pulse-section { background:#fff;border-radius:14px;padding:24px;box-shadow:0 3px 10px rgba(0,0,0,.05);margin-top:24px; }
    table{width:100%;border-collapse:collapse} th,td{border-bottom:1px solid #eee;padding:10px 8px;font-size:14px} th{text-align:left;background:#f9fafb;font-weight:600}
    .pulse-btn{display:inline-block;background:var(--primary);color:#fff;padding:6px 14px;border-radius:8px;font-size:13px;font-weight:600;text-decoration:none}
    .pulse-btn-danger{display:inline-block;background:#ef4444;color:#fff;padding:6px 14px;border-radius:8px;font-size:13px;font-weight:600;text-decoration:none}
    .pulse-btn-warning{display:inline-block;background:#f59e0b;color:#fff;padding:6px 14px;border-radius:8px;font-size:13px;font-weight:600;text-decoration:none}
    .pulse-input{width:100%;border:1px solid #dfe3e8;border-radius:10px;padding:10px 12px;margin-top:6px;background:#fff}
  </style>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-2"><i class="bi bi-gift"></i> Reloadly Gift Card API</h2>
    <p class="text-sm text-gray-500 mb-4">Customer Redeem Giftcards purchases are supplied directly by Reloadly. Sandbox and Live use separate credentials and separate access tokens. Reloadly confirms that Gift Card tokens are scoped to the Gift Card audience and that Sandbox/Live credentials are completely separate.</p>

    <?php if ($connection_result !== null): ?>
      <?php if (!empty($connection_result['ok'])): ?>
        <div class="mb-4 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-800">
          Reloadly connection successful. Balance: <strong><?= esc_html(number_format((float)($connection_result['data']['balance'] ?? 0), 2)) ?> <?= esc_html($connection_result['data']['currencyCode'] ?? '') ?></strong>.
        </div>
      <?php else: ?>
        <div class="mb-4 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-800">
          Reloadly connection failed: <?= esc_html($connection_result['message'] ?? 'Unknown error') ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>

    <div class="mb-4 rounded-xl <?= $reloadly_mode === 'live' ? 'bg-red-50 border-red-200 text-red-800' : 'bg-blue-50 border-blue-100 text-blue-800' ?> border px-4 py-3 text-sm">
      Current environment: <strong><?= $reloadly_mode === 'live' ? 'LIVE / PRODUCTION' : 'SANDBOX / TEST' ?></strong><br>
      API: <code><?= esc_html($current_base) ?></code>
      <?php if ($reloadly_mode === 'live'): ?><br><strong>Live purchases spend real Reloadly wallet balance.</strong><?php endif; ?>
    </div>

    <form method="post">
      <?php wp_nonce_field('pulsepoint_giftcard_purchase_settings'); ?>
      <input type="hidden" name="save_giftcard_purchase_settings" value="1">

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label class="block">
          <span class="font-semibold text-sm">Reloadly Environment</span>
          <select name="reloadly_mode" class="pulse-input">
            <option value="sandbox" <?= $reloadly_mode === 'sandbox' ? 'selected' : '' ?>>Sandbox / Test</option>
            <option value="live" <?= $reloadly_mode === 'live' ? 'selected' : '' ?>>Live / Production</option>
          </select>
          <small class="text-gray-500">Switching this changes which Reloadly credentials and API host the customer purchase flow uses.</small>
        </label>

        <label class="block">
          <span class="font-semibold text-sm">API purchase source</span>
          <input value="Reloadly Gift Cards" class="pulse-input" readonly>
          <small class="text-gray-500">Manual stock remains available if you switch the existing purchase mode to manual in code/database; normal Redeem purchases use Reloadly.</small>
        </label>

        <label class="block">
          <span class="font-semibold text-sm">Sandbox Client ID</span>
          <input type="text" name="sandbox_client_id" value="<?= esc_attr($sandbox_client_id) ?>" class="pulse-input" autocomplete="off">
        </label>
        <label class="block">
          <span class="font-semibold text-sm">Sandbox Client Secret</span>
          <input type="password" name="sandbox_client_secret" value="" class="pulse-input" autocomplete="new-password" placeholder="<?= $has_sandbox ? 'Configured — leave blank to keep it' : 'Paste Sandbox Client Secret' ?>">
        </label>

        <label class="block">
          <span class="font-semibold text-sm">Live Client ID</span>
          <input type="text" name="live_client_id" value="<?= esc_attr($live_client_id) ?>" class="pulse-input" autocomplete="off">
        </label>
        <label class="block">
          <span class="font-semibold text-sm">Live Client Secret</span>
          <input type="password" name="live_client_secret" value="" class="pulse-input" autocomplete="new-password" placeholder="<?= $has_live ? 'Configured — leave blank to keep it' : 'Paste Live Client Secret' ?>">
        </label>

        <label class="block">
          <span class="font-semibold text-sm">NGN conversion rate</span>
          <input type="number" step="0.0001" min="0" name="gift_api_fx_rate" value="<?= esc_attr($gift_api_fx) ?>" class="pulse-input">
          <small class="text-gray-500">Used only when Reloadly's sender/account currency is not NGN. Enter the current NGN value of 1 unit of the sender currency (for example, 1 USD = ₦1,500 → 1500).</small>
        </label>
        <label class="block">
          <span class="font-semibold text-sm">Customer markup (%)</span>
          <input type="number" step="0.01" min="0" name="gift_api_markup" value="<?= esc_attr($gift_api_markup) ?>" class="pulse-input">
          <small class="text-gray-500">Applied after converting the Reloadly provider cost to NGN.</small>
        </label>
      </div>

      <div class="flex gap-2 mt-4">
        <button class="pulse-btn" type="submit">Save Reloadly Settings</button>
      </div>
    </form>

    <form method="post" class="mt-3">
      <?php wp_nonce_field('pulsepoint_giftcard_purchase_settings'); ?>
      <input type="hidden" name="test_reloadly_connection" value="1">
      <button class="button">Test Current Reloadly Connection</button>
      <span class="text-xs text-gray-500 ml-2">Tests the selected environment without purchasing a giftcard.</span>
    </form>
  </div>

  <div class="pulse-section">
    <h2 class="text-lg font-semibold mb-4"><i class="bi bi-gift"></i> Manual Giftcard Settings</h2>
    <p class="text-sm text-gray-500 mb-4">Your existing manual giftcard settings and inventory are preserved. They are not deleted by the Reloadly integration.</p>

    <?php if (!$giftcards): ?>
      <p>No manual giftcards found. <a href="?page=pulsepoint-add-giftcard" class="text-blue-600">Add your first giftcard</a>.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table>
          <thead><tr><th>ID</th><th>Category</th><th>Type</th><th>Rate</th><th>Min Amount</th><th>Max Amount</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach ($giftcards as $g): ?>
            <tr>
              <td><?= esc_html($g->id) ?></td>
              <td><strong><?= esc_html($g->category) ?></strong></td>
              <td><?= esc_html(ucfirst($g->type)) ?></td>
              <td><?= number_format($g->rate,2) ?></td>
              <td><?= number_format($g->min_amount,2) ?></td>
              <td><?= number_format($g->max_amount,2) ?></td>
              <td><span class="<?= $g->status === 'active' ? 'text-green-600' : 'text-gray-500' ?>"><?= ucfirst($g->status) ?></span></td>
              <td><?= esc_html(date('Y-m-d',strtotime($g->created_at))) ?></td>
              <td>
                <a href="?page=pulsepoint-add-giftcard&edit=<?= $g->id ?>" class="pulse-btn"><i class="bi bi-pencil-square"></i> Edit</a>
                <a href="?page=pulsepoint-giftcard&toggle=<?= $g->id ?>" class="pulse-btn-warning"><i class="bi bi-toggle2-on"></i> Toggle</a>
                <a href="?page=pulsepoint-giftcard&delete=<?= $g->id ?>" onclick="return confirm('Delete this giftcard?')" class="pulse-btn-danger"><i class="bi bi-trash"></i> Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>
