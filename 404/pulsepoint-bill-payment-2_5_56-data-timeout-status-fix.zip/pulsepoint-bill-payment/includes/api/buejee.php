<?php
/**
 * Pulsepoint ⇄ Buejee connector endpoint
 * Path: /api/buejee.php   →   https://YOUR-SITE.com/api/buejee
 *
 * Paste that URL (and the secret Buejee gives you) in:
 *   WordPress admin → Usefooma → Other Keys → "Buejee (WhatsApp / Telegram bot)"
 *
 * Actions handled (all requests are signed JSON POSTs from Buejee):
 *   identify    – who is this phone number?      (+ profile for the AI)
 *   verify_otp  – Telegram only: confirm the emailed code
 *   manifest    – what the bot can do on this site
 *   options     – dynamic choices (data plans for a network)
 *   run         – do it (buy airtime / data, balance, funding account, lookups, tickets)
 *
 * Money is never moved here directly. Purchases call the SAME handlers the app uses
 * (pulsepoint_airtime_purchase / pulsepoint_data_purchase) so balance checks, daily limits,
 * KYC, wallet+referral split, auto-refund on failure, idempotency and emails all still apply.
 */

if (!defined('ABSPATH')) {
    $wp_load = ($_SERVER['DOCUMENT_ROOT'] ?? '') . '/wp-load.php';
    if (is_file($wp_load)) {
        require_once $wp_load;
    } else {
        http_response_code(500);
        exit;
    }
}

global $wpdb;

require_once PULSEPOINT_DIR . 'includes/buejee-helper.php';

/** Find one of this customer's transactions by the reference on the receipt (BJBJ...), by
 * Buejee's own shorter Ref (BJ...), or by request id. */
if (!function_exists('pulsepoint_buejee_find_transaction')) {
    function pulsepoint_buejee_find_transaction(string $table, int $uid, string $ref, string $cols) {
        global $wpdb;
        $ref = ltrim((string) preg_replace('/\s+/', '', trim($ref)), '#');
        if ($ref === '') return null;
        $try = [$ref];
        if (strpos($ref, 'BJBJ') === 0) {
            $try[] = substr($ref, 2);
        } elseif (strpos($ref, 'BJ') === 0) {
            $try[] = 'BJ' . $ref;
        }
        $try = array_values(array_unique($try));
        $ph = implode(',', array_fill(0, count($try), '%s'));
        $args = array_merge([$uid], $try, $try);
        return $wpdb->get_row($wpdb->prepare("SELECT {$cols} FROM `{$table}` WHERE user_id = %d AND (reference IN ({$ph}) OR request_id IN ({$ph})) LIMIT 1", ...$args));
    }
}

/** Customer-facing text when a brand name does not pick exactly one rate row. */
if (!function_exists('pulsepoint_buejee_gift_choice_message')) {
    function pulsepoint_buejee_gift_choice_message(array $candidates, string $why, float $amount): string {
        $list = implode('; ', array_slice($candidates, 0, 6));
        if ($why === 'out_of_range') {
            return 'No card of that brand accepts a value of ' . rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.') . '. Available: ' . $list . '.';
        }
        return 'More than one gift card matches that name: ' . $list . '. Which one do you mean?';
    }
}

/** "100", "₦100.00", "1,000", "5k" or "$100" -> float. Plain (float) of "₦100" would be 0. */
if (!function_exists('pulsepoint_buejee_parse_amount')) {
    function pulsepoint_buejee_parse_amount($value): float {
        $s = strtolower(trim((string) $value));
        $mult = 1.0;
        if (preg_match('/^[^0-9]*([0-9][0-9,]*(?:\.[0-9]+)?)\s*k\b/', $s, $km)) {
            $mult = 1000.0;
            $s = $km[1];
        }
        $s = (string) preg_replace('/[^0-9.]/', '', $s);
        if ($s === '' || substr_count($s, '.') > 1) return 0.0;
        return round((float) $s * $mult, 2);
    }
}

/** Keep the last 25 requests Buejee made to this endpoint (no account numbers) for the admin Chat Bot page. */
if (!function_exists('pulsepoint_buejee_trace')) {
    function pulsepoint_buejee_trace(string $line): void {
        try {
            $line = substr((string) preg_replace('/\d{6,}/', '***', wp_strip_all_tags($line)), 0, 240);
            $log = get_option('pulsepoint_buejee_trace', []);
            if (!is_array($log)) $log = [];
            $log[] = gmdate('H:i:s') . ' UTC ' . $line;
            update_option('pulsepoint_buejee_trace', array_slice($log, -25), false);
        } catch (\Throwable $e) {
            // tracing must never break a request
        }
    }
}

if (!function_exists('pulsepoint_buejee_out')) {
    function pulsepoint_buejee_out(array $payload, int $code = 200): void {
        pulsepoint_buejee_trace('out ' . $code . ': ' . (string) ($payload['message'] ?? $payload['error'] ?? (isset($payload['status']) ? $payload['status'] : implode(',', array_keys($payload)))));
        if (!headers_sent()) {
            status_header($code);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo wp_json_encode($payload);
        exit;
    }
}

if (!function_exists('pulsepoint_buejee_run_result')) {
    function pulsepoint_buejee_run_result(string $status, string $message, array $data = []): void {
        $payload = ['status' => $status, 'message' => $message];
        if ($data) {
            $payload['data'] = $data;
        }
        pulsepoint_buejee_out($payload);
    }
}

/** Fetch the same bank directory used by the app's bank-transfer UI.
 * Cached for 30 minutes. A forced refresh that fails falls back to the last good copy. */
if (!function_exists('pulsepoint_buejee_bank_list')) {
    function pulsepoint_buejee_bank_list(bool $force_refresh = false): array {
        $cached = get_transient('pp_buejee_bank_directory');
        if (!$force_refresh && is_array($cached) && $cached) return $cached;
        $stale = (is_array($cached) && $cached) ? $cached : [];
        $response = wp_remote_get('https://pulsepoint-plugin.vercel.app/api/banks.json', ['timeout' => 15, 'headers' => ['Accept' => 'application/json']]);
        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) return $stale;
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!is_array($body)) return $stale;
        // The deployed banks.json currently wraps its records in data; accept common
        // alternate wrappers too so a small API response-shape change won't break transfers.
        $raw = $body['data'] ?? $body['banks'] ?? $body['results'] ?? $body;
        if (is_array($raw) && isset($raw['banks']) && is_array($raw['banks'])) $raw = $raw['banks'];
        if (!is_array($raw)) return $stale;
        $banks = [];
        foreach ($raw as $bank) {
            if (!is_array($bank)) continue;
            $code = trim((string) ($bank['bankCode'] ?? $bank['bank_code'] ?? $bank['code'] ?? ''));
            $name = trim((string) ($bank['bankName'] ?? $bank['bank_name'] ?? $bank['name'] ?? ''));
            if ($code !== '' && $name !== '') $banks[] = ['bankCode' => $code, 'bankName' => $name];
        }
        if ($banks) {
            // Keep the source's codes as strings; leading zeroes are significant.
            set_transient('pp_buejee_bank_directory', $banks, 30 * MINUTE_IN_SECONDS);
            return $banks;
        }
        return $stale;
    }
}

/** Match a customer's bank name (or a bank code) to one entry of the bank directory.
 * Exact canonical-name/alias matches win; the supplied bank code is only used when no name was given. */
if (!function_exists('pulsepoint_buejee_resolve_bank')) {
    function pulsepoint_buejee_resolve_bank(string $bank_input, string $bank_code = ''): ?array {
        $find = static function (array $directory, string $input): ?array {
            $needle = strtolower(preg_replace('/[^a-z0-9]/i', '', $input));
            if ($needle === '') return null;
            $aliases = [
                'fidelity' => ['fidelity', 'fidelitybank'],
                'moniepoint' => ['moniepoint', 'moniepointmfb', 'moniepointmicrofinancebank'],
                'palmpay' => ['palmpay', 'palmpaylimited', 'palmpaymicrofinancebank', 'palmpaymfb'],
                'opay' => ['opay', 'paycom', 'paycomnigeria'],
                'kuda' => ['kuda', 'kudamicrofinancebank'],
                'gtbank' => ['gtbank', 'guarantytrustbank', 'gtco'],
                'access' => ['access', 'accessbank'],
                'zenith' => ['zenith', 'zenithbank'],
                'uba' => ['uba', 'unitedbankforafrica'],
                'firstbank' => ['firstbank', 'firstbankofnigeria'],
            ];
            $needles = [$needle];
            foreach ($aliases as $canonical => $variants) {
                if ($needle === $canonical || in_array($needle, $variants, true)) {
                    $needles = array_values(array_unique(array_merge([$canonical], $variants)));
                    break;
                }
            }
            // Exact match first. Prefix matches are only a fallback for official long-form names.
            foreach ($directory as $bank) {
                $candidate = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) ($bank['bankName'] ?? '')));
                if ($candidate !== '' && in_array($candidate, $needles, true)) return $bank;
            }
            foreach ($directory as $bank) {
                $candidate = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) ($bank['bankName'] ?? '')));
                if (strlen($candidate) < 4) continue;
                foreach ($needles as $n) {
                    if (strlen($n) >= 5 && (strpos($candidate, $n) === 0 || strpos($n, $candidate) === 0)) return $bank;
                }
            }
            return null;
        };

        if ($bank_input !== '') {
            $hit = $find(pulsepoint_buejee_bank_list(), $bank_input);
            if (!$hit) $hit = $find(pulsepoint_buejee_bank_list(true), $bank_input); // directory may be stale
            return $hit;
        }
        if ($bank_code !== '') {
            foreach (pulsepoint_buejee_bank_list() as $bank) {
                if ((string) $bank['bankCode'] === $bank_code) return $bank;
            }
        }
        return null;
    }
}

/** Resolve an active gift-card setting from an ID or a natural-language brand label.
 * Never guesses: when several cards fit the words given, returns null and fills $candidates. */
if (!function_exists('pulsepoint_buejee_find_giftcard')) {
    function pulsepoint_buejee_find_giftcard($input, array &$candidates = [], float $amount = 0.0, string &$why = '') {
        global $wpdb;
        $candidates = [];
        $why = '';
        $table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
        if (is_numeric($input) && (int) $input > 0) {
            $found = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE id = %d AND status = 'active' LIMIT 1", (int) $input));
            if ($found) return $found;
        }
        $name = trim(sanitize_text_field((string) $input));
        if ($name === '') return null;
        $rows = $wpdb->get_results("SELECT * FROM `{$table}` WHERE status = 'active' ORDER BY category, sub_category LIMIT 500");
        if (!$rows) return null;

        $norm = static function ($s): string {
            return trim((string) preg_replace('/[^a-z0-9]+/', ' ', strtolower((string) $s)));
        };
        $needle = $norm($name);

        // 1. Exact "category sub-category" label.
        foreach ($rows as $row) {
            if ($norm($row->category . ' ' . $row->sub_category) === $needle) return $row;
        }

        // 2. Every meaningful word must appear; amounts and filler words are ignored.
        $stop = ['gift', 'card', 'cards', 'giftcard', 'giftcards', 'the', 'a', 'my', 'i', 'want', 'to', 'sell', 'trade', 'of', 'for'];
        $tokens = [];
        foreach (explode(' ', $needle) as $t) {
            if ($t === '' || ctype_digit($t) || in_array($t, $stop, true)) continue;
            $tokens[] = $t;
        }
        if (!$tokens) return null;
        $hits = [];
        foreach ($rows as $row) {
            $hay = $norm($row->category . ' ' . $row->sub_category);
            $all = true;
            foreach ($tokens as $t) {
                if (strpos($hay, $t) === false) { $all = false; break; }
            }
            if ($all) $hits[] = $row;
        }
        if (count($hits) === 1) return $hits[0];
        $why = 'ambiguous';
        // One brand often has several rate rows for different card values (e.g. 50, 100/150, 300-500, 500-2000).
        // Use the card value to choose the row whose limits contain it; the tightest range wins.
        if (count($hits) > 1 && $amount > 0) {
            $fit = [];
            foreach ($hits as $h) {
                $lo = (float) $h->min_amount;
                $hi = (float) $h->max_amount;
                if (($lo <= 0 || $amount >= $lo) && ($hi <= 0 || $amount <= $hi)) $fit[] = $h;
            }
            if (!$fit) {
                $why = 'out_of_range';
            } else {
                $width = static function ($row): float {
                    return ((float) $row->max_amount > 0) ? ((float) $row->max_amount - (float) $row->min_amount) : 1.0E12;
                };
                usort($fit, static function ($a, $b) use ($width) {
                    return $width($a) <=> $width($b);
                });
                $best = [];
                foreach ($fit as $f) {
                    if ($width($f) === $width($fit[0])) $best[] = $f;
                }
                if (count($best) === 1) return $best[0];
                $hits = $best;
            }
        }
        foreach ($hits as $h) {
            $candidates[] = trim((string) $h->category . (trim((string) $h->sub_category) !== '' ? ' - ' . trim((string) $h->sub_category) : ''));
        }
        return null;
    }
}

/** A resolved holder name must look like a name. Error text from the provider must never pass as one. */
if (!function_exists('pulsepoint_buejee_clean_account_name')) {
    function pulsepoint_buejee_clean_account_name(string $name): string {
        $name = trim((string) preg_replace('/\s+/', ' ', wp_strip_all_tags($name)));
        $len = strlen($name);
        if ($len < 3 || $len > 100) return '';
        if (!preg_match('/^[\p{L}\p{M}0-9 .,\'&()\/\-]+$/u', $name)) return '';
        if (in_array(strtolower($name), [
            'success', 'ok', 'verified', 'account verified', 'account not found', 'failed', 'failure', 'error',
            'invalid account', 'invalid account number', 'unable to verify account', 'could not verify account',
            'verification failed', 'please try again', 'unknown', 'null', 'none', 'n/a',
        ], true)) return '';
        if (preg_match('/\b(invalid|not found|error|unable|failed|failure|unauthori[sz]ed|forbidden|incorrect|could not|cannot|try again|timed? ?out|exception|denied|does not exist|no record|not available|insufficient|bank code|account number|api key|token)\b/i', $name)) return '';
        return $name;
    }
}

/** Remember why the last account-name check failed (shown to the bot and in the admin Chat Bot page). */
if (!function_exists('pulsepoint_buejee_verify_note')) {
    function pulsepoint_buejee_verify_note(string $reason): void {
        $reason = substr(trim((string) preg_replace('/\s+/', ' ', wp_strip_all_tags($reason))), 0, 220);
        $GLOBALS['pp_bj_verify_reason'] = $reason;
        update_option('pulsepoint_buejee_last_verify', gmdate('Y-m-d H:i:s') . ' UTC | ' . $reason, false);
    }
}

/** Resolve a Nigerian account name through WhoGoPay only. Never send a transfer
 * unless WhoGoPay returns a plausible account-holder name for the exact bank code
 * and 10-digit account number supplied. */
if (!function_exists('pulsepoint_buejee_resolve_account_name')) {
    function pulsepoint_buejee_resolve_account_name(string $bank_code, string $account_number): string {
        $bank_code = trim($bank_code);
        $account_number = preg_replace('/\D+/', '', $account_number);
        if ($bank_code === '' || !preg_match('/^\d{10}$/', $account_number)) {
            pulsepoint_buejee_verify_note('bad input: bank_code=' . $bank_code);
            return '';
        }

        // A name that was just verified (e.g. at the confirmation step) is reused for 10 minutes.
        $cache_key = 'pp_bj_acct_' . md5($bank_code . '|' . $account_number);
        $cached = get_transient($cache_key);
        if (is_string($cached) && $cached !== '') return $cached;

        // Same credential the existing withdrawal UI uses. Define PULSEPOINT_WHOGOPAY_VERIFY_KEY in
        // wp-config.php to override it (recommended: rotate this key, it is visible in withdraw.html).
        $key = (defined('PULSEPOINT_WHOGOPAY_VERIFY_KEY') && PULSEPOINT_WHOGOPAY_VERIFY_KEY !== '')
            ? (string) PULSEPOINT_WHOGOPAY_VERIFY_KEY
            : 'sk_xaqajx5u7xn36qjf9jz7ve5s';

        $args = [
            'timeout' => 12,
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'User-Agent' => 'Mozilla/5.0 (compatible; Pulsepoint-Buejee/2.5.55)',
                'Authorization' => 'Bearer ' . $key,
            ],
            'body' => wp_json_encode([
                'bankCode' => $bank_code,
                'accountNumber' => $account_number,
            ]),
        ];

        // One automatic retry for a network error, a timeout, a 429 or a 5xx.
        $response = null;
        for ($attempt = 1; $attempt <= 2; $attempt++) {
            $response = wp_remote_post('https://whogopay.com.ng/api/v1/verify-account-number', $args);
            if (!is_wp_error($response)) {
                $try_code = (int) wp_remote_retrieve_response_code($response);
                if ($try_code !== 429 && $try_code < 500) break;
            }
            if ($attempt < 2) usleep(700000);
        }

        if (is_wp_error($response)) {
            error_log('[Buejee bank verification] WhoGoPay request failed: ' . $response->get_error_code() . ' ' . $response->get_error_message());
            pulsepoint_buejee_verify_note('network error contacting WhoGoPay: ' . $response->get_error_message());
            return '';
        }
        $http = (int) wp_remote_retrieve_response_code($response);
        $raw_body = (string) wp_remote_retrieve_body($response);
        $data = json_decode($raw_body, true);
        if ($http < 200 || $http >= 300) {
            error_log('[Buejee bank verification] WhoGoPay HTTP ' . $http . '; bank_code=' . $bank_code . '; response=' . substr(wp_strip_all_tags($raw_body), 0, 500));
            pulsepoint_buejee_verify_note('WhoGoPay HTTP ' . $http . ' for bank_code ' . $bank_code . ': ' . substr(wp_strip_all_tags($raw_body), 0, 120));
            return '';
        }
        if (!is_array($data)) {
            error_log('[Buejee bank verification] WhoGoPay returned non-JSON; bank_code=' . $bank_code . '; response=' . substr(wp_strip_all_tags($raw_body), 0, 500));
            pulsepoint_buejee_verify_note('WhoGoPay returned non-JSON (HTTP ' . $http . '): ' . substr(wp_strip_all_tags($raw_body), 0, 120));
            return '';
        }
        // Diagnostics intentionally omit the account number and token.
        error_log('[Buejee bank verification] WhoGoPay HTTP ' . $http . '; bank_code=' . $bank_code . '; response_keys=' . implode(',', array_keys($data)) . '; success=' . (isset($data['success']) ? var_export($data['success'], true) : 'unset') . '; status=' . (isset($data['status']) ? var_export($data['status'], true) : 'unset') . '; message=' . substr(sanitize_text_field((string) ($data['message'] ?? '')), 0, 160));

        // An explicit failure flag always wins over any text in the body.
        $flag_fail = (isset($data['success']) && in_array($data['success'], [false, 'false', 0, '0'], true))
            || (isset($data['status']) && ($data['status'] === false || (is_string($data['status']) && in_array(strtolower($data['status']), ['failed', 'failure', 'error', 'false'], true))));
        if ($flag_fail) {
            pulsepoint_buejee_verify_note('WhoGoPay said failure for bank_code ' . $bank_code . ': ' . (string) ($data['message'] ?? json_encode($data)));
            return '';
        }

        // The existing withdrawal UI treats `message` as the resolved account-holder name.
        // Prefer explicit structured fields if returned, then mirror that behavior.
        $name = pulsepoint_buejee_clean_account_name((string) (
            $data['data']['account_name'] ??
            $data['data']['accountName'] ??
            $data['data']['name'] ??
            $data['account_name'] ??
            $data['accountName'] ??
            $data['message'] ??
            ''
        ));
        if ($name !== '') {
            set_transient($cache_key, $name, 10 * MINUTE_IN_SECONDS);
        } else {
            pulsepoint_buejee_verify_note('WhoGoPay replied but no usable name for bank_code ' . $bank_code . '; keys=' . implode(',', array_keys($data)) . '; message=' . (string) ($data['message'] ?? ''));
        }
        return $name;
    }
}

/** The settings the existing transfer handler applies (fee, KYC, mode), read the same way. */
if (!function_exists('pulsepoint_buejee_transfer_settings')) {
    function pulsepoint_buejee_transfer_settings(): array {
        global $wpdb;
        $out = ['pay_bank' => 0.0, 'bank_kyc' => false, 'api_mode' => 'live'];
        $rows = $wpdb->get_results("SELECT opt_key, opt_value FROM `{$wpdb->prefix}pulsepoint_settings` WHERE opt_key IN ('pay_bank','bank_kyc','api_mode')");
        foreach ((array) $rows as $r) {
            $v = maybe_unserialize($r->opt_value);
            if ($r->opt_key === 'pay_bank') $out['pay_bank'] = (float) $v;
            elseif ($r->opt_key === 'bank_kyc') $out['bank_kyc'] = ((string) $v === '1');
            elseif ($r->opt_key === 'api_mode' && $v !== '' && $v !== null) $out['api_mode'] = (string) $v;
        }
        return $out;
    }
}

/** Parse + validate a transfer request and verify the recipient. Used by both the confirmation
 * step (quote) and the run step, so the customer confirms exactly what will be sent.
 * @return array{error?:string,bank_code?:string,bank_name?:string,account_number?:string,amount?:float,account_name?:string} */
if (!function_exists('pulsepoint_buejee_prepare_transfer')) {
    function pulsepoint_buejee_prepare_transfer(array $params): array {
        $bank_code = trim(sanitize_text_field((string) ($params['bank_code'] ?? '')));
        $bank_input = trim(sanitize_text_field((string) ($params['bank_name'] ?? ($params['bank'] ?? ''))));
        if ($bank_input === '' && isset($params['recipient_bank'])) $bank_input = trim(sanitize_text_field((string) $params['recipient_bank']));
        $account_number = preg_replace('/\D/', '', (string) ($params['account_number'] ?? ''));
        $amount_raw = trim((string) ($params['amount'] ?? '0'));
        $amount_raw = str_ireplace([',', '₦', 'NGN', ' '], '', $amount_raw);
        if (preg_match('/^([0-9]+(?:\.[0-9]+)?)k$/i', $amount_raw, $km)) $amount_raw = (string) ((float) $km[1] * 1000);
        $amount = round((float) $amount_raw, 2);

        if ($amount <= 0 || !is_finite($amount)) return ['error' => 'How much would you like to send? Please provide a valid amount in naira.'];
        if (!preg_match('/^\d{10}$/', $account_number)) return ['error' => 'Please send the recipient’s 10-digit bank account number.'];

        $chosen = pulsepoint_buejee_resolve_bank($bank_input, $bank_code);
        if (!$chosen) return ['error' => 'Which bank should I send it to? Please tell me the exact bank name so I can use the correct bank code.'];

        $bank_code = (string) $chosen['bankCode'];
        $bank_name = (string) $chosen['bankName'];
        $account_name = pulsepoint_buejee_resolve_account_name($bank_code, $account_number);
        if ($account_name === '') {
            $why = (string) ($GLOBALS['pp_bj_verify_reason'] ?? '');
            return ['error' => 'I could not verify the account name for ' . $account_number . ' at ' . $bank_name . ' (bank code ' . $bank_code . '). I have not sent any money.' . ($why !== '' ? ' Technical reason: ' . $why : '')];
        }
        return [
            'bank_code' => $bank_code,
            'bank_name' => $bank_name,
            'account_number' => $account_number,
            'amount' => $amount,
            'account_name' => $account_name,
        ];
    }
}

/** Submit a gift card through the exact handler used by /api/giftcard.php. */
if (!function_exists('pulsepoint_buejee_submit_giftcard_via_existing_handler')) {
    function pulsepoint_buejee_submit_giftcard_via_existing_handler(int $user_id, int $giftcard_id, float $amount, string $type, string $digital_code, string $note): void {
        $handler = PULSEPOINT_DIR . 'core/giftcard/pulsepoint.php';
        if (!is_file($handler)) pulsepoint_buejee_run_result('failed', 'Gift card submission is unavailable right now. Please contact support.');
        require_once $handler;
        if (!function_exists('pulsepoint_sell_giftcard')) pulsepoint_buejee_run_result('failed', 'The existing gift card submission handler could not be loaded.');
        if (session_status() !== PHP_SESSION_ACTIVE && !headers_sent()) @session_start();
        if (session_status() !== PHP_SESSION_ACTIVE) pulsepoint_buejee_run_result('failed', 'I could not start a secure submission session. Please try again.');
        $_SESSION['pulsepoint_user'] = ['id' => $user_id];
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST['giftcard_id'] = $giftcard_id;
        $_POST['amount'] = $amount;
        $_POST['type'] = $type;
        $_POST['digital_code'] = $digital_code;
        $_POST['note'] = $note;
        unset($_FILES['physical_image']);
        $base_level = ob_get_level();
        ob_start();
        $finalize = static function () use ($base_level): void {
            static $done = false;
            if ($done) return;
            $done = true;
            $output = '';
            while (ob_get_level() > $base_level) $output = (string) ob_get_clean() . $output;
            $start = strpos($output, '{'); $end = strrpos($output, '}');
            $result = null;
            if ($start !== false && $end !== false && $end >= $start) $result = json_decode(substr($output, $start, $end - $start + 1), true);
            if (session_status() === PHP_SESSION_ACTIVE) { $_SESSION = []; @session_destroy(); }
            if (!is_array($result)) {
                echo wp_json_encode(['status' => 'failed', 'message' => 'The gift card handler returned an unreadable response. Check your gift card history before trying again.']);
                return;
            }
            if (!empty($result['success'])) {
                $d = is_array($result['data'] ?? null) ? $result['data'] : [];
                $reference = (string) ($d['reference'] ?? '');
                $message = (string) ($result['message'] ?? 'Your gift card submission was received and is awaiting review.');
                echo wp_json_encode(['status' => 'success', 'message' => $message, 'data' => $d]);
            } else {
                echo wp_json_encode(['status' => 'failed', 'message' => (string) ($result['message'] ?? 'The gift card submission failed. Nothing was confirmed as submitted.')]);
            }
        };
        add_action('shutdown', $finalize, 0);
        pulsepoint_sell_giftcard();
        exit;
    }
}

/** Run the plugin's existing bank-transfer handler, preserving its wallet, KYC, limit,
 * maintenance, fee, transaction-ledger, provider and auto-refund checks. */
if (!function_exists('pulsepoint_buejee_execute_bank_transfer')) {
    function pulsepoint_buejee_execute_bank_transfer(object $user, array $post, string $bank_name, string $account_name): void {
        if (!function_exists('pulsepoint_bank_transfer')) {
            $handler_file = PULSEPOINT_DIR . 'core/transfer/pulsepoint.php';
            if (is_file($handler_file)) require_once $handler_file;
        }
        if (!function_exists('pulsepoint_bank_transfer')) {
            pulsepoint_buejee_run_result('failed', 'Bank transfers are not available on this site yet. Please contact support.');
        }
        if (session_status() !== PHP_SESSION_ACTIVE && !headers_sent()) @session_start();
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['pulsepoint_user'] = ['id' => (int) $user->id];
        }
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST['bank_code'] = sanitize_text_field((string) ($post['bank_code'] ?? ''));
        $_POST['bank_name'] = sanitize_text_field($bank_name);
        $_POST['bank_logo'] = '';
        $_POST['account_number'] = sanitize_text_field((string) ($post['account_number'] ?? ''));
        $_POST['account_name'] = sanitize_text_field($account_name);
        $_POST['amount'] = (float) ($post['amount'] ?? 0);
        $_POST['narration'] = sanitize_text_field((string) ($post['narration'] ?? 'Buejee bank transfer'));

        $base_level = ob_get_level();
        ob_start();
        $finalize = static function () use ($base_level, $bank_name, $account_name, $post): void {
            static $done = false;
            if ($done) return;
            $done = true;
            $output = '';
            while (ob_get_level() > $base_level) $output = (string) ob_get_clean() . $output;
            $decoded = null;
            $start = strpos($output, '{'); $end = strrpos($output, '}');
            if ($start !== false && $end !== false && $end >= $start) {
                $tmp = json_decode(substr($output, $start, $end - $start + 1), true);
                if (is_array($tmp)) $decoded = $tmp;
            }
            if (session_status() === PHP_SESSION_ACTIVE) { $_SESSION = []; @session_destroy(); }
            $amount = (float) ($post['amount'] ?? 0);
            $account = (string) ($post['account_number'] ?? '');
            $name = trim($account_name) !== '' ? $account_name : $account;
            $ref = trim((string) ($decoded['reference'] ?? ''));
            if (!is_array($decoded)) {
                echo wp_json_encode(['status' => 'failed', 'message' => 'I could not confirm the transfer result. Please check your transaction history before trying again.']);
                return;
            }
            if (!empty($decoded['success'])) {
                $msg = '✅ ' . pulsepoint_buejee_naira($amount) . ' to ' . $name . ' (' . $bank_name . ') initiated.';
                if ($ref !== '') $msg .= ' Ref: ' . $ref . '.';
                if (isset($decoded['new_wallet'])) $msg .= ' Balance: ' . pulsepoint_buejee_naira($decoded['new_wallet']) . '.';
                echo wp_json_encode(['status' => 'success', 'message' => $msg, 'data' => $decoded]);
            } else {
                echo wp_json_encode(['status' => 'failed', 'message' => trim((string) ($decoded['message'] ?? 'The transfer could not be completed.'))]);
            }
        };
        add_action('shutdown', $finalize, 0);
        pulsepoint_bank_transfer();
        exit;
    }
}

/**
 * Run the existing airtime/data purchase handler in-process and translate its JSON
 * into Buejee's {status: success|pending|failed, message}.
 *
 * The handlers answer with wp_send_json() (which exits), so the output is captured
 * from a WordPress 'shutdown' callback that runs BEFORE WordPress flushes buffers.
 */
if (!function_exists('pulsepoint_buejee_execute')) {
    function pulsepoint_buejee_execute(object $user, string $kind, array $post, string $reference, string $summary): void {
        global $wpdb;

        $uid     = (int) $user->id;
        $lock    = 'pp_bj_run_' . $uid;
        $last_k  = 'pp_bj_last_' . $uid;
        $handler = $kind === 'airtime' ? 'pulsepoint_airtime_purchase' : 'pulsepoint_data_purchase';

        if (!function_exists($handler)) {
            pulsepoint_buejee_run_result('failed', 'Purchases are unavailable right now. Please try again later.');
        }

        if (get_transient($last_k)) {
            pulsepoint_buejee_run_result('failed', 'Please wait a few seconds between purchases, then try again.');
        }

        $got = (int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lock));
        if ($got !== 1) {
            pulsepoint_buejee_run_result('failed', 'Another purchase on this account is still being processed. Please wait a few seconds and try again.');
        }
        set_transient($last_k, 1, 10);

        if (!defined('PULSEPOINT_BUEJEE_RUN')) {
            define('PULSEPOINT_BUEJEE_RUN', true); // suppresses duplicate chat alerts for this purchase
        }

        $level = ob_get_level();
        ob_start();

        $finalize = static function () use ($level, $uid, $lock, $reference, $summary) {
            global $wpdb;
            static $done = false;
            if ($done) {
                return;
            }
            $done = true;

            // Collect everything the handler printed (innermost buffer last).
            $out = '';
            while (ob_get_level() > $level) {
                $out = (string) ob_get_clean() . $out;
            }

            $res = null;
            $s = strpos($out, '{');
            $e = strrpos($out, '}');
            if ($s !== false && $e !== false && $e > $s) {
                $decoded = json_decode(substr($out, $s, $e - $s + 1), true);
                if (is_array($decoded)) {
                    $res = $decoded;
                }
            }

            $trnx_table = $wpdb->prefix . 'pulsepoint_trnx';
            $user_table = $wpdb->prefix . 'pulsepoint_users';

            $t = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT status, amount FROM `{$trnx_table}` WHERE reference = %s AND user_id = %d LIMIT 1",
                    $reference,
                    $uid
                )
            );
            $fresh = $wpdb->get_row(
                $wpdb->prepare("SELECT wallet, referral_balance FROM `{$user_table}` WHERE id = %d", $uid)
            );

            $msg = '';
            if (is_array($res)) {
                $msg = trim((string) ($res['message'] ?? ''));
                if (!empty($res['success'])) {
                    if ($t && $t->status === 'pending') {
                        $status = 'pending';
                    } elseif ($t && $t->status === 'failed') {
                        $status = 'failed';
                    } else {
                        $status = 'success';
                    }
                } else {
                    $status = 'failed';
                }
            } else {
                // Handler crashed or printed nothing: trust the ledger, never guess "success".
                $status = $t ? (string) $t->status : 'failed';
                if ($status === 'pending') {
                    $msg = 'It is being processed.';
                } elseif ($msg === '') {
                    $msg = 'Something went wrong while processing the purchase. Please check your transaction history before trying again.';
                }
            }

            $balance = $fresh ? ((float) $fresh->wallet + (float) $fresh->referral_balance) : null;

            if ($status === 'success') {
                $message = "{$summary} was successful.";
            } elseif ($status === 'pending') {
                $message = "{$summary} is being processed. You will be notified when it completes.";
            } else {
                $message = "{$summary} failed" . ($msg !== '' ? ': ' . $msg : '.');
            }
            $message .= "\nReference: {$reference}";
            if ($balance !== null) {
                $message .= "\nAvailable balance: " . pulsepoint_buejee_naira($balance);
            }

            $data = ['reference' => $reference, 'status' => $status];
            if ($t) {
                $data['amount'] = (float) $t->amount;
            }
            if ($balance !== null) {
                $data['available_balance'] = $balance;
            }

            // Release the per-customer lock and throw away the throw-away session.
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION = [];
                @session_destroy();
            }

            if (!headers_sent()) {
                header('Content-Type: application/json; charset=utf-8');
            }
            echo wp_json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
        };

        // Priority 0 = before wp_ob_end_flush_all (priority 1), so our buffer is still intact.
        add_action('shutdown', $finalize, 0);

        if (session_status() !== PHP_SESSION_ACTIVE && !headers_sent()) {
            @session_start();
        }
        if (!isset($_SESSION['pulsepoint_user']) || !is_array($_SESSION['pulsepoint_user'])) {
            $_SESSION['pulsepoint_user'] = [];
        }
        $_SESSION['pulsepoint_user']['id'] = $uid;
        unset($_SESSION['last_airtime_request'], $_SESSION['last_data_request']);

        $_SERVER['REQUEST_METHOD'] = 'POST';
        foreach ($post as $k => $v) {
            $_POST[$k] = $v;
        }

        $handler();   // prints JSON via wp_send_json() and exits → $finalize runs
        exit;         // handler returned without exiting: still run $finalize
    }
}

/* =========================================================
   1. METHOD + SIGNATURE
========================================================= */

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
    pulsepoint_buejee_out(['error' => 'Method not allowed'], 405);
}
pulsepoint_buejee_trace('request received');

$bj_secret = pulsepoint_buejee_secret();
if ($bj_secret === '') {
    pulsepoint_buejee_out(['error' => 'Buejee is not configured on this site yet.'], 503);
}

$bj_raw = (string) file_get_contents('php://input');
$bj_sig = (string) ($_SERVER['HTTP_X_BUEJEE_SIGNATURE'] ?? '');

if (
    !preg_match('/t=(\d+),v1=([a-f0-9]+)/', $bj_sig, $bj_m)
    || abs(time() - (int) $bj_m[1]) > 300
    || !hash_equals(hash_hmac('sha256', $bj_m[1] . '.' . $bj_raw, $bj_secret), $bj_m[2])
) {
    pulsepoint_buejee_trace('REJECTED 401: bad or missing signature (secret mismatch or clock off)');
    status_header(401);
    exit;
}

// If the server passes the Authorization header through, it must match too.
$bj_auth = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''));
if ($bj_auth !== '' && preg_match('/^Bearer\s+(.+)$/i', trim($bj_auth), $bj_b)) {
    if (!hash_equals($bj_secret, trim($bj_b[1]))) {
        status_header(401);
        exit;
    }
}

$bj_req = json_decode($bj_raw, true);
if (!is_array($bj_req)) {
    pulsepoint_buejee_out(['error' => 'Invalid JSON'], 400);
}

$bj_action = (string) ($bj_req['action'] ?? '');
pulsepoint_buejee_trace('in: action=' . $bj_action . ' id=' . (string) ($bj_req['id'] ?? '-'));

// A signed state-changing request can only be used once.
if (in_array($bj_action, ['run', 'verify_otp'], true)) {
    $bj_replay = 'pp_bj_sig_' . md5($bj_m[2]);
    if (get_transient($bj_replay)) {
        pulsepoint_buejee_trace('REJECTED 401: repeated signed request');
        status_header(401);
        exit;
    }
    set_transient($bj_replay, 1, 10 * MINUTE_IN_SECONDS);
}

/* =========================================================
   2. ACTIONS
========================================================= */

$bj_networks = [
    'MTN'     => 'MTN',
    'GLO'     => 'Glo',
    'AIRTEL'  => 'Airtel',
    '9MOBILE' => '9mobile',
];

$bj_data_table = $wpdb->prefix . 'pulsepoint_data';
$bj_trnx_table = $wpdb->prefix . 'pulsepoint_trnx';

switch ($bj_action) {

    /* ---------- "Who is this?" ---------- */
    case 'identify':
        $user = pulsepoint_buejee_find_user_by_phone($bj_req['phone'] ?? '');
        if (!$user) {
            pulsepoint_buejee_out(['found' => false]);
        }

        // Telegram: the customer typed the number themselves, so prove it is theirs.
        if (!empty($bj_req['unverified'])) {
            $otp = pulsepoint_buejee_send_otp($user);
            pulsepoint_buejee_out([
                'found'        => true,
                'otp_required' => true,
                'message'      => $otp['message'],
            ]);
        }

        pulsepoint_buejee_out([
            'found'   => true,
            'name'    => (string) $user->firstname,
            'profile' => pulsepoint_buejee_profile($user),
        ]);
        break;

    case 'verify_otp':
        $user = pulsepoint_buejee_find_user_by_phone($bj_req['phone'] ?? '');
        $ok   = $user && pulsepoint_buejee_verify_otp($user, $bj_req['code'] ?? '');
        if (!$ok) {
            pulsepoint_buejee_out(['verified' => false]);
        }
        pulsepoint_buejee_out([
            'verified' => true,
            'name'     => (string) $user->firstname,
            'profile'  => pulsepoint_buejee_profile($user),
        ]);
        break;

    /* ---------- "What can the bot do here?" ---------- */
    case 'manifest':
        $network_options = [];
        foreach ($bj_networks as $value => $label) {
            $network_options[] = ['value' => $value, 'label' => $label];
        }

        // Data networks = networks that really have active plans.
        $data_net_rows = $wpdb->get_col("SELECT DISTINCT network FROM `{$bj_data_table}` WHERE status = 'active' AND network IS NOT NULL AND network <> ''");
        $data_network_options = [];
        foreach ((array) $data_net_rows as $net) {
            $key = strtoupper(trim((string) $net));
            if (isset($bj_networks[$key])) {
                $data_network_options[$key] = ['value' => $key, 'label' => $bj_networks[$key]];
            }
        }
        $data_network_options = $data_network_options ? array_values($data_network_options) : $network_options;

        $airtime_max = (float) pulsepoint_buejee_setting('airtime_max_amount', 50000);
        if ($airtime_max <= 0) {
            $airtime_max = 50000;
        }

        // Do not expose network as a manifest parameter: some Buejee chat flows still
        // prompt for optional fields. Infer the network server-side from the phone prefix.
        // This lets 'send airtime 100 to 09064873505' proceed without a network question.
        $airtime_params = [
            ['name' => 'phone', 'label' => 'Phone number to recharge (say my number to use the registered number)', 'type' => 'phone'],
            ['name' => 'amount', 'label' => 'Amount (₦)', 'type' => 'number', 'min' => 100, 'max' => (int) $airtime_max],
        ];
        $data_params = [
            ['name' => 'network', 'label' => 'Network', 'type' => 'select', 'options' => $data_network_options],
            ['name' => 'plan', 'label' => 'Data plan', 'type' => 'select', 'options_from' => true],
            ['name' => 'phone', 'label' => 'Phone number to receive the data (optional; defaults to your registered number)', 'type' => 'phone'],
        ];

        pulsepoint_buejee_out(['actions' => [
            [
                'id'          => 'buy_airtime',
                'label'       => 'Buy airtime',
                'description' => 'Buy airtime. Understand natural language and extract amount and phone immediately. Do not ask for network; infer it from the phone prefix. Accept 10-digit Nigerian numbers by normalising them. Ask only for genuinely missing information, show one confirmation, and report the real provider result.',
                'keywords'    => ['airtime', 'recharge', 'top up', 'topup', 'vtu', 'send airtime', 'recharge my number', 'airtime for me'],
                'params'      => $airtime_params,
            ],
            [
                'id'          => 'buy_data',
                'label'       => 'Buy data',
                'description' => 'Buy data with minimal questions. Extract network, plan and recipient from the customer message. If the exact plan is named and available, select it and show one concise confirmation with plan, validity, price and phone. If the customer only says “MTN data”, show available plans and ask them to choose. Use the registered phone if no recipient is given. Accept 10-digit Nigerian mobile numbers by normalising them. Execute only after confirmation and report the actual result.',
                'keywords'    => ['data', 'bundle', 'gb', 'mb', 'internet', 'data mtn', 'buy data', 'data plans', 'show data plans'],
                'params'      => $data_params,
            ],
            [
                'id'          => 'balance',
                'label'       => 'Check balance',
                'description' => 'Answer naturally when the customer asks how much money they have, their wallet balance, available balance or referral balance.',
                'keywords'    => ['balance', 'how much', 'available balance', 'my money', 'what is my balance'],
                'confirm'     => false,
                'params'      => [],
            ],
            [
                'id'          => 'fund_wallet',
                'label'       => 'Fund wallet (get account number)',
                'description' => 'Give the customer their personal virtual bank account number for funding the wallet by bank transfer',
                'keywords'    => ['fund', 'deposit', 'account number', 'virtual account', 'add money', 'top up wallet', 'bank details', 'account details', 'where do i transfer', 'how do i fund'],
                'confirm'     => false,
                'params'      => [],
            ],
            [
                'id'          => 'bank_transfer',
                'label'       => 'Send a bank transfer',
                'description' => 'Send money to a Nigerian bank account. Use the bank name exactly as the customer said it. Start as soon as bank, 10-digit account number and amount are known, and do not ask for confirmation yourself: the system verifies the recipient and asks YES once.',
                'keywords'    => ['send money', 'transfer money', 'send 1k', 'send 1000', 'pay account', 'send to account', 'send to fidelity', 'send to moniepoint', 'send to palmpay', 'pay someone', 'make a transfer'],
                'quote'       => true,
                'confirm'     => true,
                'params'      => [
                    ['name' => 'bank_name', 'label' => 'Bank', 'type' => 'text', 'help' => 'e.g. PalmPay, Moniepoint, OPay'],
                    ['name' => 'account_number', 'label' => 'Account number', 'type' => 'digits', 'min_length' => 10, 'max_length' => 10, 'help' => '10 digits'],
                    ['name' => 'amount', 'label' => 'Amount (₦)', 'type' => 'amount', 'min' => 1, 'max' => 10000000],
                ],
            ],
            [
                'id'          => 'giftcard_rates',
                'label'       => 'Check gift card rates',
                'readonly'    => true,
                'description' => 'Look up current active gift card rates immediately. If asked what cards are available, list all active rates without asking for brand or amount first. If a brand is named, filter results to that brand. This is read-only and needs no confirmation.',
                'keywords'    => ['gift card rate', 'giftcard rate', 'gift card rates', 'giftcard rates', 'what is the rate', 'what cards are available', 'available gift cards', 'giftcard price'],
                'confirm'     => false,
                'params'      => [['name' => 'asset', 'label' => 'Brand/category filter (optional)', 'type' => 'text', 'required' => false]],
            ],
            [
                'id'          => 'sell_giftcard',
                'label'       => 'Submit a gift card for trading',
                'quote'       => true,
                'description' => 'Sell a digital gift card. Ask only for the brand, the card value and the card code. Gift cards are digital only: never ask digital or physical. Show the payout and submit once after YES.',
                'keywords'    => ['trade card', 'sell card', 'trade my card', 'i wan trade card', 'i want to trade card', 'sell gift card', 'sell my gift card', 'sell giftcard', 'sell my giftcard', 'trade gift card', 'trade my gift card', 'trade giftcard', 'trade my giftcard', 'i want to trade my giftcard', 'sell steam', 'sell amazon', 'sell itunes', 'sell apple', 'sell google play', 'sell my card', 'submit gift card', 'cash out gift card', 'redeem gift card'],
                'confirm'     => true,
                'params'      => [
                    ['name' => 'giftcard_id', 'label' => 'Gift card brand', 'type' => 'text', 'help' => 'e.g. Steam'],
                    ['name' => 'amount', 'label' => 'Card value', 'type' => 'amount', 'min' => 5, 'max' => 10000],
                    ['name' => 'digital_code', 'label' => 'Gift card code', 'type' => 'text'],
                ],
            ],
            [
                'id'          => 'transaction_status',
                'label'       => 'Check a transaction',
                'readonly'    => true,
                'description' => 'Status of one transaction by its reference',
                'params'      => [['name' => 'reference', 'label' => 'Transaction reference', 'type' => 'text']],
            ],
            [
                'id'          => 'giftcard_status',
                'label'       => 'Check my gift card submission',
                'readonly'    => true,
                'description' => 'Status of gift cards the customer submitted. Leave the number empty for the latest ones.',
                'keywords'    => ['gift card status', 'giftcard status', 'status of my gift card', 'my gift card', 'card i sent', 'card i submitted', 'uploaded card'],
                'params'      => [['name' => 'reference', 'label' => 'Gift card number', 'type' => 'text', 'required' => false, 'help' => 'e.g. 12, or skip for the latest']],
            ],
            [
                'id'          => 'ticket_status',
                'label'       => 'Check my complaint ticket',
                'readonly'    => true,
                'description' => 'Status of complaint or refund tickets the customer opened. Leave the number empty for the latest ones.',
                'keywords'    => ['ticket status', 'status of my ticket', 'my complaint', 'my ticket', 'complaint status', 'refund status'],
                'params'      => [['name' => 'ticket', 'label' => 'Ticket number', 'type' => 'text', 'required' => false, 'help' => 'e.g. 3, or skip for the latest']],
            ],
            [
                'id'          => 'report_issue',
                'label'       => 'Report a transaction problem',
                'description' => 'Log a complaint with our support team. Never tell the customer a complaint is logged unless this action ran and returned a ticket number.',
                'keywords'    => ['complaint', 'make a complaint', 'not received', 'failed', 'wrong number', 'problem'],
                'params'      => [
                    ['name' => 'reference', 'label' => 'Transaction reference', 'type' => 'text', 'required' => false, 'help' => 'starts with BJBJ, or skip'],
                    ['name' => 'details', 'label' => 'Problem details', 'type' => 'textarea', 'required' => false, 'help' => 'in one line, or skip'],
                ],
            ],
            [
                'id'          => 'request_refund',
                'label'       => 'Request a refund',
                'description' => 'Ask the support team to review a failed or stuck transaction for refund. Never say a refund request is logged unless this action returned a ticket number.',
                'keywords'    => ['refund', 'reverse', 'reversal'],
                'params'      => [['name' => 'reference', 'label' => 'Transaction reference', 'type' => 'text']],
            ],
        ]]);
        break;

    /* ---------- dynamic choices ---------- */
    case 'options':
        $id     = (string) ($bj_req['id'] ?? '');
        $param  = (string) ($bj_req['param'] ?? '');
        $values = is_array($bj_req['values'] ?? null) ? $bj_req['values'] : [];

        if ($id === 'bank_transfer' && $param === 'bank_code') {
            $banks = pulsepoint_buejee_bank_list();
            $options = [];
            foreach ($banks as $bank) {
                $options[] = ['value' => (string) $bank['bankCode'], 'label' => (string) $bank['bankName']];
            }
            pulsepoint_buejee_out(['options' => $options]);
        }

        if ($id === 'sell_giftcard' && in_array($param, ['giftcard_id', 'card'], true)) {
            $gift_table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
            $query = sanitize_text_field((string) ($bj_req['query'] ?? ''));
            $sql = "SELECT id, category, sub_category, type, rate, min_amount, max_amount FROM `{$gift_table}` WHERE status = 'active'";
            if ($query !== '') {
                $like = '%' . $wpdb->esc_like($query) . '%';
                $sql .= $wpdb->prepare(' AND (category LIKE %s OR sub_category LIKE %s)', $like, $like);
            }
            $sql .= ' ORDER BY category, sub_category LIMIT 40';
            $rows = $wpdb->get_results($sql);
            $options = [];
            foreach ((array) $rows as $row) {
                $label = trim((string) $row->category . (trim((string) $row->sub_category) !== '' ? ' - ' . trim((string) $row->sub_category) : ''));
                $label .= ' — rate ' . rtrim(rtrim(number_format((float) $row->rate, 4, '.', ''), '0'), '.') . '; limits ₦' . number_format((float) $row->min_amount, 2) . '–₦' . number_format((float) $row->max_amount, 2);
                $options[] = ['value' => (string) (int) $row->id, 'label' => $label];
            }
            pulsepoint_buejee_out(['options' => $options]);
        }

        if ($id === 'giftcard_rates') {
            $gift_table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
            $query = sanitize_text_field((string) ($bj_req['query'] ?? $values['asset'] ?? ''));
            $sql = "SELECT id, category, sub_category, type, rate, min_amount, max_amount FROM `{$gift_table}` WHERE status = 'active'";
            if ($query !== '') {
                $like = '%' . $wpdb->esc_like($query) . '%';
                $sql .= $wpdb->prepare(' AND (category LIKE %s OR sub_category LIKE %s)', $like, $like);
            }
            $sql .= ' ORDER BY category, sub_category LIMIT 80';
            $rows = $wpdb->get_results($sql);
            $options = [];
            foreach ((array) $rows as $row) {
                $label = trim((string) $row->category . (trim((string) $row->sub_category) !== '' ? ' - ' . trim((string) $row->sub_category) : ''));
                $options[] = ['value' => (string) (int) $row->id, 'label' => $label . ' — rate ' . rtrim(rtrim(number_format((float) $row->rate, 4, '.', ''), '0'), '.') . '; min ₦' . number_format((float) $row->min_amount, 2) . '; max ₦' . number_format((float) $row->max_amount, 2)];
            }
            pulsepoint_buejee_out(['options' => $options]);
        }

        if ($id !== 'buy_data' || $param !== 'plan') {
            pulsepoint_buejee_out(['options' => []]);
        }

        $network = strtoupper(trim((string) ($values['network'] ?? '')));
        if (!isset($bj_networks[$network])) {
            pulsepoint_buejee_out(['options' => []]);
        }

        $plans = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, plan, details, type, amount FROM `{$bj_data_table}`
                 WHERE status = 'active' AND network = %s AND amount > 0
                 ORDER BY amount ASC, id ASC LIMIT 80",
                $network
            )
        );

        $options = [];
        foreach ((array) $plans as $p) {
            $name = trim((string) $p->details);
            if ($name === '') {
                $name = trim((string) $p->plan);
            }
            $type = trim((string) $p->type);
            $validity = ($type !== '' && stripos($name, $type) === false) ? ' for ' . $type : '';
            $options[] = [
                'value' => (string) (int) $p->id,
                'label' => $name . $validity . ' at ₦' . number_format((float) $p->amount, 2),
            ];
        }

        pulsepoint_buejee_out(['options' => $options]);
        break;

    /* ---------- Quote a gift-card trade before confirmation ---------- */
    case 'quote':
        $quote_id = (string) ($bj_req['id'] ?? '');
        $quote_params = is_array($bj_req['params'] ?? null) ? $bj_req['params'] : [];
        if ($quote_id === 'bank_transfer') {
            if ((string) pulsepoint_buejee_setting('maintenance_mode', '0') === '1') {
                pulsepoint_buejee_out(['ok' => false, 'message' => 'The platform is under maintenance. Please try again later.']);
            }
            $xq = pulsepoint_buejee_prepare_transfer($quote_params);
            if (!empty($xq['error'])) pulsepoint_buejee_out(['ok' => false, 'message' => (string) $xq['error']]);
            $xs = pulsepoint_buejee_transfer_settings();
            $x_fee = (float) $xs['pay_bank'];
            $x_stamp = ((float) $xq['amount'] >= 10000) ? 50.0 : 0.0;
            $x_total = (float) $xq['amount'] + $x_fee + $x_stamp;
            // Pre-check the same limits the transfer handler enforces, when the customer is known.
            $xq_cust = is_array($bj_req['customer'] ?? null) ? $bj_req['customer'] : [];
            $xq_user = pulsepoint_buejee_find_user_by_phone($xq_cust['phone'] ?? '');
            if ($xq_user) {
                if (!empty($xs['bank_kyc']) && (int) $xq_user->statuskyc !== 1) {
                    pulsepoint_buejee_out(['ok' => false, 'message' => 'Please complete KYC before making bank transfers.']);
                }
                if ($xs['api_mode'] === 'live' && (float) $xq_user->wallet < $x_total) {
                    pulsepoint_buejee_out(['ok' => false, 'message' => 'Your wallet balance is not enough. You need ' . pulsepoint_buejee_naira($x_total) . ' for this transfer, and your wallet has ' . pulsepoint_buejee_naira((float) $xq_user->wallet) . '.']);
                }
            }
            $xmsg = '✅ ' . $xq['account_name'] . ' (' . $xq['bank_name'] . ')';
            if ($x_fee > 0 || $x_stamp > 0) {
                $xmsg .= ' · Fee ' . pulsepoint_buejee_naira($x_fee + $x_stamp) . ' · Total ' . pulsepoint_buejee_naira($x_total);
            }
            pulsepoint_buejee_out(['ok' => true, 'message' => $xmsg]);
        }
        if ($quote_id !== 'sell_giftcard') {
            pulsepoint_buejee_out(['ok' => true, 'message' => 'Review the details and confirm to continue.']);
        }
        $gift_table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
        $gift_input = $quote_params['giftcard_id'] ?? $quote_params['card'] ?? $quote_params['brand'] ?? '';
        $gift_amount = pulsepoint_buejee_parse_amount($quote_params['amount'] ?? $quote_params['value'] ?? 0);
        $gift_candidates = [];
        $gift_why = '';
        $gift = pulsepoint_buejee_find_giftcard($gift_input, $gift_candidates, $gift_amount, $gift_why);
        if (!$gift && $gift_candidates) pulsepoint_buejee_out(['ok' => false, 'message' => pulsepoint_buejee_gift_choice_message($gift_candidates, $gift_why, $gift_amount)]);
        if (!$gift) pulsepoint_buejee_out(['ok' => false, 'message' => 'Please choose an active gift card brand from the available rates first.']);
        if ($gift_amount <= 0 || ($gift->min_amount > 0 && $gift_amount < (float) $gift->min_amount) || ($gift->max_amount > 0 && $gift_amount > (float) $gift->max_amount)) {
            pulsepoint_buejee_out(['ok' => false, 'message' => 'That amount is outside this card’s accepted limits. Please check the current rate and limits.']);
        }
        $brand = trim((string) $gift->category . (trim((string) $gift->sub_category) !== '' ? ' - ' . trim((string) $gift->sub_category) : ''));
        $payout = $gift_amount * (float) $gift->rate;
        pulsepoint_buejee_out(['ok' => true, 'message' => $brand . ': current rate ' . rtrim(rtrim(number_format((float) $gift->rate, 4, '.', ''), '0'), '.') . '. Estimated value for ' . number_format($gift_amount, 2) . ' is ' . pulsepoint_buejee_naira($payout) . '. This is an estimate; payout is subject to review.']);
        break;

    /* ---------- "Do it." ---------- */
    case 'run':
        $act    = (string) ($bj_req['id'] ?? '');
        $params = is_array($bj_req['params'] ?? null) ? $bj_req['params'] : [];
        $cust   = is_array($bj_req['customer'] ?? null) ? $bj_req['customer'] : [];

        // WHO is buying always comes from the verified customer, never from params.
        $user = pulsepoint_buejee_find_user_by_phone($cust['phone'] ?? '');
        if (!$user) {
            pulsepoint_buejee_run_result('failed', 'We could not find your account. Please contact support.');
        }
        $uid = (int) $user->id;

        // Same reference = same operation (Buejee never retries; this is belt and braces).
        $clean = preg_replace('/[^A-Za-z0-9_-]/', '', (string) ($bj_req['reference'] ?? ''));
        $reference = 'BJ' . substr($clean !== '' ? $clean : bin2hex(random_bytes(6)), 0, 60);

        $act = [
            'transfer' => 'bank_transfer', 'send_money' => 'bank_transfer', 'make_transfer' => 'bank_transfer',
            'giftcard_rate' => 'giftcard_rates', 'check_giftcard_rates' => 'giftcard_rates',
            'trade_giftcard' => 'sell_giftcard', 'sell_gift_card' => 'sell_giftcard'
        ][$act] ?? $act;

        switch ($act) {

            case 'balance':
                $wallet   = (float) $user->wallet;
                $referral = (float) ($user->referral_balance ?? 0);
                $promo    = (float) ($user->promo_bonus_pending ?? 0);
                $msg  = 'Wallet balance: ' . pulsepoint_buejee_naira($wallet) . "\n";
                $msg .= 'Referral balance: ' . pulsepoint_buejee_naira($referral) . "\n";
                $msg .= 'Total available to spend: ' . pulsepoint_buejee_naira($wallet + $referral);
                if ($promo > 0) {
                    $msg .= "\nPending promo bonus (locked): " . pulsepoint_buejee_naira($promo);
                }
                pulsepoint_buejee_run_result('success', $msg, [
                    'wallet'            => $wallet,
                    'referral'          => $referral,
                    'available'         => $wallet + $referral,
                    'pending_promo'     => $promo,
                ]);
                break;

            case 'fund_wallet':
                if ((string) pulsepoint_buejee_setting('maintenance_mode', '0') === '1') {
                    pulsepoint_buejee_run_result('failed', 'The platform is under maintenance. Please try again later.');
                }

                $accounts = pulsepoint_buejee_virtual_accounts($uid);
                $errors   = [];

                if (
                    function_exists('pulsepoint_get_virtual_account_providers')
                    && function_exists('pulsepoint_ensure_virtual_accounts')
                ) {
                    $settings_table = $wpdb->prefix . 'pulsepoint_settings';
                    $settings = [];
                    foreach ((array) $wpdb->get_results("SELECT opt_key, opt_value FROM `{$settings_table}`") as $row) {
                        $settings[(string) $row->opt_key] = maybe_unserialize($row->opt_value);
                    }

                    $providers = pulsepoint_get_virtual_account_providers($settings);
                    $have = [];
                    foreach (pulsepoint_get_user_virtual_accounts($uid) as $acc) {
                        $have[strtolower(trim((string) $acc['provider']))] = true;
                    }
                    $missing = false;
                    foreach ($providers as $prov) {
                        if (empty($have[$prov])) {
                            $missing = true;
                            break;
                        }
                    }

                    // Provider calls are rate limited per customer (same idea as /api/virtual-account).
                    $va_key = 'pp_bj_va_' . $uid;
                    if ($missing && !get_transient($va_key)) {
                        set_transient($va_key, 1, 20);
                        $made = pulsepoint_ensure_virtual_accounts($uid, $user, $settings);
                        $errors = is_array($made['errors'] ?? null) ? $made['errors'] : [];
                        $accounts = pulsepoint_buejee_virtual_accounts($uid);
                    }
                }

                if (!$accounts) {
                    $why = '';
                    if ($errors) {
                        $first = reset($errors);
                        $why = is_array($first) ? (string) ($first['message'] ?? '') : (string) $first;
                    }
                    pulsepoint_buejee_run_result(
                        'failed',
                        'We could not set up your funding account yet' . ($why !== '' ? ': ' . $why : '.')
                        . ' Please try again in a minute or contact support.'
                    );
                }

                $lines = ["Fund your wallet by bank transfer to:"];
                foreach ($accounts as $a) {
                    $lines[] = "\n" . $a['bank'] . "\nAccount number: " . $a['account_number'] . "\nAccount name: " . $a['account_name'];
                }
                $lines[] = "\nYour wallet is credited automatically once the transfer is confirmed.";
                pulsepoint_buejee_run_result('success', implode("\n", $lines), ['accounts' => $accounts]);
                break;

            case 'transaction_status':
                $ref = trim((string) ($params['reference'] ?? ''));
                if ($ref === '') {
                    pulsepoint_buejee_run_result('failed', 'Please give the transaction reference.');
                }
                $t = pulsepoint_buejee_find_transaction($bj_trnx_table, $uid, $ref, 'reference, category, amount, status, type, recipient, description, date');
                if (!$t) {
                    pulsepoint_buejee_run_result('failed', 'No transaction with that reference was found for this customer.');
                }
                $data = [
                    'reference' => (string) $t->reference,
                    'item'      => (string) $t->description !== '' ? (string) $t->description : (string) $t->category,
                    'type'      => (string) $t->type,
                    'amount'    => (float) $t->amount,
                    'status'    => (string) $t->status,
                    'recipient' => (string) $t->recipient,
                    'date'      => (string) $t->date,
                ];
                if (in_array($t->category, ['airtime', 'data'], true) && $t->status === 'failed') {
                    $data['note'] = 'Failed airtime/data purchases are refunded to the wallet automatically by the system.';
                }
                pulsepoint_buejee_run_result('success', "Transaction {$t->reference} is {$t->status}.", $data);
                break;

            case 'giftcard_status':
                $gl_table = $wpdb->prefix . 'pulsepoint_giftcard_listings';
                $gs_table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
                $gno = (int) preg_replace('/\D/', '', (string) ($params['reference'] ?? ''));
                $gsql = "SELECT l.id, l.amount, l.selling_price, l.status, l.type, l.created_at, l.updated_at, s.category, s.sub_category
                         FROM `{$gl_table}` l LEFT JOIN `{$gs_table}` s ON s.id = l.giftcard_id WHERE l.user_id = %d";
                if ($gno > 0) {
                    $grows = $wpdb->get_results($wpdb->prepare($gsql . ' AND l.id = %d LIMIT 1', $uid, $gno));
                } else {
                    $grows = $wpdb->get_results($wpdb->prepare($gsql . ' ORDER BY l.id DESC LIMIT 3', $uid));
                }
                if (!$grows) {
                    pulsepoint_buejee_run_result('failed', $gno > 0 ? 'No gift card with that number was found for this customer.' : 'This customer has not submitted any gift cards yet.');
                }
                $gwords = ['pending' => 'waiting for review', 'approved' => 'approved', 'rejected' => 'rejected', 'sold' => 'completed'];
                $glines = [];
                $gdata = [];
                foreach ($grows as $g) {
                    $gname = trim((string) $g->category . (trim((string) $g->sub_category) !== '' ? ' - ' . trim((string) $g->sub_category) : ''));
                    $gstat = $gwords[(string) $g->status] ?? (string) $g->status;
                    $glines[] = 'Gift card #' . (int) $g->id . ' (' . $gname . ', value ' . rtrim(rtrim(number_format((float) $g->amount, 2, '.', ''), '0'), '.') . '): ' . $gstat . '. Expected ' . pulsepoint_buejee_naira((float) $g->selling_price) . '. Submitted ' . (string) $g->created_at . '.';
                    $gdata[] = ['number' => (int) $g->id, 'card' => $gname, 'value' => (float) $g->amount, 'expected_payout' => (float) $g->selling_price, 'status' => (string) $g->status, 'submitted' => (string) $g->created_at, 'updated' => (string) $g->updated_at];
                }
                pulsepoint_buejee_run_result('success', implode(' ', $glines), ['gift_cards' => $gdata]);
                break;

            case 'ticket_status':
                $tk_table = pulsepoint_buejee_tickets_table();
                $tno = (int) preg_replace('/\D/', '', (string) ($params['ticket'] ?? ''));
                $tsql = "SELECT id, type, trnx_reference, status, created_at, updated_at FROM `{$tk_table}` WHERE user_id = %d";
                if ($tno > 0) {
                    $trows = $wpdb->get_results($wpdb->prepare($tsql . ' AND id = %d LIMIT 1', $uid, $tno));
                } else {
                    $trows = $wpdb->get_results($wpdb->prepare($tsql . ' ORDER BY id DESC LIMIT 3', $uid));
                }
                if (!$trows) {
                    pulsepoint_buejee_run_result('failed', $tno > 0 ? 'No ticket with that number was found for this customer.' : 'This customer has no tickets.');
                }
                $tlines = [];
                $tdata = [];
                foreach ($trows as $tk) {
                    $tstat = ((string) $tk->status === 'open') ? 'open (our team is reviewing it)' : (string) $tk->status;
                    $tlines[] = 'Ticket #' . (int) $tk->id . ' (' . (string) $tk->type . ($tk->trnx_reference ? ', transaction ' . (string) $tk->trnx_reference : '') . ') is ' . $tstat . '. Opened ' . (string) $tk->created_at . ', last update ' . (string) $tk->updated_at . '.';
                    $tdata[] = ['ticket' => (int) $tk->id, 'type' => (string) $tk->type, 'transaction' => (string) $tk->trnx_reference, 'status' => (string) $tk->status, 'opened' => (string) $tk->created_at, 'updated' => (string) $tk->updated_at];
                }
                pulsepoint_buejee_run_result('success', implode(' ', $tlines), ['tickets' => $tdata]);
                break;

            case 'report_issue':
            case 'request_refund':
                $is_refund = $act === 'request_refund';
                $ref       = trim((string) ($params['reference'] ?? ''));
                $details   = trim(wp_strip_all_tags((string) ($params['details'] ?? '')));
                $details   = function_exists('mb_substr') ? mb_substr($details, 0, 1000) : substr($details, 0, 1000);

                if ($ref === '' && $details === '') {
                    pulsepoint_buejee_run_result('failed', 'Please tell me what went wrong, or give the transaction reference.');
                }
                if ($details === '') $details = 'Customer reported a problem (no details given).';

                $t = null;
                if ($ref !== '') {
                    $t = pulsepoint_buejee_find_transaction($bj_trnx_table, $uid, $ref, 'reference, status, type');
                }

                if ($is_refund) {
                    if (!$t) {
                        pulsepoint_buejee_run_result('failed', 'No transaction with that reference was found for this customer.');
                    }
                    if ($t->type !== 'debit') {
                        pulsepoint_buejee_run_result('failed', 'Only purchases can be refunded. That transaction is not a purchase.');
                    }
                    if ($t->status === 'success') {
                        pulsepoint_buejee_run_result('failed', 'That transaction was successful, so it cannot be refunded. If you did not receive value, report an issue instead.');
                    }
                    $details = 'Refund requested for a ' . $t->status . ' transaction.' . ($details !== '' ? ' ' . $details : '');
                } elseif ($ref !== '' && !$t) {
                    pulsepoint_buejee_run_result('failed', 'No transaction with that reference was found for this customer. Please check the reference.');
                }

                $ticket = pulsepoint_buejee_create_ticket(
                    $user,
                    $is_refund ? 'refund' : 'issue',
                    $t ? (string) $t->reference : $ref,
                    $details,
                    $reference
                );

                if ($ticket['limited']) {
                    pulsepoint_buejee_run_result('failed', 'You have logged several complaints in the last hour. Our team is already on it — please wait for their reply.');
                }

                $label = $is_refund ? 'Your refund request' : 'Your complaint';
                $extra = $is_refund
                    ? ' Failed purchases are normally reversed to your wallet automatically; the team will check yours.'
                    : '';
                pulsepoint_buejee_run_result(
                    'success',
                    "{$label} is logged (ticket #{$ticket['id']}). Our team will review it.{$extra}",
                    ['ticket' => (int) $ticket['id']]
                );
                break;

            case 'buy_airtime':
            case 'buy_data':
                if ((string) pulsepoint_buejee_setting('maintenance_mode', '0') === '1') {
                    pulsepoint_buejee_run_result('failed', 'The platform is under maintenance. Please try again later.');
                }

                // Already processed? Report the real status instead of running again.
                $prior = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT status, amount FROM `{$bj_trnx_table}` WHERE reference = %s AND user_id = %d LIMIT 1",
                        $reference, $uid
                    )
                );
                if ($prior) {
                    pulsepoint_buejee_run_result(
                        $prior->status === 'success' ? 'success' : ($prior->status === 'pending' ? 'pending' : 'failed'),
                        "This request was already processed (status: {$prior->status}). Reference: {$reference}",
                        ['reference' => $reference, 'status' => (string) $prior->status]
                    );
                }

                $raw_phone = trim((string) ($params['phone'] ?? ''));
                $phone = preg_replace('/[^0-9+]/', '', $raw_phone);
                if ($phone === '' || strlen(preg_replace('/\D/', '', $phone)) < 10) {
                    $phone = preg_replace('/[^0-9+]/', '', (string) ($user->phone ?? ''));
                }
                $digits = preg_replace('/\D/', '', $phone);
                // Nigerian users commonly omit the leading zero in chat (e.g. 9064873505).
                if (preg_match('/^\d{10}$/', $digits)) {
                    $digits = '0' . $digits;
                    $phone = $digits;
                } elseif (preg_match('/^234\d{10}$/', $digits)) {
                    $digits = '0' . substr($digits, 3);
                    $phone = $digits;
                }
                if (!preg_match('/^0\d{10}$/', $digits)) {
                    pulsepoint_buejee_run_result('failed', 'I could not identify a valid Nigerian phone number. Send the 10-digit number or the 11-digit number, or say “my number” to use your registered number.');
                }
                $network = strtoupper(trim((string) ($params['network'] ?? '')));
                $network = str_replace(['9MOBILE', '9 MOBILE', 'ETISALAT'], '9MOBILE', $network);
                if (!isset($bj_networks[$network])) {
                    $local = $digits;
                    if (strpos($local, '234') === 0) $local = '0' . substr($local, 3);
                    $prefix3 = substr($local, 0, 4);
                    $prefix5 = substr($local, 0, 5);
                    $prefixes = [
                        'MTN' => ['0803','0806','0703','0706','0810','0813','0814','0816','0903','0906','0913','0916','07025','07026','0704'],
                        'GLO' => ['0805','0807','0705','0811','0815','0905','0915'],
                        'AIRTEL' => ['0802','0808','0701','0708','0812','0902','0907','0901','0912'],
                        '9MOBILE' => ['0809','0817','0818','0908','0909'],
                    ];
                    foreach ($prefixes as $net => $list) {
                        if (in_array($prefix3, $list, true) || in_array($prefix5, $list, true)) { $network = $net; break; }
                    }
                }
                if (!isset($bj_networks[$network])) {
                    pulsepoint_buejee_run_result('failed', 'I could not confidently identify the network from that number. Which network should I use: MTN, Glo, Airtel or 9mobile?');
                }

                if ($act === 'buy_airtime') {
                    $amount = (float) ($params['amount'] ?? 0);
                    if (!is_finite($amount) || $amount < 100) {
                        pulsepoint_buejee_run_result('failed', 'The minimum airtime purchase is ₦100.');
                    }
                    $summary = pulsepoint_buejee_naira($amount) . ' ' . $bj_networks[$network] . ' airtime for ' . $phone;
                    $post = [
                        'network'   => $network,
                        'phone'     => $phone,
                        'amount'    => $amount,
                        'type'      => 'VTU',
                        'ported'    => false,
                        'reference' => $reference,
                    ];
                    $kind = 'airtime';
                } else {
                    $plan_id = (int) ($params['plan'] ?? 0);
                    $plan = $plan_id > 0 ? $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT id, plan, details, type, amount FROM `{$bj_data_table}`
                             WHERE id = %d AND network = %s AND status = 'active' LIMIT 1",
                            $plan_id, $network
                        )
                    ) : null;
                    if (!$plan) {
                        pulsepoint_buejee_run_result('failed', 'That data plan is not available for the chosen network. Please pick a plan again.');
                    }
                    $plan_name = trim((string) $plan->details) !== '' ? trim((string) $plan->details) : trim((string) $plan->plan);
                    $summary = $bj_networks[$network] . ' data ' . $plan_name . ' (' . pulsepoint_buejee_naira($plan->amount) . ') for ' . $phone;
                    $post = [
                        'network'   => $network,
                        'plan'      => $plan_id,
                        'phone'     => $phone,
                        'ported'    => false,
                        'reference' => $reference,
                    ];
                    $kind = 'data';
                }

                // Transaction PIN verification intentionally removed for Buejee chat purchases.

                pulsepoint_buejee_execute($user, $kind, $post, $reference, $summary);
                break;

            case 'giftcard_rates':
                $gift_table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
                $rate_query = sanitize_text_field((string) ($params['asset'] ?? ''));
                $rate_sql = "SELECT id, category, sub_category, type, rate, min_amount, max_amount FROM `{$gift_table}` WHERE status = 'active'";
                $rate_words = array_values(array_filter(preg_split('/[^a-z0-9]+/', strtolower($rate_query)), static function ($w) {
                    return $w !== '' && !ctype_digit($w) && !in_array($w, ['gift', 'card', 'cards', 'giftcard', 'giftcards', 'rate', 'rates', 'sell', 'trade', 'my', 'the', 'a', 'i', 'want', 'to', 'of', 'for', 'what', 'is', 'are', 'available', 'skip'], true);
                }));
                $rate_base = $rate_sql . ' ORDER BY category, sub_category';
                foreach ($rate_words as $rw) {
                    $like = '%' . $wpdb->esc_like($rw) . '%';
                    $rate_sql .= $wpdb->prepare(' AND (category LIKE %s OR sub_category LIKE %s)', $like, $like);
                }
                $rate_sql .= ' ORDER BY category, sub_category';
                $rates = $wpdb->get_results($rate_sql);
                if (!$rates && $rate_words) $rates = $wpdb->get_results($rate_base); // no match: show everything rather than dead-end
                if (!$rates) pulsepoint_buejee_run_result('failed', 'I could not find any active gift card rates right now. Please try again later.');
                $lines = ['Here are the current gift card rates on the platform:'];
                $items = [];
                foreach ($rates as $r) {
                    $brand = trim((string) $r->category . (trim((string) $r->sub_category) !== '' ? ' - ' . trim((string) $r->sub_category) : ''));
                    $line = $brand . ': ₦' . rtrim(rtrim(number_format((float) $r->rate, 4, '.', ''), '0'), '.') . ' per 1 of card value; card value ' . rtrim(rtrim(number_format((float) $r->min_amount, 2, '.', ''), '0'), '.') . ' to ' . rtrim(rtrim(number_format((float) $r->max_amount, 2, '.', ''), '0'), '.') . '.';
                    $lines[] = $line;
                    $items[] = ['id' => (int) $r->id, 'brand' => $brand, 'type' => (string) $r->type, 'rate' => (float) $r->rate, 'min_amount' => (float) $r->min_amount, 'max_amount' => (float) $r->max_amount];
                }
                pulsepoint_buejee_run_result('success', implode("\n", $lines), ['rates' => $items]);
                break;

            case 'sell_giftcard':
                if ((string) pulsepoint_buejee_setting('maintenance_mode', '0') === '1') pulsepoint_buejee_run_result('failed', 'The platform is under maintenance. Please try again later.');
                $gift_input = $params['giftcard_id'] ?? $params['card'] ?? $params['brand'] ?? '';
                $gift_amount = pulsepoint_buejee_parse_amount($params['amount'] ?? 0);
                $gift_type = strtolower(trim((string) ($params['type'] ?? 'digital')));
                if (!in_array($gift_type, ['digital', 'physical'], true)) $gift_type = 'digital';
                $gift_code = sanitize_text_field((string) ($params['digital_code'] ?? $params['code'] ?? ''));
                $gift_note = sanitize_textarea_field((string) ($params['note'] ?? 'Submitted through Buejee chat'));
                $gift_candidates = [];
                $gift_why = '';
                $gift = pulsepoint_buejee_find_giftcard($gift_input, $gift_candidates, $gift_amount, $gift_why);
                if (!$gift && $gift_candidates) pulsepoint_buejee_run_result('failed', pulsepoint_buejee_gift_choice_message($gift_candidates, $gift_why, $gift_amount) . ' Nothing was submitted.');
                if (!$gift) pulsepoint_buejee_run_result('failed', 'Please choose an active gift card brand from the current rates list first.');
                if ($gift_type === 'physical') pulsepoint_buejee_run_result('failed', 'Physical gift cards need a clear photo of the card, which cannot be sent through chat yet. Please submit it in the app under Gift Cards, or send the code if it is a digital card. Nothing was submitted.');
                if ($gift_amount <= 0 || ($gift->min_amount > 0 && $gift_amount < (float) $gift->min_amount) || ($gift->max_amount > 0 && $gift_amount > (float) $gift->max_amount)) pulsepoint_buejee_run_result('failed', 'That gift card amount is outside the accepted limits for this brand. Please check the current rates.');
                if ($gift_type === 'digital' && $gift_code === '') pulsepoint_buejee_run_result('failed', 'I still need the digital gift card code. Please send it only if you agree to submit it for review.');
                // The same digital code must never be submitted twice.
                $gift_listings = $wpdb->prefix . 'pulsepoint_giftcard_listings';
                if ($gift_code !== '' && (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM `{$gift_listings}` WHERE digital_code = %s LIMIT 1", $gift_code)) > 0) {
                    pulsepoint_buejee_run_result('failed', 'That gift card code has already been submitted. If you think this is a mistake, please contact support. Nothing new was submitted.');
                }
                // Use the same pulsepoint_sell_giftcard() handler called by /api/giftcard.php.
                // This keeps the app's normal listing, transaction record and admin notification flow.
                pulsepoint_buejee_submit_giftcard_via_existing_handler($uid, (int) $gift->id, $gift_amount, $gift_type, $gift_code, $gift_note);
                break;

            case 'bank_transfer':
                if ((string) pulsepoint_buejee_setting('maintenance_mode', '0') === '1') {
                    pulsepoint_buejee_run_result('failed', 'The platform is under maintenance. Please try again later.');
                }
                // Same checks as the confirmation step: bank from the customer's own words, verified account name.
                $transfer = pulsepoint_buejee_prepare_transfer($params);
                if (!empty($transfer['error'])) {
                    pulsepoint_buejee_run_result('failed', (string) $transfer['error']);
                }
                // One Buejee reference can only ever send one transfer.
                $xfer_guard = 'pp_bj_xfer_' . md5($reference);
                if (get_transient($xfer_guard)) {
                    pulsepoint_buejee_run_result('failed', 'This transfer request was already submitted. Please check your transaction history before trying again.');
                }
                set_transient($xfer_guard, 1, 30 * MINUTE_IN_SECONDS);
                pulsepoint_buejee_execute_bank_transfer($user, [
                    'bank_code' => $transfer['bank_code'],
                    'account_number' => $transfer['account_number'],
                    'amount' => $transfer['amount'],
                    'narration' => 'Buejee bank transfer',
                ], (string) $transfer['bank_name'], (string) $transfer['account_name']);
                break;

            default:
                pulsepoint_buejee_run_result('failed', 'That action is not available.');
        }
        break;

    default:
        pulsepoint_buejee_out(['error' => 'Unknown action'], 400);
}
