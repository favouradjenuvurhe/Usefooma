<?php
/**
 * Pulsepoint — Chat Bot (Buejee) settings
 * Path: /includes/panel/buejee.php   (Usefooma → Configuration → Chat Bot)
 *
 * Connects the platform to a Buejee WhatsApp / Telegram assistant so customers can
 * buy data & airtime, check their balance, get their funding account number and
 * report transaction problems by chatting.
 */

if (!defined('ABSPATH')) exit;

global $wpdb;

require_once PULSEPOINT_DIR . 'includes/buejee-helper.php';

$bj_prefix   = $wpdb->prefix . 'pulsepoint_';
$bj_settings_table = $bj_prefix . 'settings';

// === Default settings (inserted once) ===
$bj_defaults = [
    'buejee_secret'           => '',
    'buejee_api_key'          => '',
    'buejee_notify_funding'   => '1',
    'buejee_notify_purchases' => '1',
];

foreach ($bj_defaults as $bj_key => $bj_value) {
    $bj_exists = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$bj_settings_table}` WHERE opt_key = %s", $bj_key));
    if (!$bj_exists) {
        $wpdb->insert($bj_settings_table, [
            'opt_key'   => $bj_key,
            'opt_value' => maybe_serialize($bj_value),
            'type'      => 'string',
            'autoload'  => 0,
        ]);
    }
}

$bj_notice = '';

// === Save settings ===
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['pulsepoint_buejee_nonce'])
    && wp_verify_nonce($_POST['pulsepoint_buejee_nonce'], 'save_pulsepoint_buejee')
    && current_user_can('manage_options')
) {
    foreach ($bj_defaults as $bj_key => $bj_value) {
        if (!array_key_exists($bj_key, $_POST)) {
            continue;
        }
        $bj_new = sanitize_text_field(wp_unslash($_POST[$bj_key]));
        if (in_array($bj_key, ['buejee_notify_funding', 'buejee_notify_purchases'], true)) {
            $bj_new = $bj_new === '0' ? '0' : '1';
        } else {
            $bj_new = trim($bj_new);
        }
        $wpdb->update(
            $bj_settings_table,
            ['opt_value' => maybe_serialize($bj_new)],
            ['opt_key' => $bj_key]
        );
    }
    $bj_notice = '<div class="updated notice"><p><strong>Chat bot settings saved.</strong></p></div>';
}

// === Mark a ticket resolved ===
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['pulsepoint_bj_ticket_nonce'])
    && wp_verify_nonce($_POST['pulsepoint_bj_ticket_nonce'], 'pulsepoint_bj_ticket')
    && current_user_can('manage_options')
) {
    $bj_ticket_id = (int) ($_POST['ticket_id'] ?? 0);
    if ($bj_ticket_id > 0) {
        $wpdb->update(pulsepoint_buejee_tickets_table(), ['status' => 'resolved'], ['id' => $bj_ticket_id], ['%s'], ['%d']);
        $bj_notice = '<div class="updated notice"><p><strong>Ticket #' . $bj_ticket_id . ' marked as resolved.</strong></p></div>';
    }
}

// === Current values ===
$bj_values = [];
foreach ((array) $wpdb->get_results("SELECT opt_key, opt_value FROM `{$bj_settings_table}` WHERE opt_key LIKE 'buejee\\_%'") as $bj_row) {
    $bj_values[$bj_row->opt_key] = maybe_unserialize($bj_row->opt_value);
}

$bj_platform = $wpdb->get_var("SELECT opt_value FROM `{$bj_settings_table}` WHERE opt_key = 'color_hex' LIMIT 1");
$bj_color    = $bj_platform ? maybe_unserialize($bj_platform) : '#356cf9';
$bj_endpoint = home_url('/api/buejee');

$bj_secret_const = defined('PULSEPOINT_BUEJEE_SECRET') && PULSEPOINT_BUEJEE_SECRET !== '';
$bj_key_const    = defined('PULSEPOINT_BUEJEE_API_KEY') && PULSEPOINT_BUEJEE_API_KEY !== '';

$bj_tickets = $wpdb->get_results(
    "SELECT t.*, u.firstname, u.lastname, u.phone
     FROM `" . pulsepoint_buejee_tickets_table() . "` t
     LEFT JOIN `{$bj_prefix}users` u ON u.id = t.user_id
     ORDER BY (t.status = 'open') DESC, t.id DESC
     LIMIT 20"
);
?>

<div class="wrap">
  <h1 class="wp-heading-inline">Chat Bot (WhatsApp / Telegram)</h1>
  <hr class="wp-header-end">

  <?= $bj_notice ?>

  <style>
    :root { --primary: <?= esc_html($bj_color) ?>; }
    .pulse-section { background:#fff; border-radius:14px; padding:24px; box-shadow:0 3px 10px rgba(0,0,0,0.05); margin-top:24px; }
    .pulse-input { width:100%; border:1px solid #ddd; padding:10px 14px; border-radius:8px; font-size:14px; }
    .pulse-label { font-weight:600; font-size:14px; margin-bottom:6px; display:block; }
    .pulse-btn { background:var(--primary); color:#fff; padding:10px 20px; border:none; border-radius:8px; cursor:pointer; font-weight:600; }
    .pulse-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:16px; }
    .pulse-muted { color:#6b7280; font-size:13px; }
    .pulse-check { display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; font-size:14px; }
    .pulse-badge { display:inline-block; padding:2px 10px; border-radius:999px; font-size:12px; font-weight:600; }
    .pulse-badge.ok { background:#dcfce7; color:#166534; }
    .pulse-badge.off { background:#fee2e2; color:#991b1b; }
  </style>

  <div class="pulse-section">
    <h2 style="margin-top:0">Connect to Buejee</h2>
    <p class="pulse-muted">
      Status:
      <?php if (pulsepoint_buejee_secret() !== ''): ?>
        <span class="pulse-badge ok">Secret saved — endpoint is live</span>
      <?php else: ?>
        <span class="pulse-badge off">Not connected — add the secret below</span>
      <?php endif; ?>
    </p>
    <ol class="pulse-muted" style="margin:0 0 16px 18px;list-style:decimal">
      <li>In Buejee, open <strong>Connect docs</strong>, paste the endpoint URL below as your website endpoint.</li>
      <li>Copy the <strong>Secret</strong> and your <strong>API key</strong> from Buejee into the fields below and save.</li>
      <li>Use Buejee's <em>Test your endpoint</em> command — it should return <code>{"found":false}</code> for an unknown number, or the customer's profile for a registered one.</li>
    </ol>

    <label class="pulse-label">Endpoint URL (paste this in Buejee)</label>
    <input type="text" readonly onclick="this.select()" class="pulse-input" style="background:#f8fafc" value="<?= esc_attr($bj_endpoint) ?>">
  </div>

  <form method="POST">
    <?php wp_nonce_field('save_pulsepoint_buejee', 'pulsepoint_buejee_nonce'); ?>

    <div class="pulse-section">
      <h2 style="margin-top:0">Keys</h2>
      <div class="pulse-grid">
        <div>
          <label class="pulse-label">Buejee Secret <span class="pulse-muted">(verifies requests coming FROM Buejee)</span></label>
          <input type="password" autocomplete="off" name="buejee_secret" class="pulse-input"
                 value="<?= esc_attr($bj_values['buejee_secret'] ?? '') ?>" <?= $bj_secret_const ? 'disabled placeholder="Set in wp-config.php"' : '' ?>>
        </div>
        <div>
          <label class="pulse-label">Buejee API Key <span class="pulse-muted">(lets this site message customers)</span></label>
          <input type="password" autocomplete="off" name="buejee_api_key" class="pulse-input"
                 value="<?= esc_attr($bj_values['buejee_api_key'] ?? '') ?>" <?= $bj_key_const ? 'disabled placeholder="Set in wp-config.php"' : '' ?>>
        </div>
      </div>
      <p class="pulse-muted" style="margin-top:12px">
        Prefer keeping them out of the database? Add <code>define('PULSEPOINT_BUEJEE_SECRET','…');</code> and
        <code>define('PULSEPOINT_BUEJEE_API_KEY','…');</code> to wp-config.php — those take priority over this page.
      </p>
    </div>

    <div class="pulse-section">
      <h2 style="margin-top:0">Alerts</h2>


      <label class="pulse-check">
        <input type="hidden" name="buejee_notify_funding" value="0">
        <input type="checkbox" name="buejee_notify_funding" value="1" <?= (($bj_values['buejee_notify_funding'] ?? '1') !== '0') ? 'checked' : '' ?>>
        <span><strong>Send a WhatsApp alert when a customer's wallet is funded.</strong></span>
      </label>

      <label class="pulse-check">
        <input type="hidden" name="buejee_notify_purchases" value="0">
        <input type="checkbox" name="buejee_notify_purchases" value="1" <?= (($bj_values['buejee_notify_purchases'] ?? '1') !== '0') ? 'checked' : '' ?>>
        <span><strong>Send a WhatsApp alert for airtime/data purchases made in the app or by scheduled jobs.</strong><br>
          <span class="pulse-muted">Purchases made inside the chat are answered in the chat itself. Customers who turned off alerts in their profile never receive these.</span></span>
      </label>
    </div>

    <div class="pulse-section" style="text-align:right">
      <button type="submit" class="pulse-btn">Save Settings</button>
    </div>
  </form>

  <div class="pulse-section">
    <h2 style="margin-top:0">Last bank-name check</h2>
    <p class="pulse-muted"><?php $pp_lv = (string) get_option('pulsepoint_buejee_last_verify', ''); echo $pp_lv !== '' ? esc_html($pp_lv) : 'No failed check recorded yet.'; ?></p>
  </div>

  <div class="pulse-section">
    <h2 style="margin-top:0">Recent requests from Buejee (newest last)</h2>
    <pre class="pulse-muted" style="white-space:pre-wrap"><?php $pp_tr = get_option('pulsepoint_buejee_trace', []); echo is_array($pp_tr) && $pp_tr ? esc_html(implode("\n", $pp_tr)) : 'Nothing received yet.'; ?></pre>
  </div>

  <div class="pulse-section">
    <h2 style="margin-top:0">What customers can do in chat</h2>
    <ul class="pulse-muted" style="list-style:disc;margin-left:18px">
      <li>Buy <strong>airtime</strong> and <strong>data</strong> from their wallet (same limits, KYC rules, wallet + referral split and auto-refund as the app).</li>
      <li>Check <strong>balance</strong>, see their <strong>funding account number(s)</strong> (created on request), look up a <strong>transaction by reference</strong>.</li>
      <li>Report a transaction problem or request a refund review — these appear in the list below and are emailed to you.</li>
      <li>Telegram users must first confirm a 6-digit code sent to their registered email.</li>
    </ul>
  </div>

  <div class="pulse-section">
    <h2 style="margin-top:0">Chat bot tickets</h2>
    <?php if (!$bj_tickets): ?>
      <p class="pulse-muted">No tickets yet.</p>
    <?php else: ?>
      <div style="overflow-x:auto">
        <table class="widefat striped">
          <thead>
            <tr><th>#</th><th>Type</th><th>Customer</th><th>Transaction</th><th>Details</th><th>Status</th><th>Date</th><th></th></tr>
          </thead>
          <tbody>
          <?php foreach ($bj_tickets as $bj_tk): ?>
            <tr>
              <td><?= (int) $bj_tk->id ?></td>
              <td><?= esc_html($bj_tk->type) ?></td>
              <td><?= esc_html(trim($bj_tk->firstname . ' ' . $bj_tk->lastname)) ?><br><small><?= esc_html($bj_tk->phone) ?></small></td>
              <td><?= esc_html($bj_tk->trnx_reference) ?></td>
              <td style="max-width:320px"><?= esc_html($bj_tk->details) ?></td>
              <td><?= esc_html($bj_tk->status) ?></td>
              <td><?= esc_html($bj_tk->created_at) ?></td>
              <td>
                <?php if ($bj_tk->status === 'open'): ?>
                  <form method="POST" style="margin:0">
                    <?php wp_nonce_field('pulsepoint_bj_ticket', 'pulsepoint_bj_ticket_nonce'); ?>
                    <input type="hidden" name="ticket_id" value="<?= (int) $bj_tk->id ?>">
                    <button type="submit" class="button button-small">Mark resolved</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="pulse-muted" style="margin-top:10px">To refund a failed or pending transaction use <strong>Usefooma → Transactions → View Transaction</strong> — it refunds exactly what the customer was charged and locks the transaction so it can't be refunded twice.</p>
    <?php endif; ?>
  </div>
</div>
