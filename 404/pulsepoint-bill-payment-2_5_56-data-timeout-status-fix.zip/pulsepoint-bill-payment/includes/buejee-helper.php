<?php
/**
 * Buejee (WhatsApp / Telegram AI assistant) — shared helpers
 * Path: /includes/buejee-helper.php
 *
 * Used by:
 *   - includes/api/buejee.php        (the endpoint Buejee calls: /api/buejee)
 *   - includes/email-helper.php      (wallet-funding alerts -> WhatsApp/Telegram)
 *   - core/airtime/pulsepoint.php    (purchase alerts for purchases made in the app)
 *   - core/data/pulsepoint.php       (purchase alerts for purchases made in the app)
 *   - includes/panel/other-key.php   (admin settings)
 *
 * Nothing in here moves money. Purchases are always executed by the existing,
 * battle-tested handlers (pulsepoint_airtime_purchase / pulsepoint_data_purchase).
 */

if (!defined('ABSPATH')) exit;

/* =========================================================
   SETTINGS
========================================================= */

if (!function_exists('pulsepoint_buejee_setting')) {
    /**
     * Read one Buejee setting from pulsepoint_settings (cached per request).
     */
    function pulsepoint_buejee_setting(string $key, $default = '') {
        global $wpdb;
        static $cache = null;

        if ($cache === null) {
            $cache = [];
            $table = $wpdb->prefix . 'pulsepoint_settings';
            $rows  = $wpdb->get_results(
                "SELECT opt_key, opt_value FROM `{$table}` WHERE opt_key IN (
                    'buejee_secret','buejee_api_key',
                    'buejee_notify_funding','buejee_notify_purchases',
                    'airtime_max_amount','maintenance_mode','platform_name'
                )"
            );
            if ($rows) {
                foreach ($rows as $r) {
                    $cache[(string) $r->opt_key] = maybe_unserialize($r->opt_value);
                }
            }
        }

        return array_key_exists($key, $cache) && $cache[$key] !== null && $cache[$key] !== ''
            ? $cache[$key]
            : $default;
    }
}

if (!function_exists('pulsepoint_buejee_secret')) {
    /** Shared secret Buejee signs requests with. wp-config constant wins over the panel. */
    function pulsepoint_buejee_secret(): string {
        if (defined('PULSEPOINT_BUEJEE_SECRET') && PULSEPOINT_BUEJEE_SECRET !== '') {
            return (string) PULSEPOINT_BUEJEE_SECRET;
        }
        return trim((string) pulsepoint_buejee_setting('buejee_secret', ''));
    }
}

if (!function_exists('pulsepoint_buejee_api_key')) {
    /** API key used to message customers from this site. wp-config constant wins over the panel. */
    function pulsepoint_buejee_api_key(): string {
        if (defined('PULSEPOINT_BUEJEE_API_KEY') && PULSEPOINT_BUEJEE_API_KEY !== '') {
            return (string) PULSEPOINT_BUEJEE_API_KEY;
        }
        return trim((string) pulsepoint_buejee_setting('buejee_api_key', ''));
    }
}


if (!function_exists('pulsepoint_buejee_naira')) {
    function pulsepoint_buejee_naira($amount): string {
        return '₦' . number_format((float) $amount, 2);
    }
}

/* =========================================================
   CUSTOMER LOOKUP
========================================================= */

if (!function_exists('pulsepoint_buejee_last10')) {
    /** Last 10 digits of a phone number (08031234567 / +2348031234567 / 2348031234567 all match). */
    function pulsepoint_buejee_last10($phone): string {
        $digits = preg_replace('/\D/', '', is_scalar($phone) ? (string) $phone : '');
        return strlen($digits) >= 10 ? substr($digits, -10) : '';
    }
}

if (!function_exists('pulsepoint_buejee_find_user_by_phone')) {
    /**
     * Find ONE active Pulsepoint customer by phone number.
     * Returns null when nothing matches OR when more than one account shares the
     * number (never guess whose wallet it is).
     */
    function pulsepoint_buejee_find_user_by_phone($phone): ?object {
        global $wpdb;

        $last10 = pulsepoint_buejee_last10($phone);
        if ($last10 === '') {
            return null;
        }

        $table = $wpdb->prefix . 'pulsepoint_users';
        $norm  = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone,' ',''),'-',''),'+',''),'(',''),')','')";

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM `{$table}`
                 WHERE {$norm} LIKE %s
                   AND status = 1
                   AND (close_account IS NULL OR close_account = 0)
                 LIMIT 5",
                '%' . $wpdb->esc_like($last10)
            )
        );

        $matches = [];
        foreach ((array) $rows as $row) {
            if (pulsepoint_buejee_last10($row->phone) === $last10) {
                $matches[] = $row;
            }
        }

        return count($matches) === 1 ? $matches[0] : null;
    }
}

/* =========================================================
   EMAIL OTP (Telegram identity check)
========================================================= */

if (!function_exists('pulsepoint_buejee_mask_email')) {
    function pulsepoint_buejee_mask_email(string $email): string {
        $parts = explode('@', $email, 2);
        if (count($parts) !== 2 || $parts[0] === '') {
            return 'your registered email';
        }
        return substr($parts[0], 0, 1) . '***@' . $parts[1];
    }
}

if (!function_exists('pulsepoint_buejee_send_otp')) {
    /**
     * Email a 6-digit code to the account's registered email.
     * @return array{ok:bool,message:string}
     */
    function pulsepoint_buejee_send_otp(object $user): array {
        $uid     = (int) $user->id;
        $key     = 'pp_bj_otp_' . $uid;
        $cnt_key = 'pp_bj_otpcount_' . $uid;
        $state   = get_transient($key);
        $masked  = pulsepoint_buejee_mask_email((string) $user->email);

        if (is_array($state) && !empty($state['sent_at']) && (time() - (int) $state['sent_at']) < 60) {
            return ['ok' => true, 'message' => "A code was just sent to {$masked}. Enter it here, or wait a minute to request another."];
        }

        $count = (int) get_transient($cnt_key);
        if ($count >= 5) {
            return ['ok' => false, 'message' => 'Too many code requests. Please try again in an hour.'];
        }

        if (empty($user->email) || !is_email($user->email)) {
            return ['ok' => false, 'message' => 'This account has no valid email to send a code to. Please contact support.'];
        }

        try {
            $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        } catch (\Throwable $e) {
            $code = str_pad((string) wp_rand(0, 999999), 6, '0', STR_PAD_LEFT);
        }

        $platform = function_exists('pulsepoint_email_settings')
            ? (string) (pulsepoint_email_settings()['platform_name'] ?? 'Pulsepoint')
            : 'Pulsepoint';

        $sent = (bool) @wp_mail(
            $user->email,
            "{$platform} verification code",
            '<p>Hi ' . esc_html((string) $user->firstname) . ',</p>'
            . '<p>Your verification code is <strong style="font-size:20px;letter-spacing:3px">' . esc_html($code) . '</strong>.</p>'
            . '<p>It expires in 10 minutes. If you did not request this, ignore this email — do not share the code with anyone.</p>',
            ['Content-Type: text/html; charset=UTF-8']
        );

        if (!$sent) {
            return ['ok' => false, 'message' => 'We could not send the code right now. Please try again shortly.'];
        }

        set_transient($key, [
            'h'       => hash_hmac('sha256', $code, wp_salt('auth') . '|' . $uid),
            'tries'   => 0,
            'sent_at' => time(),
        ], 10 * MINUTE_IN_SECONDS);
        set_transient($cnt_key, $count + 1, HOUR_IN_SECONDS);

        return ['ok' => true, 'message' => "We sent a 6-digit code to {$masked}. Enter it here to continue."];
    }
}

if (!function_exists('pulsepoint_buejee_verify_otp')) {
    function pulsepoint_buejee_verify_otp(object $user, $code): bool {
        $uid   = (int) $user->id;
        $key   = 'pp_bj_otp_' . $uid;
        $state = get_transient($key);

        if (!is_array($state) || empty($state['h'])) {
            return false;
        }

        if ((int) ($state['tries'] ?? 0) >= 5) {
            delete_transient($key);
            return false;
        }

        $code = preg_replace('/\D/', '', (string) $code);
        $calc = hash_hmac('sha256', $code, wp_salt('auth') . '|' . $uid);

        if ($code !== '' && hash_equals((string) $state['h'], $calc)) {
            delete_transient($key);
            return true;
        }

        $state['tries'] = (int) ($state['tries'] ?? 0) + 1;
        set_transient($key, $state, 10 * MINUTE_IN_SECONDS);
        return false;
    }
}

/* =========================================================
   SUPPORT TICKETS (issue reports + refund requests)
========================================================= */

if (!function_exists('pulsepoint_buejee_tickets_table')) {
    function pulsepoint_buejee_tickets_table(): string {
        global $wpdb;

        $table = $wpdb->prefix . 'pulsepoint_bot_tickets';

        if (get_option('pulsepoint_bot_tickets_v1') !== '1') {
            $charset = $wpdb->get_charset_collate();
            $wpdb->query("CREATE TABLE IF NOT EXISTS `{$table}` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` BIGINT UNSIGNED NOT NULL,
                `type` VARCHAR(20) NOT NULL DEFAULT 'issue',
                `trnx_reference` VARCHAR(255) DEFAULT NULL,
                `details` TEXT,
                `status` VARCHAR(20) NOT NULL DEFAULT 'open',
                `bot_reference` VARCHAR(100) DEFAULT NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `bot_reference_unique` (`bot_reference`),
                KEY `user_idx` (`user_id`),
                KEY `status_idx` (`status`)
            ) {$charset};");
            update_option('pulsepoint_bot_tickets_v1', '1', false);
        }

        return $table;
    }
}

if (!function_exists('pulsepoint_buejee_create_ticket')) {
    /**
     * @return array{id:int,duplicate:bool,limited:bool}
     */
    function pulsepoint_buejee_create_ticket(object $user, string $type, string $trnx_ref, string $details, string $bot_ref): array {
        global $wpdb;

        $table = pulsepoint_buejee_tickets_table();
        $uid   = (int) $user->id;

        // Same Buejee reference => same ticket (a repeat never creates a second one).
        $existing = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM `{$table}` WHERE bot_reference = %s LIMIT 1", $bot_ref)
        );
        if ($existing > 0) {
            return ['id' => $existing, 'duplicate' => true, 'limited' => false];
        }

        // Max 5 tickets / hour / customer.
        $recent = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM `{$table}` WHERE user_id = %d AND created_at >= %s",
                $uid,
                date('Y-m-d H:i:s', strtotime(current_time('mysql')) - HOUR_IN_SECONDS)
            )
        );
        if ($recent >= 5) {
            return ['id' => 0, 'duplicate' => false, 'limited' => true];
        }

        $wpdb->insert($table, [
            'user_id'        => $uid,
            'type'           => $type === 'refund' ? 'refund' : 'issue',
            'trnx_reference' => $trnx_ref !== '' ? $trnx_ref : null,
            'details'        => $details,
            'status'         => 'open',
            'bot_reference'  => $bot_ref,
            'created_at'     => current_time('mysql'),
        ], ['%d', '%s', '%s', '%s', '%s', '%s', '%s']);

        $id = (int) $wpdb->insert_id;

        // Email the platform admin.
        if ($id > 0) {
            $settings = function_exists('pulsepoint_email_settings') ? pulsepoint_email_settings() : [];
            $admin    = $settings['email_number'] ?? get_option('admin_email');
            $label    = $type === 'refund' ? 'Refund request' : 'Transaction issue';
            $rows     = [
                'Ticket'      => '#' . $id,
                'Customer'    => trim($user->firstname . ' ' . $user->lastname) . ' (' . $user->email . ')',
                'Phone'       => (string) $user->phone,
                'Transaction' => $trnx_ref !== '' ? $trnx_ref : '—',
                'Details'     => $details !== '' ? $details : '—',
                'Via'         => 'WhatsApp / Telegram bot (Buejee)',
            ];

            if (!empty($admin) && function_exists('pulsepoint_send_transaction_email')) {
                pulsepoint_send_transaction_email((string) $admin, "New {$label} #{$id}", [
                    'status_label' => 'OPEN',
                    'status_color' => '#f59e0b',
                    'heading'      => $label,
                    'firstname'    => 'Admin',
                    'message'      => "A customer logged a {$label} through the chat bot. Review it under Usefooma → Transactions.",
                    'details'      => $rows,
                ]);
            }
        }

        return ['id' => $id, 'duplicate' => false, 'limited' => false];
    }
}

/* =========================================================
   PROFILE (what the AI knows about the customer)
========================================================= */

if (!function_exists('pulsepoint_buejee_daily_limit')) {
    function pulsepoint_buejee_daily_limit(object $user): float {
        $limit = (float) ($user->account_limit ?? 0);
        return $limit > 0 ? $limit : 5000.0; // same fallback the purchase handlers use
    }
}

if (!function_exists('pulsepoint_buejee_virtual_accounts')) {
    function pulsepoint_buejee_virtual_accounts(int $user_id): array {
        global $wpdb;
        $table = $wpdb->prefix . 'pulsepoint_account';
        $rows  = $wpdb->get_results(
            $wpdb->prepare("SELECT bank, name, number FROM `{$table}` WHERE user_id = %d ORDER BY id ASC", $user_id)
        );
        $out = [];
        foreach ((array) $rows as $r) {
            if (empty($r->number)) continue;
            $out[] = [
                'bank'           => (string) $r->bank,
                'account_number' => (string) $r->number,
                'account_name'   => (string) $r->name,
            ];
        }
        return $out;
    }
}

if (!function_exists('pulsepoint_buejee_profile')) {
    function pulsepoint_buejee_profile(object $user): array {
        global $wpdb;

        $uid       = (int) $user->id;
        $trnx      = $wpdb->prefix . 'pulsepoint_trnx';
        $wallet    = (float) $user->wallet;
        $referral  = (float) ($user->referral_balance ?? 0);
        $promo     = (float) ($user->promo_bonus_pending ?? 0);

        $profile = [
            'Wallet balance'            => pulsepoint_buejee_naira($wallet),
            'Referral balance'          => pulsepoint_buejee_naira($referral) . ' (spendable together with the wallet)',
            'Total available to spend'  => pulsepoint_buejee_naira($wallet + $referral),
        ];

        if ($promo > 0) {
            $profile['Pending promo bonus'] = pulsepoint_buejee_naira($promo) . ' (locked until the promo transaction threshold is reached)';
        }

        $profile['Account type']          = (string) ($user->account_type ?? 'Customer');
        $profile['Daily purchase limit']  = pulsepoint_buejee_naira(pulsepoint_buejee_daily_limit($user));
        $profile['KYC verified']          = !empty($user->statuskyc) ? 'Yes' : 'No';
    
        $accounts = pulsepoint_buejee_virtual_accounts($uid);
        $profile['Funding accounts'] = $accounts ?: 'None yet (the customer can ask for an account number to fund the wallet)';

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT reference, category, amount, status, type, description, date
                 FROM `{$trnx}` WHERE user_id = %d ORDER BY id DESC LIMIT 5",
                $uid
            )
        );
        $recent = [];
        foreach ((array) $rows as $t) {
            $item = (string) $t->description;
            if ($item !== '' && function_exists('pulsepoint_transaction_description')) {
                $item = pulsepoint_transaction_description($item);
            }
            $recent[] = [
                'ref'    => (string) $t->reference,
                'item'   => $item !== '' ? $item : (string) $t->category,
                'type'   => (string) $t->type,
                'amount' => (float) $t->amount,
                'status' => (string) $t->status,
                'date'   => (string) $t->date,
            ];
        }
        $profile['Recent transactions'] = $recent ?: 'No transactions yet';

        $tickets_table = pulsepoint_buejee_tickets_table();
        $open = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, type, trnx_reference, status, created_at, updated_at FROM `{$tickets_table}`
                 WHERE user_id = %d ORDER BY id DESC LIMIT 5",
                $uid
            )
        );
        $complaints = [];
        foreach ((array) $open as $o) {
            $complaints[] = [
                'ticket'      => '#' . (int) $o->id,
                'type'        => (string) $o->type,
                'transaction' => (string) $o->trnx_reference,
                'status'      => (string) $o->status,
                'opened'      => (string) $o->created_at,
                'last_update' => (string) $o->updated_at,
            ];
        }
        $profile['Complaints and tickets (latest 5)'] = $complaints ?: 'None';

        // Gift cards the customer submitted (never includes the card code).
        $gl_table = $wpdb->prefix . 'pulsepoint_giftcard_listings';
        $gs_table = $wpdb->prefix . 'pulsepoint_giftcard_settings';
        $prev_suppress = $wpdb->suppress_errors(true);
        $gc_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT l.id, l.amount, l.selling_price, l.status, l.created_at, s.category, s.sub_category
                 FROM `{$gl_table}` l LEFT JOIN `{$gs_table}` s ON s.id = l.giftcard_id
                 WHERE l.user_id = %d ORDER BY l.id DESC LIMIT 5",
                $uid
            )
        );
        $wpdb->suppress_errors($prev_suppress);
        $gift_cards = [];
        foreach ((array) $gc_rows as $g) {
            $gift_cards[] = [
                'number'          => '#' . (int) $g->id,
                'card'            => trim((string) $g->category . ' ' . (string) $g->sub_category),
                'value'           => (float) $g->amount,
                'expected_payout' => (float) $g->selling_price,
                'status'          => (string) $g->status,
                'submitted'       => (string) $g->created_at,
            ];
        }
        $profile['Recent gift card submissions'] = $gift_cards ?: 'None';

        return $profile;
    }
}

/* =========================================================
   OUTBOUND NOTIFICATIONS  (this site -> customer's WhatsApp / Telegram)
========================================================= */

if (!function_exists('pulsepoint_buejee_notify_phone')) {
    /**
     * POST https://buejee.co/api/v1/connector/notify
     * Non-blocking so payment webhooks / purchases are never slowed down.
     */
    function pulsepoint_buejee_notify_phone(string $phone, string $message): bool {
        $key = pulsepoint_buejee_api_key();
        $last10 = pulsepoint_buejee_last10($phone);

        if ($key === '' || $last10 === '' || trim($message) === '') {
            return false;
        }

        $res = wp_remote_post('https://buejee.co/api/v1/connector/notify', [
            'timeout'  => 5,
            'blocking' => false,
            'headers'  => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body'     => wp_json_encode([
                'channel' => 'whatsapp',
                'phone'   => '0' . $last10,
                'message' => $message,
            ]),
        ]);

        return !is_wp_error($res);
    }
}

if (!function_exists('pulsepoint_buejee_notify_user')) {
    /**
     * @param string $kind 'funding' | 'purchases'
     */
    function pulsepoint_buejee_notify_user(object $user, string $message, string $kind = 'funding'): void {
        try {
            if (pulsepoint_buejee_api_key() === '') return;
            if ((string) pulsepoint_buejee_setting('buejee_notify_' . $kind, '1') === '0') return;
            if (isset($user->alert) && (int) $user->alert === 0) return; // customer turned alerts off
            if (empty($user->phone)) return;

            pulsepoint_buejee_notify_phone((string) $user->phone, $message);
        } catch (\Throwable $e) {
            // Never let a chat alert break a payment callback or a purchase.
        }
    }
}

if (!function_exists('pulsepoint_buejee_on_transaction_notice')) {
    /**
     * Called from pulsepoint_notify_transaction() (all wallet-funding callbacks go through it).
     */
    function pulsepoint_buejee_on_transaction_notice(array $args): void {
        global $wpdb;

        if (pulsepoint_buejee_api_key() === '') return;

        $heading = (string) ($args['heading'] ?? '');
        $status  = strtoupper((string) ($args['status_label'] ?? ''));
        $email   = (string) ($args['user_email'] ?? '');

        if ($email === '' || $status !== 'SUCCESS' || !preg_match('/fund|credit/i', $heading)) {
            return;
        }

        $table = $wpdb->prefix . 'pulsepoint_users';
        $user  = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE email = %s LIMIT 1", $email));
        if (!$user) return;

        $details  = is_array($args['details'] ?? null) ? $args['details'] : [];
        $credited = (string) ($details['Amount Credited'] ?? ($details['Transaction Amount'] ?? ''));
        $ref      = (string) ($details['Reference'] ?? '');

        $msg  = "✅ Wallet credited\n";
        if ($credited !== '') $msg .= "Amount: {$credited}\n";
        if ($ref !== '')      $msg .= "Reference: {$ref}\n";
        $msg .= 'New balance: ' . pulsepoint_buejee_naira((float) $user->wallet);

        pulsepoint_buejee_notify_user($user, $msg, 'funding');
    }
}

if (!function_exists('pulsepoint_buejee_notify_purchase')) {
    /**
     * Alert for purchases made in the app/website (not through the bot — the bot
     * already replies in the chat, so PULSEPOINT_BUEJEE_RUN suppresses a duplicate).
     */
    function pulsepoint_buejee_notify_purchase(object $user, string $status, string $what, string $recipient, float $amount, string $reference): void {
        if (defined('PULSEPOINT_BUEJEE_RUN')) return;
        if (!in_array($status, ['success', 'failed'], true)) return;

        $icon = $status === 'success' ? '✅' : '❌';
        $word = $status === 'success' ? 'successful' : 'failed';

        $msg  = "{$icon} {$what} {$word}\n";
        $msg .= 'Amount: ' . pulsepoint_buejee_naira($amount) . "\n";
        if ($recipient !== '') $msg .= "To: {$recipient}\n";
        $msg .= "Reference: {$reference}";

        pulsepoint_buejee_notify_user($user, $msg, 'purchases');
    }
}
