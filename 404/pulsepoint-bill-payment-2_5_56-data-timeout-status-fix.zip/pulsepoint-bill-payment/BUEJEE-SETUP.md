# Buejee chat-bot integration (WhatsApp / Telegram)

Customers can chat with your Buejee assistant to **buy data & airtime, check balance, get their
funding (virtual) account number, look up a transaction, report a problem / request a refund review**.
Your site also **messages customers** when their wallet is funded.

## Setup (5 minutes)
1. Upload/activate this plugin version.
2. WordPress admin → **Usefooma → Configuration → Chat Bot**.
3. In Buejee → *Connect docs*, paste your endpoint URL: `https://YOUR-SITE.com/api/buejee`
   (the page shows the exact URL).
4. Copy Buejee's **Secret** and **API key** into the Chat Bot page → Save.
   (Optional: put them in wp-config.php instead — they take priority:
   `define('PULSEPOINT_BUEJEE_SECRET','...'); define('PULSEPOINT_BUEJEE_API_KEY','...');`)
5. If the URL 404s once, go to Settings → Permalinks and press Save (flushes rewrite rules).
6. Run Buejee's "Test your endpoint" curl. Expected: `{"found":false}` for an unknown number,
   or the customer's profile (wallet balance, plan, recent transactions, funding accounts…) for a registered one.

## How it works
| Buejee action | What this site does |
|---|---|
| `identify` | Finds the customer by phone (last 10 digits, so 080… / 234… / +234… all match). Returns wallet, referral balance, daily limit, KYC, funding accounts, last 5 transactions, open tickets. Telegram: emails a 6-digit code first (`otp_required`). |
| `verify_otp` | Confirms the emailed code (10 min, 5 tries). |
| `manifest` | Airtime, data, balance, fund wallet, transaction status (read-only), report issue, request refund. |
| `options` | Data plans for the chosen network from your *Data* table (selling price shown). |
| `run` | `buy_airtime` / `buy_data` call the **same handlers as the app** (`pulsepoint_airtime_purchase` / `pulsepoint_data_purchase`): maintenance mode, KYC, daily limit, per-transaction cap, wallet+referral split, locked debit, auto-refund on failure, idempotency, email receipts. Nothing is re-implemented. |

## Security
* Every request must carry a valid `X-Buejee-Signature` (HMAC-SHA256, max 5 min old). `run` and `verify_otp` signatures can be used only once.
* Who is buying always comes from the verified phone (`customer.phone`), never from params.
* One purchase at a time per customer (DB lock) + 10 s spacing. Same Buejee `reference` can never buy twice.
* `request_refund` never moves money. It logs a ticket (listed on the Chat Bot page and emailed to the admin email). Refund from *Transactions → View Transaction* as before.

## Alerts to customers (needs the API key)
* **Wallet funded** — sent from the existing funding callbacks (`pulsepoint_notify_transaction`), so every provider that already emails the customer also sends a chat alert.
* **Airtime/data purchase result** for purchases made in the app or by scheduled jobs. (Purchases made in chat are answered in the chat.)
* Respects each customer's profile "alerts" switch and the two checkboxes on the Chat Bot page.

## Not included (yet)
Cable TV, electricity, betting, exam pins, transfers, order tracking and card actions are not exposed to the bot.

## Files
* new: `includes/api/buejee.php`, `includes/buejee-helper.php`, `includes/panel/buejee.php`
* edited: `loader.php`, `legacy-loader.php` (load helper), `includes/email-helper.php` (funding alert hook),
  `core/airtime/pulsepoint.php`, `core/data/pulsepoint.php` (purchase alert hook), `includes/panel/configuration.php` (tab)
* new table (auto-created on first use): `{prefix}pulsepoint_bot_tickets`

Not executed: no PHP interpreter was available when this was built. Test on staging first
(buy ₦100 airtime to your own number, fund via transfer, ask for balance).


**Transaction PIN:** Buejee chat purchases do not ask for or verify the app transaction PIN. This makes chat purchases more convenient, but anyone with access to the customer's connected chat account may be able to spend from their wallet. Keep WhatsApp/Telegram accounts secure and test on staging before production.


## Human-style chat and bank transfers

The updated manifest describes everyday requests such as “send airtime 200 to my number”, “Data MTN”, “account number”, “what is my balance?” and “send 1k to [account number] [bank]”. Data plan options now include price and available validity information. Airtime can infer a likely network from common Nigerian number prefixes when the customer does not specify one; number portability means this inference is not guaranteed, so the assistant should ask when uncertain.

Outgoing bank transfers use the existing plugin bank-transfer handler, so the site's maintenance, KYC, wallet, daily-limit, fee, transaction-ledger and failed-transfer refund logic still apply. The assistant must show the recipient, bank and amount and get explicit confirmation before submitting. The connector loads bank options from the same bank directory used by the app and attempts an account-name enquiry before sending. Account-name enquiry requires a configured `bank_token` or `strowallet_key`; if it cannot verify the account, the connector refuses to submit the transfer.

The endpoint returns the final result after the provider handler completes. It cannot independently send a second message 30–120 seconds later unless the Buejee chat service supports asynchronous/progress messages. The action descriptions instruct the assistant to say “Please wait while I process…” before the tool call and to report success only after the tool result returns. Test bank transfers in staging/sandbox first; never test with an unfamiliar real account.


## Version 2.5.32 chat improvements
- Bank transfer action accepts a plain-text bank name and common Nigerian bank aliases; recipient account name must still be verified before a transfer is sent.
- Gift card rates are read from active gift card settings. Gift card submissions through chat are stored as pending review; they do not promise instant payout.
- Customer-facing plugin responses avoid emoji.
- Natural-language understanding and the conversational personality are partly controlled by Buejee's AI service; ensure its connector has refreshed this endpoint's manifest after installing this update.


## Version 2.5.33 conversation-flow improvements
- Removed recipient account-name and narration from required chat parameters; recipient name is resolved automatically and narration uses a safe default.
- Updated transfer/airtime/data action instructions to parse complete requests and ask only for missing details.
- Normalises 10-digit Nigerian mobile numbers (for example 9064873505) to 09064873505 for airtime/data purchases.
- Existing transfer KYC, wallet, provider, transaction and limit checks remain enabled. This package has PHP syntax and ZIP integrity checks only; live transfers must be tested in a staging account.
- Refresh/reconnect the Buejee action manifest after installation so the bot uses the updated parameter list.


## v2.5.36 conversational flow update
- Transfer manifest no longer asks Buejee to add a second preliminary confirmation; the actual action still requires YES before execution.
- Gift-card quote and submission accept an active brand/category name (for example, `Steam USD`) as well as the numeric gift-card ID, preventing the quote/submission mismatch. `code` is accepted as an alias for `digital_code`; optional notes can be skipped.
- Gift-card rate lookup is explicitly read-only and should list active rates without asking for amount first.
- The visible `menu` command/list is generated by the Buejee workspace, not by this WordPress endpoint. Disable the built-in menu/help-list feature in Buejee workspace settings if available; the endpoint cannot suppress a menu that Buejee itself generates.


### Version 2.5.40 bank verification update

Buejee account-name enquiry now uses WhoGoPay only via `/api/v1/verify-account-number`, sending the selected bank code and 10-digit account number. It reads the credential from the server-side `bank_token` setting (or `whogopay_token` if separately configured), and blocks the transfer unless WhoGoPay returns a plausible account-holder name. There is no Strowallet fallback. Validate this against your live WhoGoPay account and bank-code directory in staging before enabling real transfers.


### Version 2.5.39 verification and gift-card submission update (superseded for verification by 2.5.40)
- Bank directory parsing now accepts the `data`, `banks`, `results`, or top-level list formats while preserving bank codes as strings. It continues to use the same `https://pulsepoint-plugin.vercel.app/api/banks.json` directory used by the existing transfer handler.
- In 2.5.39, verification attempted Strowallet before WhoGoPay. Version 2.5.40 supersedes that behavior and uses WhoGoPay only.
- Gift-card chat submissions now call the existing `pulsepoint_sell_giftcard()` handler used by `/api/giftcard.php`, instead of maintaining a separate direct-database submission path. This preserves the normal listing/transaction creation and admin-notification behavior.
- Syntax/ZIP checks are not live provider tests. Verify bank-code resolution and gift-card submission on staging before production use.


## v2.5.41 — WhoGoPay verification credential compatibility

Buejee account-name verification now uses the same WhoGoPay verification endpoint and request fields as the existing withdrawal page, and falls back to the currently configured withdrawal-page credential if no server-side `bank_token` or `whogopay_token` is set. Rotate this credential because it is currently exposed in frontend JavaScript, then configure the replacement server-side.


### v2.5.42 WhoGoPay verification alignment
Buejee account-name lookup now uses the same WhoGoPay verification credential as the existing withdrawal UI rather than `bank_token`, which may be configured for the transfer provider and not account verification. It uses the same endpoint, JSON request fields and response message convention. This should be validated with a live account lookup before real transfers are enabled. The credential remains hardcoded for compatibility and should be rotated and moved to a server-side setting.


## v2.5.43 bank-name resolution fix

When a customer says a bank name (for example, “PalmPay”), Buejee now resolves that name against the canonical banks.json directory before considering any model-supplied bank_code. This prevents a stale or mismatched action parameter from overriding the customer's explicit bank name. The WhoGoPay verification request still uses the hardcoded credential and request contract mirrored from the existing withdrawal component. This requires staging/live API verification before claiming end-to-end operation.
\n\n## v2.5.44 transfer verification diagnostics\nBuejee bank-transfer action instructions now explicitly preserve the bank name stated by the customer (PalmPay must not become OPay). Server-side WhoGoPay failures are written to the PHP error log without logging the API token or account number. If verification still fails, inspect the log entries beginning `[Buejee bank verification]` and refresh/resync the Buejee workspace action manifest so its cached bank-transfer description is current.\n

## v2.5.45 bank directory and bank-name resolution hardening
- Bank directory cache lifetime reduced to 30 minutes and can be refreshed on demand.
- If an explicit bank name does not match the cached directory, Buejee fetches a fresh copy once before failing.
- Explicit customer bank names are resolved with exact canonical-name/alias matches first. The action's supplied bank code is never used to override an explicit bank name.
- Verification still uses the same legacy WhoGoPay verification endpoint and request shape as the existing withdrawal UI; end-to-end provider success must be confirmed on the live site.


## v2.5.46 transfer / gift-card hardening
- **Bank transfer now has a real confirmation step.** Buejee asks this site (`quote`) to verify the recipient first. The customer sees "Send ₦X to NAME (account) at BANK, fee, total. Reply YES" and the money only moves after YES. If the wallet cannot cover amount + fee + stamp duty, or KYC is required, the customer is told before confirming. (Manifest flags `quote` and `confirm` are now true for `bank_transfer`; refresh/resync the Buejee action manifest after installing.)
- Account-name check: error text from WhoGoPay can no longer be mistaken for an account holder name; explicit `success:false` / `status:false` always fails; one automatic retry on network error, 429 or 5xx; a verified name is reused for 10 minutes so confirm-then-run does not call WhoGoPay twice.
- Bank directory: if a forced refresh fails, the last good copy is used instead of an empty list.
- One Buejee reference can send only one transfer.
- **Gift cards:** brand matching no longer guesses. "Steam" with several Steam cards now asks which one; matching uses every word the customer typed. Physical cards are declined in chat (they need a photo; use the app). The same digital code cannot be submitted twice.
- Temporary sessions created for transfers and gift-card submissions are now destroyed after use.
- Optional: define `PULSEPOINT_WHOGOPAY_VERIFY_KEY` in wp-config.php to replace the key that is currently hard-coded (and visible in `withdraw.html`). Rotate that key with WhoGoPay.
- Not tested against live providers. No PHP interpreter was available when this was built: install on staging first.
