<?php
/**
 * Secure Register Function for Pulsepoint Plugin
 * Path: /wp-content/plugins/pulsepoint-bill-payment/core/register.php
 * Author: Amaaavl
 *
 * SECURITY / RELIABILITY PATCH (matches login.php):
 * 1. Registration abuse protection: unexpected server/database failures are
 *    rate-limited per IP using WP transients. Normal validation errors and
 *    duplicate-account checks never lock a legitimate customer out.
 * 2. Session fixation protection: session_regenerate_id(true) is called
 *    once a session is established for a newly registered user.
 * 3. Session cookie hardened: HttpOnly + Secure (when on HTTPS) + SameSite=Lax,
 *    set via the array-options form of setcookie() (PHP 7.3+/8.3 safe).
 *    The old 6-argument setcookie() call did not set HttpOnly/SameSite at all.
 * 4. Verification (OTP) emails now render from a shared HTML template
 *    (/templates/register.html) instead of an inline HTML string, with all
 *    dynamic values escaped before injection.
 * 5. FIXED BUG: the $wpdb->insert() format array was missing an entry
 *    (16 columns were being inserted with only 15 format specifiers, and
 *    status_email was typed as %s instead of %d). This silently
 *    misaligned formats with columns.
 * 6. FIXED BUG: pulsepoint_google_signup() never checked close_account /
 *    status (0=suspended, 2=inactive) on returning users, never set
 *    status_email/account_limit/updated_at on new users, never rotated
 *    the session id, and never set the session cookie (inconsistent with
 *    the normal register/login flow). All fixed to match login.php.
 * 7. Inputs now go through wp_unslash() before sanitizing (WP adds slashes
 *    to superglobals), and the Google id_token is now rawurlencode()'d.
 * 8. Defensive input limits (max password length) to avoid abuse of the
 *    bcrypt hashing cost with oversized input.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file access
}

const PULSEPOINT_REGISTER_MAX_ATTEMPTS  = 20;
const PULSEPOINT_REGISTER_LOCKOUT_SECS  = 600;   // 10 minutes
const PULSEPOINT_REGISTER_RL_VERSION    = 'v3';
const PULSEPOINT_REGISTER_MAX_PW_LENGTH = 1024;  // defensive cap, bcrypt itself caps at 72 bytes

// ==========================
// REGULAR USER REGISTRATION
// ==========================
add_action('wp_ajax_nopriv_pulsepoint_user_register', 'pulsepoint_user_register');
add_action('wp_ajax_pulsepoint_user_register', 'pulsepoint_user_register');

/**
 * Build the transient key used for registration rate limiting.
 */
function pulsepoint_register_rl_key(string $ip): string {
    return 'pp_register_rl_' . PULSEPOINT_REGISTER_RL_VERSION . '_' . md5($ip);
}

function pulsepoint_register_get_attempts(string $ip): int {
    $val = get_transient(pulsepoint_register_rl_key($ip));
    return $val ? (int) $val : 0;
}

function pulsepoint_register_record_failure(string $ip): void {
    $key = pulsepoint_register_rl_key($ip);
    $attempts = pulsepoint_register_get_attempts($ip) + 1;
    set_transient($key, $attempts, PULSEPOINT_REGISTER_LOCKOUT_SECS);
}

function pulsepoint_register_clear_attempts(string $ip): void {
    delete_transient(pulsepoint_register_rl_key($ip));
}

/**
 * Remove counters created by older plugin versions. This prevents an old
 * failed test run from locking a legitimate signup after an update.
 */
function pulsepoint_register_clear_legacy_attempts(string $ip): void {
    delete_transient('pp_register_rl_' . md5($ip));
    delete_transient('pp_register_rl_v2_' . md5($ip));
}

/**
 * Load and render the register/verification email template.
 * Template path: /templates/register.html relative to the plugin root.
 * Supported placeholders: {{platform_name}} {{heading}} {{firstname}}
 * {{message}} {{code}} {{year}} {{support_email}} {{color_hex}}
 *
 * Kept as a separate function (distinct name) from login.php's
 * pulsepoint_render_email_template() so this file has no load-order
 * dependency on login.php and can't collide with it.
 */
function pulsepoint_render_register_email_template(array $vars): string {
    $template_path = dirname(__DIR__) . '/templates/register.html';

    if (!file_exists($template_path)) {
        // Fallback so email sending never hard-fails if the template is missing.
        return '<p>' . nl2br(htmlspecialchars($vars['message'] ?? '', ENT_QUOTES, 'UTF-8')) . '</p>';
    }

    $html = file_get_contents($template_path);

    $defaults = [
        'platform_name' => 'Pulsepoint',
        'heading'       => '',
        'firstname'     => '',
        'message'       => '',
        'code'          => '',
        'year'          => date('Y'),
        'support_email' => get_option('admin_email'),
        'color_hex'     => '#6C63FF',
    ];

    $vars = array_merge($defaults, $vars);

    foreach ($vars as $key => $value) {
        // 'message' is allowed to carry pre-built safe HTML (line breaks etc);
        // everything else is escaped as plain text.
        $safe = $key === 'message'
            ? $value
            : htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');

        $html = str_replace('{{' . $key . '}}', $safe, $html);
    }

    return $html;
}


/**
 * Repair the minimum database schema required by registration.
 *
 * This is intentionally defensive because plugin ZIP updates do not rerun
 * register_activation_hook() on an existing installation. Registration must
 * not depend on an admin page having been opened previously.
 */
if (!function_exists('pulsepoint_register_prepare_schema')) {
    function pulsepoint_register_prepare_schema(): bool {
        global $wpdb;

        $base_prefix = $wpdb->prefix . 'pulsepoint_';
        $users_table = $base_prefix . 'users';

        // The promo schema repair owns these columns/tables. Run it before
        // duplicate checks and before the INSERT so an old installation cannot
        // fail with "unknown column promo_bonus_pending".
        if (function_exists('pulsepoint_promo_schema')) {
            pulsepoint_promo_schema();
        }

        // Verify the users table actually exists.
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s",
            $users_table
        ));

        if ((int) $table_exists !== 1) {
            error_log('[Pulsepoint Registration] Users table is missing: ' . $users_table);
            return false;
        }

        // Self-healing fallback for installations where promo-bonus.php was
        // not loaded or its upgrade hook did not run.
        $columns = [
            'promo_bonus_pending' => "DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `wallet`",
            'promo_bonus_unlocked' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER `promo_bonus_pending`",
        ];

        foreach ($columns as $column => $definition) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = %s
                   AND COLUMN_NAME = %s",
                $users_table,
                $column
            ));

            if ((int) $exists === 0) {
                $result = $wpdb->query(
                    "ALTER TABLE `{$users_table}` ADD COLUMN `{$column}` {$definition}"
                );

                if ($result === false) {
                    error_log(sprintf(
                        '[Pulsepoint Registration] Failed to add %s.%s: %s',
                        $users_table,
                        $column,
                        $wpdb->last_error
                    ));
                    return false;
                }
            }
        }

        return true;
    }
}

function pulsepoint_user_register() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    // Repair/update the registration schema before ANY registration query.
    // This protects existing installations upgraded by ZIP from schema drift.
    if (!pulsepoint_register_prepare_schema()) {
        wp_send_json(['success' => false, 'message' => 'Registration service is temporarily unavailable. Please try again later.']);
    }

    $user_ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'unknown');

    // Do not inherit stale lockouts from older plugin builds.
    pulsepoint_register_clear_legacy_attempts($user_ip);

    // === Spam/brute-force check (before touching the DB) ===
    if (pulsepoint_register_get_attempts($user_ip) >= PULSEPOINT_REGISTER_MAX_ATTEMPTS) {
        wp_send_json([
            'success' => false,
            'message' => 'Too many registration attempts. Please try again in a few minutes.'
        ]);
    }

    // Sanitize inputs
    $firstname = isset($_POST['firstname']) ? sanitize_text_field(wp_unslash($_POST['firstname'])) : '';
    $lastname  = isset($_POST['lastname'])  ? sanitize_text_field(wp_unslash($_POST['lastname']))  : '';
    $phone     = isset($_POST['phone'])     ? sanitize_text_field(wp_unslash($_POST['phone']))     : '';
    $password  = isset($_POST['password'])  ? (string) wp_unslash($_POST['password'])              : '';
    $passcode  = isset($_POST['passcode'])  ? sanitize_text_field(wp_unslash($_POST['passcode']))  : '';
    $email     = isset($_POST['email'])     ? sanitize_email(wp_unslash($_POST['email']))          : '';
    $refer     = isset($_POST['refer'])     ? sanitize_text_field(wp_unslash($_POST['refer']))     : '';

    // Required fields check
    if (empty($firstname) || empty($lastname) || empty($phone) || empty($password) || empty($passcode)) {
        wp_send_json(['success' => false, 'message' => 'Firstname, lastname, phone, password and passcode are required.']);
    }

    if (strlen($password) > PULSEPOINT_REGISTER_MAX_PW_LENGTH) {
        wp_send_json(['success' => false, 'message' => 'Invalid password.']);
    }

    // Normalize phone
    $phone = preg_replace('/\s+/', '', $phone);
    $phone = preg_replace('/[^0-9+]/', '', $phone);

    // Validate passcode
    if (!preg_match('/^\d{4}$/', $passcode)) {
        wp_send_json(['success' => false, 'message' => 'Passcode must be exactly 4 digits.']);
    }

    $weak_passcodes = ['1234','1111','0000','1212','9999','4321','0001','2580'];
    if (in_array($passcode, $weak_passcodes, true)) {
        wp_send_json(['success' => false, 'message' => 'Passcode is too weak.']);
    }

    // Email fallback
    if (empty($email)) {
        $email = preg_replace('/^\+/', '', $phone) . '@pulsepoint.ng';
        $email = sanitize_email($email);
    }

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table = $base_prefix . 'users';

    // Check duplicates
    $existing = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM `{$table}` WHERE `phone` = %s OR `email` = %s LIMIT 1", $phone, $email)
    );

    if ($existing) {
        if ($existing->phone === $phone) wp_send_json(['success' => false, 'message' => 'Phone number already registered.']);
        if ($existing->email === $email) wp_send_json(['success' => false, 'message' => 'Email already registered.']);
        wp_send_json(['success' => false, 'message' => 'Account already exists.']);
    }

    // The existing referral field accepts either a referral code/identifier
    // or a signup promo code. Promo codes take precedence when the same text
    // happens to match an existing user identifier.
    $referby_id = null;
    $promo_code_row = null;

    if (!empty($refer)) {
        $promo_table = $base_prefix . 'promo_codes';
        $promo_code_row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, code, bonus_amount, threshold_amount
                 FROM `{$promo_table}`
                 WHERE code = %s AND status = 'active'
                 LIMIT 1",
                strtoupper($refer)
            )
        );

        if (!$promo_code_row) {
            $referby = $wpdb->get_row(
                $wpdb->prepare("SELECT id FROM `{$table}` WHERE phone = %s OR uniqueid = %s LIMIT 1", $refer, $refer)
            );
            if ($referby) {
                $referby_id = $referby->id;
            }
        }
    }

    // Generate token
    $prefix = 'PS-NG';
    $random_len = 30 - strlen($prefix);
    $pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $rand = '';
    for ($i = 0; $i < $random_len; $i++) {
        $rand .= $pool[random_int(0, strlen($pool) - 1)];
    }
    $token = $prefix . $rand;

    // Hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Load settings
    $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
    }

    $account_limit = isset($settings['account_limit']) ? floatval($settings['account_limit']) : 5000.00;
    $auth_email    = isset($settings['auth_email']) ? intval($settings['auth_email']) : 0;
    $platform_name = isset($settings['platform_name']) ? $settings['platform_name'] : 'Pulsepoint';
    $color_hex     = isset($settings['color_hex']) ? $settings['color_hex'] : '#6C63FF';

    // ===== EMAIL VERIFICATION ADDITION =====
    $user_status   = 1;   // default active
    $email_status  = 1;   // default email enabled
    $security_code = null;

    if ($auth_email === 1) {
        $user_status   = 1;   // must verify first
        $email_status  = 0;   // no login email until verified
        $security_code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }
    // ===== END ADDITION =====

    // Insert user
    $inserted = $wpdb->insert(
        $table,
        [
            'firstname'        => $firstname,
            'lastname'         => $lastname,
            'phone'            => $phone,
            'email'            => $email,
            'wallet'              => 0.00,
            'promo_bonus_pending' => $promo_code_row ? max(0, (float)$promo_code_row->bonus_amount) : 0.00,
            'promo_bonus_unlocked'=> 0,
            'referral_balance'     => 0.00,
            'referby'          => $referby_id,
            'token'            => $token,
            'passcode'         => $passcode,
            'password'         => $password_hash,
            // The users table requires twofa_secret to be non-NULL. A new
            // account does not have 2FA configured yet, so store an empty
            // value and let the existing 2FA setup flow populate it later.
            'twofa_secret'     => '',
            'security_code'    => $security_code,
            'account_limit'    => $account_limit,
            'status'           => $user_status,
            'status_email'     => $email_status,
            'created_at'       => current_time('mysql', 1),
            'updated_at'       => current_time('mysql', 1),
        ],
        [
            '%s','%s','%s','%s','%f','%f','%d','%f','%d','%s','%s','%s','%s','%s','%f','%d','%d','%s','%s'
        ]
    );

    if ($inserted === false) {
        $db_error = (string) $wpdb->last_error;
        error_log('[Pulsepoint Registration] User insert failed: ' . $db_error);

        // Never expose SQL details to the customer, but keep the stable generic
        // response expected by the frontend.
        pulsepoint_register_record_failure($user_ip);
        wp_send_json(['success' => false, 'message' => 'Registration failed. Please try again later.']);
    }

    // Successful registration — clear this IP's failure counter
    pulsepoint_register_clear_attempts($user_ip);

    $new_user_id = $wpdb->insert_id;

    // Record promo usage once the new user exists. The bonus itself is already
    // isolated in promo_bonus_pending and cannot be spent as normal wallet funds.
    if ($promo_code_row && (float)$promo_code_row->bonus_amount > 0) {
        $wpdb->insert(
            $base_prefix . 'promo_code_usage',
            [
                'promo_code_id' => (int)$promo_code_row->id,
                'user_id'       => (int)$new_user_id,
                'bonus_amount'  => (float)$promo_code_row->bonus_amount,
            ],
            ['%d','%d','%f']
        );
    }

    // ===== OPTIONAL EMAIL OTP SEND =====
    // API clients cannot depend on a browser PHP session, so create a short-
    // lived verification challenge when email verification is enabled.
    $verification_challenge = '';
    if ($auth_email === 1) {
        $verification_challenge = bin2hex(random_bytes(32));
        set_transient(
            'pulsepoint_email_verify_' . hash('sha256', $verification_challenge),
            (int) $new_user_id,
            15 * MINUTE_IN_SECONDS
        );
    }

    // Email is a notification/verification enhancement, not a dependency for
    // completing registration. If WordPress has no working SMTP/mail transport
    // (or wp_mail() fails), activate the account and continue normally.
    if ($auth_email === 1) {
        $mail_sent = false;

        if (function_exists('wp_mail') && is_email($email)) {
            $mail_sent = (bool) @wp_mail(
                $email,
                "Verify your {$platform_name} account",
                pulsepoint_render_register_email_template([
                    'platform_name' => $platform_name,
                    'color_hex'     => $color_hex,
                    'heading'       => 'Verify Your Account',
                    'firstname'     => $firstname,
                    'code'          => $security_code,
                    'message'       => 'Enter this code to activate your account. This code will expire soon, so please verify shortly.',
                ]),
                ['Content-Type: text/html; charset=UTF-8']
            );
        }

        if ($mail_sent) {
            wp_send_json([
                'success'               => true,
                'message'              => 'Verification code sent to your email.',
                'redirect'             => site_url('/auth/verification'),
                'verification_token'  => $verification_challenge
            ]);
        }

        // No SMTP/mail transport: do not make registration fail or leave the
        // customer permanently stuck in an email-verification state.
        $wpdb->update(
            $table,
            [
                'status_email'  => 1,
                'security_code' => null,
                'updated_at'    => current_time('mysql', 1),
            ],
            ['id' => $new_user_id],
            ['%d', '%s', '%s'],
            ['%d']
        );
    }
    // ===== END OPTIONAL EMAIL VERIFICATION FLOW =====

    $user = $wpdb->get_row(
        $wpdb->prepare("SELECT id, firstname, lastname, email, phone, wallet, token, passcode, account_limit FROM `{$table}` WHERE id = %d LIMIT 1", $new_user_id)
    );

    if (!$user) {
        wp_send_json(['success' => false, 'message' => 'Registration succeeded but could not retrieve user.']);
    }

    // === Session handling (fixation-safe) ===
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    // New authenticated identity → rotate the session ID.
    session_regenerate_id(true);

    $_SESSION['pulsepoint_user'] = [
        'id'            => $user->id,
        'firstname'     => $user->firstname,
        'lastname'      => $user->lastname,
        'email'         => $user->email,
        'phone'         => $user->phone,
        'wallet'        => $user->wallet,
        'token'         => $user->token,
        'passcode'      => $user->passcode,
        'account_limit' => $user->account_limit,
    ];

    setcookie('pulsepoint_user_session', session_id(), [
        'expires'  => time() + (defined('PULSEPOINT_SESSION_LIFETIME') ? PULSEPOINT_SESSION_LIFETIME : (90 * DAY_IN_SECONDS)),
        'path'     => '/',
        'domain'   => $_SERVER['SERVER_NAME'] ?? '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    wp_send_json([
        'success' => true,
        'message' => 'Registration successful.',
        'new_user' => true,
        'redirect' => site_url('/dashboard'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}

// ==========================================
// GOOGLE SIGN-UP / AUTO-LOGIN
// ==========================================
add_action('wp_ajax_nopriv_pulsepoint_google_signup', 'pulsepoint_google_signup');
add_action('wp_ajax_pulsepoint_google_signup', 'pulsepoint_google_signup');

function pulsepoint_google_signup() {
    global $wpdb;

    header('Content-Type: application/json; charset=utf-8');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json(['success' => false, 'message' => 'Invalid request method.']);
    }

    $id_token = isset($_POST['id_token'])
        ? sanitize_text_field(wp_unslash($_POST['id_token']))
        : (isset($_POST['credential']) ? sanitize_text_field(wp_unslash($_POST['credential'])) : '');

    if (empty($id_token)) {
        wp_send_json(['success' => false, 'message' => 'Google ID token is required.']);
    }

    $google_url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($id_token);
    $response   = wp_remote_get($google_url);

    if (is_wp_error($response)) {
        wp_send_json(['success' => false, 'message' => 'Unable to verify Google token.']);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);

    if (!isset($data['email_verified']) || $data['email_verified'] != 'true') {
        wp_send_json(['success' => false, 'message' => 'Google email not verified.']);
    }

    // Google's own audience/client-id check should be added here if not already
    // enforced elsewhere (compare $data['aud'] against your OAuth client ID) to
    // stop tokens issued for a *different* app from being accepted.

    $email     = sanitize_email($data['email']);
    $firstname = sanitize_text_field($data['given_name'] ?? '');
    $lastname  = sanitize_text_field($data['family_name'] ?? '');

    if (!is_email($email)) {
        wp_send_json(['success' => false, 'message' => 'Invalid Google account email.']);
    }

    $base_prefix = $wpdb->prefix . 'pulsepoint_';
    $table = $base_prefix . 'users';

    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `email` = %s LIMIT 1", $email));

    if (!$user) {
        // Load settings so new Google sign-ups get the same defaults as normal registrations
        $settings_rows = $wpdb->get_results("SELECT opt_key, opt_value FROM {$base_prefix}settings");
        $settings = [];
        foreach ($settings_rows as $row) {
            $settings[$row->opt_key] = maybe_unserialize($row->opt_value);
        }
        $account_limit = isset($settings['account_limit']) ? floatval($settings['account_limit']) : 5000.00;

        $prefix = 'PS-NG';
        $random_len = 30 - strlen($prefix);
        $pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $rand = '';
        for ($i = 0; $i < $random_len; $i++) {
            $rand .= $pool[random_int(0, strlen($pool) - 1)];
        }
        $token    = $prefix . $rand;
        $passcode = random_int(1000, 9999);

        $wpdb->insert(
            $table,
            [
                'firstname'    => $firstname,
                'lastname'     => $lastname,
                'email'        => $email,
                'passcode'     => $passcode,
                'token'        => $token,
                'password'     => password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT),
                'status'       => 1,
                'status_email' => 1,
                'wallet'       => 0.00,
                'account_limit'=> $account_limit,
                'created_at'   => current_time('mysql', 1),
                'updated_at'   => current_time('mysql', 1),
            ],
            ['%s','%s','%s','%s','%s','%s','%d','%d','%f','%f','%s','%s']
        );

        $user_id = $wpdb->insert_id;
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE `id` = %d LIMIT 1", $user_id));
    }

    if ((int) $user->close_account === 1) {
        wp_send_json(['success' => false, 'message' => 'Your account is pending deletion and cannot login.']);
    }

    if ((int) $user->status === 0) {
        wp_send_json(['success' => false, 'message' => 'Your account has been suspended.']);
    }

    if ((int) $user->status === 2) {
        wp_send_json(['success' => false, 'message' => 'Inactive account.']);
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    session_regenerate_id(true);

    $_SESSION['pulsepoint_user'] = [
        'id'        => $user->id,
        'firstname' => $user->firstname,
        'lastname'  => $user->lastname,
        'email'     => $user->email,
        'phone'     => $user->phone,
        'wallet'    => $user->wallet,
        'token'     => $user->token,
        'passcode'  => $user->passcode
    ];

    setcookie('pulsepoint_user_session', session_id(), [
        'expires'  => time() + (defined('PULSEPOINT_SESSION_LIFETIME') ? PULSEPOINT_SESSION_LIFETIME : (90 * DAY_IN_SECONDS)),
        'path'     => '/',
        'domain'   => $_SERVER['SERVER_NAME'] ?? '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    wp_send_json([
        'success' => true,
        'message' => 'Login successful via Google.',
        'redirect' => site_url('/dashboard'),
        'user' => $_SESSION['pulsepoint_user']
    ]);
}
