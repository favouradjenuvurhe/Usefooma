<?php
/**
 * Pulsepoint Msorg Data API Integration
 *
 * Status rules (important):
 *  - The request never reached the provider (could not resolve/connect/SSL) => failed (safe to refund).
 *  - The provider says fail / a 4xx error                                   => failed.
 *  - Timeout, empty reply, 5xx, non-JSON or an unrecognised answer           => PENDING.
 *    The provider may still have delivered the data. A pending purchase is kept charged and is
 *    never refunded automatically; an admin can mark it Success or Failed after checking.
 */

if (!defined('ABSPATH')) exit;

function send_data($network, $plan, $phone, $amount, $token, $value, $reference, $transaction_id)
{
    // Map network names
    $network_map = [
        'MTN'     => 1,
        'AIRTEL'  => 4,
        'GLO'     => 2,
        '9MOBILE' => 3
    ];

    $network_id = $network_map[strtoupper($network)] ?? 0;

    if ($network_id === 0) {
        return [
            'success' => false,
            'status'  => 'failed',
            'message' => "Invalid network: {$network}",
            'details' => []
        ];
    }

    // Decode endpoint
    if (is_string($value)) {
        $decoded_val = json_decode($value, true);
        if (json_last_error() === JSON_ERROR_NONE && isset($decoded_val['endpoint'])) {
            $value = $decoded_val['endpoint'];
        }
    }

    $api_url = trim($value ?: 'https://www.maskawasub.com/api/data/');
    $request_id = $reference ?: 'MSORG_DATA_' . mt_rand(1000000, 9999999);

    // Payload
    $payload = [
        "network"        => $network_id,
        "mobile_number"  => $phone,
        "plan"           => intval($plan),
        "Ported_number"  => true
    ];

    // cURL
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 20,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_HTTPHEADER => [
            "Authorization: Token {$token}",
            "Content-Type: application/json"
        ]
    ]);

    $response   = curl_exec($ch);
    $curl_errno = (int) curl_errno($ch);
    $curl_error = curl_error($ch);
    $http_code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $base_details = [
        'transaction_id' => $request_id,
        'network'        => $network,
        'phone'          => $phone,
        'plan'           => $plan,
        'amount'         => $amount,
        'provider'       => 'Msorg',
        'http_code'      => $http_code,
        'payload'        => $payload,
    ];

    // ❌/⏳ CURL ERROR
    if ($curl_errno !== 0) {
        // These mean the request never left this server, so the provider cannot have processed it.
        // 3 bad URL, 5/6 cannot resolve proxy/host, 7 cannot connect, 35 SSL connect,
        // 51/58/59/60/83 certificate problems, 77 CA file missing.
        $never_sent = [3, 5, 6, 7, 35, 51, 58, 59, 60, 77, 83];
        if (in_array($curl_errno, $never_sent, true)) {
            return [
                'success' => false,
                'status'  => 'failed',
                'message' => "Could not reach the provider: {$curl_error}",
                'details' => $base_details + ['curl_error' => $curl_error, 'curl_errno' => $curl_errno]
            ];
        }
        // Timeout / reset / empty reply AFTER sending: the provider may have delivered it.
        return [
            'success' => true,
            'status'  => 'pending',
            'message' => 'Your purchase is being confirmed with the provider. Please do not retry; you will be updated shortly.',
            'reference' => $request_id,
            'details' => $base_details + ['curl_error' => $curl_error, 'curl_errno' => $curl_errno, 'note' => 'No answer from provider; held as pending, not refunded automatically.']
        ];
    }

    $decoded = json_decode((string) $response, true);

    // Pull the most useful human message out of whatever the provider sent.
    $pick_message = static function ($d) {
        if (!is_array($d)) return '';
        foreach (['message', 'Message', 'error', 'Error', 'detail', 'msg'] as $k) {
            if (!isset($d[$k])) continue;
            $v = $d[$k];
            if (is_array($v)) {
                $flat = [];
                array_walk_recursive($v, static function ($x) use (&$flat) { if (is_scalar($x)) $flat[] = (string) $x; });
                $v = implode(' ', $flat);
            }
            $v = trim((string) $v);
            if ($v !== '') return $v;
        }
        return '';
    };

    // ❌/⏳ NOT JSON (HTML error page, empty body, gateway timeout ...)
    if (!is_array($decoded)) {
        $snippet = substr(trim(strip_tags((string) $response)), 0, 300);
        if ($http_code >= 400 && $http_code < 500) {
            return [
                'success' => false,
                'status'  => 'failed',
                'message' => "Provider rejected the request (HTTP {$http_code})",
                'details' => $base_details + ['raw_response' => $snippet]
            ];
        }
        return [
            'success' => true,
            'status'  => 'pending',
            'message' => 'Your purchase is being confirmed with the provider. Please do not retry; you will be updated shortly.',
            'reference' => $request_id,
            'details' => $base_details + ['raw_response' => $snippet, 'note' => 'Unreadable provider answer; held as pending, not refunded automatically.']
        ];
    }

    // 🔥 NORMALIZE STATUS (providers send Status or status)
    $raw_status = $decoded['Status'] ?? $decoded['status'] ?? '';
    $raw_status = is_scalar($raw_status) ? strtolower(trim((string) $raw_status)) : '';

    $success_states = ['success', 'successful', 'completed', 'complete', 'delivered', 'done'];
    $pending_states = ['pending', 'processing', 'process', 'queued', 'in progress', 'inprogress', 'submitted'];
    $failed_states  = ['fail', 'failed', 'failure', 'error', 'rejected', 'declined', 'cancelled', 'canceled', 'unsuccessful', 'refunded'];

    if (in_array($raw_status, $success_states, true)) {
        $status = 'success';
        $success = true;
    } elseif (in_array($raw_status, $pending_states, true)) {
        $status = 'pending';
        $success = true; // still true so the wallet is charged once and kept
    } elseif (in_array($raw_status, $failed_states, true)) {
        $status = 'failed';
        $success = false;
    } elseif ($http_code >= 400 && $http_code < 500) {
        // No status in the body and a client error: the provider refused it.
        $status = 'failed';
        $success = false;
    } else {
        // Unknown answer: never assume failure. Hold as pending for an admin to check.
        $status = 'pending';
        $success = true;
    }

    // Message handling
    $message = $pick_message($decoded) ?: ucfirst($status);
    if ($status === 'pending' && $raw_status === '' ) {
        $message = 'Your purchase is being confirmed with the provider. Please do not retry; you will be updated shortly.';
    }

    return [
        'success' => $success,
        'status'  => $status,
        'message' => $message,
        'reference' => $decoded['reference'] ?? $request_id,
        'details' => $base_details + ['api_response' => $decoded]
    ];
}
