<?php
/**
 * Pulsepoint API — User / Wallet
 * Path: /api/user.php
 *
 * Compatibility endpoint for mobile clients using:
 *   POST /api/user
 *   {"token":"..."}
 *
 * Also accepts GET ?token=... and Authorization: Token <token>.
 * The response intentionally keeps `user.wallet` as a simple numeric NGN
 * value because the Android client reads that exact field.
 */

if (!defined('ABSPATH')) {
    $wp_load = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
    if (is_file($wp_load)) {
        require_once $wp_load;
    }
}

global $wpdb;

header('Content-Type: application/json; charset=utf-8');

/** Return JSON and stop this endpoint. */
if (!function_exists('pulsepoint_user_api_response')) {
    function pulsepoint_user_api_response(array $payload) {
        echo function_exists('wp_json_encode')
            ? wp_json_encode($payload)
            : json_encode($payload);
        exit;
    }
}

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''));
if (!in_array($method, ['GET', 'POST'], true)) {
    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}

// Read JSON first, then fall back to normal form POST.
$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);
if (!is_array($input)) {
    $input = $_POST;
}
if (!is_array($input)) {
    $input = [];
}

// Support all token formats used by the app/API ecosystem.
$token = isset($input['token']) ? trim((string) $input['token']) : '';
if ($token === '' && isset($_GET['token'])) {
    $token = trim((string) $_GET['token']);
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
$authorization = '';
if (is_array($headers)) {
    $authorization = $headers['Authorization'] ?? ($headers['authorization'] ?? '');
}
if ($authorization === '') {
    $authorization = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
}

if ($token === '' && preg_match('/^Token\s+(.+)$/i', trim((string) $authorization), $matches)) {
    $token = trim($matches[1]);
}

$token = sanitize_text_field($token);

if ($token === '') {
    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Token is required'
    ]);
}

if (!isset($wpdb) || !is_object($wpdb)) {
    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Database connection unavailable'
    ]);
}

$table = $wpdb->prefix . 'pulsepoint_users';

// Select the complete user row rather than requiring optional columns such as
// promo_bonus_pending to exist. This keeps older installations compatible.
$user = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM `{$table}` WHERE `token` = %s LIMIT 1",
        $token
    )
);

if (!$user) {
    // Do not expose the database error to the mobile client.
    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Invalid or expired token'
    ]);
}

$status = isset($user->status) ? (int) $user->status : 0;
if ($status !== 1) {
    pulsepoint_user_api_response([
        'success' => false,
        'message' => 'Account inactive',
        'status' => $status
    ]);
}

// These fields are the contract used by the Android app.
$lastname    = isset($user->lastname) ? (string) $user->lastname : '';
$firstname   = isset($user->firstname) ? (string) $user->firstname : '';
$email       = isset($user->email) ? (string) $user->email : '';
$phone       = isset($user->phone) ? (string) $user->phone : '';
$wallet      = isset($user->wallet) ? (float) $user->wallet : 0.0;
$promo       = isset($user->promo_bonus_pending) ? (float) $user->promo_bonus_pending : 0.0;
$dollar      = isset($user->dollar) ? (float) $user->dollar : 0.0;
$referral    = isset($user->referral_balance) ? (float) $user->referral_balance : 0.0;
$accountType = isset($user->account_type) ? (string) $user->account_type : '';
$userToken   = isset($user->token) ? (string) $user->token : $token;
$userId      = isset($user->id) ? (int) $user->id : 0;

// `wallet` is the value the supplied Android code displays. Keep it numeric.
// Include pending promo balance when that column exists, preserving the
// behaviour of the previous endpoint.
$totalWallet = round($wallet + $promo, 2);

pulsepoint_user_api_response([
    'success' => true,
    'message' => 'User fetched successfully',
    'user' => [
        'id' => $userId,
        'firstname' => $firstname,
        'lastname' => $lastname,
        'email' => $email,
        'phone' => $phone,
        'wallet' => $totalWallet,
        'wallet_balance' => round($wallet, 2),
        'promo_bonus_pending' => round($promo, 2),
        'wallet_formatted' => '₦' . number_format($totalWallet, 2, '.', ','),
        'dollar' => '$' . number_format($dollar, 2, '.', ','),
        'referral_balance' => '₦' . number_format($referral, 2, '.', ','),
        'token' => $userToken,
        'account_type' => $accountType,
        'status' => $status,
    ]
]);
